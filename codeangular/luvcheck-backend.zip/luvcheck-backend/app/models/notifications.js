
var mongoose = require('mongoose'),
	Schema   = mongoose.Schema;

var notificationSchema = new Schema({
    message   : {type: String},
    notificationsType   : {type: String, enum: ['general', 'friend', 'alert', 'reminder']},
    notificationsStatus : {type: String, enum: ['read', 'unread'], default: 'unread'},
    from                : {type: String},
    to                  : {type: String},
    isDeleted           : {type: Boolean,  'default': false},
    createdDate         : {type: Date, default: Date.now},
    updatedDate         : {type: Date, default: Date.now}
});

var notifications = mongoose.model('notifications', notificationSchema);
module.exports = notifications;