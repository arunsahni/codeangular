
var mongoose = require('mongoose'),
    Schema = mongoose.Schema;


var callSchema = new Schema({
    fromUser            : {type : String, required: true},
    toUser              : {type:Array,required: true},
    duration            : {type : String},
    startsAt            :  {type : Number},
    endsAt              :  {type : Number},
    status             :  {type : String},
    createdDate         : {type : Date, default: Date.now},
    updatedDate         : {type : Date, default: Date.now}
});


var calls = mongoose.model('calls', callSchema);

module.exports = calls;