
var express = require('express');
var invitation = require('../app/controllers/invitationsCtrl.js');
var router = express.Router();


app.get('/connect', function(req, res){
    res.writeHead(200, {
        'Connection': 'keep-alive',
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache'
    });

    setInterval(function(){
        console.log('writing ' + testdata);
        res.write('data: {"msg": '+ testdata +'}\n\n');
    }, 1000);
});