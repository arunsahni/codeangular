var express = require('express');
var invitation = require('../app/controllers/invitationsCtrl.js');
var router = express.Router();

var authentication = require('../config/authentication.js');

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

/* To send invite. */
router.post('/sendInvitation',invitation.sendInvitation);

/* To save status of inviatation . */
router.post('/invitationStatus',invitation.invitationStatus);

/* To get detail of user who inviated anyone. */
router.get('/viewUser',invitation.invitedByUserDetail);

/* To get list of sent invitations. */
router.get('/sentInvitation', invitation.sentInvitation);

/* To get list of recieved invitations. */
router.get('/receivedInvitation', invitation.receivedInvitation);

/* To revoke invitation . */
router.post('/revokeInvitation',invitation.revokeInvitation);

/* To decline invitation . */
router.post('/declineInvitation', invitation.declineInvitation);

/* To resend invitation. */
router.post('/resendInvitation',invitation.resendInvitation);

module.exports = router;

