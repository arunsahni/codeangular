var express = require('express');
var admin = require('../app/controllers/adminCtrl.js');
var router = express.Router();
// var passport = require('passport');
// require('../config/passport')(passport);

/* GET listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});


/* To get list of admins. */
router.get('/viewAdmins',admin.viewAdmins);

/* To create admin. */
router.post('/createAdmin', admin.createAdmin);

/* To delete admin . */
router.post('/deleteAdmin', admin.deleteAdmin);

module.exports = router;

