	var express = require('express');
	var user = require('../app/controllers/userCtrl.js');
	var router = express.Router();

	/* GET users listing. */
	router.get('/', function(req, res, next) {
	  res.send('Users Api resource');
	});

	/* To Delete User. */
	router.post('/delete', user.deleteUser);

	/* To updateProfile of User. */
	router.post('/updateProfile', user.updateProfile);

	/* To change password. */
	router.post('/changePassword', user.changePassword);

	/* To search user. */
	router.get('/search', user.searchUser);

	/* To List User. */
	router.get('/getFriends', user.friendList);

	/* To Get User. */
	router.get('/userProfile', user.userProfile);

	/* To Update User Profile. */
	router.post('/updateAvatar', user.updateAvatar);


	/* To delete friend */
	router.post('/deleteFriend', user.deleteFriend);

	/* To get user info. */
	router.get('/getUserInfo', user.getUserInfo);

	module.exports = router;

