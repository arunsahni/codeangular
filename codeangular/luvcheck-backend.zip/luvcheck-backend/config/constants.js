
const twilioCredentials = {
    "TwilioNumber" : "+19149337525",
    "Authy" : "BT3ybwzIHaDiNghYsUCbnajVUk93AxUf",
    "ACCOUNTSID"   : "ACb76e2a9503584eee8836854bc8bb40eb",
    "AUTHTOKEN"    : "1e41430304caa28891a9577f0954eaff"

};

const gmailSMTPCredentials = {
    "type": "SMTP",
    "service": "Gmail",
    "host": "smtp.gmail.com",
    "port": 587,
    "secure": false,
    "username": "noreplyluvcheck@gmail.com",
    "password": "luvcheck123"
};

const smsCredentials = {
    number:'4755292423'
};

const rpiCredentials = {
    baseUrl:'http://proxy7.remote-iot.com:11804'
};

const imagePaths = {
    "user": "/../../public/images/user/avatar",
    "url": "/images/user/avatar"
};

var obj = { gmailSMTPCredentials:gmailSMTPCredentials, twilioCredentials: twilioCredentials,smsCredentials:smsCredentials,imagePaths: imagePaths,rpiCredentials:rpiCredentials };

module.exports = obj;