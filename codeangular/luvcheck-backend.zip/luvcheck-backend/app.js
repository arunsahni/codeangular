  require('dotenv').load();
  var express = require('express');
  var path = require('path');
  var favicon = require('serve-favicon');
  var logger = require('morgan');
  var cookieParser = require('cookie-parser');
  var bodyParser = require('body-parser');
  var cors = require('cors');
  var jwt = require('jsonwebtoken');
  var cfg = require('./config/passport_config.js');
  var mongodb = require("mongodb");
  var mongoose = require('mongoose');
 // mongoose.Promise = require('bluebird');
  var app = express();
  var router = express.Router();
  var debug = require('debug')('luvcheck-backend:server');
  var http = require('http');
  var AccessToken = require('twilio').AccessToken;
  var  VideoGrant = AccessToken.VideoGrant;
  var socketActions = require('./routes/socketActions');

  //Routes

  var index = require('./routes/index');
  var users = require('./routes/users');
  var api = require('./routes/publicApi');
  var invitations = require('./routes/invitations');
  var admins = require('./routes/admins');

  var db;

  var device = require('express-device');
  app.use(device.capture());

  app.get('/hello',function(req,res) {
    res.send("Hi to "+req.device.type.toUpperCase()+" User");
  });

  // Get port from environment and store in Express.

  var port = normalizePort(process.env.PORT || '3000');
  app.set('port', port);

   // Create HTTP server.
  var server = http.createServer(app);

  server.listen(port);
  server.on('error', onError);
  server.on('listening', onListening);

  var io = require('socket.io')(server);


  app.use(function(req, res, next) {
    req.io = io;
    next();
  });
  
  //Notification Push

  // app.get('/notify', function(req, res){
  //   res.writeHead(200, {
  //     'Connection': 'keep-alive',
  //     'Content-Type': 'text/event-stream',
  //     'Cache-Control': 'no-cache'
  //   });
  //
  //   setInterval(function(){
  //     console.log('writing ' + res.data);
  //     res.write({msg:res.data});
  //   }, 3*1000);
  // });


  //console.log(process.env.MONGODB_URI);

  mongoose.connect(process.env.MONGODB_URI,function (err, database) {
    if (err) {
      console.log(err);
      process.exit(1);
    }
    // Save database object from the callback for reuse.=
    db = database;
    console.log("Database connection ready");
  });

  //Listen on provided port, on all network interfaces.

  router.use(function(req, res, next) {
    var token =  req.headers['authorization'];
    if (token) {
      try {
        token = token.split(' ')[1];
        var decoded = jwt.verify(token,cfg.secret,function (err,decoded){
          if(err){
            res.status(401).send({
              msg: 'Authorization token is not valid'
            });
          }else {
            // console.log(decoded,"decoded token")
            req.user = decoded;
            next();
          }
        });
      } catch (e) {
        return res.status(401).send({
          msg: 'Authorization token is not valid'
        });
      }
    } else {
      console.log("No token");
      return res.status(401).send({
        msg: 'Authorization token missing in request.'
      });
    }
  });

  // view engine setup
  app.set('views', path.join(__dirname, 'views'));
  app.set('view engine', 'pug');

  // uncomment after placing your favicon in /public

  app.use(logger('dev'));
  app.use(bodyParser({limit: '50mb'}));
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({extended: true}));
  app.use(cookieParser());
  app.use(express.static(path.join(__dirname, 'public')));

  app.use(cors());

  app.use('/users', router);
  app.use('/invitations', router);

  app.use('/', index);
  app.use('/api', api);
  app.use('/users', users);
  app.use('/invitations', invitations);
  app.use('/admins', admins);


  function decodeToken(token, cb) {
    if (token) {
      try {
        token = token.split(' ')[1];
        var decoded = jwt.verify(token, cfg.secret,function (err,decoded) {
          if(err){
           console.log(err,"decoding error")
          }else {

            cb(decoded);
          }
        });
      } catch (e) {
        console.log(e,'error')
      }
    } else {
      console.log("No token");
    }
  }


  function twillioVideo (user) {
    var identity = user;

    // Create an access token which we will sign and return to the client,
    // containing the grant we just created
    var token = new AccessToken(
        process.env.TWILIO_ACCOUNT_SID,
        process.env.TWILIO_API_KEY,
        process.env.TWILIO_API_SECRET
    );

    // Assign the generated identity to the token
    try {
      token.identity = identity.profile && identity.profile.name+'__'+ (identity.uid);

      //grant the access token Twilio Video capabilities
      var grant = new VideoGrant();
      grant.configurationProfileSid = process.env.TWILIO_CONFIGURATION_SID;
      token.addGrant(grant);

      return {
        token: token.toJwt(),
        identity:identity
      }
    }catch(e) {
      console.log("errt",e)
    }

  }

  io.use(function(socket, next){
    if (socket.handshake.query && socket.handshake.query.token){
      next();
    }
  });

  var callerSockets = {};

  io.on('connection', function (socket) {
    console.log("socket is connected");
    var token = socket.handshake.query.token;
      decodeToken(token,function (decoded){
        socket.join(decoded.uid);

        io.in(decoded.uid).emit('twillio-log', twillioVideo(decoded));

        // console.log(decoded,"user decoded");

        socket.on('placeCall', function (data, cb) {
          console.log(data,"placeCall")
          socketActions.notifyMakeCall(io, decoded, data.toUser, data.callType, data.activeCall, cb, socket,callerSockets);
        });

        socket.on('answerCall', function (data, cb) {
          socketActions.notifyAnswerCall(io, decoded, data.callId, data.response, data.activeCall, socket, callerSockets);
        });

        socket.on('endCall', function (data, cb) {
          socketActions.notifyEndCall(io,data);
        });
        

        socket.on('deleteConnection', function (data, cb) {
          socketActions.notifyDeletedContact(io,data.toUser,data.fromUser);
        });

        socket.on('calendarEvent', function (data, fn) {
          console.log(data,"Admin")
        });

        socket.on('changeAccessLevel', function (data, fn) {

        });

        socket.on('notifyActiveStatus', function (data, fn) {
          socketActions.notifyToFriends(io,decoded,data);
        });
      });
    // console.log(socket.handshake.query.token,"socket")
  });




  //Error Handlers
  app.use(function(req, res, next) {
    req.socket.on("error", function(e) {
      console.log('socket req error',e)
    });
    res.socket.on("error", function(e) {
      console.log('socket res error',e)
    });
    next();
  });


  // catch 404 and forward to error handler
  // app.use(function(req, res, next) {
  //   var err = new Error('Not Found');
  //   err.status = 404;
  //   next(err);
  // });

  // error handler
  app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
  });


  // Normalize a port into a number, string, or false.

  function normalizePort(val) {
    var port = parseInt(val, 10);

    if (isNaN(port)) {
      // named pipe
      return val;
    }

    if (port >= 0) {
      // port number
      return port;
    }

    return false;
  }

  // Event listener for HTTP server "error" event.

  function onError(error) {
    console.log('Server',error);
    if (error.syscall !== 'listen') {
      throw error;
    }

    var bind = typeof port === 'string'
        ? 'Pipe ' + port
        : 'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
      case 'EACCES':
        console.error(bind + ' requires elevated privileges');
        process.exit(1);
        break;
      case 'EADDRINUSE':
        console.error(bind + ' is already in use');
        process.exit(1);
        break;
      default:
        throw error;
    }
  }

  // Event listener for HTTP server "listening" event.

  function onListening() {
    var addr = server.address();
    var bind = typeof addr === 'string'
        ? 'pipe ' + addr
        : 'port ' + addr.port;
    debug('Listening on ' + bind);
  }


  module.exports = app;