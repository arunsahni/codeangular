/**
 * Created by dianasellar on 10/10/16.
 */
'use strict';

angular
    .module('bazarApp')
    .directive('card', function (adsService, $window) {
        return {
            restrict: 'EA',
            scope: {
                ad: "=", //data from BE
                index: "=",
                displayMode: "="
            },
            link: function (scope, element, attrs) {

                truncateDescription();

                angular.element($window).bind('resize', function(){

                    truncateDescription();

                    scope.$digest();
                });

                function truncateDescription(){
                    if($window.innerWidth > 1200){
                        scope.sizeControl = 490;
                    }

                    else if($window.innerWidth <= 1200 && 768 < $window.innerWidth){
                        scope.sizeControl = 350;
                    }

                    else if(600 < $window.innerWidth && $window.innerWidth <= 768){
                        scope.sizeControl = 450;
                    }

                    else if(540 < $window.innerWidth && $window.innerWidth <= 600){
                        scope.sizeControl = 400;
                    }

                    else if(470 < $window.innerWidth && $window.innerWidth <= 540){
                        scope.sizeControl = 340;
                    }

                    else if(430 < $window.innerWidth && $window.innerWidth <= 470){
                        scope.sizeControl = 300;
                    }

                    else if(0 < $window.innerWidth && $window.innerWidth <= 430){
                        scope.sizeControl = 260;
                    }
                }
                
            },
            templateUrl: 'app/directives/card/card_template.html'
        }
    });