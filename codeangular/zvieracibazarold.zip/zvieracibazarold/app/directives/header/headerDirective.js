/**
 * Created by dianasellar on 25/10/16.
 */

'use strict';

angular
    .module('bazarApp')
    .directive('pageHeader', function (adsService, $window) {
        return {
            restrict: 'EA',
            scope: true,
            controller: 'headerController',
            link: function (scope, element, attrs) {
                scope.type = attrs.type;
            },
            templateUrl: 'app/directives/header/header_template.html'
        }
    });