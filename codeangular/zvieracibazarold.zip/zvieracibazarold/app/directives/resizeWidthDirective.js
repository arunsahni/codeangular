/**
 * Created by dianasellar on 07/10/16.
 */
'use strict';
angular.module('bazarApp')
    .directive('resizeDivWidth', function() {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                element.on( "focusin", function() {
                    element.css("width", attrs.resizeDivWidth)
                });
            }
        };
    });