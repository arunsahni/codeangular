/**
 * Created by dianasellar on 05/10/16.
 */
angular.module('bazarApp')
    .config(
        function ($stateProvider, $urlRouterProvider, $locationProvider) {
            $urlRouterProvider.otherwise('/login');
            $locationProvider.html5Mode(true);
            $stateProvider

                .state('main', {
                    url: '/',
                    abstract: true,
                    views: {
                        '': {
                            templateUrl: "app/views/main/main_wrapper.html"
                        },
                        'menu@main': {
                            templateUrl: "app/views/main/main_menu.html",
                            controller: "menuController"
                        }

                    }
                })

                .state('main.ads', {
                    url: '',
                    templateUrl: "app/views/main/main_content.html",
                    controller: "adsController"
                })

                .state('main.offer', {
                    url: 'offer',
                    templateUrl: "app/views/offer/offer_detail.html",
                    controller: "offerDetailController"
                })
                
                .state('login', {
                    url: '/login',
                    views: {
                        '': {
                            templateUrl: "app/views/login/login_wrapper.html"
                        },
                        'content@login': {
                            templateUrl: "app/views/login/login_content.html"
                        }

                    }
                })

                .state('registration', {
                    url: '/registration',
                    views: {
                        '': {
                            templateUrl: "app/views/registration/registration_wrapper.html"
                        },
                        'content@registration': {
                            templateUrl: "app/views/registration/registration_content.html"
                        }

                    }
                })
        });
