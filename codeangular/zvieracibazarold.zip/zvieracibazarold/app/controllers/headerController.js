/**
 * Created by dianasellar on 06/10/16.
 */
'use strict';
angular.module('bazarApp')
    .controller('headerController',
        function ($scope, $timeout) {
             $('.carousel').carousel();
        })
;