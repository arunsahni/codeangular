/***
 ** Created by dianasellar on 10/10/16.
 **/
'use strict';
angular.module('bazarApp')
    .controller('adsController',
        function ($scope, adsService, $window) {
            
            //simulation of request
            $scope.fakeData = adsService.getAllAds();

            // //change how ads are showed
            // $scope.displayMode = "grid";
            $scope.displayMode = "detailed";

            $scope.setDetailed = function () {
                $scope.displayMode = "detailed";
            };


            $scope.setGrid = function () {
                $scope.displayMode = "grid";
            };
            
        })
;
