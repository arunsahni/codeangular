/**
 * Created by dianasellar on 07/10/16.
 */
'use strict';
angular.module('bazarApp')
    .controller('menuController',
        function ($timeout) {

            //initialization of menu
            $timeout(function () {
                var menuEl = document.getElementById('ml-menu'),
                        mlmenu = new MLMenu(menuEl, {
                            breadcrumbsCtrl : false, // show breadcrumbs
                            initialBreadcrumb : 'all', // initial breadcrumb text
                            backCtrl : false, // show back button
                            itemsDelayInterval : 60 // delay between each menu item sliding animation
                        });

                    // mobile menu toggle
                    var openMenuCtrl = document.querySelector('.action--open'),
                        closeMenuCtrl = document.querySelector('.action--close');

                    openMenuCtrl.addEventListener('click', openMenu);
                    closeMenuCtrl.addEventListener('click', closeMenu);

                    function openMenu() {
                        angular.element(menuEl).addClass('menu--open');
                    }

                    function closeMenu() {
                        angular.element(menuEl).removeClass('menu--open');

                    }
            });

        })
;