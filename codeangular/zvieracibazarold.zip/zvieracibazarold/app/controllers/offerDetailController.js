/**
 * Created by dianasellar on 11/10/16.
 */
'use strict';
angular.module('bazarApp')
    .controller('offerDetailController',
        function ($scope, $timeout) {
            $scope.offer = {
                mainPic: '/app/assets/images/offer-pic.png',
                pics: ['/app/assets/images/pic.png', '/app/assets/images/pic2.png', '/app/assets/images/pic3.png'],
                name: 'Very nice cat indeed',
                category1: 'category',
                category2: 'cat',
                category3: 'category',
                description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                timestamp: '3 days ago',
                gender: 'male',
                price: '30€',
                town: 'Kosice',
                views: '24',
                contactname: 'Jožko Mrkvička',
                contactphone: '0900 666 666',
                contactmail: 'jozko@gmail.com',
            }

            $scope.offer.contactmessage = "Dobrý deň, mám záujem o..."
        })
;
