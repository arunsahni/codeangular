/**
 * Created by dianasellar on 17/10/16.
 */
'use strict';

angular.module('bazarApp')
    .factory('adsService', function () {

        var adsService = {};

        adsService.getAllAds = function(){
            return [
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: true,
                    top: true

                },
                {
                    pic: '/app/assets/images/pic2.png',
                    name: 'Very nice dog indeed and very long title as well',
                    category1: 'category',
                    category2: 'dog',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'female',
                    price: '50€',
                    town: 'Spišská Nová Ves',
                    views: '42',
                    liked: true,
                    top: true

                },
                {
                    pic: '/app/assets/images/pic3.png',
                    name: 'Very nice bird indeed',
                    category1: 'category',
                    category2: 'bird',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '330€',
                    town: 'Nitra',
                    views: '24',
                    liked: false,
                    top: false

                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: false,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: false,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic2.png',
                    name: 'Very nice dog indeed and very long title as well',
                    category1: 'category',
                    category2: 'dog',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'female',
                    price: '50€',
                    town: 'Spišská Nová Ves',
                    views: '42',
                    liked: false,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic3.png',
                    name: 'Very nice bird indeed',
                    category1: 'category',
                    category2: 'bird',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '330€',
                    town: 'Nitra',
                    views: '24',
                    liked: true,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: false,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: false,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic2.png',
                    name: 'Very nice dog indeed and very long title as well',
                    category1: 'category',
                    category2: 'dog',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'female',
                    price: '50€',
                    town: 'Spišská Nová Ves',
                    views: '42',
                    liked: false,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic3.png',
                    name: 'Very nice bird indeed',
                    category1: 'category',
                    category2: 'bird',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '330€',
                    town: 'Nitra',
                    views: '24',
                    liked: true,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: true,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: true,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic2.png',
                    name: 'Very nice dog indeed and very long title as well',
                    category1: 'category',
                    category2: 'dog',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'female',
                    price: '50€',
                    town: 'Spišská Nová Ves',
                    views: '42',
                    liked: true,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic3.png',
                    name: 'Very nice bird indeed',
                    category1: 'category',
                    category2: 'bird',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '330€',
                    town: 'Nitra',
                    views: '24',
                    liked: true,
                    top: false
                },
                {
                    pic: '/app/assets/images/pic.png',
                    name: 'Very nice cat indeed',
                    category1: 'category',
                    category2: 'cat',
                    category3: 'category',
                    description: 'Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased to twinkle. By the same illusion which lifts the horizon of the sea to the level of the spectator on a hillside, the sable cloud beneath was dished out, and the car seemed to float in the middle of an immense dark sphere, whose upper half was strewn with silver. Looking down into the dark gulf below, I could see a ruddy light streaming through a rift in the clouds.',
                    timestamp: '3 days ago',
                    gender: 'male',
                    price: '30€',
                    town: 'Kosice',
                    views: '24',
                    liked: false,
                    top: false
                }
            ]
        };

        return adsService;
        }
    );