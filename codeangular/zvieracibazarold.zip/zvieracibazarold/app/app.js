/**
 * Created by dianasellar on 05/10/16.
 */
'use strict';

var bazarApp = angular.module('bazarApp', ['ui.router', 'ngAria', 'ngAnimate', 'ngMaterial'])

    ;


