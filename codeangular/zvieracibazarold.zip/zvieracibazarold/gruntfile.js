module.exports = function (grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        sass: {
            main: {
                files: [{
                    expand: true,
                    cwd: 'app/assets/sass',
                    src: ['*.{scss,sass}'],
                    dest: 'app/assets/css',
                    ext: '.css'
                }]
            }
        },
        watch: {
            css: {
                files: 'app/assets/sass/*.scss',
                tasks: ['sass']
            }
        }

    });

    //register all installed packages
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-reload');

    
    //watch for changes in scss
    grunt.registerTask('changes', ['watch']);

    //create main.css
    grunt.registerTask('makecss', ['sass:main']);

};
