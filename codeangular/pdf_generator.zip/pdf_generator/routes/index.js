const express = require('express'),
      router = express.Router(),
      api = require('../app/controllers/publicApi');
/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index', {title: 'express'});
});

router.post('/pdf-input', api.pdfgenerate);

module.exports = router;
