# README #

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

#####

* go to root folder: npm install
*On MacOS or Linux, run the app with this command:DEBUG=:pdf-generator* npm start
* On Windows, use this command to run
:set DEBUG=pdf-generator:* & npm start
or npm start
