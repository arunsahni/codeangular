const fs = require('fs');
const PDFDocument = require('pdfkit');
const path = require('path');
/*________________________________________________________________________
 * @Date:       2 Feb,2018
 * @Method :    pdfgenerate
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to generate pdf.
 _________________________________________________________________________
 */

const pdfgenerate = function (req, res) {
    const fields = req.body;
    console.log(fields, 'fields')
    if(!fields ||!fields.firstName || !fields.lastName || !fields.address || !fields.postCode || !fields.city || !fields.country || !fields.gender){
        res.json({status: 204,msg: 'Some fields are missing.'})
    } else {
        const doc = new PDFDocument(),
        filename = Math.floor(Date.now() / 1000).toString() + '.pdf',
        writeStream = fs.createWriteStream(path.resolve(".")+'/uploads/'+filename);
        doc.pipe(writeStream);

        doc.y = 300;
        doc.font('Helvetica-Bold').text('PDF FORM', 50, 20);
        doc.font('Times-Roman').text('Name:', 20, 50);
        doc.font('Times-Roman').text(fields.firstName, 100, 50);
        doc.font('Times-Roman').text(fields.lastName, 140, 50);
        doc.font('Times-Roman').text('Address:', 20, 90);
        doc.font('Times-Roman').text(fields.address, 100, 90);
        doc.font('Times-Roman').text('Post code:', 20, 130);
        doc.font('Times-Roman').text(fields.postCode, 100, 130);
        doc.font('Times-Roman').text('City:', 175, 130);
        doc.font('Times-Roman').text(fields.city, 200, 130);
        doc.font('Times-Roman').text('Country:', 20, 170);
        doc.font('Times-Roman').text(fields.country, 100, 170);
        doc.font('Times-Roman').text('Gender:', 20, 210);
        doc.font('Times-Roman').text(fields.gender, 100, 210);
        doc.end();
        const url = path.resolve(".")+'/uploads/'+filename;
        writeStream.on('finish', function () {
            res.jsonp({status: 200, msg: 'file generated successfully',url: url});
        });
    }
};

//  functions
exports.pdfgenerate = pdfgenerate;
