import { ZvieraciBazarPage } from './app.po';

describe('zvieraci-bazar App', function() {
  let page: ZvieraciBazarPage;

  beforeEach(() => {
    page = new ZvieraciBazarPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
