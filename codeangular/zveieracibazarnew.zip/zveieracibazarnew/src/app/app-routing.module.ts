import {Routes, RouterModule} from '@angular/router';
import {NgModule} from '@angular/core';
import {RegisterComponent} from './components/register/register.component';
import {LoginComponent} from './components/login/login.component';
import {OffersComponent} from './components/offers/viewOffers/offers.component';
import {OfferComponent} from './components/offers/viewOffer/offer.component';
import {AddOfferComponent} from './components/offers/addOffer/addOffer.component';
import {ChecktokenService} from './services/auth.route';
import {ViewMyOffersComponent} from './components/viewMyOffers/viewMyOffers.component';
import {FavouriteOffersComponent} from './components/offers/favouriteOffers/favOffers.component';
import {EnableComponent} from './shared/userEnable/userEnable.component';
import {UserStatisticsComponent} from './components/userStatistics/userStatistics.component';
import {ApproveVetsComponent} from './components/approveVets/approveVets.component';
import {EditCategoriesComponent} from './components/editCategories/editCategories.component';
import {UserSettingsComponent} from './components/userSettings/userSettings.component';
import {EnableOfferComponent} from './shared/enableOffer/enableOffer.component';
import {ForgotPasswordComponent} from './components/forgot-password/forgot-password.component';
import {ResetPasswordComponent} from './components/reset-password/reset-password.component';

const appRoutes: Routes = [

  {path: '', component: OffersComponent},
  {path: 'home', redirectTo: ''},
  {path: 'registration', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  {path: 'offer/enable', component: EnableOfferComponent},
  {path: 'offer/:uuid', component: OfferComponent},
  {path: 'user/enable', component: EnableComponent},
  {path: 'profile', redirectTo: 'profile/view-my-offers', canActivate: [ChecktokenService]},
  {path: 'profile/view-my-offers', component: ViewMyOffersComponent, canActivate: [ChecktokenService]},
  {path: 'profile/favourite-offers', component: FavouriteOffersComponent, canActivate: [ChecktokenService]},
  {path: 'profile/add-offer/:uuid', component: AddOfferComponent},
  {path: 'profile/add-offer', component: AddOfferComponent},
  {path: 'profile/statistics', component: UserStatisticsComponent, canActivate: [ChecktokenService]},
  {path: 'profile/approve-vets', component: ApproveVetsComponent, canActivate: [ChecktokenService]},
  {path: 'profile/declined-vets', component: ApproveVetsComponent, canActivate: [ChecktokenService]},
  {path: 'profile/settings', component: UserSettingsComponent, canActivate: [ChecktokenService]},
  {path: 'profile/edit-categories', component: EditCategoriesComponent, canActivate: [ChecktokenService]},
  {path: 'forgot-password', component: ForgotPasswordComponent},
  {path: 'reset-password/:hash', component: ResetPasswordComponent},
  {path: ':categoryUuid', component: OffersComponent}
];

@NgModule({
    imports: [
        RouterModule.forRoot(
            appRoutes
        )
    ],
    exports: [
        RouterModule
    ],
})
export class AppRoutingModule {
}
