import {Injectable} from '@angular/core';
import {environment} from '../environments/environment';

@Injectable()
export class Endpoints {
  public static serverBase = environment.serverBase;
  public static imageBase = environment.imageBase;

  public static location = Endpoints.serverBase + '/location';

  public static menuLevel = Endpoints.serverBase + '/menuLevel/';
  public static uploadFile = Endpoints.serverBase + '/image/?flag=3'; // S4, S6


  public static registration = Endpoints.serverBase + '/user/createUser';
  public static userEnable = (keyValue: string) => Endpoints.serverBase + '/user/enable/?key=' + keyValue;
  public static offerEnable = (keyValue: string) => Endpoints.serverBase + '/offer/enable/?key=' + keyValue;
  public static login = Endpoints.serverBase + '/user/login';

  public static addOffer = Endpoints.serverBase + '/offer';
  public static updateOffer = (uuid) =>
    Endpoints.serverBase + '/offer/' + uuid;
  public static getOffer = (uuid) =>
    Endpoints.serverBase + '/offer/' + uuid;
  public static getUsersOffer = (userUuid, page, size, menuLevelUuid) =>
    Endpoints.serverBase + '/user/' + userUuid + '/getOffers?pgNum=' + page + '&pgSize=' + size + '&menuLevelUuid=' + menuLevelUuid;
  public static deleteOffer = (uuid) =>
    Endpoints.serverBase + '/offer/' + uuid;
  public static offersList = (page: number, size: number, menuLevelUuid) =>
    Endpoints.serverBase + '/offer?pgNum=' + page + '&pgSize=' + size + '&menuLevelUuid=' + menuLevelUuid;
  public static offerFilter = (page: number, size: number) =>
    Endpoints.serverBase + '/offer/filter?pgNum=' + page + '&pgSize=' + size;

  public static favouriteList = (page: number, size: number) =>
    Endpoints.serverBase + '/offer/favorite?pgNum=' + page + '&pgSize=' + size;
  public static addAsFavouriteOffer = (offerUuid) =>
    Endpoints.serverBase + '/offer/favorite/' + offerUuid;
  public static removefavouriteOffer = (offerUuid) =>
    Endpoints.serverBase + '/offer/favorite/' + offerUuid;
  // public static searchOffer = (searchText: string) =>
  // Endpoints.serverBase + '/search?searchExp=' + searchText;

  public static getVetToConfirm = (pgNum, pgSize) => Endpoints.serverBase + `/admin/getVetToConfirm?pgNum=${pgNum}&pgSize=${pgSize}`;
  public static getDeclinedVets = (pgNum, pgSize) => Endpoints.serverBase + `/admin/getDeclinedVets?pgNum=${pgNum}&pgSize=${pgSize}`;
  public static approveVet = (userUuid) => Endpoints.serverBase + `/admin/approveVet/${userUuid}`;
  public static createUpdateMenuLevel = () => Endpoints.serverBase + `/menuLevel`;
  public static removeMenuLevel = (categoryUuid) => Endpoints.serverBase + `/menuLevel/${categoryUuid}`;
  public static getMySettings = () => Endpoints.serverBase + `/user`;
  public static checkOfferPassword = (offerUuid) => Endpoints.serverBase + `/offer/${offerUuid}/checkOfferPassword`;
  public static forgotPassword = (email: string) => Endpoints.serverBase + `/user/forgotPassword?email=${email}`;
  public static resetPassword = Endpoints.serverBase + `/user/resetPassword`;
  public static changePassword = Endpoints.serverBase + `/user/changePassword`;
  public static refreshToken = Endpoints.serverBase + `/user/refreshToken`;
}
