import {Page} from '../models/page';

export class Constants {
  public static DEFAULT_PAGE_SIZE = 10;

  public static getDefaultPageObject(): Page {
    const page = new Page();
    page.offset = 0;
    page.pageSize = Constants.DEFAULT_PAGE_SIZE;

    return page;
  }

  public static ERROR_500_MESSAGE = 'Neznáma chyba. Skúste akciu opakovať neskôr prosím';
}
