import {Headers, RequestOptions} from '@angular/http';

export function createRequestOptions(isAuthorized = false): RequestOptions {
  const headers = new Headers({
    'Content-Type': 'application/json',
    'Authorization': isAuthorized
  });

  return new RequestOptions({headers});
}

export function updateValidator(form, fieldName, validators: Array<any>) {
  form.get(fieldName).setValidators(validators);
  form.get(fieldName).updateValueAndValidity();
}
