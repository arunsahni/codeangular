import {NgModule} from '@angular/core';
import {AppComponent} from './app.component';
import {HeaderComponent} from './shared/header/header.component';
import {SideBarItemComponent} from 'app/shared/sidebar/side-bar-item/sidebar-item.component';
import {SideBarComponent} from './shared/sidebar/sidebar.component';
import {RegisterComponent} from './components/register/register.component';
import {LoginComponent} from './components/login/login.component';
import {OfferDetailedComponent} from './components/offers/detailedViewOffers/offerDetailed.component';
import {OfferGridComponent} from './components/offers/gridViewOffers/offerGrid.component';
import {OfferComponent} from 'app/components/offers/viewOffer/offer.component';
import {AddOfferComponent} from 'app/components/offers/addOffer/addOffer.component';
import {ViewMyOffersComponent} from 'app/components/viewMyOffers/viewMyOffers.component';
import {OffersComponent} from 'app/components/offers/viewOffers/offers.component';
import {FavouriteOffersComponent} from './components/offers/favouriteOffers/favOffers.component';
import {EnableComponent} from './shared/userEnable/userEnable.component';
import {TruncatePipe} from './pipes/truncate';
import {FilterPipe} from './pipes/data-filter';
import {FilterOfferComponent} from './shared/filter-offer/filter-offer.component';
import {OnlyNumberDirective} from './directives/only-number.directive';
import {MainCategoriesComponent} from './components/main-categories/main-categories.component';
import {BrowserModule} from '@angular/platform-browser';
import {InfiniteScrollModule} from 'ngx-infinite-scroll';
import {
    MD_PLACEHOLDER_GLOBAL_OPTIONS,
    MdButtonModule, MdInputModule, MdProgressSpinnerModule, MdSelectModule, MdSnackBarModule, MdDialogModule
} from '@angular/material';
import {Angular2SocialLoginModule} from 'angular2-social-login';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {HttpModule, RequestOptions, XHRBackend, Http} from '@angular/http';
import {AppRoutingModule} from './app-routing.module';
import {UserService} from './services/user.service';
import {OfferStoreService} from './services/offer-store.service';
import {OffersService} from './services/offers.service';
import {GlobalService} from './global';
import {Endpoints} from './endpoints';
import {ChecktokenService} from './services/auth.route';
import {LocationService} from './services/location.service';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FileUploadModule} from 'ng2-file-upload';
import {ThumbPipe} from './pipes/thumb.pipe';
import {ApproveVetsComponent} from './components/approveVets/approveVets.component';
import {UserStatisticsComponent} from './components/userStatistics/userStatistics.component';
import {EditCategoriesComponent} from './components/editCategories/editCategories.component';
import {AdminService} from './services/admin.service';
import {EditCategoryItemComponent} from './components/editCategoryItem/editCategoryItem.component';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {UserSettingsComponent} from './components/userSettings/userSettings.component';
import {LoaderComponent} from './shared/loader/loader.component';
import {AppTitleComponent} from './components/app-title/app-title.component';
import {ProfileMenuComponent} from './components/profile-menu/profile-menu.component';
import {EnableOfferComponent} from './shared/enableOffer/enableOffer.component';
import {ForgotPasswordComponent} from './components/forgot-password/forgot-password.component';
import {ResetPasswordComponent} from './components/reset-password/reset-password.component';
import {FormHeaderComponent} from './shared/form-header/form-header.component';
import {AuthInterceptor} from './services/auth-interceptor';
import {Router} from '@angular/router';
import {SpinnerComponent} from './shared/spinner/spinner.component';
import {MessageService} from './message.service';
import {DialogService} from './services/dialog.service';
import {BasicDialog} from './shared/basicDialog/BasicDialog';
import {CarouselComponent} from './carousel/carousel.component';
import {NgxGalleryModule} from 'ngx-gallery';

export function authInterceptorFactory(backend: XHRBackend, options: RequestOptions, router: Router) {
  return new AuthInterceptor(backend, options, router);
}

const socialProviders = {
  google: {
    clientId: '618476616535-4rrgoma5u4eib6kjdjkr21epibfsokgv.apps.googleusercontent.com'
  },
  facebook: {
    clientId: '125740828079697',
    apiVersion: 'v2.10'
  }
};

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SideBarComponent,
    SideBarItemComponent,
    RegisterComponent,
    LoginComponent,
    OffersComponent,
    OfferDetailedComponent,
    OfferGridComponent,
    OfferComponent,
    AddOfferComponent,
    ViewMyOffersComponent,
    FavouriteOffersComponent,
    EnableComponent,
    TruncatePipe,
    FilterPipe,
    FilterOfferComponent,
    OnlyNumberDirective,
    MainCategoriesComponent,
    ApproveVetsComponent,
    UserStatisticsComponent,
    EditCategoriesComponent,
    EditCategoryItemComponent,
    UserSettingsComponent,
    LoaderComponent,
    ThumbPipe,
    AppTitleComponent,
    ProfileMenuComponent,
    EnableOfferComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    FormHeaderComponent,
    SpinnerComponent,
    BasicDialog,
    CarouselComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpModule,
    BrowserAnimationsModule,
    Angular2SocialLoginModule,
    MdSelectModule,
    MdInputModule,
    MdButtonModule,
    MdProgressSpinnerModule,
    InfiniteScrollModule,
    FileUploadModule,
    NgxDatatableModule,
    MdSnackBarModule,
    MdDialogModule,
    NgxGalleryModule
  ],
  providers: [
    {
      provide: Http,
      useFactory: authInterceptorFactory,
      deps: [XHRBackend, RequestOptions, Router]
    },
    MessageService,
    GlobalService,
    OffersService,
    UserService,
    Endpoints,
    ChecktokenService,
    OfferStoreService,
    LocationService,
    AdminService,
    DialogService,
    {provide: MD_PLACEHOLDER_GLOBAL_OPTIONS, useValue: {float: 'never'}},
    ThumbPipe
  ],
  entryComponents: [BasicDialog],
  bootstrap: [AppComponent],
})
export class AppModule {
}

Angular2SocialLoginModule.loadProvidersScripts(socialProviders);
