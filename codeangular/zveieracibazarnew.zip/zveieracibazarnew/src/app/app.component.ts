import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {UserService} from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  isAdmin = false;
  isLogged = false;

  constructor(private router: Router, private userService: UserService) {
  }

  ngOnInit() {
    this.router.events.subscribe(() => {
      this.isAdmin = localStorage.getItem('userRole') === 'ADMIN';
      this.isLogged = this.userService.isLogged();
    });
  }

  showSideBar(): boolean {
    // this is route :categoryUuid - it's uuids of main categories: animal, product or service
    return this.router.isActive('/animal', true)
      || this.router.isActive('/product', true)
      || this.router.isActive('/service', true)
      || this.router.isActive('', true)
      || this.router.isActive('/offer', false)
      || (this.router.isActive('/profile/add-offer', true) && !this.isLogged);
  }

  showProfileMenu(): boolean {
    return this.router.isActive('/profile', false) && this.isLogged;
  }

  isRegistrationLoginActive(): boolean {
   return this.router.isActive('/registration', true)
     || this.router.isActive('/login', true)
     || this.router.isActive('/reset-password', false)
     || this.router.isActive('/forgot-password', true);
  }

  isBaseActive(): boolean {
    return this.router.isActive('/', true);
  }
}
