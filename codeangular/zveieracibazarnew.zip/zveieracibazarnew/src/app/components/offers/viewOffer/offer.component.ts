import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {MessageService} from '../../../message.service';
import {OffersService} from '../../../services/offers.service';
import {Gender} from '../../../models/gender.enum';
import {NgxGalleryImage, NgxGalleryOptions} from 'ngx-gallery';
import {ThumbPipe} from '../../../pipes/thumb.pipe';

@Component({
  selector: 'app-offer',
  styleUrls: ['offer.component.scss'],
  templateUrl: './offer.component.html'
})

export class OfferComponent implements OnInit {
  // Intializations
  offer: any = {};
  params: any;
  showPasswordInput = false;
  password: string;
  isPhoneVisible = false;
  isFetching = true;
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];

  constructor(private router: Router, private route: ActivatedRoute, private messageService: MessageService,
              private offersService: OffersService, private thumbPipe: ThumbPipe) {
  }

  ngOnInit() {
    this.params = this.route.params.subscribe(param => {
      if (param['uuid']) {
        this.offersService.getOfferByUuid(param['uuid'])
          .subscribe(
            data => {
              this.offer = data;
              this.isFetching = false;
              this.galleryImages = this.offer.picPath.map(img => {
                return {
                  small: this.thumbPipe.transform(img, 6),
                  medium: this.thumbPipe.transform(img, 4),
                  big: this.thumbPipe.transform(img, 4)
                };
              });
            },
            () => {
              this.messageService.showError('Chyba: Inzerát neexistuje');
              this.isFetching = false;
            });
      } else {
        this.router.navigate(['']);
      }
    });

    this.galleryOptions = [
      { previewCloseOnClick: true, previewCloseOnEsc: true, width: '100%', height: '300px' },
      { breakpoint: 500, width: '100%', height: '400px', 'thumbnailsColumns': 3 },
      { breakpoint: 300, width: '100%', height: '300px', 'thumbnailsColumns': 2 }
    ];
  }

  getGenderByType(genderType) {
    switch (genderType) {
      case Gender.MALE:
        return 'Samec';
      case Gender.FEMALE:
        return 'Samička';
      case Gender.OTHER:
      default:
        return '';
    }
  }

  requirePassword() {
   this.showPasswordInput = true;
  }

  hidePasswordInput() {
    this.showPasswordInput = false;
  }

  checkPassword() {
    this.offersService.checkOfferPassword(this.offer.uuid, this.password).subscribe(
      () => this.router.navigate(['/profile/add-offer/' + this.offer.uuid]),
      error => this.messageService.showError('Nesprávne heslo')
    );
  }
}
