import {Component, OnInit} from '@angular/core';
import {OffersService} from '../../../services/offers.service';
import {OfferStoreService} from '../../../services/offer-store.service';
import {MessageService} from '../../../message.service';
import {Constants} from '../../../utils/constants';
@Component({
  selector: 'app-fav-offers',
  styleUrls: ['favOffers.component.scss'],
  templateUrl: './favOffers.component.html'
})

export class FavouriteOffersComponent implements OnInit {
  data: any = [];
  isFetching = true;

  constructor(private offerStoreService: OfferStoreService, private offersService: OffersService, private messageService: MessageService) {
  }

  ngOnInit() {
    this.favouriteOffers();
  }

  favouriteOffers() {
    let pgNum = 0;
    let pgSize = 100;
    this.offersService.favouriteOffers(pgNum, pgSize)
      .subscribe(
        data => {
          this.data = data.content;
          this.isFetching = false;
        },
        error => {
          let err = JSON.parse(error._body) || {};
          this.messageService.showError('Chyba: ' + (err || Constants.ERROR_500_MESSAGE));
          this.isFetching = false;
        });
  }
  onScroll() {
    this.offerStoreService.getNextOfferPage();
  }
}
