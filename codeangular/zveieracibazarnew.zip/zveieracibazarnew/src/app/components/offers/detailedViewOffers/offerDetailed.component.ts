import {Component, Input, OnInit} from '@angular/core';
import {MessageService} from '../../../message.service';
import {OffersService} from '../../../services/offers.service';
import {Gender} from '../../../models/gender.enum';
import {UserService} from '../../../services/user.service';
import {Constants} from '../../../utils/constants';

@Component({
  selector: 'app-detailed',
  styleUrls: ['offerDetailed.component.scss'],
  templateUrl: './offerDetailed.component.html'
})

export class OfferDetailedComponent implements OnInit {
  @Input()
  data: any = {};
  isLogged = false;

  constructor(private offersService: OffersService, private messageService: MessageService, private userService: UserService) {
  }

  ngOnInit() {
    this.isLogged = this.userService.isLogged();
  }

  addAsFavourite() {
    this.offersService.addAsFavouriteOffer(this.data.uuid)
      .subscribe(
        () => {
          this.messageService.showSuccess('Pridanie do obľúbených bolo úspešné');
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
        });
  }

  removeFavourite() {
    this.offersService.removeFavouriteOffer(this.data.uuid)
      .subscribe(
        () => {
          this.messageService.showSuccess('Odstránenie z obľúbených bolo úspešné');
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
        });
  }

  favoriteToggle() {
    this.data.favourite = !this.data.favourite;
    if (this.data.favourite === true) {
      this.addAsFavourite();
    } else {
      this.removeFavourite();
    }
  }

  getGenderByType(genderType) {
    switch (genderType) {
      case Gender.MALE:
        return 'Samec';
      case Gender.FEMALE:
        return 'Samička';
      case Gender.OTHER:
      default:
        return 'Iné';
    }
  }
}
