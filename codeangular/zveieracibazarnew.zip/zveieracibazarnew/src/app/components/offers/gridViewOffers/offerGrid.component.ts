import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-grid',
  styleUrls: ['offerGrid.component.scss'],
  templateUrl: './offerGrid.component.html'
})

export class OfferGridComponent {
  @Input()
  data: any = {};
}
