import {Component, OnDestroy, OnInit} from '@angular/core';
import {OfferStoreService} from '../../../services/offer-store.service';
import {ActivatedRoute} from '@angular/router';
import {Subscription} from 'rxjs/Subscription';
import {Offer} from '../../../models/offer';
import {GlobalService} from '../../../global';
@Component({
  selector: 'app-offers',
  styleUrls: ['offers.component.scss'],
  templateUrl: './offers.component.html'
})

export class OffersComponent implements OnInit, OnDestroy {

  offers: Offer[];
  fetchingOffers = false;
  displayMode: any = 'detailed';

  offersSubscription: Subscription;
  fetchingOfferSubscription: Subscription;
  // offerFilterData: any = {};
  constructor(private offerStoreService: OfferStoreService,
              private route: ActivatedRoute,
              private globalService: GlobalService) {
  }

  // On Init
  ngOnInit() {
    this.offerStoreService.getNewListOfferByFilter();

    this.globalService.filterData.subscribe(res => {
      this.offers = res;
    });
    this.offersSubscription = this.offerStoreService.offersObservable
      .subscribe((offers: Offer[]) => {
        this.offers = offers;
      });

    this.fetchingOfferSubscription = this.offerStoreService.fetchingOffersObservable
      .subscribe((fetchingOffers: boolean) => {
        this.fetchingOffers = fetchingOffers;
      });

    this.route.params.subscribe(params => {
      let categoryUuid = params['categoryUuid'];
      if (categoryUuid) {
        this.offerStoreService.setMenuLevelUuid(categoryUuid, false);
      }
      if (!categoryUuid) {
        this.offerStoreService.setMenuLevelUuid('all', false);
        this.offerStoreService.resetFilter();
      }
    });
  }

  ngOnDestroy(): void {
      if (this.offersSubscription) {
          this.offersSubscription.unsubscribe();

      }
      if (this.fetchingOfferSubscription) {
          this.fetchingOfferSubscription.unsubscribe();

      }
  }

  onScroll() {
    this.offerStoreService.getNextOfferPage();
  }

  setDetailed() {
    this.displayMode = 'detailed';
  }

  setGrid() {
    this.displayMode = 'grid';
  }
}
