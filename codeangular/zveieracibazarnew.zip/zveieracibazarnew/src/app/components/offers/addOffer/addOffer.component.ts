import {Component, OnInit, ChangeDetectorRef} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {MessageService} from '../../../message.service';
import {OffersService} from '../../../services/offers.service';
import {Gender} from '../../../models/gender.enum';
import {LocationRegion} from '../../../models/location-region';
import {Subscription} from 'rxjs';
import {LocationCountry} from '../../../models/location-country';
import {OfferStoreService} from '../../../services/offer-store.service';
import {FileUploader, FileItem, ParsedResponseHeaders, FileLikeObject} from 'ng2-file-upload';
import {Endpoints} from '../../../endpoints';
import {ActivatedRoute, Router} from '@angular/router';
import {UserService} from '../../../services/user.service';
import {updateValidator} from '../../../utils/utils';
import {Constants} from '../../../utils/constants';
import {DialogService} from '../../../services/dialog.service';

const maxFileSize = 10000000; // 10MB
@Component({
  selector: 'app-addoffer',
  styleUrls: ['addOffer.component.scss'],
  templateUrl: './addOffer.component.html'
})

export class AddOfferComponent implements OnInit {
  offerForm: FormGroup;
  GenderEnum = Gender;
  menuLevelUuid = '';
  menuLevelName;
  selectedRegion: LocationRegion = null;
  selectedCity;
  selectedCityName;
  locationsSubscription: Subscription;
  locations: LocationCountry = null;
  isAnonym = true;
  isProductCategory = false;
  wrongCategory = false; // wrong category is Product or Animal for now

  public uploader: FileUploader = new FileUploader(
    {
      url: Endpoints.uploadFile,
      authToken: localStorage.getItem('authToken'),
      autoUpload: true,
      allowedFileType: ['image'],
      maxFileSize: maxFileSize
    });
  pics = [];
  params: any;
  isEditMode = false;

  constructor(public _fb: FormBuilder, private offersService: OffersService, private messageService: MessageService,
              private offerStoreService: OfferStoreService, private detector: ChangeDetectorRef,
              private route: ActivatedRoute, private router: Router, private userService: UserService,
              private dialogService: DialogService) {
  }

  ngOnInit() {
    this.offerStoreService.setMenuLevelUuid('all', true, false);

    this.formInitilization();
    this.locationsSubscription = this.offerStoreService.locationsObservable
      .subscribe((locations: LocationCountry) => {
        this.locations = locations;
      });
    this.offerStoreService.getLocation();

    this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
    this.uploader.onWhenAddingFileFailed = (item, filter, options) => this.onErrorItem(item, filter, options);
    this.uploader.onProgressAll = (progress: any) => this.detector.detectChanges();

    // Edit offer
    this.params = this.route.params.subscribe(param => {
      if (param['uuid']) {
        this.isEditMode = true;
        this.getOfferByUuid(param['uuid']);
      }
    });
    this.isAnonym = !this.userService.isLogged();
    if (this.isAnonym) {
      this.requireAnonymFields();
    }
  }

  getOfferByUuid(uuid) {
    this.offersService.getOfferByUuid(uuid)
      .subscribe(
        data => {
          this.offerForm.controls['uuid'].setValue(data.uuid);
          this.offerForm.controls['menuLevelUuid'].setValue(data.menuLevelUuid);
          this.offerForm.controls['title'].setValue(data.title);
          this.offerForm.controls['description'].setValue(data.description);
          this.offerForm.controls['price'].setValue(data.price);
          this.offerForm.controls['currency'].setValue(data.currency);
          this.offerForm.controls['gender'].setValue(data.gender);
          this.offerForm.controls['provinceId'].setValue(data.province.id);
          this.offerForm.controls['picPath'].setValue(data.picPath);
          if (data.anonymous) {
            this.offerForm.controls['email'].setValue(data.email);
            this.offerForm.controls['phoneNumber'].setValue(data.phoneNumber);
          }
          this.selectedRegion = data.province.regionId;
          this.selectedCity = data.province.id;
          this.selectedCityName = data.province.name;
          this.menuLevelName = data.menuLevelName;
          this.menuLevelUuid = data.menuLevelUuid;
          this.pics = data.picPath;
        },
        error => {
        });
  }

  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    this.uploader.clearQueue();
    if (status === 200) {
      this.pics.push(JSON.parse(response).urls[0]);
    }
  }

  onErrorItem(item: FileLikeObject, filter: any, options: any): any {
    this.uploader.clearQueue();

    if (item.size > maxFileSize) {
      this.messageService.showError('Chyba: súbor je príliš veľký, maximum je 10MB');
    }
  }

  formInitilization() {
    this.offerForm = this._fb.group({
      title: ['', [Validators.required]],
      description: ['', [Validators.required]],
      price: ['', [Validators.required, Validators.min(0)]],
      gender: [null],
      menuLevelUuid: [''],
      currency: ['EUR'],
      provinceId: [null],
      picPath: [[]],
      uuid: [null],
      email: ['', []],
      phoneNumber: ['', []],
      password: ['', []]
    });
  }

  save(offer) {
    if (this.offerForm.valid && this.menuLevelUuid && this.selectedCity) {
      offer._value.menuLevelUuid = this.menuLevelUuid;
      offer._value.provinceId = this.selectedCity;
      offer._value.picPath = this.pics;
      offer._value.anonymous = this.isAnonym;
      if (this.isEditMode) {
        this.offersService.updateOffer(offer._value.uuid, offer._value)
          .subscribe(this.successCallback, this.failureCallback);
      } else {
        this.offersService.saveOffer(offer._value)
          .subscribe(this.successCallback, this.failureCallback);
      }
    }
  }

  successCallback = (data) => {
    this.messageService.showSuccess(this.isAnonym ? 'Potvrďte pridanie inzerátu emailom na vašom účte' : 'Inzerát bol pridaný');
    // if anonym creates new offer, go to homepage because offer is not public yet (email enable)
    if (this.isAnonym) {
      if (!this.isEditMode) {
        this.router.navigate(['']);
      } else {
        // if anonym is editting offer, go to offer
        this.router.navigate(['/offer/' + data.json().uuid]);
      }
    } else {
      // logged user
      if (window.history.length < 3) {
        this.router.navigate(['/offer/' + data.json().uuid]);
      } else {
        window.history.back();
      }
    }
  };

  failureCallback = () => {
    this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
  };

  handleSelectItem($event) {
    if ($event.uuid === 'product' || $event.uuid === 'animal') {
      this.wrongCategory = true;
      return;
    }
    this.wrongCategory = false;
    this.menuLevelUuid = $event.uuid;
    // When select different category as loaded from BE, remove old name
    this.menuLevelName = '';
    if ($event.uuid === 'product') {
      this.isProductCategory = true;
      this.offerForm.controls['gender'].setValue(null);
    }
    if ($event.uuid === 'animal') {
      this.isProductCategory = false;
    }
  }

  requireAnonymFields() {
    updateValidator(this.offerForm, 'email', [Validators.required, Validators.email]);
    updateValidator(this.offerForm, 'phoneNumber', [Validators.required]);
    updateValidator(this.offerForm, 'password', [Validators.required]);
  }

  changeRegion($event) {
    this.selectedRegion = this.locations.locationRegionPojos
        .find(region => region.regionId === $event);
    this.selectedCity = null;
    this.selectedCityName = '';
  }

  changeCity($event) {
    this.selectedCity = $event;
  }

  deletePic(position: number) {
    this.pics.splice(position, 1);
  }

  showDeleteOfferDialog() {
    this.dialogService.confirm('Odstrániť inzerát', 'Naozaj chcete vymazať tento inzerát ?')
      .subscribe(data => {
        if (data) { this.deleteOffer(); }
      });
  }

  deleteOffer() {
    const uuid = this.offerForm.controls['uuid'].value;
    this.offersService.deleteOffer(uuid, this.offerForm.controls['password'].value)
      .subscribe(
        () => {
          this.messageService.showSuccess('Vymazanie úspešné');
          this.router.navigate(['']);
        },
        error => {
          if (error.status === 412) {
            this.messageService.showError('Chyba: nesprávne heslo');
          } else {
            this.messageService.showError('Chyba: ' +  Constants.ERROR_500_MESSAGE);
          }
        });
  }
}
