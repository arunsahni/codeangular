import {Component, OnInit, OnDestroy} from '@angular/core';
import {OfferStoreService} from '../../services/offer-store.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-edit-categories',
  styleUrls: ['editCategories.component.scss'],
  templateUrl: 'editCategories.component.html'
})

export class EditCategoriesComponent implements OnInit, OnDestroy {

  categories: any;
  private categoriesSubscription: Subscription;

  constructor(private offerStoreService: OfferStoreService) {}

  ngOnInit() {
    this.offerStoreService.getCategories();
    this.categoriesSubscription = this.offerStoreService.categoriesObservable
      .subscribe(categories => {
        if (categories) {
          this.categories = Object.assign([], categories);
          this.categories.childFolders = this.categories.childFolders.filter(cat => cat.uuid !== 'service');
        }
      });
  }

  ngOnDestroy(): void {
    if (this.categoriesSubscription) {
      this.categoriesSubscription.unsubscribe();
    }
  }

}
