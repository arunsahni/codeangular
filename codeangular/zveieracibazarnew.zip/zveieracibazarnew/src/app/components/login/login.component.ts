import {Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {GlobalService} from '../../global';
import {Router} from '@angular/router';
import {MessageService} from '../../message.service';
import {AuthService} from 'angular2-social-login';
import {User} from '../../models/user';
import {Constants} from '../../utils/constants';

@Component({
  selector: 'app-login',
  styleUrls: ['login.component.scss'],
  templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  user: any = {};

  constructor(public _fb: FormBuilder, private base_path_Service: GlobalService, private userService: UserService,
              private router: Router, private messageService: MessageService, public auth: AuthService) {
  }

  ngOnInit() {
    this.formInitilization();
    if (this.userService.isLogged()) {
      this.router.navigate(['/']);
    }
  }

  formInitilization() {
    this.loginForm = this._fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }
  login(userForm) {
    if (userForm.valid) {
      this.user.loginType = 'ZVIERACIBAZAR';
      this.userService.login(this.user)
        .subscribe(
          () => {
            this.base_path_Service.loginCheck.next(true);
            this.router.navigate(['']);
          },
          error => {
            let err = JSON.parse(error._body);
            if (err.status === 401) {
              this.messageService.showError('Nesprávny email alebo heslo');
            } else {
              this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
            }
          });
    }
  }

  loginSocial(provider) {
    this.auth.login(provider).subscribe(
      (data: {email: string, name: string, token: string}) => {
        const names = name ? data.name.split(' ') : [];
        const user: User = {
          email: data.email,
          firstname: names[0],
          lastname: names.slice(1).join(' '),
          password: data.token,
          loginType: provider.toUpperCase()
        };
        this.userService.login(user).subscribe(() => {
          this.router.navigate(['']);
          this.base_path_Service.loginCheck.next(true);
        });
      }
    );
  }
}
