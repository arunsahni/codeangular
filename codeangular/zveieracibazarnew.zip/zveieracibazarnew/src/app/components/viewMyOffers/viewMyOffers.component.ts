import {Component, OnInit} from '@angular/core';
import {MessageService} from '../../message.service';
import {OffersService} from '../../services/offers.service';
import {Page} from '../../models/page';
import {Constants} from '../../utils/constants';
import {DialogService} from '../../services/dialog.service';
@Component({
  selector: 'app-view-my-offers',
  styleUrls: ['viewMyOffers.component.scss'],
  templateUrl: 'viewMyOffers.component.html'
})

export class ViewMyOffersComponent implements OnInit {
  uuid: any;

  rows = [];
  page = new Page();
  isFetching = true;

  constructor(private offersService: OffersService, private messageService: MessageService,
              private dialogService: DialogService) {
  }

  ngOnInit() {
    this.setPage(Constants.getDefaultPageObject());
  }

  deleteValue(uuid) {
    this.uuid = uuid;
    this.dialogService.confirm('Odstrániť inzerát', 'Naozaj chcete vymazať tento inzerát ?')
      .subscribe(data => {
        if (data) { this.deleteOffer(); }
      });
  }

  deleteOffer() {
    const uuid = this.uuid;
    this.offersService.deleteOffer(uuid)
      .subscribe(
        () => {
          this.messageService.showSuccess('Vymazanie úspešné');
          this.setPage(Constants.getDefaultPageObject());
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
        });
  }

  /**
   * Populate the table with new data based on the page number
   * @param pageInfo The page to select
   */
  setPage(pageInfo) {
    this.page.offset = pageInfo.offset;
    this.page.pageSize = pageInfo.pageSize;
    const menuLevelUuid = 'all';
    const userUuid = localStorage.getItem('userUuid');
    this.offersService.getUsersOffers(userUuid, this.page.offset, this.page.pageSize, menuLevelUuid)
      .subscribe(
        data => {
          this.rows = data.content;
          this.page.totalElements = data.totalElements;
          this.isFetching = false;
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
          this.isFetching = false;
        });
  }
}
