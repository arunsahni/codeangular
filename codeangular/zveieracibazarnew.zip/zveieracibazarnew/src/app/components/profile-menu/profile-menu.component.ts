import {Component, OnInit, Input} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-profile-menu',
  templateUrl: './profile-menu.component.html',
  styleUrls: ['profile-menu.component.scss']
})
export class ProfileMenuComponent implements OnInit {
  @Input()
  isAdmin = false;

  constructor(public router: Router) { }

  ngOnInit() {
  }

  openGoogleAnalytics() {
    const url = 'https://analytics.google.com/analytics/web/#embed/report-home/a107565793w160623366p161817698/';
    window.open(url, '_blank');
  }

}
