import {Component, OnInit} from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {MessageService} from '../../message.service';
import {Constants} from '../../utils/constants';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  form: FormGroup;
  disabled = false;

  constructor(public _fb: FormBuilder, private userService: UserService, private messageService: MessageService) {
  }

  ngOnInit() {
    this.formInitilization();
  }

  formInitilization() {
    this.form = this._fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  login(form) {
    if (form.valid) {
      this.userService.forgotPassword(form._value.email)
        .subscribe(
          () => {
            this.loginBubbleSuccess();
            this.disabled = true;
            setTimeout(() => this.disabled = false, 5000);
          },
          error => {
            let err = JSON.parse(error._body);
            if (err.status === 412) {
              this.messageService.showError('Chyba: Používateľ s takýmto emailom nie je zaregistrovaný');
            } else {
              this.messageService.showError('Chyba:' + Constants.ERROR_500_MESSAGE);
            }
          });
    }
  }

  loginBubbleSuccess() {
    this.messageService.showSuccess('Hotovo, skontrolujte svoju emailovú schránku');
  }
}
