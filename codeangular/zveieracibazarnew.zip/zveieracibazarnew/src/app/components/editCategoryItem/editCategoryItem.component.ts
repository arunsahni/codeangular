import {Component, OnInit, Input} from '@angular/core';
import {AdminService} from '../../services/admin.service';
import {OffersService} from '../../services/offers.service';
import {MessageService} from '../../message.service';
import {DialogService} from '../../services/dialog.service';
import {Constants} from '../../utils/constants';

@Component({
  selector: 'app-edit-category-item',
  styleUrls: ['editCategoryItem.component.scss'],
  templateUrl: 'editCategoryItem.component.html'
})

export class EditCategoryItemComponent {
  @Input()
  category: any;

  @Input()
  parentName = 'Žiadny';

  @Input()
  parentUuid: string;

  uuidToDelete = '';
  positionToDelete = 0;

  constructor(private offersService: OffersService, private messageService: MessageService, private dialogService: DialogService) {}

  resetItem(position) {
    const cat = this.category[position];
    cat.name = cat.originName;
    cat.changed = false;
  }

  confirmChanges(position) {
    let cat = this.category[position];
    const requestCat = {
      name: cat.name,
      parentUuid: cat.parentUuid,
      uuid: cat.uuid
    };
    console.log(cat);
    // edit existing
    if (cat.uuid) {
      this.offersService.updateMenuLevel(requestCat).subscribe(data => {
        cat.changed = false;
        cat.originName = cat.name;
      });
    } else {
      // creating new one
      this.offersService.createMenuLevel(requestCat).subscribe(data => {
        cat.changed = false;
        cat.originName = cat.name;
        cat.uuid = data.uuid;
      });
    }
  }

  addItem() {
    this.category.push({name: '', parentUuid: this.parentUuid, childFolders: []});
  }

  handleCatChanged($event, cat) {
    if (!cat.originName) {
      cat.originName = cat.name;
    }
    cat.changed = $event !== cat.originName;
    cat.name = $event;
  }

  // To delete Offer
  deleteOffer() {
    // if has UUID, means this category is stored in DB
    if (this.uuidToDelete) {
      this.offersService.removeMenuLevel(this.uuidToDelete).subscribe(() => {
        this.category.splice(this.positionToDelete, 1);
        this.messageService.showSuccess('Vymazanie úspešné');
      },
() => {
        this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
      });
    } else {
      // if not UUID, category was created on page but not stored in DB yet
      this.category.splice(this.positionToDelete, 1);
    }
    this.uuidToDelete = null;
  }

  showDeleteCategory(position) {
    this.dialogService.confirm('Odstrániť kategóriu', 'Naozaj chcete vymazať túto kategóriu ?')
      .subscribe(data => {
        if (data) { this.deleteOffer(); }
      });
    this.uuidToDelete = this.category[position].uuid;
    this.positionToDelete = position;
  }
}
