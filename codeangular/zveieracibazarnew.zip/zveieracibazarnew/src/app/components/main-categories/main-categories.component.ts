import {Component, OnDestroy, OnInit} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {Categories} from '../../models/categories';
import {OfferStoreService} from '../../services/offer-store.service';
import {Router} from '@angular/router';

@Component({
    selector: 'app-main-categories',
    styleUrls: ['main-categories.component.scss'],
    templateUrl: 'main-categories.component.html'
})

export class MainCategoriesComponent implements OnInit, OnDestroy {

    category: any;
    private categoriesSubscription: Subscription;

    constructor(private offerStoreService: OfferStoreService,
                private router: Router) {}


    ngOnInit(): void {
        this.categoriesSubscription = this.offerStoreService.categoriesObservable
            .subscribe((category) => {
                this.category = category;
            });
        this.offerStoreService.getCategories();
        // this.offerStoreService.resetFilter();
    }

    ngOnDestroy(): void {
        if (this.categoriesSubscription) {
            this.categoriesSubscription.unsubscribe();
        }
    }

    selectItem(categories: Categories) {
        this.offerStoreService.setMenuLevelUuid(categories.uuid, true);
    }


}

