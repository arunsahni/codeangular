import {Component, OnInit} from '@angular/core';
import {Page} from '../../models/page';
import {OffersService} from '../../services/offers.service';
import {MessageService} from '../../message.service';
import {Constants} from '../../utils/constants';
import {DialogService} from '../../services/dialog.service';

@Component({
  selector: 'app-user-statistics',
  styleUrls: ['userStatistics.component.scss'],
  templateUrl: 'userStatistics.component.html'
})

export class UserStatisticsComponent implements OnInit {
  uuid: any;
  display = false;

  rows = [];
  page = new Page();
  isFetching = true;

  constructor(private offersService: OffersService, private messageService: MessageService,
              private dialogService: DialogService) {
  }

  ngOnInit() {
    this.setPage(Constants.getDefaultPageObject());
  }

  deleteValue(uuid) {
    this.uuid = uuid;
    this.dialogService.confirm('Odstrániť inzerát', 'Naozaj chcete vymazať tento inzerát ?')
      .subscribe(data => {
        if (data) { this.deleteOffer(); }
      });
  }

  deleteOffer() {
    const uuid = this.uuid;
    this.offersService.deleteOffer(uuid)
      .subscribe(
        () => {
          this.messageService.showSuccess('Vymazanie úspešné');
          this.setPage(Constants.getDefaultPageObject());
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
        });
  }

  /**
   * Populate the table with new data based on the page number
   * @param pageInfo The page to select
   */
  setPage(pageInfo) {
    this.page.offset = pageInfo.offset;
    this.page.pageSize = pageInfo.pageSize;
    this.offersService.getAllOffers(this.page.offset, this.page.pageSize)
      .subscribe(
        data => {
          this.rows = data.content;
          this.page.totalElements = data.totalElements;
          this.isFetching = false;
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
          this.isFetching = false;
        });
  }
}
