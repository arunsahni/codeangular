import {Component, OnInit} from '@angular/core';
import {MessageService} from '../../message.service';
import {ActivatedRoute, Router} from '@angular/router';
import {UserService} from '../../services/user.service';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {PasswordValidation} from '../../utils/passwordValidation';
import {Constants} from '../../utils/constants';

@Component({
  selector: 'app-reset-password',
  templateUrl: 'reset-password.component.html',
  styleUrls: ['reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  params: any;
  form: FormGroup;
  hash: string;

  constructor(private router: Router, private route: ActivatedRoute, private messageService: MessageService,
              private userService: UserService, public _fb: FormBuilder) {
  }

  ngOnInit() {
    this.formInitilization();
    this.params = this.route.params.subscribe(param => {
      if (param['hash']) {
        this.hash = param['hash'];
      } else {
        this.router.navigate(['']);
      }
    });
  }

  formInitilization() {
    this.form = this._fb.group({
      password: ['', [Validators.required, Validators.minLength(5)]],
      confirmPassword: ['']
    },
    {
      validator: PasswordValidation.MatchPassword
    });
  }

  changePassword(form) {
    if (form.valid) {
      this.userService.resetPassword(this.hash, form._value.password)
        .subscribe(
          () => {
            this.userService.logout();
            this.messageService.showSuccess('Teraz sa môžete prihlásiť');
          },
          () => this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE)
        );
    }
  }
}
