import {Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {PasswordValidation} from '../../utils/passwordValidation';
import {MessageService} from '../../message.service';
import {LocationCountry} from '../../models/location-country';
import {Subscription} from 'rxjs';
import {LocationRegion} from '../../models/location-region';
import {OfferStoreService} from '../../services/offer-store.service';
import {updateValidator} from '../../utils/utils';
import {Router} from '@angular/router';
@Component({
  selector: 'app-register',
  styleUrls: ['register.component.scss'],
  templateUrl: './register.component.html'
})

export class RegisterComponent implements OnInit {
  signUpForm: FormGroup;
  user: any = {};

  locations: LocationCountry = null;
  locationsSubscription: Subscription;
  selectedRegion: LocationRegion = null;
  selectedCity;
  selectedCityName;

  constructor(public _fb: FormBuilder, private userService: UserService, private messageService: MessageService,
    private offerStoreService: OfferStoreService, private router: Router) {
  }

  ngOnInit() {
    this.formInitilization();
    this.locationsSubscription = this.offerStoreService.locationsObservable
      .subscribe((locations: LocationCountry) => {
        this.locations = locations;
      });
    this.offerStoreService.getLocation();
  }

  formInitilization() {
    // default is userType = user, so firstname and lastname are required at init
    this.signUpForm = this._fb.group({
      loginType: ['ZVIERACIBAZAR'],
      firstname: ['', [Validators.required]],
      lastname: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(5)]],
      confirmPassword: [''],
      userRole: ['USER', Validators.required],
      companyName: ['', []],
      phoneNumber: ['', Validators.required],
      provinceId: ['']
    }, {
      validator: PasswordValidation.MatchPassword
    });
  }

  registration(user) {
    if (this.signUpForm.valid) {
      if (user._value.userRole === 'VET' && !this.selectedCity) {
        return;
      }
      user._value.provinceId = this.selectedCity;
      this.userService.register(user._value)
        .subscribe(
          () => {},
          error => {
            let err = JSON.parse(error._body);
            if (err.status === 412) {
              this.messageService.showError('Chyba: Tento email je už zaregistrovaný');
            }
            if (err.status === 401) {
              this.messageService.showSuccess('Takmer hotovo. Skontrolujte svoj email pre aktiváciu účtu');
              this.router.navigate(['/login']);
            }
          });
    }
  }

  handleUserRoleChange($event) {
    if ($event.value === 'USER') {
      updateValidator(this.signUpForm, 'firstname', [Validators.required]);
      updateValidator(this.signUpForm, 'lastname', [Validators.required]);
      updateValidator(this.signUpForm, 'companyName', []);
    } else {
      updateValidator(this.signUpForm, 'firstname', []);
      updateValidator(this.signUpForm, 'lastname', []);
      updateValidator(this.signUpForm, 'companyName', [Validators.required]);
    }
  }

  changeRegion($event) {
    this.selectedRegion = this.locations.locationRegionPojos
      .find(region => region.regionId === $event);
  }

  changeCity($event) {
    console.log($event);
    this.selectedCity = $event;
  }
}
