import {Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {MessageService} from '../../message.service';
import {LocationCountry} from '../../models/location-country';
import {Subscription} from 'rxjs';
import {OfferStoreService} from '../../services/offer-store.service';
import {LocationRegion} from '../../models/location-region';
import {PasswordValidation} from '../../utils/passwordValidation';
import {Constants} from '../../utils/constants';

@Component({
  selector: 'app-user-statistics',
  styleUrls: ['userSettings.component.scss'],
  templateUrl: 'userSettings.component.html'
})

export class UserSettingsComponent implements OnInit {
  userForm: FormGroup;
  changePasswordForm: FormGroup;
  userRole: string;
  locations: LocationCountry = null;
  locationsSubscription: Subscription;
  selectedRegion: LocationRegion = null;
  selectedCity;
  selectedCityName;
  showChangePasswordForm = false;

  constructor(public formBuilder: FormBuilder, private userService: UserService, private messageService: MessageService,
    private offerStoreService: OfferStoreService) {
  }

  ngOnInit() {
    this.userRole = localStorage.getItem('userRole');
    this.showChangePasswordForm = localStorage.getItem('userRegisterType').indexOf('ZVIERACIBAZAR') !== -1;
    this.formInitialization();
    this.userService.getMySettings().subscribe(data => {
      this.userForm.controls['firstname'].setValue(data.firstname);
      this.userForm.controls['lastname'].setValue(data.lastname);
      this.userForm.controls['address'].setValue(data.address);
      this.userForm.controls['phoneNumber'].setValue(data.phoneNumber);
      this.userForm.controls['companyName'].setValue(data.companyName);
      this.userForm.controls['provinceId'].setValue(data.province.id);
      this.userForm.controls['userRole'].setValue(data.userType);
      this.selectedRegion = data.province.regionId;
      this.selectedCity = data.province.id;
      this.selectedCityName = data.province.name;
    });

    this.locationsSubscription = this.offerStoreService.locationsObservable
      .subscribe((locations: LocationCountry) => {
        this.locations = locations;
      });
    this.offerStoreService.getLocation();
  }

  formInitialization() {
    const isVet = localStorage.getItem('userRole') === 'VET';
    this.userForm = this.formBuilder.group({
      firstname: ['', !isVet ? [Validators.required] : []],
      lastname: ['', !isVet ? [Validators.required] : []],
      address: [''],
      phoneNumber: ['', [Validators.required]],
      companyName: ['', isVet ? [Validators.required] : []],
      provinceId: [''],
      userRole: ['']
    });

    this.changePasswordForm = this.formBuilder.group({
      oldPassword: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(5)]],
      confirmPassword: ['']
      },
      {
        validator: PasswordValidation.MatchPassword
      });
  }

  save(userForm) {
    console.log(userForm);

    if (this.userForm.valid) {
      if (this.userRole === 'VET' && !this.selectedCity) { return; }
      userForm._value.provinceId = this.selectedCity;
      this.userService.saveMySettings(userForm._value).subscribe(
        () => {
          this.messageService.showSuccess('Zmeny uložené');
        },
        () => {
          this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
        });
    }
  }

  changeRegion($event) {
    this.selectedRegion = this.locations.locationRegionPojos
      .find(region => region.regionId === $event);
  }

  changeCity($event) {
    console.log($event);
    this.selectedCity = $event;
  }

  changePassword(form) {
    if (form._value.oldPassword === form._value.password) {
      this.changePasswordForm.controls['password'].setErrors({NotMatch: true});
      return;
    }
    if (form.valid) {
      this.userService.changePassowrd(form._value.oldPassword, form._value.password).subscribe(
        () => {
          this.userService.logout();
          this.messageService.showSuccess('Hotovo. Znovu sa prihláste');
        },
        error => {
          let err = JSON.parse(error._body) || {};
          if (err.status === 401) {
            this.messageService.showError('Chyba: nesprávne staré heslo');
          } else if (err.status === 412) {
            this.messageService.showError('Chyba: ste registrovaný len cez sociálnu sieť. Zmena hesla nie je možná');
          } else {
            this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
          }
        });
    }
  }
}
