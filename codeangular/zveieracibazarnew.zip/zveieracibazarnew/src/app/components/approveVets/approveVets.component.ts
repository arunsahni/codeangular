import {Component, OnInit} from '@angular/core';
import {AdminService} from '../../services/admin.service';
import {Page} from '../../models/page';
import {Constants} from '../../utils/constants';
import {Router} from '@angular/router';
import {MessageService} from '../../message.service';

@Component({
  selector: 'app-login',
  styleUrls: ['approveVets.component.scss'],
  templateUrl: 'approveVets.component.html'
})

export class ApproveVetsComponent implements OnInit {
  vets = [];
  page = new Page();
  isApprovePage = false;
  isFething = true;

  constructor(private adminService: AdminService, private messageService: MessageService, private router: Router) {}

  ngOnInit() {
    this.isApprovePage = this.router.url.indexOf('approve-vets') !== -1;
    this.setPage(Constants.getDefaultPageObject());
  }

  enableVet(vetUuid, position, state) {
    this.adminService.approveVet(vetUuid, state).subscribe(() => {
      this.vets.splice(position, 1);
      this.messageService.showSuccess('Veterinár bol ' + (state ? 'schválený' : 'zablokovaný'));
    });
  }

  /**
   * Populate the table with new data based on the page number
   * @param pageInfo The page to select
   */
  setPage(pageInfo) {
    this.page.offset = pageInfo.offset;
    this.page.pageSize = pageInfo.pageSize;
    if (this.isApprovePage) {
      this.adminService.getVetToConfirm(this.page.offset, this.page.pageSize)
        .subscribe(this.onSuccess, this.onFailure);
    } else {
      this.adminService.getDesclinedVets(this.page.offset, this.page.pageSize)
        .subscribe(this.onSuccess, this.onFailure);
    }
  }

  onSuccess = (data) => {
    this.vets = data.content;
    this.page.totalElements = data.totalElements;
    this.isFething = false;
  };

  onFailure = (error) => {
    this.messageService.showError('Chyba: ' + Constants.ERROR_500_MESSAGE);
    this.isFething = false;
  };
}
