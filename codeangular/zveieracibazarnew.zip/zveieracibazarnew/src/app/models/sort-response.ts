import {SortDirection} from './sort-direction.enum';

export class SortResponse {
    direction: SortDirection;
    property: string;
    ignoreCase: boolean;
    nullHandling: string;
    ascending: boolean;
}
