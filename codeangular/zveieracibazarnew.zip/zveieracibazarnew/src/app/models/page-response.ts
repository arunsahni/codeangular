import {SortResponse} from './sort-response';

export class PageResponse {
    content: any;
    totalPages: number;
    totalElements: number;
    last: boolean;
    numberOfElements: number;
    sort: SortResponse;
    first: boolean;
    size: number;
    number: number;
}
