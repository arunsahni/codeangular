export class Page {
  offset: number;
  pageSize: number;
  totalElements = 0;
}
