import {Gender} from './gender.enum';
import {TopStatus} from './top-status.enum';
import {LocationProvince} from './location-province';

export class Offer {
  currency: string;
  description: string;
  genderEnum: Gender;
  isTopped: TopStatus;
  picPath: string[];
  price: number;
  provinceId: number;
  provincePojo: LocationProvince;
  title: string;
  uuid: string;
  views: number;
  menuLevelName: string;
  menuLevelUuid: string;
}
