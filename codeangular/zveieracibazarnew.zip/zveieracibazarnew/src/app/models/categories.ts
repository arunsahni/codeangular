export class Categories {
    description: string;
    name: string;
    uuid: string;
    selected: boolean;
    childFolders: Categories[];
}
