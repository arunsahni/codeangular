import {LocationRegion} from './location-region';

export class LocationCountry {
    code: string;
    country: string;
    countryId: number;
    locationRegionPojos: LocationRegion[];
}
