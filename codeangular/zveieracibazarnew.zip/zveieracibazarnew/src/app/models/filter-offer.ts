import {SortDirection} from './sort-direction.enum';

export class FilterOffer {
  direction: SortDirection;
  gender: string;
  menuLevelUuid: string;
  orderBy: string;
  priceFrom: number;
  priceTo: number;
  provinceId: number;
  regionId: number;
  searchText: string;

  static copyFilter = (filterOffer: FilterOffer): FilterOffer => {
    let newFilterOffer = new FilterOffer();
    newFilterOffer.direction = filterOffer.direction;
    newFilterOffer.gender = filterOffer.gender;
    newFilterOffer.menuLevelUuid = filterOffer.menuLevelUuid;
    newFilterOffer.orderBy = filterOffer.orderBy;
    newFilterOffer.priceFrom = filterOffer.priceFrom;
    newFilterOffer.priceTo = filterOffer.priceTo;
    newFilterOffer.provinceId = filterOffer.provinceId;
    newFilterOffer.regionId = filterOffer.regionId;
    newFilterOffer.searchText = filterOffer.searchText;
    return newFilterOffer;
  }

}
