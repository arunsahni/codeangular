export enum Gender {
    MALE = <any> 'MALE',
    FEMALE = <any> 'FEMALE',
    OTHER = <any> 'OTHER',
}
