import {LocationProvince} from './location-province';

export class LocationRegion {
    region: string;
    regionId: number;
    locationProvincePojos: LocationProvince[];
}
