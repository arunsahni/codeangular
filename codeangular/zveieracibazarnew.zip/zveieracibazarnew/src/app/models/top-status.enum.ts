export enum TopStatus {
    NOT = <any> 'NOT',
    SEVEN = <any> 'SEVEN',
    TEN = <any> 'TEN',
    TOPPED = <any> 'TOPPED',
}
