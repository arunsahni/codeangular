export class LocationProvince {
    province: string;
    provinceId: number;
}
