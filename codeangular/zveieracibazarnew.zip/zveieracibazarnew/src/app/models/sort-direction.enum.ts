export enum SortDirection {
    ASC = <any> 'ASC',
    DESC = <any> 'DESC',
}
