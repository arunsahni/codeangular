export interface User {
  companyName?: string;
  email: string;
  firstname: string;
  lastname?: string;
  language?: string;
  loginType?: string;
  password?: string;
  phoneNumber?: string;
  userRoleEnum?: string;
};
