import {Injectable} from '@angular/core';
import {Location} from '@angular/common';
import {Router} from '@angular/router';
import * as Rx from 'rxjs/Rx';
import 'rxjs/add/observable/of';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class GlobalService {
  loginCheck: Rx.Subject<any> = new Rx.Subject<any>();
  sideBarCheck: Rx.Subject<any> = new Rx.Subject<any>();
  filterData: Rx.Subject<any> = new Rx.Subject<any>(); // To Filter as per fulltext search
  sidebarVisible: Boolean = false;

  constructor(private location: Location, private router: Router) {
    this.router.events.subscribe(res => {
      const currentRoute = this.location.prepareExternalUrl(location.path());
      if (currentRoute.includes('registration') || currentRoute.includes('login')) {
        this.sidebarVisible = true;
        this.sideBarCheck.next(this.sidebarVisible);
      } else {
        this.sidebarVisible = false;
        this.sideBarCheck.next(this.sidebarVisible);
      }
    });
  }
}
