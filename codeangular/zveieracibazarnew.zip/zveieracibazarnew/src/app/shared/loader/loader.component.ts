import {Component} from '@angular/core';
import {GlobalService} from '../../global';
import {UserService} from '../../services/user.service';
import {Router} from '@angular/router';

@Component({
    selector: 'app-loader',
    styleUrls: ['loader.component.scss'],
    templateUrl: 'loader.component.html'
})

export class LoaderComponent {
}
