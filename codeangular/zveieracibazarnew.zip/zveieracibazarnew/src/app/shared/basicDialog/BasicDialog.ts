import {Component} from '@angular/core';
import {MdDialogRef} from '@angular/material';

@Component({
  selector: 'app-dialog-overview-example-dialog',
  template: `
    <p>{{ title }}</p>
    <p>{{ message }}</p>
    <button type="button" md-raised-button 
        (click)="dialogRef.close(true)">{{okButtonLabel}}</button>
    <button type="button" md-button 
        (click)="dialogRef.close()">Zrušiť</button>
    `
})
export class BasicDialog {
  public title: string;
  public message: string;
  public okButtonLabel: string;

  constructor(public dialogRef: MdDialogRef<BasicDialog>) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
