import {Component, ElementRef, HostListener} from '@angular/core';
import {GlobalService} from '../../global';
import {UserService} from '../../services/user.service';
import {Router, NavigationEnd} from '@angular/router';

@Component({
  selector: 'app-header',
  styleUrls: ['./header.component.scss'],
  templateUrl: './header.component.html'
})

export class HeaderComponent {
  public loggedIn = false;
  userName = '';
  showFilter = false;
  isScrolled = false;
  isScrolledFilter = false;
  images: Array<any> = [
    {url: '/assets/images/header-1.jpg'},
    {url: '/assets/images/header-2.jpg'},
    {url: '/assets/images/header-3.jpg'},
    {url: '/assets/images/header-4.jpg'},
    {url: '/assets/images/header-5.jpg'}
  ];
  constructor(private globalService: GlobalService,
              private userService: UserService,
              private router: Router) {

    this.loggedIn = this.userService.isLogged();
    if (this.loggedIn) {
      this.userName = localStorage.getItem('userName');
    }
    this.globalService.loginCheck.subscribe(res => {
      this.loggedIn = res;
      if (this.loggedIn) {
        this.userName = localStorage.getItem('userName');
      }
    });
    this.router.events.subscribe((event) => {
      if (
        event instanceof NavigationEnd &&
        (
          this.router.isActive('/animal', true) ||
          this.router.isActive('/product', true) ||
          this.router.isActive('/service', true) ||
          this.router.isActive('', true)
        )) {
        this.showFilter = true;
      } else {
        this.showFilter = false;
      }
    });
  }

  logout() {
    this.userService.logout();
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll($event) {
    const distanceY = window.pageYOffset || document.documentElement.scrollTop;
    const shrinkLogoOn = 75;
    const fixFilterOn = 183;
    this.isScrolled = distanceY > shrinkLogoOn;
    this.isScrolledFilter = distanceY > fixFilterOn;
  }
}
