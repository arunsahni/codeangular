import {Component} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import {UserService} from '../../services/user.service';
import {MessageService} from '../../message.service';

@Component({
  selector: 'app-enable',
  styleUrls: ['userEnable.component.scss'],
  templateUrl: './userEnable.component.html'
})
export class EnableComponent {
  key: any = '';

  constructor(private userService: UserService, private activatedRoute: ActivatedRoute, private messageService: MessageService) {
    this.activatedRoute.queryParams.subscribe((params: Params) => {
      this.key = params['key'];
    });
    this.enableUser();
  }

  enableUser() {
    this.userService.getUserEnabled(this.key)
      .subscribe(
        () => this.messageService.showSuccess('Hotovo'),
        () => {});
  }
}
