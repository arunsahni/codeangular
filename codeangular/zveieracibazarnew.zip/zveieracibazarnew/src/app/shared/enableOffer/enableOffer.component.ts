import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {MessageService} from '../../message.service';
import {OffersService} from '../../services/offers.service';
@Component({
  selector: 'app-enable-offer',
  styleUrls: ['enableOffer.component.scss'],
  templateUrl: './enableOffer.component.html'
})

export class EnableOfferComponent implements OnInit {
  key: any = '';
  isOK: boolean = null;

  constructor(private offerService: OffersService, private activatedRoute: ActivatedRoute,
              private messageService: MessageService, private router: Router) {
    this.activatedRoute.queryParams.subscribe((params: Params) => {
      this.key = params['key'];
    });
  }

  ngOnInit() {
    this.enableUser();
  }

  enableUser() {
    this.offerService.enableOffer(this.key)
      .subscribe(
        data => {
          this.messageService.showSuccess('Inzerát bol pridaný');
          this.router.navigate(['/offer/' + data.uuid]);
        },
        () => {
          this.messageService.showError('Inzerát už bol pridaný');
        });
  }
}
