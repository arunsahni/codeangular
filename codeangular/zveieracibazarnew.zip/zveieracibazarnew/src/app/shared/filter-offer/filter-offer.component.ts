import {Component, OnDestroy, OnInit} from '@angular/core';
import {OfferStoreService} from '../../services/offer-store.service';
import {LocationCountry} from '../../models/location-country';
import {Subscription} from 'rxjs/Subscription';
import {LocationRegion} from '../../models/location-region';
import {Gender} from '../../models/gender.enum';
import {FilterOffer} from '../../models/filter-offer';
import {SortDirection} from '../../models/sort-direction.enum';

@Component({
  selector: 'app-filter-offer',
  styleUrls: ['filter-offer.component.scss'],
  templateUrl: 'filter-offer.component.html'
})
export class FilterOfferComponent implements OnInit, OnDestroy {

  locations: LocationCountry = null;
  selectedRegion: LocationRegion = null;
  filterOffer: FilterOffer = null;
  sortValue = null;

  locationsSubscription: Subscription;
  filterOfferSubscription: Subscription;
  isFilterExpanded = false;

  GenderEnum = Gender;

  constructor(private offerStoreService: OfferStoreService) {
  }

  ngOnInit(): void {
    this.locationsSubscription = this.offerStoreService.locationsObservable
      .subscribe((locations: LocationCountry) => {
        this.locations = locations;
      });
    this.offerStoreService.getLocation();

    this.filterOfferSubscription = this.offerStoreService.filterObservable
      .subscribe((filterOffer: FilterOffer) => {
        this.filterOffer = filterOffer;
        if (this.filterOffer.regionId) {
          this.selectedRegion = this.locations.locationRegionPojos
            .find(region => region.regionId === this.filterOffer.regionId);
        } else {
          this.selectedRegion = null;
        }

        if (this.filterOffer.orderBy) {
          this.setSort(this.filterOffer);
        }

      });
  }

  ngOnDestroy(): void {
    if (this.locationsSubscription) {
      this.locationsSubscription.unsubscribe();
    }
  }

  onSubmit() {
    if (this.filterOffer.searchText) {
      if (this.filterOffer.searchText.length > 0 && this.filterOffer.searchText.length < 3) {
        return;
      }
    } else {
      this.filterOffer.searchText = null;
    }
    this.offerStoreService.getNewListOfferByFilter();
    this.toggleFilter();
  }

  changeRegion($event) {
    if ($event !== '') {
      this.selectedRegion = this.locations.locationRegionPojos
        .find(region => region.regionId === $event);
    } else {
      this.selectedRegion = null;
    }
    this.filterOffer.provinceId = null;
  }

  changeSort($event) {
    if (this.filterOffer) {
      switch ($event) {
        case 'createdAsc': {
          this.filterOffer.direction = SortDirection.ASC;
          this.filterOffer.orderBy = 'created';
          break;
        }
        case 'createdDesc': {
          this.filterOffer.direction = SortDirection.DESC;
          this.filterOffer.orderBy = 'created';
          break;
        }
        case 'priceAsc': {
          this.filterOffer.direction = SortDirection.ASC;
          this.filterOffer.orderBy = 'price';
          break;
        }
        case 'priceDesc': {
          this.filterOffer.direction = SortDirection.DESC;
          this.filterOffer.orderBy = 'price';
          break;
        }
        default: {
          this.filterOffer.direction = SortDirection.ASC;
          this.filterOffer.orderBy = 'created';
          break;
        }
      }
    }
  }

  private setSort(filterOffer: FilterOffer) {
    if (this.filterOffer.direction === SortDirection.ASC) {
      this.sortValue = this.filterOffer.orderBy + 'Asc';
    } else {
      this.sortValue = this.filterOffer.orderBy + 'Desc';
    }
  }

  toggleFilter() {
    this.isFilterExpanded = !this.isFilterExpanded;
  }
}
