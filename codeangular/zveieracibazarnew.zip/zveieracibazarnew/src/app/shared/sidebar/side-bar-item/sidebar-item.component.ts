import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Categories} from '../../../models/categories';

@Component({
    selector: 'app-sidebar-item',
    styleUrls: ['./sidebar-item.component.scss'],
    templateUrl: './sidebar-item.component.html'
})

export class SideBarItemComponent {

    @Input()
    category: Categories;

    @Input()
    expanded: boolean;

    @Input()
    expandedParent: boolean;

    @Input()
    level: number;

    @Output()
    selectEvent = new EventEmitter();

    selectClick(category: Categories) {
        this.expanded = true;
        this.selectEvent.emit(category);
    }

    switchCollapse() {
        this.expanded = !this.expanded;
    }

}
