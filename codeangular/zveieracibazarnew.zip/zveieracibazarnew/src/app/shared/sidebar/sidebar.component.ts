import {Component, OnDestroy, OnInit, EventEmitter, Output, Input} from '@angular/core';
import {Categories} from '../../models/categories';
import {OfferStoreService} from '../../services/offer-store.service';
import {Subscription} from 'rxjs/Subscription';
import {DialogService} from '../../services/dialog.service';

@Component({
    selector: 'app-sidebar',
    styleUrls: ['./sidebar.component.scss'],
    templateUrl: './sidebar.component.html'
})

export class SideBarComponent implements OnInit, OnDestroy {
    @Input() hideServices = false;
    @Output() onSelectItem = new EventEmitter();

    category: Categories;
    categoriesSubscription: Subscription;
    constructor(private offerStoreService: OfferStoreService) {
    }

    ngOnInit(): void {
        this.categoriesSubscription = this.offerStoreService.categoriesObservable
            .subscribe((category) => {
            if (category) {
                if (this.hideServices) {
                    this.category = Object.assign([], category);
                    this.category.childFolders = this.category.childFolders.filter(cat => cat.uuid !== 'service');
                } else {
                    this.category = category;
                }
            }
        });
        this.offerStoreService.getCategories();
    }

    ngOnDestroy(): void {
        this.categoriesSubscription.unsubscribe();
    }

    selectItem(categories: Categories) {
        this.onSelectItem.emit(categories);
        this.offerStoreService.setMenuLevelUuid(categories.uuid, true, this.onSelectItem.observers.length === 0);
    }
}
