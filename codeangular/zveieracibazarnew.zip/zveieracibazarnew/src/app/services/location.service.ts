import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import {Endpoints} from '../endpoints';
import {LocationCountry} from '../models/location-country';

@Injectable()
export class LocationService {
  constructor(private http: Http) {
  }

  getLocations(): Observable<LocationCountry> {
      return this.http.get(Endpoints.location)
          .map((response: Response) => {
              return response.json().locationCountryPojo as LocationCountry;
          });
  }

}
