import {
  Injectable
} from '@angular/core';
import {CanActivate} from '@angular/router';
import {GlobalService} from '../global';

@Injectable()
export class ChecktokenService implements CanActivate {
  constructor(private globalService: GlobalService) { }

  canActivate() {
    let myToken = localStorage.getItem('authToken');

    this.globalService.loginCheck.subscribe(res => {
      myToken = localStorage.getItem('authToken');
    });

    if (myToken) {
      return true;
    }
  }
}
