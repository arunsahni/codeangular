import {Injectable} from '@angular/core';
import {MdDialog, MdDialogRef} from '@angular/material';
import {Observable} from 'rxjs';
import {BasicDialog} from '../shared/basicDialog/BasicDialog';

@Injectable()
export class DialogService {

  constructor(public dialog: MdDialog) { }

  public confirm(title: string, message: string, okButtonLabel = 'Vymazať'): Observable<boolean> {

    let dialogRef: MdDialogRef<BasicDialog>;

    dialogRef = this.dialog.open(BasicDialog);
    dialogRef.componentInstance.title = title;
    dialogRef.componentInstance.message = message;
    dialogRef.componentInstance.okButtonLabel = okButtonLabel;

    return dialogRef.afterClosed();
  }
}
