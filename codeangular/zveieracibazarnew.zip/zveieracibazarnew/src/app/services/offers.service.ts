import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import {Endpoints} from '../endpoints';
import {Categories} from '../models/categories';
import {Observable} from 'rxjs/Observable';
import {FilterOffer} from '../models/filter-offer';
import {PageResponse} from '../models/page-response';
import {Offer} from '../models/offer';
import {createRequestOptions} from '../utils/utils';
import {UserService} from './user.service';

@Injectable()
export class OffersService {

  private headers = new Headers({
    'Content-Type': 'application/json',
  });

  constructor(private http: Http, private userService: UserService) {
  }

  getUsersOffers(userUuid: string, page: number, size: number, menuLevelUuid) {
    const options = createRequestOptions(true);
    return this.http.get(Endpoints.getUsersOffer(userUuid, page, size, menuLevelUuid), options).map(
      (response: Response) => response.json());
  }

  // To view specific Offer
  getOfferByUuid(uuid: string) {
    const options = createRequestOptions(this.userService.isLogged());
    return this.http.get(Endpoints.getOffer(uuid), options).map(
      (response: Response) => response.json());
  }

  // To save offer
  saveOffer(offer: Offer) {
    const options = createRequestOptions(this.userService.isLogged());
    return this.http.post(Endpoints.addOffer, offer, options).map(
      (response: Response) => response);
  }

  // To update Offer
  updateOffer(uuid: string, offer: Offer) {
    const options = createRequestOptions(this.userService.isLogged());
    return this.http.put(Endpoints.updateOffer(uuid), offer, options).map(
      (response: Response) => response);
  }

  // To delete Offer
  deleteOffer(uuid: string, deletePassword = '') {
    const options = createRequestOptions(this.userService.isLogged());
    return this.http.post(Endpoints.deleteOffer(uuid), {deletePassword}, options).map(
      (response: Response) => response);
  }

  getCategories(): Observable<Categories> {
    return this.http.get(Endpoints.menuLevel)
      .map((response: Response) => {
        return response.json();
      });
  }

  getOfferByFilter(page: number, size: number, filterOffer: FilterOffer): Observable<PageResponse> {
    const options = createRequestOptions(this.userService.isLogged());
    return this.http.post(
      Endpoints.offerFilter(page, size),
      JSON.stringify(filterOffer),
      options)
      .map((response: Response) => {
        return response.json();
      });
  }

  getAllOffers(page: number, size: number): Observable<PageResponse> {
    return this.http.get(
      Endpoints.offersList(page, size, 'all'),
      {headers: this.headers})
      .map((response: Response) => {
        return response.json();
      });
  }

  // To view Favourite Offers
  favouriteOffers(page: number, size: number) {
    const options = createRequestOptions(true);
    return this.http.get(Endpoints.favouriteList(page, size), options).map(
      (response: Response) => response.json());
  }

  // To add in Favourite Offers
  addAsFavouriteOffer(offerUuid) {
    const options = createRequestOptions(true);
    return this.http.post(Endpoints.addAsFavouriteOffer(offerUuid), {}, options).map(
      (response: Response) => response.json());
  }

  // To remove from Favourite Offers
  removeFavouriteOffer(offerUuid) {
    const options = createRequestOptions(true);
    return this.http.delete(Endpoints.removefavouriteOffer(offerUuid), options);
  }

  // Create new category in Menu
  createMenuLevel(category) {
    const options = createRequestOptions(true);
    return this.http.post(Endpoints.createUpdateMenuLevel(), category, options).map(
      (response: Response) => response.json());
  }

  // Update category in Menu
  updateMenuLevel(category) {
    const options = createRequestOptions(true);
    return this.http.put(Endpoints.createUpdateMenuLevel(), category, options).map(
      (response: Response) => response.json());
  }

  // To remove category
  removeMenuLevel(categoryUuid) {
    const options = createRequestOptions(true);
    return this.http.delete(Endpoints.removeMenuLevel(categoryUuid), options);
  }

  enableOffer(key: string) {
    return this.http.get(Endpoints.offerEnable(key)).map(
      (response: Response) => response.json());
  }

  // Create new category in Menu
  checkOfferPassword(offerUuid, password) {
    const options = createRequestOptions();
    return this.http.post(Endpoints.checkOfferPassword(offerUuid), {password}, options);
  }
}
