import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import {Endpoints} from '../endpoints';
import {createRequestOptions} from '../utils/utils';

@Injectable()
export class AdminService {
  constructor(private http: Http) {
  }

  getVetToConfirm(pageNum: number, pageSize: number) {
    const options = createRequestOptions(true);
    return this.http.get(Endpoints.getVetToConfirm(pageNum, pageSize), options).map(
      (response: Response) => response.json());
  }

  getDesclinedVets(pageNum: number, pageSize: number) {
    const options = createRequestOptions(true);
    return this.http.get(Endpoints.getDeclinedVets(pageNum, pageSize), options).map(
      (response: Response) => response.json());
  }

  approveVet(userUuid: string, state: boolean) {
    const options = createRequestOptions(true);
    return this.http.put(Endpoints.approveVet(userUuid), {approve: state}, options);
  }
}
