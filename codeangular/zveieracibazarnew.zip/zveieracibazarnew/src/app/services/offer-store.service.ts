import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Categories} from '../models/categories';
import {Observable} from 'rxjs/Observable';
import {LocationCountry} from '../models/location-country';
import {LocationService} from './location.service';
import {FilterOffer} from '../models/filter-offer';
import {Router} from '@angular/router';
import {OffersService} from './offers.service';
import {Offer} from '../models/offer';
import {PageResponse} from '../models/page-response';
import {GlobalService} from '../global';
import {MessageService} from '../message.service';
import {Constants} from '../utils/constants';

@Injectable()
export class OfferStoreService {

  private categories: BehaviorSubject<Categories> = new BehaviorSubject<Categories>(null);
  private filter: BehaviorSubject<FilterOffer> = new BehaviorSubject<FilterOffer>(new FilterOffer());
  private locations: BehaviorSubject<LocationCountry> = new BehaviorSubject<LocationCountry>(null);
  private offers: BehaviorSubject<Offer[]> = new BehaviorSubject<Offer[]>([]);
  private requestOfferSubject: BehaviorSubject<FilterOffer> = new BehaviorSubject<FilterOffer>(new FilterOffer());
  private fetchingOffers: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  categoriesObservable: Observable<Categories> = this.categories.asObservable();
  filterObservable: Observable<FilterOffer> = this.filter.asObservable();
  locationsObservable: Observable<LocationCountry> = this.locations.asObservable();
  offersObservable: Observable<Offer[]> = this.offers.asObservable();
  fetchingOffersObservable: Observable<boolean> = this.fetchingOffers.asObservable();

  private pageOffer = 0;
  private sizeOffer = 20;
  private lastOfferPage = false;
  private lastFilterUsed: FilterOffer;

  constructor(private offersService: OffersService,
              private router: Router,
              private locationService: LocationService,
              private messageService: MessageService) {
    this.requestOfferSubject
      .debounceTime(300)
      .switchMap((filterOffer: FilterOffer) => {
        if (!filterOffer.menuLevelUuid) {
          filterOffer.menuLevelUuid = 'all';
        }
        return this.offersService.getOfferByFilter(this.pageOffer, this.sizeOffer, filterOffer)
          .map((pageResponse: PageResponse) => {
            this.lastOfferPage = pageResponse.last;
            return pageResponse.content as Offer[];
          });
      }).subscribe((offers: Offer[]) => {
      this.fetchingOffers.next(false);
      this.offers.next(this.offers.getValue().concat(offers));
    }, (error) => {
      this.showAlter();
    });
  }

  getCategories(): void {
    if (this.categories.getValue() === null) {
      this.offersService.getCategories()
        .subscribe((categories: Categories) => {
          this.categories.next(categories);
        }, (error) => {
          this.showAlter();
        });
    }
  }

  getLocation(): void {
    if (this.locations.getValue() === null) {
      this.locationService.getLocations()
        .subscribe((locationCountry: LocationCountry) => {
          this.locations.next(locationCountry);
        }, (error) => {
          this.showAlter();
        });
    }
  }

  getNewListOfferByFilter() {
    this.pageOffer = 0;
    this.lastFilterUsed = FilterOffer.copyFilter(this.filter.getValue());
    this.offers.next([]);
    this.fetchingOffers.next(true);
    this.requestOfferSubject.next(this.lastFilterUsed);
  }

  getNextOfferPage() {
    this.pageOffer += 1;
    if (!this.lastOfferPage && !this.fetchingOffers.getValue()) {
      this.fetchingOffers.next(true);
      this.requestOfferSubject.next(this.lastFilterUsed);
    }
  }


  setMenuLevelUuid(uuid: string, fromMenu: boolean, redirect = true) {
    if (this.filter.getValue().menuLevelUuid !== uuid) {
      if (this.categories.getValue() !== null) {
        if (!fromMenu && this.isMainCategorySelected(uuid)) {
          return;
        }
        this.setMenuLevelInFilter(uuid, redirect);
      } else {
        let subscription = this.categories.subscribe(
          (categories: Categories) => {
            if (categories !== null) {
              this.setMenuLevelInFilter(uuid, redirect);
              subscription.unsubscribe();
            }
          }
        );
      }

    }
  }

  private isMainCategorySelected(uuid: string) {
    let mainCategory: Categories = this.categories.getValue().childFolders.find(categories => categories.uuid === uuid);
    if (mainCategory) {
      return mainCategory.selected;
    } else {
      return false;
    }
  }

  private setMenuLevelInFilter(uuid: string, redirect = true) {
    this.unselectAll(this.categories.getValue());
    let foundCategory = this.setSelectedCategory(this.categories.getValue(), uuid);
    if (foundCategory) {
      this.filter.getValue().menuLevelUuid = uuid;
      this.filter.next(this.filter.getValue());
      this.getNewListOfferByFilter();
      let parentCategory: Categories = this.categories.getValue().childFolders
        .find(categories => categories.selected === true);
      if (parentCategory) {
        // reset filter
        if (parentCategory.uuid === uuid) {
          let newFilter = new FilterOffer();
          newFilter.menuLevelUuid = uuid;
          this.filter.next(newFilter);
          this.getNewListOfferByFilter();
        }
        if (redirect) {
          this.router.navigateByUrl('/' + parentCategory.uuid);
        }
      }
    } else if (redirect) {
      this.router.navigateByUrl('/');
    }
  }

  private setSelectedCategory(category: Categories, uuid: string): Categories {
    if (category.uuid === uuid) {
      category.selected = true;
      return category;
    } else if (category.childFolders !== null) {
      let foundCategory: Categories = null;
      for (let i = 0; foundCategory === null && i < category.childFolders.length; i++) {
        foundCategory = this.setSelectedCategory(category.childFolders[i], uuid);
      }
      if (foundCategory) {
        category.selected = true;
      }
      return foundCategory;
    }
    return null;
  }

  private unselectAll(category: Categories) {
    category.selected = false;
    if (category.childFolders !== null) {
      for (let i = 0; i < category.childFolders.length; i++) {
        this.unselectAll(category.childFolders[i]);
      }
    }
  }

  private showAlter() {
    this.messageService.showError('Chyba: ' +  Constants.ERROR_500_MESSAGE);
  }

  resetFilter() {
    this.filter.next(new FilterOffer());
    this.offers.next([]);
  }

}
