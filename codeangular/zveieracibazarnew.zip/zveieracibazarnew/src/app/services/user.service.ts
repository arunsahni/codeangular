import {Injectable} from '@angular/core';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import {User} from '../models/user';
import {Endpoints} from '../endpoints';
import {GlobalService} from '../global';
import {Router} from '@angular/router';
import {AuthService} from 'angular2-social-login';
import {createRequestOptions} from '../utils/utils';

@Injectable()
export class UserService {
  constructor(private http: Http, private globalService: GlobalService, private router: Router,
              public _auth: AuthService) {
  }

  register(user: User) {
    const options = createRequestOptions();
    return this.http.post(Endpoints.registration, user, options)
      .map((response: Response) => response);
  }

  getUserEnabled(key: string) {
    return this.http.get(Endpoints.userEnable(key)).map(
      (response: Response) => response.json());
  }

  login(user: User) {
    const options = createRequestOptions();
    return this.http.post(Endpoints.login, user, options)
      .map((response: Response) => {
        const loggedUser = response.json();
        if (loggedUser) {
          localStorage.setItem('authToken', loggedUser.authToken);
          localStorage.setItem('refreshToken', loggedUser.refreshToken);
          localStorage.setItem('userUuid', loggedUser.userUuid);
          localStorage.setItem('userRegisterType', loggedUser.user.registerType);
          this.updateUserName(loggedUser);
          const loginTime = new Date().getTime() + (loggedUser.expiresInSeconds * 1000) - (300 * 1000);
          localStorage.setItem('expTime', loginTime + '');
          localStorage.setItem('userRole', loggedUser.userRole);
        }
      });
  }

  logout() {
    this._auth.logout();
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('userUuid');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userName');
    localStorage.removeItem('expTime');
    localStorage.removeItem('userRegisterType');
    this.globalService.loginCheck.next(false);
    this.router.navigate(['/login']);
  }

  isLogged() {
    const isLoggedIn = localStorage.getItem('authToken');
    return isLoggedIn ? true : false;
  }

  getMySettings() {
    const options = createRequestOptions(true);
    return this.http.get(Endpoints.getMySettings(), options).map(
      (response: Response) => response.json());
  }

  saveMySettings(user) {
    this.updateUserName(user);
    // after update localstorage, we need to fire event which update header component (here we are using subscritpion
    // on login checking
    this.globalService.loginCheck.next(true);
    const options = createRequestOptions(true);
    return this.http.put(Endpoints.getMySettings(), user, options);
  }

  forgotPassword(email: string) {
    return this.http.post(Endpoints.forgotPassword(email), null)
      .map((response: Response) => response.json());
  }

  resetPassword(hash: string, password: string) {
    const options = createRequestOptions();
    return this.http.post(Endpoints.resetPassword, {hash, password}, options)
      .map((response: Response) => response.json());
  }

  changePassowrd(oldPassword: string, newPassword: string) {
    const options = createRequestOptions(true);
    return this.http.post(Endpoints.changePassword, {oldPassword, newPassword}, options);
  }

  updateUserName(user) {
    if (user.userRole === 'VET') {
      localStorage.setItem('userName', user.user.companyName);
    } else {
      localStorage.setItem('userName', (user.user.firstname || '') + ' ' + (user.user.lastname || ''));
    }
  }
}
