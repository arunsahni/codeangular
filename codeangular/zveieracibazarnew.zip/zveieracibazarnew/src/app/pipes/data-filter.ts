import {Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';
@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(items: Array<any>, filter: any): Array<any> {
    return items.filter(item => {
      for (let key in item ) {
        if (('' + item[key]).includes(filter)) {
          return true;
        }
      }
      return false;
    });
  }
}
