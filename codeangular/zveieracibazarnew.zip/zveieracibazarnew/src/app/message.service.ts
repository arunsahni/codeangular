import {Injectable} from '@angular/core';
import {MdSnackBar} from '@angular/material';

@Injectable()
export class MessageService {

  constructor(private snackBar: MdSnackBar) { }

  public showSuccess(text: string, action = 'Zatvoriť') {
    this.openMessage(text, action, 'success');
  }

  public showError(text: string, action = 'Zatvoriť') {
    this.openMessage(text, action, 'error');
  }

  private openMessage(text: string, action, styleClass: string) {
    this.snackBar.open(text, action, {
      duration: 5000,
      extraClasses: ['app-snackbar', styleClass]
    });
  }
}
