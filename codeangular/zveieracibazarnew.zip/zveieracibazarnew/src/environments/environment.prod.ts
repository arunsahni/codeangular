export const environment = {
  production: true,
  serverBase: 'http://zb-api.localhostsro.sk',
  imageBase: 'http://zb-images.localhostsro.sk'
};
