export class AppConfig {
  public readonly apiUrl = 'http://server.localhostsro.sk:19030';
}
;
