import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';

import {ToastyModule} from 'ng2-toasty';
import {DndModule} from 'ng2-dnd';
import {SlimLoadingBarModule} from 'ng2-slim-loading-bar';
import {ToastComponent, ToastCommunicationService} from './shared/toast';

import {CustomerService, CampaignService, BatchService, UserService, ChecktokenService} from './services/index';
import {AppComponent} from './app.component';
import {FormWizardModule} from 'angular2-wizard';
import {AppConfig} from './app.config';
import {WizardComponent} from './components/wizard/wizard.component';
import {HomeComponent} from './components/home/home.component';
import {HeaderComponent} from './shared/header/header.component';
import {CampaignComponent} from './components/campaign/campaigns/campaigns.component';
import {CampaignViewComponent} from './components/campaign/campaign/campaignDetails.component';
import {BatchComponent} from './components/batch/addBatch/batch.component';
import {BatchesComponent} from './components/batch/batchesList/batches.component';
import {BatchViewComponent} from './components/batch/batchDetails/batchDetails.component';
import {SendMailComponent} from './components/sendMail/sendMail.component';
import {EditBatchComponent} from './components/batch/editBatch/editBatch.component';
import {EditCampaignComponent} from './components/campaign/editCampaign/editCampaign.component';
import {LoginComponent} from './components/login/login.component';
import {CreateCampaignComponent} from './components/campaign/createCampaign/createCampaign.component';
import {ModalComponent} from './shared/modalwindow/modal.component';
import {routing} from './app.routing';
import {DataTableModule} from 'angular2-datatable';
import {DataFilterPipe, } from './shared/pipes/data-filter';
import {EmailFilterPipe, } from './shared/pipes/email-filter';

import {GlobalService} from './global';

@NgModule({
  declarations: [
    AppComponent,
    WizardComponent,
    HomeComponent,
    HeaderComponent,
    CampaignComponent,
    DataFilterPipe,
    EmailFilterPipe,
    ToastComponent,
    CampaignViewComponent,
    BatchComponent,
    BatchesComponent,
    BatchViewComponent,
    SendMailComponent,
    EditBatchComponent,
    EditCampaignComponent,
    LoginComponent,
    CreateCampaignComponent,
    ModalComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    routing,
    HttpModule,
    FormWizardModule,
    DataTableModule,
    ToastyModule.forRoot(),
    DndModule.forRoot(),
    SlimLoadingBarModule.forRoot()
  ],
  providers: [
    CustomerService,
    CampaignService,
    BatchService,
    AppConfig,
    ToastCommunicationService,
    GlobalService,
    UserService,
    ChecktokenService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

