import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Subject, Observable, Subscription} from 'rxjs/Rx';
import { UserService } from '../../services/index';
import { GlobalService } from '../../global';
declare var jQuery: any;


@Component({
  selector: 'app-header',
  styleUrls: ['./header.component.css'],
  templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit {
  // Intializations
  user: any = {};
  loggedIn: any = false;
  // constructor
  constructor(private userService: UserService, private base_path_Service: GlobalService) {
  }

  // On Init
  ngOnInit() {
  }

  // Logout session
  logout() {
    this.base_path_Service.dummyObsCounter++;
    console.log(this.base_path_Service.dummyObsCounter,'---------', 'Header component => Logout');
    this.base_path_Service.dummyObs.next(this.base_path_Service.dummyObsCounter);
    this.userService.logout();
  }
}
