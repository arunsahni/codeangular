
import {Component, OnInit} from '@angular/core';
import { UserService } from '../../services/index';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../toast/toast-communication.service';
import { Router } from '@angular/router';
declare var jQuery: any;

@Component({
  selector: 'app-modal',
  styleUrls: ['./modal.component.css'],
  templateUrl: './modal.component.html',
  providers: [UserService]
})

export class ModalComponent implements OnInit {
  // Intializations

  // constructor
  constructor(private userService: UserService, private router: Router, private toastyService: ToastyService,
              private toastCommunicationService: ToastCommunicationService) {
  }
  // On Init
  ngOnInit() {
  }
  // To close the modal
  close() {
      // jQuery('#myModal').dismiss();
      jQuery('#myModal').modal('hide');
      // jQuery('#myModal').modal('toggle');
  }
}
