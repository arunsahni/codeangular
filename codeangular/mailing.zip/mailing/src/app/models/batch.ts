
export interface Batch {
  name: string;
  customers: [{
    email: string,
    uuid: string
  }];
};
