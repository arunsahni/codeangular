﻿export interface Customer {
    email: string;
    uuid: string;
};
