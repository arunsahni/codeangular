export interface Campaign {
    campaignCustomers: any;
    campaignSentDate: Date;
    campaignUrl: string;
    hasCustomers: Boolean;
    mailTemplate: {
      'originalFileName': string,
      'path': string,
      'uuid': string
    };
    name: string;
    status: string; // ['NEW', 'READY', 'SENT'],
    subject: string;
    templatePath: string;
    uuid: string;
};
