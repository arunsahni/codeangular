
import {
  Injectable
} from '@angular/core';
import {Router, CanActivate} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../shared/toast/toast-communication.service';
import {GlobalService} from '../global';
@Injectable()


export class ChecktokenService implements CanActivate {
  constructor(private router: Router, private toastyService: ToastyService,
              private toastCommunicationService: ToastCommunicationService, public global: GlobalService) {
  }

  canActivate() {
    const myToken = localStorage.getItem('authToken');
    const expiresInSeconds = parseInt(localStorage.getItem('expiresInSeconds'));
    const currentTime = new Date().getTime();
    // console.log('result checker', expiresInSeconds - currentTime, expiresInSeconds , currentTime);

    if ((expiresInSeconds - currentTime) < 5000) {
      localStorage.removeItem('authToken');
      localStorage.removeItem('expiresInSeconds');
      const toastOptions: ToastOptions = {
        title: '',
        msg: 'Token expired. Please login again.',
        timeout: 5000
      };
      this.toastyService.error(toastOptions);
      this.global.loginCheck.next(false);
      this.router.navigate(['/login']);
    } else {
      setTimeout(e => {
        localStorage.removeItem('authToken');
        localStorage.removeItem('expiresInSeconds');
        const toastOptions: ToastOptions = {
          title: '',
          msg: 'Token expired. Please login again.',
          timeout: 5000
        };
        this.toastyService.error(toastOptions);
        this.global.loginCheck.next(false);
        this.router.navigate(['/login']);
        console.log('Timeout called');
      }, (expiresInSeconds - currentTime));
    }

    if (myToken) {
      return true;
    }
  }
}
