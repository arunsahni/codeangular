import {
  Injectable
} from '@angular/core';
import {
  Http,
  Headers,
  RequestOptions,
  Response
} from '@angular/http';
import {
  Observable
} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {
  Customer
} from '../models/index';
import {
  AppConfig
} from '../app.config';


@Injectable()
export class CustomerService {
  baseurl: any;

  constructor(private http: Http, private config: AppConfig) {
    this.baseurl = config.apiUrl;
  }

  createAuthorizationHeader(headers: Headers) {
    const token = localStorage.getItem('authToken');
    headers.append('Content-Type', 'application/json');
    headers.append('auth_token', token);
  }

  getCustomers() {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.get(this.baseurl + '/customer/all', options).map(
      (response: Response) => response.json());
  }

  saveCustomer(customer: Customer) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.post(this.baseurl + '/customer/save', customer, options)
      .map((response: Response) => response);
  }

  getCustomerByUuid(uuid: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.get(this.baseurl + '/customer/' + uuid, options).map(
      (response: Response) => response.json());
  }

  uploadFile(file: any) {
    const headers = new Headers({
      'Content-Type': 'multipart/form-data'
    });

    return this.http.post(this.baseurl + '/customer/upload', file, {
      headers
    });
  }

  deleteCustomer(uuid: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.delete(this.baseurl + '/customer/' + uuid, options);
  }
}
;
