import {
  Injectable
} from '@angular/core';
import {
  Http,
  Headers,
  RequestOptions,
  Response
} from '@angular/http';
import {
  Observable
} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {
  Campaign
} from '../models/index';
import {
  AppConfig
} from '../app.config';

@Injectable()

export class CampaignService {
  baseurl: any;

  constructor(private http: Http, private config: AppConfig) {
    this.baseurl = config.apiUrl;
  }

  createAuthorizationHeader(headers: Headers) {
    const token = localStorage.getItem('authToken');
    headers.append('Content-Type', 'application/json');
    headers.append('auth_token', token);
  }

  saveCampaign(campaign: Campaign) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    console.log(campaign, 'service');
    return this.http.post(this.baseurl + '/campaign/save', campaign, options).map(
      (response: Response) => response);
  }

  getCampaignByUuid(uuid: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.get(this.baseurl + '/campaign/' + uuid, options).map(
      (response: Response) => response.json());
  }

  SendMails(uuid: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    const url = this.baseurl + '/campaign/sendEmails/' + uuid;
    return this.http.post(url, uuid, options).map(
      (response: Response) => response);
  }

  SendMailBatch(batch: string, campaign: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    const url = this.baseurl + '/campaign/sendEmails/?batchName=' + batch + '&campaignName=' + campaign;
    return this.http.post(url, batch, options).map(
      (response: Response) => response);
  }

  campagianList() {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    console.log('Header', headers);
    const options = new RequestOptions({headers: headers});
    console.log('options', options);
    return this.http.get(this.baseurl + '/campaign/all', options).map(
      (response: Response) => response.json());
  }

  // uploadCampaignTemplate(file: any, campaignname: string) {
  //   const headers = new Headers();
  //   const token = localStorage.getItem('authToken');
  //   // headers.append('Content-Type', 'multipart/form-data');
  //   headers.append('auth_token', token);
  //   const url = this.baseurl + '/campaigns/uploadTemplate/' + campaignname;
  //   const options = new RequestOptions({ headers: headers });
  //   const formData = new FormData();
  //   formData.append( 'file' , file);
  //   formData.append('Content-Type', 'multipart/form-data');
  //   console.log('* service in update :', options, formData);
  //
  //   return this.http.post(url,  formData, options).map(
  //     (response: Response) => {
  //       console.log(response, '******');
  //       return response;
  //     });
  // }

  updateCampaign(campaign: Campaign) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.put(this.baseurl + '/campaign/edit', campaign, options).map(
      (response: Response) => response);
  }

  uploadCampaignTemplate(file: any) {
    return Observable.fromPromise(this.postFileRequest(file).then(
      (result) => {
        console.log(result, 'result here');
        return result;
      },
      (error) => {
        console.error(error, 'Error here');
        return error;
      })
    );
  }

  postFileRequest(file: any) {
    const url_new = this.baseurl + '/campaign/uploadTemplate';

    return new Promise((resolve, reject) => {
      const formData: any = new FormData();
      const xhr = new XMLHttpRequest();

      formData.append('file', file);
      xhr.onreadystatechange = () => {
        if (xhr.readyState === 4) {
          console.log('status is 4');
          if (xhr.status === 200 || xhr.status === 201) {
            console.log(xhr.response, 'IF xhr status is 200');
            resolve(xhr.response);
          } else if (xhr.status !== 200 && xhr.status !== 201) {
            console.log(xhr.response, 'else if xhr');
            reject(xhr.response);
          }
        }
      }

      const token = localStorage.getItem('authToken');
      xhr.open('POST', url_new, true);
      xhr.setRequestHeader('auth_token', token);
      xhr.send(formData);
    });
  }

  deleteCampaign(uuid: string) {

    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.delete(this.baseurl + '/campaign/' + uuid, options).map(
      (response: Response) => response);
  }
}
;
