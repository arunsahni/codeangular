
import {
  Injectable
} from '@angular/core';
import {
  Http,
  Headers,
  RequestOptions,
  Response
} from '@angular/http';
import {
  Observable
} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {
  User
} from '../models/index';
import {
  AppConfig
} from '../app.config';
// import {auditTime} from "rxjs/operator/auditTime";
import {Router, CanActivate} from '@angular/router';
import {GlobalService} from '../global';

@Injectable()
export class UserService {
  baseurl: any;

  constructor(private http: Http, private config: AppConfig, private router: Router, private base_path_Service: GlobalService) {
    this.baseurl = config.apiUrl;
    this.logout();
    this.login('dgfjsf');
    this.base_path_Service.dummyObs.subscribe(res => {
      console.log('Called Changes', this.base_path_Service.dummyObsCounter);
      this.logout();
    });
  }

  createAuthorizationHeader(headers: Headers) {
    const token = localStorage.getItem('authToken');
    headers.append('Content-Type', 'application/json');
    headers.append('auth_token', token);
  }

  login(user: any) {
    return this.http.post(this.baseurl + '/user/login', user).map(
      (response: Response) => {
        const user = response.json();
        if (user) {
          const loginTime = new Date().getTime() + ((parseInt(user.expiresInSeconds) * 1000));
          localStorage.setItem('expiresInSeconds', JSON.stringify(loginTime));
          localStorage.setItem('authToken', user.authToken);
        }
      });
  }

  logout() {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    console.log('this.baseurl', this.baseurl, options);
    const url = this.baseurl + '/user/logout';
    return this.http.get(url, options).map(
      (response: Response) => {
        console.log('inside logout', response);
      });
  }

}
