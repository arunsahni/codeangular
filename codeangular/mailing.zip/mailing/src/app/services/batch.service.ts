
import {
  Injectable
} from '@angular/core';
import {
  Http,
  Headers,
  RequestOptions,
  Response
} from '@angular/http';
import {
  Observable
} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {
  Batch
} from '../models/index';
import {
  AppConfig
} from '../app.config';

@Injectable()

export class BatchService {
  baseurl: any;

  constructor(private http: Http, private config: AppConfig) {
    this.baseurl = config.apiUrl;
  }

  createAuthorizationHeader(headers: Headers) {
    const token = localStorage.getItem('authToken');
    headers.append('Content-Type', 'application/json');
    headers.append('auth_token', token);
  }

  saveBatch(batch: Batch) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    const batchName = batch.name;
    return this.http.post(this.baseurl + '/customer/save/?batchName=' + batchName, batch.customers, options).map(
      (response: Response) => response);
  }

  updateBatch(batch: Batch) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    const batchName = batch.name;
    return this.http.post(this.baseurl + '/customer/save/?batchName=' + batchName, batch.customers, options).map(
      (response: Response) => response);
  }

  batchList() {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.get(this.baseurl + '/batch/all', options).map(
      (response: Response) => response.json());
  }

  getBatchByName(batchName: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.get(this.baseurl + '/batch/' + batchName, options).map(
      (response: Response) => response.json());
  }
  deleteBatch(batchName: string) {
    const headers = new Headers();
    this.createAuthorizationHeader(headers);
    const options = new RequestOptions({headers: headers});
    return this.http.delete(this.baseurl + '/batch/' + batchName, options).map(
      (response: Response) => response);
  }
}
;
