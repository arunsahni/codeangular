
import {Observable} from 'rxjs/Rx';
import * as Rx from 'rxjs/Rx';
import 'rxjs/add/observable/of';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';

export class GlobalService {
  loginCheck: Rx.Subject<any> = new Rx.Subject<any>();
  public loggedIn: boolean;

  dummyObs: Rx.Subject<any> = new Rx.Subject<any>();
  public dummyObsCounter = 1;
}
