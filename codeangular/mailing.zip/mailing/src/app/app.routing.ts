import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {CampaignComponent} from './components/campaign/campaigns/campaigns.component';
import {CampaignViewComponent} from './components/campaign/campaign/campaignDetails.component';
import {WizardComponent} from './components/wizard/wizard.component';
import {HomeComponent} from './components/home/home.component';
import {BatchComponent} from './components/batch/addBatch/batch.component';
import {BatchesComponent} from './components/batch/batchesList/batches.component';
import {BatchViewComponent} from './components/batch/batchDetails/batchDetails.component';
import {SendMailComponent} from './components/sendMail/sendMail.component';
import {EditBatchComponent} from './components/batch/editBatch/editBatch.component';
import {EditCampaignComponent} from './components/campaign/editCampaign/editCampaign.component';
import {LoginComponent} from './components/login/login.component';
import {CreateCampaignComponent} from './components/campaign/createCampaign/createCampaign.component';
import {ModalComponent} from './shared/modalwindow/modal.component';
import {ChecktokenService} from './services/index';


const appRoutes: Routes = [
  {path: '', redirectTo: 'login', pathMatch: 'full'},
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent},
  {path: 'campgians', component: CampaignComponent, canActivate: [ChecktokenService]},
  {path: 'campgiandetails/:id', component: CampaignViewComponent, canActivate: [ChecktokenService]},
  {path: 'createcampaign', component: CreateCampaignComponent, canActivate: [ChecktokenService]},
  {path: 'editcampaign/:id', component: EditCampaignComponent, canActivate: [ChecktokenService]},

  {path: 'batches', component: BatchesComponent, canActivate: [ChecktokenService]},
  {path: 'batchdetails/:name', component: BatchViewComponent, canActivate: [ChecktokenService]},
  {path: 'addbatch', component: BatchComponent, canActivate: [ChecktokenService]},
  {path: 'editbatch/:name', component: EditBatchComponent, canActivate: [ChecktokenService]},
  {path: 'sendmail', component: SendMailComponent, canActivate: [ChecktokenService]},
  {path: 'modal', component: ModalComponent}
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
