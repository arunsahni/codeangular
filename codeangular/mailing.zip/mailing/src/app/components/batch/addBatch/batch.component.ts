import {Component, OnInit} from '@angular/core';
import {CustomerService, BatchService} from '../../../services/index';
import {Router} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';

@Component({
  selector: 'app-addbatch',
  styleUrls: ['./batch.component.css'],
  templateUrl: './batch.component.html',
  providers: [CustomerService, BatchService]
})

export class BatchComponent implements OnInit {
  // Intializations
  data: any = {};
  customers: any;
  batchCustomers: any = [];

  // constructor
  constructor(private customerService: CustomerService, private batchService: BatchService, private router: Router,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {

  }

  // To Save Batch
  saveBatch(batch) {
    const emails = batch.emails.split(',');
    for (let i = 0; i < emails.length; i++) {
      const object = {
        email: emails[i]
      };
      this.batchCustomers.push(object);
    }
    batch.customers = this.batchCustomers;
    this.batchService.saveBatch(batch)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'saved successfully.',
            timeout: 6000
          };
          this.toastyService.success(toastOptions);
          this.router.navigate(['batches']);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: JSON.parse(error._body).error || error._body,
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }
}
