import {Component, OnInit} from '@angular/core';
import {CustomerService, BatchService} from '../../../services/index';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';

@Component({
  selector: 'app-editbatch',
  styleUrls: ['./editBatch.component.css'],
  templateUrl: './editBatch.component.html',
  providers: [CustomerService, BatchService]
})

export class EditBatchComponent implements OnInit {
  // Intializations
  data: any = {};
  customers: any;
  batchCustomers: any = [];
  newCustomers: any = [];
  params: any;
  // constructor
  constructor(private customerService: CustomerService, private batchService: BatchService, private router: Router,
              private route: ActivatedRoute, private toastyService: ToastyService,
              private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.params = this.route.params.subscribe(param => {
      this.batchDetails(param['name']);
    });
  }

  // To fetch batch details
  batchDetails(batchName) {
    this.batchService.getBatchByName(batchName)
      .subscribe(
        data => {
          this.data = data;
          for (let i = 0; i < data.customers.length; i++) {
            this.batchCustomers.push(this.data.customers[i].email);
          }
          this.data.emails = this.batchCustomers;
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body.error || error._body,
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }

  // To update batch
  updateBatch(batch) {
    const emails = batch.emails.split(',');
    for (let i = 0; i < emails.length; i++) {
      const object = {
        email: emails[i]
      };
      this.newCustomers.push(object);
    }
    batch.customers = this.newCustomers;
    this.batchService.updateBatch(batch)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'updated successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
          this.router.navigate(['batches']);
        },
        error => {
          const msg = error._body || 'Something Wrong.';
          const toastOptions: ToastOptions = {
            title: '',
            msg: msg,
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }
}
