
import {Component, OnInit} from '@angular/core';
import {BatchService} from '../../../services/index';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';
@Component({
  selector: 'app-batchdetails',
  styleUrls: ['./batchDetails.component.css'],
  templateUrl: './batchDetails.component.html',
  providers: [BatchService]
})

export class BatchViewComponent implements OnInit {
  // Intializations
  params: any;
  batch: any = {};
  public data;
  public filterQuery = '';
  public rowsOnPage = 5;
  public sortBy = 'email';
  public sortOrder = 'asc';

  // constructor
  constructor(private batchService: BatchService, private router: Router, private route: ActivatedRoute,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.params = this.route.params.subscribe(param => {
      this.batchDetails(param['name']);
    });
  }

  // To Fetch batch details
  batchDetails(batchName) {
    this.batchService.getBatchByName(batchName)
      .subscribe(
        data => {
          this.data = data.customers;
          this.batch = data;
        },
        error => {
        });
  }
}
