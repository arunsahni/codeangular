import {Component, OnInit} from '@angular/core';
import {BatchService} from '../../../services/index';
import {Router} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';
@Component({
  selector: 'app-batches',
  styleUrls: ['./batches.component.css'],
  templateUrl: './batches.component.html',
  providers: [BatchService]
})

export class BatchesComponent implements OnInit {
  // Intializations
  public data;
  public filterQuery = '';
  public rowsOnPage = 5;
  public sortBy = 'email';
  public sortOrder = 'asc';
  batchName: any;
  // constructor
  constructor(private batchService: BatchService, private router: Router,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.batchList();
  }

  // To Fetch all batches
  batchList() {
    this.batchService.batchList()
      .subscribe(
        data => {
          this.data = data;
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'get data successfully',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
        });
  }

  // To view details of a batch
  viewDetails(item) {
    this.router.navigate(['batchdetails/' + item.name]);
  }

  // Navigate to edit any batch
  edit(item) {
    this.router.navigate(['editbatch/' + item.name]);
  }
  // To get name of batch to delete batch
  getValue(name) {
    this.batchName =  name;
  }
  // To delete batch
  deleteBatch() {
    const batchName = this.batchName;
    this.batchService.deleteBatch(batchName)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'Batch deleted successfully.',
            timeout: 5000
          };
          this.batchList();
          this.toastyService.success(toastOptions);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body || JSON.parse(error._body),
            timeout: 5000
          };
          this.toastyService.error(toastOptions);
        });
  }
  // private functions
  public toInt(num: string) {
    return +num;
  }

  public sortByWordLength = (a: any) => {
    return a.city.length;
  }

}
