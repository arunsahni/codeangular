import {
  Component,
  OnInit
} from '@angular/core';

import {CustomerService, CampaignService, BatchService} from '../../services/index';
import {
  Observable
} from 'rxjs/Rx';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../shared/toast/toast-communication.service';

@Component({
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.css'],
  providers: [CustomerService, CampaignService, BatchService]
})
export class WizardComponent implements OnInit {
  // Intializations
  file: any = null;
  customers: any;
  uuid: any;
  batchData: any = [];
  step2: any = {
    showNext: true,
    showPrev: true
  };
  step3: any = {
    showSecret: false
  };

  customer: any = {
    email: ''
  };
  campaign: any = {};
  campCustomer: any = [];

  isCompleted = false;
  isSelected = false;
  // constructor
  constructor(private customerService: CustomerService,
              private campaignService: CampaignService,
              private batchService: BatchService,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {

    this.customers = [];
  }

  ngOnInit() {
    this.loadAllCustomers();
  }

  onStep1Next(event) {
    this.campCustomer = this.customers.filter(data => data.isChecked === true);
  }

  isSelectedCustomer() {
    this.campCustomer = this.customers.filter(data => data.isChecked === true);
    if (this.campCustomer.length === 0) {
      this.isSelected = false;
    } else {
      this.isSelected = true;
    }
  }

  onStep2Next(event) {
  }

  onStep3Next(event) {
  }

  onComplete(event) {
    this.isCompleted = true;
  }

  onStepChanged(step) {
  }

  // to load customers
  private loadAllCustomers() {
    this.customerService.getCustomers().subscribe(customers => {
      customers.forEach(data => data.isChecked = false);
      this.customers = customers;
    });
  }

  // Save customer
  saveCustomer(customer) {
    // Check if email already exists
    let isExists: any;
    isExists = this.customers.filter((data) => data.email === customer.email).length > 0;
    if (!isExists) {
      this.customerService.saveCustomer(customer)
        .subscribe(
          data => {
            this.loadAllCustomers();
            const toastOptions: ToastOptions = {
              title: '',
              msg: 'saved successfully',
              timeout: 5000
            };
            this.toastyService.success(toastOptions);
          },
          error => {
            const toastOptions: ToastOptions = {
              title: '',
              msg: error._body,
              timeout: 5000
            };
            this.toastyService.error(toastOptions);
          });
      this.customer = {};
    } else {
      // Change message
      // this.alertService.success("Already exists");
    }
  }

  // to push customers in array as per selection
  saveCampaignCustomer(customer) {
    this.campCustomer.push({
      customer: customer
    });
  }

  // to save campaigns
  saveCampaign(campaign) {
    campaign.campaignCustomers = this.campCustomer;
    this.campaignService.saveCampaign(campaign)
      .subscribe(
        data => {
          this.uuid = data.json().uuid;
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body,
            timeout: 5000
          };
          this.toastyService.error(toastOptions);
        });
  }

  // to upload file
  selectFile($event): void {
    let inputValue: any;
    inputValue = $event.target;
  }

  // to send mail
  sendmail() {
    this.campaignService.SendMails(this.uuid)
      .subscribe(
        data => {
          this.campCustomer = [];
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body,
            timeout: 5000
          };
          this.toastyService.error(toastOptions);
        });
  }

  // to delete customer
  remove(customerUuid) {
    this.customerService.deleteCustomer(customerUuid)
      .subscribe(
        data => {
          this.loadAllCustomers();
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'deleted successfully',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
          const msg = JSON.parse(error._body);
          const toastOptions: ToastOptions = {
            title: '',
            msg: msg.error,
            timeout: 5000
          };
          this.toastyService.error(toastOptions);
        });
  }
}
;
