import {Component, OnInit} from '@angular/core';
import {CampaignService, BatchService} from '../../services/index';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../shared/toast/toast-communication.service';
import {GlobalService} from '../../global';
import {UserService} from '../../services/index';
@Component({
  selector: 'app-login',
  styleUrls: ['./login.component.css'],
  templateUrl: './login.component.html',
  providers: [CampaignService, BatchService]
})

export class LoginComponent implements OnInit {
  // Intializations
  data: any = {};
  // constructor
  constructor(private campaignService: CampaignService, private batchService: BatchService, private router: Router,
              private route: ActivatedRoute, private toastyService: ToastyService,
              private toastCommunicationService: ToastCommunicationService,
              private base_path_Service: GlobalService, private userService: UserService) {
  }

  // On Init
  ngOnInit() {
  }

  // To login
  login(credentials) {
    this.userService.login(credentials)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'login successfully',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
          this.router.navigate(['campgians']);
          this.base_path_Service.loginCheck.next(true);
        },
        error => {
          const msg = JSON.parse(error._body).message || error._body;
          const toastOptions: ToastOptions = {
            title: '',
            msg: msg,
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }
}
