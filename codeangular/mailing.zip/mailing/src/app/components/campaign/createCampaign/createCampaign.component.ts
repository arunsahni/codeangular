import {Component, OnInit} from '@angular/core';
import {CampaignService} from '../../../services/index';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';

@Component({
  selector: 'app-createcampaign',
  styleUrls: ['./createCampaign.component.css'],
  templateUrl: './createCampaign.component.html',
  providers: [CampaignService]
})

export class CreateCampaignComponent implements OnInit {
  // Intializations
  data: any = {};
  file: any = '';
  mailTemplate: any;
  // constructor
  constructor(private campaignService: CampaignService, private router: Router,
              private route: ActivatedRoute, private toastyService: ToastyService,
              private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
  }

// To upload file
  uploadCampaignTemplate($event): void {
    let inputValue: any;
    inputValue = $event.target;
    this.file = inputValue.files[0];
    console.log('selected file :', this.file);
    this.campaignService.uploadCampaignTemplate(this.file)
      .subscribe(
        data => {
          this.mailTemplate = JSON.parse(data);
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'Template uploaded successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: JSON.parse(error._body).error || error._body || JSON.parse(error._body),
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }

  // To save campaign
  saveCampaign(campaign) {
    campaign.mailTemplate = this.mailTemplate;
    this.campaignService.saveCampaign(campaign)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'saved successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
          this.router.navigate(['campgians']);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body || JSON.parse(error._body),
            timeout: 10000
          };
          this.toastyService.error(toastOptions);
        });
  }
}
