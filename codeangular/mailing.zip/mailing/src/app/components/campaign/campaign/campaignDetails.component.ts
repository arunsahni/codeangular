
import {Component, OnInit} from '@angular/core';
import {CampaignService} from '../../../services/index';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';
@Component({
  selector: 'app-campgiandetails',
  styleUrls: ['./campaignDetails.component.css'],
  templateUrl: './campaignDetails.component.html',
  providers: [CampaignService]
})

export class CampaignViewComponent implements OnInit {
  // Intializations
  params: any;
  campaign: any = {};
  public data;
  public filterQuery = '';
  public rowsOnPage = 5;
  public sortBy = 'email';
  public sortOrder = 'asc';

  // constructor
  constructor(private campaignService: CampaignService, private router: Router, private route: ActivatedRoute,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.params = this.route.params.subscribe(param => {
      this.campagianDetails(param['id']);
    });
  }

  // On fetch any campaign
  campagianDetails(params) {
    this.campaignService.getCampaignByUuid(params)
      .subscribe(
        data => {
          this.data = data.campaignCustomers;
          this.campaign = data;
        },
        error => {
        });
  }
}
