import {Component, OnInit} from '@angular/core';
import {CampaignService, BatchService} from '../../../services/index';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';

@Component({
  selector: 'app-editcampaign',
  styleUrls: ['./editCampaign.component.css'],
  templateUrl: './editCampaign.component.html',
  providers: [CampaignService, BatchService]
})

export class EditCampaignComponent implements OnInit {
  // Intializations
  data: any = {};
  customers: any;
  campaignCustomers: any = [];
  params: any;
  file: any;
  mailTemplate: any;
  // constructor
  constructor(private campaignService: CampaignService, private batchService: BatchService, private router: Router,
              private route: ActivatedRoute, private toastyService: ToastyService,
              private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.params = this.route.params.subscribe(param => {
      this.CampaignDetails(param['id']);
    });
  }

  // To fetch any campaign
  CampaignDetails(uuid) {
    this.campaignService.getCampaignByUuid(uuid)
      .subscribe(
        data => {
          this.data = data;
          console.log('edit data:', this.data);
          this.mailTemplate = this.data.mailTemplate;
          if (data.campaignCustomers.length > 0) {
            for (let i = 0; i < data.campaignCustomers.length; i++) {
              this.campaignCustomers.push(this.data.campaignCustomers[i].email);
            }
            this.data.emails = this.campaignCustomers;
          } else {
            this.data.emails = [];
          }
        },
        error => {
          const msg = JSON.parse(error._body).error || error._body;
          const toastOptions: ToastOptions = {
            title: '',
            msg: msg,
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }

  // to upload file
  uploadCampaignTemplate($event): void {
    let inputValue: any;
    inputValue = $event.target;
    this.file = inputValue.files[0];
    console.log('selected file :', this.file);
    this.campaignService.uploadCampaignTemplate(this.file)
      .subscribe(
        data => {
          this.mailTemplate = JSON.parse(data);
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'Template uploaded successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: JSON.parse(error._body).error || error._body || JSON.parse(error._body),
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }

  // To update campaigns
  updateCampaign(campaign) {
    campaign.mailTemplate = this.mailTemplate;
    this.campaignService.updateCampaign(campaign)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'updated successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
          this.router.navigate(['campgians']);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body || JSON.parse(error._body).error || JSON.parse(error._body),
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
        });
  }
}
