import {Component, OnInit} from '@angular/core';
import {CampaignService} from '../../../services/index';
import {Router} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../../shared/toast/toast-communication.service';
@Component({
  selector: 'app-campgians',
  styleUrls: ['./campaigns.component.css'],
  templateUrl: './campaigns.component.html',
  providers: [CampaignService]
})

export class CampaignComponent implements OnInit {
  // Intializations
  public data;
  public filterQuery = '';
  public rowsOnPage = 5;
  public sortBy = 'email';
  public sortOrder = 'asc';
  campaignUuid: any;
  // constructor
  constructor(private campaignService: CampaignService, private router: Router,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.campagianList();
  }

  // To fetch all campaign
  campagianList() {
    this.campaignService.campagianList()
      .subscribe(
        data => {
          this.data = data;
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'get data successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
        });
  }

  // To view details of any campaigns
  viewDetails(item) {
    this.router.navigate(['campgiandetails/' + item.uuid]);
  }

  // Navigate to edit any campaigns
  edit(item) {
    this.router.navigate(['editcampaign/' + item.uuid]);
  }
  // To get uuid of campaign to delete
  getValue(uuid) {
    this.campaignUuid =  uuid;
  }
// To delete campaign
  deleteCampaign() {
    const uuid = this.campaignUuid;
    console.log(uuid, 'uuid')
    this.campaignService.deleteCampaign(uuid)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'Campaign deleted successfully.',
            timeout: 5000
          };
          this.campagianList();
          this.toastyService.success(toastOptions);
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body || JSON.parse(error._body),
            timeout: 5000
          };
          this.toastyService.error(toastOptions);
        });
  }
  // Private functions
  public toInt(num: string) {
    return +num;
  }

  public sortByWordLength = (a: any) => {
    return a.city.length;
  }

}
