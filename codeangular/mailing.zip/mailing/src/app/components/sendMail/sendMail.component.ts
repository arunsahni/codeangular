import {Component, OnInit} from '@angular/core';
import {CampaignService, BatchService} from '../../services/index';
import {Router} from '@angular/router';
import {ToastyService, ToastyConfig, ToastOptions, ToastData} from 'ng2-toasty';
import {ToastCommunicationService} from '../../shared/toast/toast-communication.service';
declare var jQuery: any;
@Component({
  selector: 'app-sendmail',
  styleUrls: ['./sendMail.component.css'],
  templateUrl: './sendMail.component.html',
  providers: [CampaignService, BatchService]
})

export class SendMailComponent implements OnInit {
  // Intializations
  campgianData: any = [];
  batchData: any = [];
  selectedBatch: any;
  selectedCampaign: any;
  data: any = [];

  // constructor
  constructor(private campaignService: CampaignService, private batchService: BatchService, private router: Router,
              private toastyService: ToastyService, private toastCommunicationService: ToastCommunicationService) {
  }

  // On Init
  ngOnInit() {
    this.batchList();
    this.campagianList();
  }

  // To fetch batches
  batchList() {
    this.batchService.batchList()
      .subscribe(
        data => {
          this.batchData = data;
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'get data successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
        });
  }

  // To fetch batch details
  batchDetails(batchName) {
    this.batchService.getBatchByName(batchName)
      .subscribe(
        data => {
          this.data = data.customers;
        },
        error => {
        });
  }

  // To fetch data in modal as per batch
  send(selectedCampaign) {
    console.log(selectedCampaign, 'selectedCampaign');
    this.batchDetails(selectedCampaign);
  }

  // To fetch campaigns
  campagianList() {
    this.campaignService.campagianList()
      .subscribe(
        data => {
          this.campgianData = data;
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'get data successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
        },
        error => {
        });
  }

  // To send mail to selected batch
  SendMailBatch(batch, campgian) {
    console.log(batch, campgian, 'batch & ');
    this.campaignService.SendMailBatch(batch, campgian)
      .subscribe(
        data => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: 'sent mail successfully.',
            timeout: 5000
          };
          this.toastyService.success(toastOptions);
          this.router.navigate(['batches']);
          // jQuery('#myModal').modal('hide');
        },
        error => {
          const toastOptions: ToastOptions = {
            title: '',
            msg: error._body || JSON.parse(error._body).error || JSON.parse(error._body).message,
            timeout: 7000
          };
          this.toastyService.error(toastOptions);
          // jQuery('#myModal').modal('hide');
        });
  }
}
