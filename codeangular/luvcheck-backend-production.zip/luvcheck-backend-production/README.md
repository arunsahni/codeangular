# README #


### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact


#####
* clone repo: git clone https://vedp@bitbucket.org/luvcheck/luvcheck-backend.git
* go to root folder: npm install
*On MacOS or Linux, run the app with this command:DEBUG=luvcheck-backend:* npm start
* On Windows, use this command to run
:set DEBUG=luvcheck-backend:* & npm start
or npm start

![Screenshot](screenshot.png)
