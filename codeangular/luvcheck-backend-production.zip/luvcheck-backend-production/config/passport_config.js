
module.exports = {
    'secret': 'luvcheckBackendo9+H7b3f3o7V`}1r76y/9*b8OBR~94'
};
