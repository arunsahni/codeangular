
// var JwtStrategy = require('passport-jwt').Strategy;

// load up the user model
// var User = require('../app/models/users');
// var config = require('./passport_config'); // get passport config file
//
// module.exports = function(passport) {
//   var opts = {};
//   opts.secretOrKey = config.secret;
//   opts.exp = '1s';
//   passport.use('jwt',new JwtStrategy(opts, function(jwt_payload, done) {
//       console.log(jwt_payload,"hpaylload");
//       return done(null,jwt_payload);
//   }));
// };


