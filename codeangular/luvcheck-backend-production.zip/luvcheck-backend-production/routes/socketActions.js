/**
 * Created by ved on 16/7/17.
 */

var User = require('../app/models/users');
var Rpi = require('../app/controllers/rpi');
var Invitation = require('../app/models/invitations');
var Call = require('../app/models/call.js');
var timeoutInstance = null;
var reAttemptTimer = null;
var Notifications = require('../app/models/notifications.js');
var currentPowerStatus = null;


function notifyContacts(io,fromUser,toUser){
    console.log(fromUser[0].uid,"toUser");
    try{
        io.in(fromUser[0].uid).emit('contacts', toUser)
    }catch(e) {
        console.log(e,'invitationReceived');
    }
}

function notifySentInvitationContact(io,toUser,fromUser) {
console.log(toUser,"toUser");
console.log(fromUser,"fromUser");
    try{
        io.in(toUser).emit('invitationReceived',fromUser);
    }catch(e) {
        console.log(e,'invitationReceived');
    }
}

function notifyInvitationAcceptedContact(io,toUser,fromUser) {
    try{
        io.in(toUser).emit('invitationAccepted',fromUser);
    }catch(e) {
        console.log(e,'invitationAccepted');
    }
}

function notifyDeletedContact(io,toUser,fromUser) {
    try{
        io.in(toUser).emit('connectionDeleted',fromUser);
    }catch(e) {
        console.log(e,'connectionDeleted');
    }
}

function notifyMakeCall(io,fromUser,toUser,callType, activeCall, callback, socket, callerSockets) {
    var msg = "";
    // console.log(fromUser,"fromUser");
    // console.log(toUser,"toUser");
    // console.log(callType,"callType");

    if(!toUser.uid ){
        msg = "No participants";
        io.in(fromUser.uid).emit('MakeCallError',msg);

    } else {
        try{
            reAttemptTimer = true;
            User.findOne({uid:fromUser.uid},{friendList:1},function(err,success) {
                if(err) {
                    console.log(err,"1")
                    msg = "Something went wrong. Please try again";
                    io.in(fromUser.uid).emit('MakeCallError',msg);
                }else {
                    var to = null;
                    if(success && success.friendList.length > 0){
                        to =  success.friendList.filter(function(friend) {
                            return friend.uid == toUser.uid;
                        })
                    }else {
                        console.log("2");
                        msg = "You don't have any contacts";
                        io.in(fromUser.uid).emit('MakeCallError',msg);
                    }
                    if(to.length > 0){
                        var obj = {};
                        obj.fromUser = fromUser.uid;
                        obj.toUser = [toUser.uid];
                        obj.startsAt = new Date().getTime();
                        obj.status = "pending";
                        Call(obj).save(function (err,response){
                            if(err){
                                console.log("err3",err);
                            }else {
                                var callInfo = generateCallInfo(fromUser,response);


                                Rpi.power_status(function (response){

                                    try{
                                        // response = JSON.parse(response);
                                        // currentPowerStatus = response.power_status;
                                        // if(response.power_status === 'on'){
                                        //     Rpi.change_hdmi_2(function (response1){
                                        //         if(response1.status){
                                        //             console.log("HDMI @ is 2",response1)
                                        //         }
                                        //     })
                                        // }else {
                                            Rpi.switch_on_tv(function (response2) {
                                                // if(response2.status){
                                                    Rpi.change_hdmi_2(function (response3){
                                                        console.log("HDMI @ is 2",response3)
                                                    })
                                                // }
                                            });
                                        // }
                                    }catch(e){
                                        console.log("RPI ERROR",e)
                                    }

                                });

                                function re_emit() {
                                    var clients = io.sockets.adapter.rooms[toUser.uid];
                                    // console.log(clients,"Reattempt");
                                    var interval = null;

                                    if(io.sockets.adapter.rooms[toUser.uid]){
                                        if(interval){
                                            clearTimeout(interval);
                                        }
                                        io.in(toUser.uid).emit('incomingCall', {
                                            roomInfo: callInfo,
                                            from:fromUser
                                        });
                                    }else {
                                        // console.log(reAttemptTimer,"reAttemptTimer")
                                        if(reAttemptTimer){
                                            interval  = setTimeout(function (){
                                                re_emit();

                                            },1000)
                                        }
                                    }
                                }

                              re_emit();


                                callback({success: true, roomInfo: callInfo, toUser: to, fromUser: fromUser});

                                timeoutInstance =  setTimeout(function () {
                                    reAttemptTimer = false;
                                    Call.findOne({_id:response._id},function (err,call){
                                        if(err) {
                                            console.log(err,"err4")
                                        }else {
                                            if (call.status == 'pending') {
                                                call.status = 'missed';
                                                call.save(function (err, call) {
                                                    if (!err) {
                                                        io.in(toUser.uid).emit('missedCall', fromUser);
                                                        io.in(fromUser.uid).emit('callResponse', {
                                                            status: 'missed',
                                                            data:toUser
                                                        });
                                                    }
                                                })
                                            }
                                        }
                                    })
                                },60*1000);
                            }
                        })
                    }else {
                        msg = "participants is not in your contact list";
                        io.in(fromUser.uid).emit('MakeCallError',msg);
                    }
                }
            })
        }catch(e) {
            console.log(e)
        }
    }
}

function reAttemptCall(io) {

}

function notifyAnswerCall(io, fromUser, callId, response, activeCall, socket, callerSockets) {

    if(!callId ||!fromUser){

      return  console.log("data missing")
    }

    Call.findOne({_id: callId}, function (err, call) {
        if(err) {
            console.log(err,"err");
        }else {
            if(response==='answered') {
                try {
                    console.log("answered");
                    clearTimeout(timeoutInstance);
                    // var callerSocket = callerSockets[call._id];
                    // delete callerSocket[call._id]

                    call.status = response;
                    call.save(function (err,answeredCall) {
                        if(!err){
                            console.log(answeredCall.fromUser,"answeredCall.fromUser");
                            var obj = {to:answeredCall.fromUser,from:fromUser};
                            io.in(answeredCall.fromUser).emit('callStarted',obj);
                            io.in(fromUser.uid).emit('callStarted',obj);

                        }
                    })
                }catch(e) {
                    console.log(e,"answered");
                }

            }else if(response==='rejected'){
                try {
                    clearTimeout(timeoutInstance);
                    reAttemptTimer = false;
                    call.status = response;
                    call.save(function (err,answeredCall) {
                        if(!err){
                            io.in(answeredCall.fromUser).emit('rejectedCall');
                            io.in(fromUser.uid).emit('rejectedCall');
                        }
                    })
                }catch(e) {
                    console.log(e,'rejected')
                }

            }
        }
    })
}


function notifyEndCall(io, data) {
    try{
        Call.findOne({_id: data.callId}, function (err, call) {
            call.status = call.status==='pending'?'missed':'completed';
            call.end = new Date().getTime();
            call.save(function (err,response){
                if(err) {
                    console.error('ERROR!');
                } else {
                    console.log("call ended successfully");
                    clearTimeout(timeoutInstance);
                    reAttemptTimer = false;
                    Rpi.change_hdmi_1();
                    io.in(call.toUser[0]).emit('callEnded');

                    // if(currentPowerStatus==='on'){
                    //     Rpi.switch_on_tv();
                    // }else {
                    //
                    //
                    // }


                }
            });
            console.log('CALL OFFICIALLY ENDED AND LOGGED');
        })
    }catch(e) {
        console.log(e,"notifyEndCall");
    }
}

function notifyToFriends(io,user,status) {
    try{
        if(!user.uid){
            User.findOne({uid:user.uid},{friendList:1},function (err,user){
                if(!err){
                    var friendUid = user.friendList &&
                    user.friendList.length > 0?
                        user.friendList.map(function(users){
                            return users.uid;
                        }):[];
                    if(friendUid.length > 0){
                        if(status==='offline'){
                            user.active = false;
                            user.lastSeen = new Date().getTime();
                            user.save(function (err,success){
                                if(!err){
                                    friendUid.forEach(function (uid){
                                        io.in(uid).emit(status,user);
                                    })
                                }
                            });
                        }else {
                            friendUid.forEach(function (uid){
                                io.in(uid).emit(status,user);
                            })
                        }

                    }
                }
            })
        }
    }catch(e) {
        console.log('notifyToFriends error',e);
    }
}


function generateCallInfo(data,call) {
    return {
        roomId: data.uid+"videoroom"+data._id,
        callId: call._id
    };
}

exports.notifyContacts = notifyContacts;
exports.notifySentInvitationContact = notifySentInvitationContact;
exports.notifyInvitationAcceptedContact = notifyInvitationAcceptedContact;
exports.notifyDeletedContact = notifyDeletedContact;
exports.notifyEndCall = notifyEndCall;
exports.notifyMakeCall = notifyMakeCall;
exports.notifyAnswerCall = notifyAnswerCall;
exports.notifyToFriends = notifyToFriends;