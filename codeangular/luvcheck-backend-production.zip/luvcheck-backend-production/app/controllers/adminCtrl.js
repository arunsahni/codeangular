
var Admin = require('../models/admin.js');
var Mail = require('../models/SendMail.js');
var SMS = require('../models/SendSms.js');
var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var Promise = require("bluebird");
var jwt = require('jwt-simple');
var fs = require('fs');
var formidable = require("formidable");

var Constant = require('../../config/constants');


/*________________________________________________________________________
 * @Date:       02 July,2017
 * @Method :    viewAdmins
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to view list.
 _________________________________________________________________________
 */

var viewAdmins = function (req, res) {
    Admin.find({isDeleted: false}, {}, function (err, result) {
        if (err) {
            res.send(400, err);
        } else {
            res.status(200).json(result);
        }
    });
};


/*________________________________________________________________________
 * @Date:       02 July,2017
 * @Method :    createAdmin
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to add or register new admin.
 _________________________________________________________________________
 */

var createAdmin = function (req, res) {
    var user = {};
    user = req.body;
    
    if(!user){
        res.send(400,"Something went wrong.");
    }else {
        Admin(user).save(function (err, result) {
            if (err) {
                res.send(400, err);
            } else {
                res.status(200).json(result);
            }
        });
    }
};


/*________________________________________________________________________
 * @Date:       02 July,2017
 * @Method :    deleteAdmin
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to remove a admin.
 _________________________________________________________________________
 */

var deleteAdmin = function (req, res) {
    var fields = {
        isDeleted: true
    };
    var conditions = {
        uid: req.body.uid
    };

    // authy.delete_user(user.authyId, function (err, res) {
    //     if(err) {
    //         res.send(err);
    //     }else {
            Admin.update(conditions, {$set: fields}, function (err, result) {
                if (err) {
                    res.send(400, err);
                } else {
                    res.status(200).json("deleted successfully.");
                }
            });
    //     }
    // })
    
};



//  functions
exports.viewAdmins  = viewAdmins;
exports.createAdmin = createAdmin;
exports.deleteAdmin = deleteAdmin;