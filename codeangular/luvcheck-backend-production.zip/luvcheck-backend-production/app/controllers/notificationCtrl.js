var Notification = require('../models/notifications.js');


var readNotification  = function (req,res) {

    var user = req.user;
    var uid = user.uid;

    Notification.update({to:uid},{$set: {notificationsStatus: "read"}}, {multi: true}).then(function (err,response){
        if(err) {
            console.log("error on notification",err);
            res.status(400).send({msg:"Error Reading Notification"});
        } else {
            console.log("Message read successfully")
        }
    }).catch(function (e){
        console.log(e,"exception error");
        throw new Error('Error Reading Notification');
    })
};


var getNotification = function (req,res) {
    var user = req.user;
    var uid = user.uid;

    Notification.find({$and:[{to:uid},{isDeleted: false},{notificationsStatus:"unread"}]}).sort({createdDate:-1}).limit(5)
        .then(function (err,data){
          if(err){
            res.send(400).send({msg:"Error Reading Notification"});
          }else {
              res.status(200).json(data);
          }
    }).catch(function (e){
        console.log(e,"error");
    })
};


var getAllNotification = function (req,res) {
    var user = req.user;
    var uid = user.uid;

    Notification.find({$and:[{to:uid},{isDeleted: false}]})
        .then(function (err,data){
            if(err){
                res.send(400).send({msg:"Error Reading Notification"});
            }else {
                res.status(200).json(data);
            }
        }).catch(function (e){
        console.log(e,"error")
    })
};


exports.readNotification = readNotification;
exports.getNotification = getNotification;
exports.getAllNotification = getAllNotification;