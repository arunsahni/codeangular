
var User = require('../models/users.js');
var Invitations = require('../models/invitations.js');
var Notifications = require('../models/notifications.js');
var Mail = require('../models/SendMail.js');
var SMS = require('../models/SendSms.js');
var mongoose = require('mongoose');
var SocketActions = require('../../routes/socketActions');


/*________________________________________________________________________
 * @Date:      	29 May,2017
 * @Method :   	sendInvitation
 * Created By: 	Ved Prakash
 * Modified On:	-
 * @Purpose:   	This function is used to send invite to user.
 _________________________________________________________________________
 */

var sendInvitation = function (req, res) {
    var body = req.body;
    var uid = req.user && req.user.uid;

    if(!uid || !body || !body.receiverUid  || !body.email|| !body.phone || !body.countryCode || !body.invitedPersonName) {
        res.status(400).send({msg:"Please provide the complete details"});

    }else {
        if(body.receiverUid === uid){
           res.status(400).send("Error ! you are trying to invite yourself.");
        } else{
                var inviteeData = {
                    receiverUid         : body.receiverUid || '',
                    senderUid           : uid,
                    statusCode          : "pending",
                    invitationType      : "registered"
                };

                var notifyObj = {
                    from:req.user && req.user.profile.name,
                    message:"You have new connection from",
                    to:body.receiverUid
                };
   
                Invitations(inviteeData).save(function (error, data) {
                    if (error) {
                        console.log("error");
                        res.status(400).send(error);
                    } else {
                        var reqData = {
                            invitedPersonName   : body.invitedPersonName,
                            profile       : req.user.profile,
                            senderUid           : uid
                        };
                        
                        if(body.receiverUid){
                            SocketActions.notifySentInvitationContact(req.io,body.receiverUid,reqData);
                        }

                        Notifications(notifyObj).save(function (error, response) {
                            if (error) {
                                console.log("error",error);
                               
                            } else {
                                console.log('Success')
                            }
                        });

                        res.status(200).json({msg: "Invitations sent successfully."});

                        // Mail.sendInvitationMail(req, reqData, function (msg) {
                        //     console.log("Welcome", msg);
                        // });
                        //
                        // SMS.sendInvitationSms(reqData, function (msg) {
                        //     console.log("Welcome", msg);
                        // });

                }
            });    
        }
    }
};


/*________________________________________________________________________
 * @Date:       20 May,2017
 * @Method :    invitedByUserDetail
 * Modified On: -
 * @Purpose:    This function is used .to get detail of user who invitated anyone.
 _________________________________________________________________________
 */
var invitedByUserDetail = function (req, res) {
    var uid = req.user.uid;
    if(!uid){
        res.send(400,"Something went wrong.");

    }else {
        User.findOne({uid: uid},
            { uid: 1,profile:1}, function (err, data) {
                if (err) {
                    res.send(400,err);
                } else{
                    if(data.length === 0){
                        res.send(400,{msg:"No account found with given email or phone"});
                    } else {
                        res.status(200).json(data);
                    }
                }
            });
    }
};

/*________________________________________________________________________
 * @Date:      	29 May,2017
 * @Method :   	invitationStatus
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to save in friend list based on status.
 _________________________________________________________________________
 */

var invitationStatus = function (req, res) {

    var body = req.body;
    var uid = req.user.uid;
    
    if (!body || !body.senderUid ||!uid ||!body.status ){
      return  res.status(400).send({msg:"Please provide the complete details"})
    }

    if(body.status === 'accepted'){
        Invitations.remove({$and:[{senderUid : body.senderUid},{receiverUid : uid}]},
            function (err, obj) {
                if (err) {
                    res.status(400).send({msg:err});
                } else {
                    if(obj.result.n === 0 ) {
                      return  res.status(400).send({msg:'No any pending invitation found from this user'});
                    }else {
                        updateUserContacts(req,res);
                    }
                }
            });
    } else if(body.status === 'rejected'){

        Invitations.update({$and:[{senderUid : body.senderUid},{receiverUid : uid}]}, {$set: {statusCode: body.status}},
            function (err, data) {
                if (err) {
                   return res.status(400).send({msg:err})
                } else {
                    if (data.nModified !== 1) {
                        return  res.status(400).send({msg:"OOPS! Something went wrong. Please try again"})
                    } else {
                        return res.status(200).json({msg:"You have rejected this invitation"});
                    }
                    
                }
            })
    } else {
        return  res.status(400).send({msg:"No status found."});
    }
};

function updateUserContacts(req,res) {

    var body = req.body;
    var uid = req.user.uid;

    var senderUidArray = [body.senderUid];
    console.log(senderUidArray,"senderUidArray");

    User.find({$and: [{uid : uid},{friendList: {'$elemMatch':{uid: senderUidArray}}}]},{}, function (err, friendListData) {
        if (err) {
            console.log(err);
            res.status(400).send({msg:err});
        } else {
            try {
                if (friendListData && friendListData.length === 0) {
                    User.update({uid: uid}, {$push: {friendList: {uid: body.senderUid}}}, function (err, data) {
                        if (err) {
                            return res.status(400).send({msg: err});
                        } else {
                            if (data.nModified !== 1) {
                                res.status(400).send({msg: "OOPS!!! Something went wrong. Please try again"})
                            } else {
                                var invitedPersonUidArray = [uid];
                                User.find({$and: [{uid: body.senderUid}, {friendList: {'$elemMatch': {uid: invitedPersonUidArray}}}]}, {}, function (err, friendListData1) {
                                    if (err) {
                                        return  res.status(400).send({msg: err});
                                    } else {
                                        if (friendListData1 && friendListData1.length === 0) {
                                            User.update({uid: body.senderUid}, {$push: {friendList: {uid: uid}}}, function (err, data2) {
                                                if (err) {
                                                    return res.status(400).send({msg: err})
                                                } else {
                                                    if (data2.nModified !== 1) {
                                                        return res.status(400).send({msg: "OOPS! Something went wrong. Please try again"})
                                                    } else {
                                                        SocketActions.notifyInvitationAcceptedContact(req.io, body.senderUid, req.user);

                                                        var notifyObj = {
                                                            from:req.user && req.user.profile.name,
                                                            message:"You are now connected to",
                                                            to:body.senderUid
                                                        };

                                                        Notifications(notifyObj).save(function (error, response) {
                                                            if (error) {
                                                                console.log("error",error);
                                                            } else {
                                                                console.log('Success')
                                                            }
                                                        });

                                                        return res.status(200).json({msg: "Invitation accepted by you successfully"})
                                                    }
                                                }
                                            })
                                        } else {
                                            return res.status(400).send({msg: "This person is already your friend"})
                                        }
                                    }
                                });
                            }
                        }
                    });
                } else {
                    return res.status(400).send({msg: "This person is already in your contact list"})
                }
            }catch(e) {
                console.log(e)
            }
        }
    });
}

/*________________________________________________________________________
 * @Date:      	17 June,2017
 * @Method :   	sentInvitation
 * Created By:
 * Modified On:	-
 * @Purpose:   	This function is used to see the list of Invitations.
 _________________________________________________________________________
 */

var sentInvitation = function (req, res) {
    var uid = req.user && req.user.uid;
    if(!uid){
        res.status(400).send({msg:"User does not exists."});
    }else {
        Invitations.find({$and: [{senderUid: uid},{isDeleted: false},{statusCode:"pending"}]},
                    {},function (err,result) {
            if(err) {
                return res.status(400).send({msg:err})
            } else if(result && result.length < 1){
                return res.status(200).json({msg:"You don't have sent any invitation"})
            }
            else {
                try{
                    var userUid = [];
                    if(result && result.length > 0){
                        result && result.forEach(function(val) {
                            userUid.push(val.receiverUid);
                        })
                    }
                    User.find({uid:{'$in': userUid}},{friendList:0,authyId:0},function (err,response) {
                        if(err){
                            return  res.status(400).send({msg:err})
                        }else {
                            return  res.status(201).json(response);
                        }
                    })
                }catch(e){
                    console.log(e)
                }
            }
        })
    }
};

/*________________________________________________________________________
 * @Date:      	17 June,2017
 * @Method :   	recevedInvitation
 * Created By:
 * Modified On:	-
 * @Purpose:   	This function is used to see the list of recieved invitation.
 _________________________________________________________________________
 */

var receivedInvitation = function (req, res) {
    var uid = req.user && req.user.uid;
    if(!uid){
        res.status(400).send({msg:"User does not exists."});
    }else {
        Invitations.find({$and: [{receiverUid: uid},{isDeleted: false},{statusCode:"pending"}]},{senderUid: 1}, function (err, result) {
            if (err) {
                res.status(400).send({msg:err});
            }else if(result && result.length < 1){
                res.status(200).json({msg:"You don't have  any pending invitation"})
            } else {
                try {
                    var invited = [];
                    if(result && result.length > 0){
                        result.forEach(function(val) {
                            invited.push(val.senderUid);
                        })
                    }
                    User.find({'uid': {'$in': invited}},{friendList:0,authyId:0}
                        , function (err, response) {
                            if(err){
                                res.status(400).send({msg:err})
                            }else {
                                res.status(201).json(response);
                            }
                        });
                }catch(e){
                    console.log(e);
                }
            }
        })
    }
};


/*________________________________________________________________________
 * @Date:       17 June,2017
 * @Method :    revokeInvitation
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to see the list of revoke invitation.
 _________________________________________________________________________
 */

var revokeInvitation = function (req, res) {
    var uid = req.user && req.user.uid;
    var receiverUid = req.body && req.body.receiverUid;
    if(!uid || !receiverUid){
        res.status(400).send("OOPS! Something went wrong. Please try again")

    }else {
        Invitations.remove( {$and: [{senderUid: uid},{receiver: receiverUid}]}, function (err, result) {
            if (err) {
                res.status(400).send({msg:err});
            }else{
                res.status(200).json("You revoked invitation successfully.");
            }
        });
    }
};

/*________________________________________________________________________
 * @Date:       17 June,2017
 * @Method :    declineInvitation
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to see the list of decline invitation.
 _________________________________________________________________________
 */

var declineInvitation = function (req, res) {
    var uid = req.user.uid;
    if(!uid){
        res.send(400,"User does not exists.");
    }else {
        Invitations.update({receiverUid: uid},
            {$set: {statusCode: 'rejected'}}, function (err, result) {
                if (err) {
                    res.send(400, err);
                }else{
                    res.status(200).json(result);
                }
        });
    }
};

/*________________________________________________________________________
 * @Date:       29 May,2017
 * @Method :    resendInvitation
 * Created By:
 * Modified On: -
 * @Purpose:    This function is used to resend invite to user.
 _________________________________________________________________________
 */

var resendInvitation = function (req, res) {
    console.log("===========================++++++++++++");
    console.log('invited:',req.body);
    var body = req.body;
    var uid = req.user.uid;

    if(!uid || !body || !body.email ||  !body.countryCode || !body.phone || !body.invitedByName || !body.invitedPersonName) {
        res.status(400).send("Please provide the complete details");
    }else {
        var reqData = {
            email               : req.body.email,
            invitedPersonName   : req.body.invitedPersonName,
            invitedByName       : req.body.invitedByName,
            senderUid           : req.user.uid,
            countryCode         : req.body.countryCode,
            phone               : req.body.phone

        };

        res.status(200).json({msg: "Invitations sent successfully."});

        // Mail.resendInvitationMail(req, reqData, function (msg) {
        //     console.log("Welcome", msg);
        // });
        // SMS.resendInvitationSms(reqData, function (msg) {
        //     console.log("Welcome", msg);
        // });

        // Promise.resolve().then(function () {
        //
        // }).then(function (responseMobile) {
        //
        // }).then(function (responseMobile) {
        //
        // });
    }
};


//  functions
exports.sendInvitation = sendInvitation;
exports.invitedByUserDetail = invitedByUserDetail;
exports.invitationStatus = invitationStatus;
exports.sentInvitation = sentInvitation;
exports.receivedInvitation = receivedInvitation;
exports.revokeInvitation = revokeInvitation;
exports.declineInvitation = declineInvitation;
exports.resendInvitation = resendInvitation;
