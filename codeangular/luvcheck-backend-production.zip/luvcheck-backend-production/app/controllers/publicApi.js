
var User = require('../models/users.js');
var Mail = require('../models/SendMail.js');
var SMS = require('../models/SendSms.js');
var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var config = require('../../config/passport_config.js');
var jwt = require('jsonwebtoken');
var fs = require('fs');
var formidable = require("formidable");

var Constant = require('../../config/constants');

var http = require('http');
var io = require('socket.io')(http);

var authy = require('authy')(Constant.twilioCredentials.Authy);
var twilio = require('twilio')(Constant.twilioCredentials.ACCOUNTSID, Constant.twilioCredentials.AUTHTOKEN);

/*________________________________________________________________________
 * @Date:      	9 June,2017
 * @Method :   	SMS
 * Modified On:	-
 * @Purpose:   	This function is used to send otp to user.
 _________________________________________________________________________
 */

function requestAuthySms(id,callback){
    "use strict";
    authy.request_sms(id, function (err, response) {
        callback(err,response);
    });
}


/*________________________________________________________________________
 * @Date:      	18 May,2017
 * @Method :   	Register verification
 * Modified On:	-
 * @Purpose:   	This function is used to send otp to user.
 _________________________________________________________________________
 */


var register = function (req, res) {
    var user =  req.body;
    var profile = user.profile;
    if(!user || !profile.email || !profile.phone ||!profile.countryCode || !profile.name || !user.password || !user.password_confirm) {
        res.status(400).send({msg:"Please provide  all the details"})

    }else if(user.password !== user.password_confirm){
        res.status(400).send({msg:"Password and Confirm Password are not same"});

    } else {
        User.find({$or:[{'profile.phone': profile.phone},{'profile.email': profile.email}]}, function (err,data) {
            if (err) {
                res.status(400).send({msg:err});
            }
            else if(data.length>0){
                res.status(401).send({msg:"USER ALREADY EXIST WITH GIVEN PHONE OR EMAIL"});

            } else {
                authy.register_user(profile.email,profile.phone,profile.countryCode, function (err, response) {
                    if(err){
                        res.status(400).send({msg:err});
                    } else {
                        user.authyId = response.user && response.user.id;
                        requestAuthySms( user.authyId,function (err, result) {
                            if(err) {
                                res.status(400).send({msg:err});
                            } else {
                                result.authyId = user.authyId;
                                res.status(200).json(result);
                            }
                        });
                    }
                });
            }
        })
    }
};


/*________________________________________________________________________
 * @Date:      	21 May,2017
 * @Method :   	verify_register
 * Modified On:	-
 * @Purpose:   	This function is used to verify otp
 _________________________________________________________________________
 */

var verify_register = function (req, res) {
    var userData = req.body;

    if(!userData.otp) {
        res.status(400).send({msg:"Please provide the Security code"});
        
    }else if(!userData.authyId || !userData.profile){
        res.status(400).send({msg:"OOPS! Something went wrong. Please try again"});
    }else {
        authy.verify(userData.authyId,userData.otp, function (err, response) {
            if(err){
                res.status(400).send(err);
            }else{
                console.log(response,"response");
                if(response.success==='true') {
                    userData.profile.email = userData.profile.email.toLowerCase();
                    User(userData).save(function (error, data) {
                        if (error) {
                            console.log("error");
                            res.status(400).send({msg:error});
                        } else {
                            console.log(data,"data of reg");
                            res.status(201).json({msg: "User Registered Successfully."});

                            // Mail.sendWelcomeMail(userData.profile,function (msg){
                            //     console.log("Welcome Email",msg);
                            // });
                            // SMS.sendWelcomeSms(userData.profile,function (msg) {
                            //     console.log("Welcome Sms",msg);
                            // });
                        }
                    });
                }
            }
        });
    }

};

/*________________________________________________________________________
 * @Date:       20 May,2017
 * @Method :    login
 * Modified On: -
 * @Purpose:    This function is used to authenticate user.
 _________________________________________________________________________
 */

var login = function (req, res) {
    var user = req.body;
    if(!user ||!user.username) {
        res.status(400).send({msg:"Please provide valid email/phone and password"});
    } else {
        User.findOne({$or:[{'profile.phone': user.username},{'profile.email': user.username}]},
            {profile: 1, password: 1,uid:1}, function (err,data) {
                if (err) {
                    res.status(400).send({msg:err});
                } else {
                    if (data && data.uid) {

                        bcrypt.compare(user.password,data.password, function (err, result) {
                            if (err) {
                                res.status(400).send({msg:err});
                            } else {
                                if (result === true) {
                                    data.active = true;
                                    data.lastSeen = new Date().getTime();
                                    data.save(function (err,success){
                                        if(!err){
                                            var token = jwt.sign({_id:data._id,uid:data.uid,profile: data.profile}, config.secret);
                                            // to remove password from response.
                                            data = data.toObject();
                                            delete data.password;
                                            res.status(200).json({token: token,data:data});
                                        }
                                    });
                                } else {
                                    res.status(400).send({msg: 'Authentication failed due to wrong details.'});
                                }
                            }
                        });
                    } else {
                        res.status(400).send({msg: 'No account found with given email or phone'});
                    }
                }
            });
    }
};


/*________________________________________________________________________
 * @Date:       26 May,2017
 * @Method :    forgot_password
 * Modified On: -
 * @Purpose:    This function is used when user forgots password.
 _________________________________________________________________________
 */
var forgotPassword = function (req, res) {
    var user = req.body;
    if(!user || !user.username){
        res.status(400).send({msg:"Please provide us the complete details."});
    }else {
        User.findOne({$or:[{'profile.phone': user.username},{'profile.email': user.username}]}, function (err,data) {
            if (err) {
                res.status(400).send({msg:err});
            } else{
                if(data && data.authyId){
                    authy.request_sms(data.authyId, function (err, result) {
                        if(err){
                            res.status(400).send({msg:err});
                        } else {
                            result.authyId = data.authyId;
                            res.status(200).json(result)
                        }
                    });
                } else {
                    res.status(400).send({msg:"No accound found with given email or phone"});
                }
            }
        });
    }
};


/*________________________________________________________________________
 * @Date:       27 May,2017
 * @Method :    forgot_password
 * Modified On: -
 * @Purpose:    This function is used when user forgots password.
 _________________________________________________________________________
 */


var resetPassword = function (req, res,next) {
    var user = req.body;

    if(!req.body || !req.body.username || !req.body.password || !req.body.password_confirm || !req.body.otp) {
        res.status(400).send({msg:"Please provide us the complete details."});
    } else {
        authy.verify(user.authyId,user.otp, function (err, response) {
            if(err){
                res.status(400).send({msg:err});
            }else{
                console.log(response,"response");
                if(response.success==='true') {
                    User.hashPassword(user.password).then(function(hashed){
                        user.password = hashed;

                        User.findOneAndUpdate({$or:[{'profile.phone': user.username},{'profile.email': user.username}]}, {$set:{password:user.password}}).then(function(err, data){
                            if(err){
                                res.status(400).send({msg:err});
                                console.log("Something wrong when updating data!");
                            } else {
                                res.status(200).json({msg: "Your password has been updated successfully"});
                                Mail.sendResetPasswordMail(data.profile,function (msg){
                                    console.log("Password EMAIL",msg)
                                });
                                // SMS.sendResetPasswordSms(data,function (msg) {
                                //     console.log("Password MSG",msg)
                                // })
                            }
                        }).catch(function (e){
                            next(err);

                        })
                    })
                }
            }
        });
    }
};




/*________________________________________________________________________
 * @Date:       28 May,2017
 * @Method :    ResendOtp
 * Modified On: -
 * @Purpose:    This function is for logout
 _________________________________________________________________________
 */
var resendOtp = function (req, res) {
    var authyId = req.body && req.body.authyId;
    if(!authyId) {
        res.status(400).send({msg:"OOPS!, Something went wrong. Please try again."});
    }
    requestAuthySms(authyId,function (err, result) {
        if(err) {
            res.status(400).send({msg:err});
        } else {
            res.status(200).json(result);
        }
    });
};


var deleteF = function (req,res) {
    User.remove({},function (err,resonse) {
        if(err){

        }else {
            res.status(200).json(resonse)
        }
    })
};


/*________________________________________________________________________
 * @Date:      	23 May,2017
 * @Method :   	OTP by call
 * Modified On:	-
 * @Purpose:   	This function is used to call user for verification.
 _________________________________________________________________________
 */

var requestCall = function (req,res) {
    var user = req.params;
    // console.log(user.id,"authyid for call");
    if(!user || !user.id) {
        res.status(400).send({msg:"OOPS!, Something went wrong. Please try again."});
    }else {
        authy.request_call(user.id,'call', function (err, result) {
            if(err) {
                console.log(err);
                res.status(400).send({msg:err});
            }else {
                console.log(result);
                res.status(200).json(result);
            }
        })
    }
};



/*________________________________________________________________________
 * @Date:       20 June,2017
 * @Method :    AVATAR
 * Created By:  Ved Prakash
 * Modified On: -
 * @Purpose:    This function is used to update Avatar
 _________________________________________________________________________
 */

// function updateAvatar(req, res){
//     var uid = req.body.uid;
//
//     if(req.body.myCroppedImage){
//         User._findOneAndUpdate({"uid": uid}, {'profile.avatar': req.body.myCroppedImage}, function (err, user) {
//             if (err){
//                 res.status(400).send(err);
//             } else {
//                 res.status(200).json({avatar: req.body.myCroppedImage});
//             }
//         });
//     }
//     else
//     {
//         User._findOneAndUpdate({"uid":uid}, {'profile.avatar': "/img/user.svg"}, function (err, user) {
//             if(err) {
//                 res.send(400,err);
//             }else {
//                 res.status(200).json({avatar: "/img/user.svg"});
//             }
//         });
//     }
// }



//  functions
exports.register = register;
exports.requestCall = requestCall;
exports.verify_register = verify_register;
exports.login = login;
exports.forgotPassword = forgotPassword;
exports.resetPassword = resetPassword;
exports.resendOtp = resendOtp;
exports.deleteF = deleteF;
