var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var Q = require('q');
var uniqueValidator = require('mongoose-unique-validator');
var nodemailer = require('nodemailer');

var _jade = require('jade');
var fs = require('fs');

var Constant = require('../../config/constants');


var MailSchema = new Schema({
    to                  : { type : String },
    subject             : { type : String },
    body                : { type : String },
    title                : { type : String },
    status              : { type : Schema.Types.Mixed },
    updated_at          : { type : Date },
    deleted_at          : { type : Date, default: null },
    created_at          : { type : Date }
});


// smtp settings
var transporter = nodemailer.createTransport("SMTP",{
    service: 'gmail',
    auth: {
        user: Constant.gmailSMTPCredentials.username,
        pass:Constant.gmailSMTPCredentials.password
    }
});

MailSchema.statics = {

    sendInvitationMail: function (req1,req, cb) {
        var self = this;
        var obj = {};
        console.log("===========================");
        console.log('invited:',req);
        console.log("===========================");
        obj.msg = 'Hi  &nbsp;&nbsp;'+ req.invitedPersonName + ',<br><br>'+
            'You are receiving this because you have invitated by   &nbsp;&nbsp;'+ req.invitedByName +'. <br><br>'+
            '<a href="' + 'http://' + req1.headers.host +'#!'+'/invitation/' + req.senderUid + '" target="_blank" >' + 'http://' + req1.headers.host + '#!' +'/invitation/' + req.senderUid + '</a><br><br>',

            'Thanks, <br><br>'+
            'Luvcheck Team <br><br>';
        obj.subject = "Luvcheck Invitation";
        obj.email = req.email;
        self.send(obj,cb);

    },
    resendInvitationMail: function (req1,req, cb) {
        var self = this;
        var obj = {};
        console.log("===========================");
        console.log('invited:',req);
        console.log("===========================");
        obj.msg = 'Hi  &nbsp;&nbsp;'+ req.invitedPersonName + ',<br><br>'+
            'You are receiving this because you have invitated by   &nbsp;&nbsp;'+ req.invitedByName +'. <br><br>'+
            '<a href="' + 'http://' + req1.headers.host +'#!'+'/invitation/' + req.senderUid + '" target="_blank" >' + 'http://' + req1.headers.host + '#!' +'/invitation/' + req.senderUid + '</a><br><br>',

            'Thanks, <br><br>'+
            'Luvcheck Team <br><br>';
        obj.subject = "Luvcheck Invitation";
        obj.email = req.email;
        self.send(obj,cb);

    },
    sendWelcomeMail: function (data,cb) {
        var self = this;
        var template = process.cwd() + '/templates/welcome.jade';
        var obj = data;
        obj.msg = template;
        obj.subject = "Welcome to LuvCheck";

        // get template from file system
        fs.readFile(template, 'utf8', function(err, file) {
            if (err) {
                //handle errors
                console.log('ERROR!',err);
                cb('error',err)
            }
            else {
                //compile jade template into function
                var compiledTmpl = _jade.compile(file, {filename: template});
                // set context to be used in template
                var context = {title: 'LuvCheck'};
                // get html back as a string with the context applied;
                var html = compiledTmpl(context);

                var data = {
                    from: Constant.gmailSMTPCredentials.username,
                    to: obj.email,
                    subject: (obj.subject || "No Subject"),
                    html: (html || "Empty Body")
                };

                // send mail with defined transport object
                transporter.sendMail(data, function (error, info) {
                    if (error) {
                        console.log(error,"error");
                        cb(error);
                    }else{
                        console.log('Message sent: ' + info.messageId);
                        cb('Message sent: ' + info.messageId)
                    }
                });

            }
        })
    },
    sendResetPasswordMail: function (data,cb) {
        var self = this;
        var obj = {};
        obj.msg = "Your password has been updated successfully";
        obj.subject = "Password Reset";
        obj.email = data.email;
        obj.name = data.name;
        self.send(obj,cb)
    },
    sendInvitationReminderMail: function () {

    },
    sendActivationMail : function () {

    },
    send: function(obj,callback){
        var self = this;
        var data = {
            from: Constant.gmailSMTPCredentials.username,
            to: obj.email,
            title: (obj.title || "No Title"),
            subject: (obj.subject || "No Subject"),
            html: (obj.msg || "Empty Body")
        };

        // send mail with defined transport object
        transporter.sendMail(data, function (error, info) {
            if (error) {
                console.log(error,"error");
                return console.log(error);
            }else{
                console.log('Message sent: ' + info.messageId);
                callback('Message sent: ' + info.messageId)

            }
        });
        return true;
    }

};

var Mail = mongoose.model('Mail', MailSchema);

module.exports = Mail;