var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcrypt-nodejs');//FOR PASSWORD
var Q = require('q');
var uniqueValidator = require('mongoose-unique-validator');
var crypto = require('crypto');//FOR PASSWORD

var constantObj = require('../../config/constants');
var authy = require('authy')(constantObj.twilioCredentials.Authy);
var twilio = require('twilio')(constantObj.twilioCredentials.ACCOUNTSID, constantObj.twilioCredentials.AUTHTOKEN);


SALT_WORK_FACTOR = 5;//FOR PASSWORD

var userSchema = new Schema({
    uid 				: {type:String},
    profile        : {
        email               : {type : String, unique: true , required :true },
        name                : {type : String, required: true},
        phone               : {type : String, unique: true , required : true },    
        avatar              : {type : String, default: ''},
        countryCode         : {type: String, required: true  },
        country             : {type : String}
                        },
    password            : {type : String, required: true, select: false},
    accountType         : {type : String},
    authyId             : {type: String, required: true},
    friendList          : [{uid : {type : String},
                            emergencyCaller: {type: Boolean, default: false},
                            accountManager : {type: Boolean, default: false}
                         }],
	devices             : [{select: false}],
	active              : {default:false,type:Boolean},
	lastSeen            : {type:Number},
    verified            : {type: Boolean, default: false},
    isTrial             : {type:Boolean, default: true},
    accountExpiresOn    : {type : Date,default:+new Date() + 30*24*60*60*1000},
    isDeleted           : {type: Boolean, default: false},
    createdDate         : {type:Date, default: Date.now,select: false},
    updatedDate         : {type:Date, default: Date.now,select: false}
});

userSchema.pre('save', function (next) {
    var user = this;
    if(!user.uid){
        var uid = 'luvcheck' + crypto.randomBytes(11).toString('hex');
        user.uid = uid;
        if (!user.isModified('password')) {
            return next();
        }
        bcrypt.genSalt(5, function (err, salt) {
            bcrypt.hash(user.password, salt, null, function (err, hash) {
                user.password = hash;
                next();
            });
        });
    }else {
        next();
    }
});

userSchema.statics = {
    hashPassword: function(password){
        var deferred = Q.defer();
        bcrypt.genSalt(5, function (err, salt) {
            bcrypt.hash(password, salt, null, function (err, hash) {
                password = hash;
                return deferred.resolve(password);
            });
        });
        return deferred.promise;
    }
};

userSchema.plugin(uniqueValidator);
userSchema.plugin(uniqueValidator, {message: "Email already exists"});
var users = mongoose.model('users', userSchema);

module.exports = users;

