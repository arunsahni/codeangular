
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;
var crypto = require('crypto');

var adminSchema = new Schema({
    email               : {type : String, required: true},
    phone               : {type : String, required: true},
    name                : {type : String,required: true},
    avatar              : {type : String},
    role                : {type: String,
                            enum: ['superadmin','admin'],
                            default:'admin'
                           },
    uid                 : {type: String},
    countryCode         : { type: String, required: true  },
    country             : { type: String, required: true  },
    isDeleted           : {type : Boolean, 'default': false},
    createdDate         : {type : Date, default: Date.now},
    updatedDate         : {type : Date, default: Date.now}
});

adminSchema.pre('save', function (next) {
    var user = this;
    var uid = 'luvcheckadmin' + crypto.randomBytes(11).toString('hex');
    user.uid = uid;
    next();
});

var admins = mongoose.model('admins', adminSchema);

module.exports = admins;