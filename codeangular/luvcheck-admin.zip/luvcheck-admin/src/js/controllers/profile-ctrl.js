

angular
    .module('LuvCheck')
    .controller('ProfileCtrl', ['$scope','$state', ProfileCtrl]);

function ProfileCtrl($scope,$state) {

    $scope.date = new Date();

    $scope.isCreateMode = false;


    $scope.profileData = [{data:{name:"Eddie Quiroz",role:"Super Admin",avatar:"img/avatar.jpg",country_code:'+1',email:"eddie@nexweb.com",phone:"11111111111",password:"123"}}];

    $scope.getProfile = function () {

    };

    $scope.resetAdmin = function () {
        $scope.profile = {};
    };

    $scope.deleteAdmin = function () {

    };

    $scope.editProfile = function () {
        $scope.isCreateMode = true;
        $scope.profile = $scope.profileData[0].data;
        $scope.profile.role = $scope.profileData[0].data.role;
    };

    $scope.cancelCreate = function () {
        $scope.isCreateMode = false;
        $scope.profile =  {};
    };

    $scope.toggle = function () {
        $scope.isCreateMode = true;
    };


    $scope.createAdmin = function (profile) {

        console.log(profile);

    }
}