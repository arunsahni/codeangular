
angular
    .module('LuvCheck')
    .controller('LoginCtrl', ['$scope','$state','$window', LoginCtrl]);

function LoginCtrl($scope,$state,$window) {

    $window.localStorage.removeItem('auth_token');

    $scope.alerts = [];

    $scope.closeAlert = function(index) {
        $scope.alerts.splice(index, 1);
    };

    var addToAlert = function (msg){
        $scope.alerts.push(msg);
    };
    

    $scope.login  = function (user) {
        if(user.username == 'luvcheck' && user.psw === 'luvcheck'){
            $window.localStorage.setItem('auth_token','luvcheck');
            $state.go('index');
        }else {
            var msg =  {
                type: 'danger',
                msg: 'Username or Password incorrect.'
            };
            addToAlert(msg)
        }
    }
}