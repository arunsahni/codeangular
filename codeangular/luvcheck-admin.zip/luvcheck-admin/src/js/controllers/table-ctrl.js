

angular
    .module('LuvCheck')
    .controller('TableCtrl', ['$scope','$state','NgTableParams','TablesData', TableCtrl]);

function TableCtrl($scope,$state,NgTableParams,TablesData) {

    $scope.userData = [{name:'Ved',age:22},{name:'Arun',age:30},{name:'Ved',age:22},{name:'Arun',age:30},{name:'Ved',age:22},{name:'Arun',age:30}];

    console.log(TablesData,"TablesData")
    $scope.defaultConfigTableParams = new NgTableParams({}, { dataset: TablesData});

    $scope.tableParams = new NgTableParams({
        page: 1, // show first page
        count: 5 // count per page
    }, {
        counts: [],
        filterDelay: 0,
        dataset: TablesData
    });

}