

angular
    .module('LuvCheck')
    .controller('TableDetailsCtrl', ['$scope','$state','NgTableParams','$stateParams','TableData','ApiCall', TableDetailsCtrl]);

function TableDetailsCtrl($scope,$state,NgTableParams,$stateParams,TableData,ApiCall) {

    console.log(TableData);

    var tableType = $stateParams.type;
    if(!tableType){
        $state.go('tables');
    }

    $scope.closeAlert = function(index) {
        $scope.alerts.splice(index, 1);
    };

    var addToAlert = function (msg){
        $scope.alerts.push(msg);
    };
    
    $scope.defaultConfigTableParams = new NgTableParams({}, { dataset: TableData});

    var initTable = function () {
        $scope.tableParams = new NgTableParams({
            page: 1, // show first page
            count: 10 // count per page
        }, {
            filterDelay: 0,
            dataset: TableData
        });
    };
    initTable();


    $scope.deleteUser = function (uid,authyid,index) {
        var params = {uid:uid,authyId:authyid} ;
        ApiCall.deleteUser(params,function (res) {
            console.log(res,"res");
            if(res.status===201){
                TableData.splice(index,1);
                var msg = {type: 'success',
                    msg: 'User Deleted Successfully'
                };
                initTable();
                addToAlert(msg)
            }else {
                var msg =  {
                    type: 'danger',
                    msg: 'Something went wrong! Please retry.'
                };
                addToAlert(msg)
            }
        })
    };

}