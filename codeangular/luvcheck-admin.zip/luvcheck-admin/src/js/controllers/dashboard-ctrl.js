/**
 * Alerts Controller
 */

angular
    .module('LuvCheck')
    .controller('DashboardCtrl', ['$scope','ApiCall', DashboardCtrl]);

function DashboardCtrl($scope,ApiCall) {

    var getAdmins = function () {

    }


}