/**
 * Created by ved on 30/6/17.
 */

angular
    .module('LuvCheck')
    .factory('Auth', ['$state','$window', Auth]);

function Auth($state,$window) {

    return {
        isLoggedIn : function() {
            var token = $window.localStorage.getItem('auth_token');
            return token ? token : false;
        },
        logout:function() {
            $window.localStorage.removeItem('auth_token');
            $state.go('login');
        }
    }
}