

angular
    .module('LuvCheck')
    .factory('ApiCall', ['$http', ApiCall]);

function ApiCall($http) {
    var obj = {};
    
    obj.getAdmins = function () {

    };

    obj.getUsersData = function () {

    };

    obj.getTablePageData = function () {
        var url = 'http://luvcheck-backend.herokuapp.com/users/listUsers';
        var promise = $http.get(url)
            .then(function(response){
                return response.data;
            });
        return promise;
    };

    obj.getTableData = function (type) {
        console.log(type);
        if(!type){
            return [];
        }else {
            var data = [];
            if(type==='users'){
                var url = 'http://luvcheck-backend.herokuapp.com/users/listUsers';
                var promise = $http.get(url)
                    .then(function(response){

                        return response.data;
                    });
                return promise;
            }else if(type==='invitations'){
                data = [{name:1,age:3}]
            }
        }
    };

    obj.createAdmin = function () {

    };

    obj.deleteAdmin = function () {

    };

    obj.deleteUser = function (params,cb) {
        var url = 'http://luvcheck-backend.herokuapp.com/users/deleteuser';
        $http.post(url,params).then(function (res) {
            console.log(res,"res");
            cb(res);
        },function (err) {
            console.log(err,"err");
        })
    };

    obj.editUser = function() {

    };

    obj.updateAdmin = function () {

    };

    obj.updateUser = function () {

    };

    obj.deleteInvitationRecord = function () {

    };


    return obj;


}