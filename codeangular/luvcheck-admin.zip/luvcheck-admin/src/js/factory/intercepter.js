

angular
    .module('LuvCheck')
    .factory('SessionInjector', ['$http','Auth', SessionInjector])
    .factory('ErrorInterceptor', ['$http','$q','Auth', ErrorInterceptor])
    .factory('SpinnerInterceptor', ['$http','$q', SpinnerInterceptor]);

function SessionInjector($http,Auth) {

    var sessionInjector = {
        request:function (config){
            if(Auth.isLoggedIn()) {
                config.headers['Authorization'] = Auth.isLoggedIn();
            }
            return config
        }
    };

    return sessionInjector;

}

function ErrorInterceptor($http,$q,Auth) {

    var errorInterceptor = {
        responseError: function(rejection) {
            // do something on error
            if(rejection.status === 401){
                Auth.logout();
            }
            return $q.reject(rejection);
        }
    };

    return errorInterceptor;

}

function SpinnerInterceptor($http,$q) {

}