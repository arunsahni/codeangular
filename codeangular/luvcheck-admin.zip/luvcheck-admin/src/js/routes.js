'use strict';

/**
 * Route configuration for the LuvCheck module.
 */
angular.module('LuvCheck').config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        // For unmatched routes
        $urlRouterProvider.otherwise('/login');

        // Application routes
        $stateProvider
            .state('index', {
                url: '/dashboard',
                menuCategory: 'dashboard',
                title: 'Dashboard',
                controller:'DashboardCtrl',
                templateUrl: 'templates/dashboard.html'
            })
            .state('login', {
                url: '/login',
                menuCategory: 'login',
                controller:'LoginCtrl',
                templateUrl: 'templates/login.html'
            })
            .state('stats', {
                url: '/stats',
                menuCategory: 'stats',
                title: 'Stats',
                templateUrl: 'templates/stats.html'
            })
            .state('settings', {
                url: '/settings',
                menuCategory: 'settings',
                title: 'Settings',
                templateUrl: 'templates/settings.html'
            })
            .state('servers', {
                url: '/servers',
                menuCategory: 'servers',
                title: 'Servers',
                templateUrl: 'templates/server.html'
            })
            .state('profile', {
                url: '/profile',
                menuCategory: 'profile',
                controller:'ProfileCtrl',
                title: 'Profile',
                templateUrl: 'templates/profile.html'
            })
            .state('tables', {
                url: '/tables',
                menuCategory: 'tables',
                title: 'Tables',
                controller:'TableCtrl',
                templateUrl: 'templates/tables.html',
                resolve: {
                    TablesData: ['ApiCall', '$state', '$stateParams', function (ApiCall, $state, $stateParams) {
                        return ApiCall.getTablePageData();
                    }]
                }
            })
            .state('tables.type', {
                url: '/:type',
                menuCategory: 'tables',
                parentView: 'Tables',
                controller: 'TableDetailsCtrl',
                title: '',
                templateUrl: 'templates/table-details.html',
                resolve: {
                    TableData: ['ApiCall', '$state', '$stateParams', function (ApiCall, $state, $stateParams) {
                        return ApiCall.getTableData($stateParams.type);
                    }]
                }
            });
    }

]).run(['$state','$rootScope','Auth',function ($state,$rootScope,Auth) {

    $rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
        if(!Auth.isLoggedIn()){
            event.preventDefault();
            $state.go('login')
        }
        $rootScope.menuCategory = toState.menuCategory;
        console.log("toParams.type",toParams.type)
        $rootScope.title = toState.title?toState.title:( toParams.type && toParams.type.length? (toParams.type.charAt(0).toUpperCase() + toParams.type.slice(1)):"");
        $rootScope.parentView = toState.parentView;
        $rootScope.path = ""
    });



}]);