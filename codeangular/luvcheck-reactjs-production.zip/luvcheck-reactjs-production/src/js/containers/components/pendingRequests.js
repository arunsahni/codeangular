import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Row, Col} from 'react-bootstrap';
import Alert from 'react-s-alert';
//Material-ui imports
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
import FlatButton from 'material-ui/FlatButton';


//Default image import
import img from '../../../../public/resources/images/user.png'

//Custom imports
import {acceptPendingRequest, rejectPendingRequest} from '../../actions/directoryActions';

const randomColor = ['#4527A0', '#7B1FA2', '#AA00FF', '#76FF03', '#3949AB', '#1565C0', '#D32F2F'];

class PendingRequests extends React.Component {
	constructor(props) {
		super(props);

	}
	//Error Alert on OTP form
	errorAlert = (message, position) => {
		console.log('alert: ',message);
		Alert.error(message, {
			position: position,
			effect: 'slide',
			timeout: 5000
		})
	}
	//success Alert on OTP form
	successAlert = (message, position) => {
		console.log('alert: ',message);
		Alert.success(message, {
			position: position,
			effect: 'slide',
			timeout: 5000
		})
	}
	acceptRequest = (personInfo, index) => {
		console.log(personInfo);
		var authToken = localStorage.getItem('authToken');
		var data = {	
			status:"accepted",
			senderUid: personInfo.uid || personInfo.senderUid
		}
		this.props.acceptPendingRequest(authToken, data, personInfo, index)
			.then((response) => {
				console.log(response)
				this.successAlert('Invitation accepted successfully', 'bottom-right');
			})
			.catch((error) => {
				console.log(error);
				this.errorAlert(error, 'bottom-right');
			})
	}
	rejectRequest = (personInfo, index) => {
		var authToken = localStorage.getItem('authToken');
		var data = {
			status:"rejected",
			senderUid: this.props.userInfo.uid
		}
		this.props.rejectPendingRequest(authToken, data, index)
			.then((response) => {
				console.log(response)
				this.successAlert('You have rejected the Invitation', 'bottom-right');
			})
			.catch((error) => {
				console.log(error);
				this.errorAlert(error, 'bottom-right');
			})
	}
	render() {
		const paperStyles = {
			position: 'relative',
			height: '280px',
			margin: '10px',
			width: '220px',
			textAlign: 'center',
		}
		return (
			<Row>
				{this.props.pendingRequests.map((request, index) => {
					return  (
						<Col sm={4} xs={12} lg={3}  key={index}>
							<Paper zDepth={1} style={{...paperStyles, background: `${randomColor[index%7]}`}}>
								<Avatar src={img} size={60} style={{marginTop: '60px'}}/>
								<div>
									<p style={{color: '#ffffff', fontSize: '1.5em'}}>{request.profile.name}</p>
									<p style={{color: '#ffffff'}}>{request.profile.email || ''}</p>
								</div>
								<div style={{position: 'absolute', width: '100%', display: 'flex', bottom: '0'}}>
									<FlatButton label="Accept" onTouchTap={()=>this.acceptRequest(request, index)} style={{width: '50%', color: '#ffffff'}} />
									<FlatButton label="Reject" onTouchTap={()=>this.rejectRequest(request, index)} style={{width: '50%', color: '#ffffff'}}/>
								</div>
							</Paper>
						</Col>
					)

				})}
				
				<Alert stack={{limit: 3}} html={true} offSet={50}/>
			</Row>
			)
	}
}

const mapStateToProps = (state) => {
	return {
		pendingRequests: state.userInfoReducer.contactList.pendingRequests,
		userInfo: state.userInfoReducer
	}
}
const mapDispatchToProps = (dispatch) => {
	return bindActionCreators({acceptPendingRequest, rejectPendingRequest}, dispatch)
}
export default connect(mapStateToProps, mapDispatchToProps)(PendingRequests);