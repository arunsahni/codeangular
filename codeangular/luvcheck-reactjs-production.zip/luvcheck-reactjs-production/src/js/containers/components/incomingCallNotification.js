import React from 'react';
import {withRouter} from 'react-router';
import ReactHowler from 'react-howler';
//Material-ui imports
import Dialog from 'material-ui/Dialog';
import Avatar from 'material-ui/Avatar';
import {ListItem} from 'material-ui/List';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import CallReceiveIcon from 'material-ui/svg-icons/communication/call';
import CallEndIcon from 'material-ui/svg-icons/communication/call-end';
import VideoIcon from 'material-ui/svg-icons/av/videocam';
import {red500} from 'material-ui/styles/colors';

//Custom imports
import img from '../../../../public/resources/images/user.png';

class IncomingCall extends React.Component {
	constructor(props) {
		super(props);
	}
	
	componentWillReceiveProps(nextProps){
		console.log('IC',nextProps.callStore.incomingCall, this.props.callStore.incomingCall, nextProps.callStore.activeCall);
		if(nextProps.callStore.incomingCall === false && this.props.callStore.incomingCall === true && nextProps.callStore.activeCall===true) {
			this.props.history.push({pathname: '/activeCallRoom', state: {from: this.props.location.pathname} } );
		}
	}
	answerCall = () => {
		//call action creator to answer call
		const {pendingCallDetails} = this.props.callStore;
		console.log(this.props.userStore);

		const {socket} = this.props.userStore;
		this.props.answerCall(socket, pendingCallDetails.roomInfo.callId, "answered", "normal")

		
	}
	rejectCall = () => {
		//call action creator to answer call
		const {pendingCallDetails} = this.props.callStore;
		console.log(this.props.userStore);

		const {socket} = this.props.userStore;
		this.props.rejectCall(socket, pendingCallDetails.roomInfo.callId, "rejected", "normal")

	}
	CallPrimaryDetails = () => {
		var {pendingCallDetails} = this.props.callStore;
		console.log(pendingCallDetails && pendingCallDetails.from === undefined, 'check');
		if(pendingCallDetails !== null && pendingCallDetails.from !== undefined) {
			return <div id="callerName">{pendingCallDetails.from.profile.name || ''}</div>
		}
		return <div></div>
	}
	render() {
		return ( 
			<Dialog open={this.props.onIncomingCallDialog}
				modal={false}
				bodyClassName="incomingCallDialog"
				contentClassName="incomingCallContainer"
				overlayStyle={{backgroundColor: 'rgba(0,0,0,0)'}}
			>
				{this.props.onIncomingCallDialog? <ReactHowler
							src="../resources/sounds/phone.wav"
							playing={true}
							loop={true}
						/> : null}
				<ListItem 
					leftAvatar={<Avatar size={50} src={img}/>}
					primaryText={this.CallPrimaryDetails()}
					secondaryText={<div style={{color: '#ffffff',fontSize: '1em', marginLeft: '3em'}}>Incoming Call</div>}
					hoverColor={"none"}
					/>
				<div className="incomingCallActions">
					<FloatingActionButton style={{padding: '5px'}} backgroundColor={red500} onTouchTap={() => this.rejectCall()}>
						<CallEndIcon/>
					</FloatingActionButton>
					<FloatingActionButton style={{padding: '5px'}} onTouchTap={() => this.answerCall()}>
						<VideoIcon/>
					</FloatingActionButton>
					<FloatingActionButton style={{padding: '5px'}} onTouchTap={() => this.answerCall()} backgroundColor={'green'}>
						<CallReceiveIcon/>
					</FloatingActionButton>
				</div>
			</Dialog>
			)
	}
}

export default withRouter(IncomingCall);