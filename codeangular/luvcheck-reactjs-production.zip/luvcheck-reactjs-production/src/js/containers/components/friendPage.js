import React from 'react';
import {connect} from 'react-redux';
import {withRouter} from 'react-router';
import {bindActionCreators} from 'redux';
import {Row, Col} from 'react-bootstrap';

//import {Grid, Cell, Card, CardTitle, CardText, CardActions, Button} from 'react-mdl';

//Material-ui imports
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
import FlatButton from 'material-ui/FlatButton';

const randomColor = ['#4527A0', '#7B1FA2', '#AA00FF', '#76FF03', '#3949AB', '#1565C0', '#D32F2F'];

//Default image import

const paperStyles = {
	position: 'relative',
	height: '280px',
	margin: '10px',
	width: '220px',
	textAlign: 'center',
}
const cardStyle = {
	width: '220px', height: '300px', display:'inline-flex', marginLeft: '10px', marginTop: '10px'
}

import img from '../../../../public/resources/images/user.png';

class FriendList extends React.Component {
	constructor(props) {
		super(props);
	}
	callAction = (friend) => {
		this.props.history.push({pathname:'/activeCallRoom', state: {friendInfo: friend, from: this.props.location.pathname}});
	}
	render() {
		return (
			<Row>
				{this.props.friendList.map((friend, index) => {
					return  (
						<Col sm={4} xs={12} lg={3} key={index}>
							<Paper zDepth={1} style={{...paperStyles, background: `${randomColor[index%7]}`}}>
								<Avatar src={img} size={60} style={{marginTop: '60px'}}/>
								<div>
									<p style={{color: '#ffffff', fontSize: '1.5em'}}>{friend.profile.name}</p>
									<p style={{color: '#ffffff'}}>{friend.profile.email || ''}</p>
								</div>
								<FlatButton label="Call" 
									style={{position: 'absolute', bottom: '0', left: '0', width: '100%', color: '#ffffff'}} 
									onTouchTap={() => this.callAction(friend)}
								/>
							</Paper>	
						</Col>
					)

				})}
			</Row>
		)
		
	}
}

const mapStateToProps = (state) => {
	return {
		friendList: state.userInfoReducer.contactList.friendList
	}
}

export default connect(mapStateToProps)(withRouter(FriendList));

/*
let defaultImg = "http://www.getmdl.io/assets/demos/dog.png";
		return(
			<Grid>
				<Cell col={12}>
					{Array(20).fill(1).map((el, i) => 
						<Card key={i} shadow={0} style={cardStyle}>
						    <CardTitle expand style={{color: '#fff', textAlign: 'center', background: `${randomColor[i%7]}`}}>
 								<Avatar src={img} size={80}/>	
						    </CardTitle>
						    <CardText>
						    	Hello {i + 1}
						    </CardText>
						    <CardActions border>
						        <Button colored>View Details</Button>
				     		</CardActions>
						</Card>
					)}
				</Cell>
			</Grid>
		)
*/