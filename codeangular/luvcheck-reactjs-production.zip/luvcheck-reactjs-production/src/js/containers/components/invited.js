import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Row, Col} from 'react-bootstrap';

//Material-ui imports
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
import FlatButton from 'material-ui/FlatButton';


//Default image import
import img from '../../../../public/resources/images/user.png'

const randomColor = ['#4527A0', '#7B1FA2', '#AA00FF', '#76FF03', '#3949AB', '#1565C0', '#D32F2F'];

class InvitedList extends React.Component {
	constructor(props) {
		super(props);

	}
	render() {
		const paperStyles = {
			position: 'relative',
			height: '280px',
			margin: '10px',
			width: '220px',
			textAlign: 'center',
		}
		
		return (
			<Row>
				{this.props.invitedList.map((invitation, index) => {
					return  (
						<Col sm={4} xs={12} lg={3} key={index}>
							<Paper zDepth={1} style={{...paperStyles, background: `${randomColor[index%7]}`}}>
								<Avatar src={img} size={60} style={{marginTop: '60px'}}/>
								<div>
									<p style={{color: '#ffffff', fontSize: '1.5em'}}>{invitation.profile.name}</p>
									{/*<p style={{color: '#ffffff'}}>{invitation.profile.email}</p>*/}
								</div>
								
								<FlatButton label="Resend" style={{position: 'absolute', bottom: '0', left: '0', width: '100%', color: '#ffffff'}} />
							</Paper>

						</Col>
					)

				})}
			</Row>

			)
		
	}
}

const mapStateToProps = (state) => {
	return {
		invitedList: state.userInfoReducer.contactList.invitations
	}
}

export default connect(mapStateToProps)(InvitedList);