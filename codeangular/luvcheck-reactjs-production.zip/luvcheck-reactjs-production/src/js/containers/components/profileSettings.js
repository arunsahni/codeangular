import React from 'react';
import {connect} from 'react-redux';
import Avatar from 'material-ui/Avatar'
import {Row, Col} from 'react-bootstrap';

//Default image import
import img from '../../../../public/resources/images/user.png'
import ProfileUpdateForm from '../reduxForms/profileUpdateForm';
import ProfileImageCropDialog from './profileImageCropDialog'

//Import actions
import {updateProfilePic, updateProfileInfo} from '../../actions/profileSettingsActions';

class ProfileSettings extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			imagePreviewUrl: '',
			file: null,
			openImageCropper: false,
			scaledImage: null
		}
	}
	//Get the file URL
	fileInputChange = (e) => {
		e.preventDefault();
		console.log('onChange called', e.target.files[0])
		let reader = new FileReader();
	    let file = e.target.files[0];

	    reader.onloadend = () => {
	      this.setState({
	        file: file,
	        imagePreviewUrl: reader.result, 
	        openImageCropper: true
	      });
	    }
	    reader.readAsDataURL(file)
	}
	//Trigger click on file upload input
	fileLoaderOption = () => {
		console.log('fileReader')
		this.fileInput.click();
		
	}
	//Close Dialog
	closeImageDialog = () => {
		this.setState({openImageCropper: false})
	}
	//Get the cropped image
	getCroppedImage = () => {
		this.closeImageDialog();
		//Getting the scaled Image
		const scaledImage = this.profileImg.editedRef.getImageScaledToCanvas().toDataURL();

		//Calling redux action creators to update image
		this.props.updateProfilePic(scaledImage);
		this.setState({scaledImage});
	}
	//handle Profile Update
	handleProfileUpdate=(values)=>{
		
	}
	render() {
		var image= this.props.userInfo.profilePic === ''? img : this.props.userInfo.profilePic;
		return (
			<div style={{textAlign: 'center'}}>
				<div >
					<Avatar src={this.props.userInfo.profilePic || img} style={{marginTop: '5%'}} size={150} onClick={this.fileLoaderOption}/>
					<input type="file" ref={(fp) => {this.fileInput = fp}} onChange={this.fileInputChange} style={{display: 'none'}}/>
				</div>
				<div style={{textAlign: 'center'}}>
					<Row>
						<Col sm={8} md={6}><ProfileUpdateForm /></Col>
					</Row>
				</div>
				<ProfileImageCropDialog openImageCropper={this.state.openImageCropper}
				 previewImg={this.state.imagePreviewUrl} closeImageDialog={this.closeImageDialog}
				 getCroppedImage={this.getCroppedImage} ref={(prImg) => this.profileImg = prImg}/>
			</div>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.userInfoReducer
	}
}

const mapDispatchToProps = (dispatch) => {
	return {
		updateProfilePic: (img) => dispatch(updateProfilePic(img)),
		updateProfileInfo: () => dispatch(updateProfileInfo())
	}
}	

export default connect(mapStateToProps, mapDispatchToProps)(ProfileSettings);