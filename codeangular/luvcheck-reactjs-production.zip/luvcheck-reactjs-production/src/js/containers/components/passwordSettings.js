import React from 'react';
import {connect} from 'react-redux';
import {Row, Col} from 'react-bootstrap';
import {Grid, Cell} from 'react-mdl';
import Alert from 'react-s-alert';
//Custom Imports
import PasswordUpdateForm from  '../reduxForms/passwordUpdateForm';
import {changeProfilePassword} from '../../actions/profileSettingsActions';

class PasswordSettings extends React.Component {
	constructor(props) {
		super(props);

	}
	successAlert = () => {
		var message = 'Password Changed Successfully';
		console.log('alert: ' ,message);
		Alert.success(message, {
			position: 'bottom',
			effect: 'slide',
			timeout: 5000
		})
	}
	errorAlert = (error) => {
		var message = 'Error Changing Password.'
		Alert.error(message, {
			position: 'bottom',
			effect: 'slide',
			timeout: 5000
		})
	}
	handleSubmit = (values) => {
		var authToken = localStorage.getItem('authToken');
		var data = {
			current_password: values.profileOldPassword,
			password: values.profileNewPassword,
			confirm_password: values.profileConfirmPassword,
			uid: this.props.userStore.uid
		}
		
		//updating user password
		this.props.changeProfilePassword(data, authToken)
			.then((reponse) => {
				this.successAlert();
				this.props._handleDialogClose();
			})
			.catch((error) => {
				this.errorAlert();
			})
	}
	render() {
		return (
			<Grid>
				<Cell col={12}>
					<PasswordUpdateForm _handleDialogClose={this.props._handleDialogClose} onSubmit={this.handleSubmit}/>
				</Cell>
				<Alert stack={{limit: 3}} html={true} offSet={50}/>
			</Grid>
		)
	}
}
const mapStateToProps = (state) => {
	return {
		userStore: state.userInfoReducer
	}
}
const mapDispatchToProps = (dispatch) => {
	return {
		changeProfilePassword: (data, token) => dispatch(changeProfilePassword(data, token))
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(PasswordSettings);