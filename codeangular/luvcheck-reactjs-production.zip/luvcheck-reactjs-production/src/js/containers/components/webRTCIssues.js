import React from 'react'
import FlatButton from 'material-ui/FlatButton';
import {List, ListItem} from 'material-ui/List';

class WebRTCError extends React.Component {

	constructor(props) {
		super(props);
	}

	render() {

		var results = this.props.rtcIssues;

		if (results == null) {
			return null
		}

		var errors = []

		var style = {
			color: "red"
		}

		if (!results.isChromeFirefox) {
			errors.push( <ListItem style={style} primaryText="Must use Chrome or Firefox" onClick={()=> window.open("https://www.google.com/chrome/browser/desktop/")} /> )
		}

		if (!results.webcamPermission) {
			errors.push( <ListItem style={style} primaryText="Must enable webcam permission"  onClick={()=> window.open("https://support.google.com/chrome/answer/2693767?hl=en")} /> )
		}

		if (!results.microphonePermission) {
			errors.push( <ListItem style={style} primaryText="Must enable microphone permission" onClick={()=> window.open("https://support.google.com/chrome/answer/2693767?hl=en")} /> )
		}

		if (!results.hasWebcam) {
			errors.push( <ListItem style={style} primaryText="No webcam connected. Please plug one in" onClick={()=> window.open("https://support.google.com/chrome/answer/2693767?hl=en")} /> )
		}

		if (!results.hasMicrophone) {
			errors.push( <ListItem style={style} primaryText="No microphone connected. Please plug one in"  onClick={()=> window.open("http://www.wintuts.com/How-To-Install-and-Setup-a-Microphone")} /> )
		}

		if (!results.webRTCSupport) {
			errors.push( <ListItem style={style} primaryText="Your computer does not support browser based video"  /> )
		}


		return (
			<div>
				<div>
				
					Your System is not configured to support LuvCheck. Click the issues below to learn how to resolve them.
					<List>
						{errors}
					</List>
					<FlatButton
							label="Try Again"
							primary={true}
							onTouchTap={()=> {
								location.reload();
							}}
						/>
				</div>
			</div>
		)

	}
}

export default WebRTCError;