import React from 'react';

import {Grid, Cell} from 'react-mdl';

import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import {startAudioVideo} from '../../actions/webRTCActions';

class HomeWebcam extends React.Component {
	constructor(props) {
		super(props);
		this.videoCall=null;
	}
	componentDidMount() {
		this.props.startAudioVideo(this.videoCall);
 	}
 	componentDidUpdate(prevProps){
 		if(prevProps.turnOffVideo === true && this.props.turnOffVideo === false) {
 			this.props.startAudioVideo(this.videoCall);
 		}
 	}
	render() {
		if(this.props.turnOffVideo)
			return (
				<Grid>
					<Cell col={6} style={{marginTop: '15%', marginLeft: '34%'}}>
						Video has been turned off Kindly <a style={{cursor: 'pointer'}} onClick={this.props._handleVideoOff}>click here</a> to turn it on again.
					</Cell>
				</Grid>
			)
		return(
			<div id="video-wrap">
              	<video ref={(vid) => this.videoCall = vid} /*style={{height: '100%'}}*/ muted></video>
            </div>
		)
	}
}

function mapDispatchToProps(dispatch){
  return bindActionCreators({startAudioVideo}, dispatch);
}

export default connect(null, mapDispatchToProps)(HomeWebcam);