import React from 'react';
import AvatarEditor from 'react-avatar-editor';

//Material-ui imports
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';

class ProfileImageCropDialog extends React.Component {
	render() {
		const actions = [
			<FlatButton 
				label="Submit"
				primary={true}
				onTouchTap={this.props.getCroppedImage}
			/>,
			<FlatButton 
				label="Cancel"
				default={true}
				onTouchTap={this.props.closeImageDialog}
			/>
		]
		return (
			<Dialog open={this.props.openImageCropper}
				onRequestClose={this.props.closeImageDialog}
				actions={actions}
				>
				<AvatarEditor 
					ref={(cropRef)=> this.editedRef=cropRef}
					image={this.props.previewImg}
					width={500}
			        height={500}
			        border={0}
			        borderRadius={300}
				/>
			</Dialog>
			)
	}
}

export default ProfileImageCropDialog;