import React, { Component } from 'react';
import {Redirect, Route} from 'react-router-dom';
// import {Grid, Row, Col} from 'react-bootstrap';
import {Grid, Cell} from 'react-mdl';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

//Custom imports
import Sidebar from './sidebar'
import Navbar from './Navbar';
import AddContact from './addContact';
import Directory from './directory';
import Profile from './profile';
import ActiveCallRoom from './activeCallRoom';
import HomeWebcam from './components/homeCamera.js';
import WebRTCIssues from './components/webRTCIssues';
import IncomingCallModal from './components/incomingCallNotification';
import {getUserProfileInformation} from '../actions/loginRegisterActions';
import {getFriendList, getPendingRequests, getSentInvitations} from '../actions/directoryActions';
import {answerCall, rejectCall} from '../actions/callActions';

//importing css
import styles from '../../../public/resources/styles/app.css';


class App extends Component {
  
  constructor(props){
    super(props);
    this.state = {
      isAuthenticated: false,
      isWaitingResponse: true,
      RTCIssuesExist: false
    }
  }

  componentWillMount() {

    var authToken = localStorage.getItem('authToken');
    var uid = localStorage.getItem('authUid');
    if(authToken) {
      this.props.getUserProfileInformation(authToken, uid)
        .then(response => {
            this.setState({isAuthenticated: true, isWaitingResponse: false});
        })
        .catch((error) => {
            this.setState({isWaitingResponse: false});
        })
    } else {
      this.setState({isAuthenticated: false, isWaitingResponse: false});
    }

    //RTCIssues
    const {RTCResults} = this.props;
    var RTCIssuesExist = !(RTCResults === null ||
                            RTCResults.isChromeFirefox &&
                            RTCResults.webcamPermission &&
                            RTCResults.microphonePermission &&
                            RTCResults.hasWebcam &&
                            RTCResults.hasMicrophone &&
                            RTCResults.webRTCSupport
                          )
    console.log(RTCIssuesExist, RTCResults);
    this.setState({RTCIssuesExist});

  }
  componentWillReceiveProps(nextProps) {
    //RTCIssues
    const {RTCResults} = nextProps;
    var RTCIssuesExist = !(RTCResults === null ||
                            RTCResults.isChromeFirefox &&
                            RTCResults.webcamPermission &&
                            RTCResults.microphonePermission &&
                            RTCResults.hasWebcam &&
                            RTCResults.hasMicrophone &&
                            RTCResults.webRTCSupport
                          )    
    console.log(RTCIssuesExist, RTCResults);
    this.setState({RTCIssuesExist});
  }
  render() {
    var {RTCResults} = this.props;
    var {RTCIssuesExist} = this.state;

    if(RTCIssuesExist) {
      return <WebRTCIssues rtcIssues={RTCResults}/>
    }
    return (
        <Route render={props => (
            this.state.isWaitingResponse? (<div>Loading...</div>) :
              this.state.isAuthenticated ? (
                  <Home {...this.props}/>
                ): (
              <Redirect to={{
                  pathname: '/login',
                  state: { from: props.location }
                }}/>
              )
          )}/>
      )
  }
}

class Home extends Component {

  constructor(props) {
    super(props);
    this.state = {
        glyphiconChevron: 'glyphicon-chevron-right', 
        wrapperClass: '', 
        hamburgerState: 'is-closed', 
        openAddContactDialog: false,
        openSideBar: false,
        turnOffVideo: false
    }
  }


  componentDidMount() {
    var token = localStorage.getItem('authToken');
      //Get Friend List
      this.props.getFriendList(token);
  }
  addContactDialog = () => {
    this.setState({openAddContactDialog: true});
  }

  closeAddContactDialog = () => {
    this.setState({openAddContactDialog: false});
  }

  toggleSideBar = () => {
    this.setState(prevState => ({
        openSideBar: !prevState.openSideBar
    }))
  }

  _handleVideoOff = () => {
      this.setState(prevState => ({
        turnOffVideo: !prevState.turnOffVideo
    }))
  }

  render() {
        return (

        <div className="appcontainer">
          <Navbar toggleSideBar={this.toggleSideBar}/>
          <div className="app">
            <Sidebar openSideBar={this.state.openSideBar} addContactDialog={this.addContactDialog} _handleVideoOff={this._handleVideoOff}/>
            <div className="content">
                <Route exact path="/" render={(props) => <HomeWebcam turnOffVideo={this.state.turnOffVideo} _handleVideoOff={this._handleVideoOff} {...props}/>}/>
                <Route path="/directory" component={Directory}/>
                <Route path="/profileSettings" component={Profile}/>
                <Route path="/activeCallRoom" component={ActiveCallRoom}/>
            </div>
            <AddContact openAddContactDialog={this.state.openAddContactDialog} closeAddContactDialog={this.closeAddContactDialog}/>
            <IncomingCallModal 
              onIncomingCallDialog={this.props.callStore.incomingCall}
              answerCall={this.props.answerCall}
              rejectCall={this.props.rejectCall}
              callStore={this.props.callStore}
              userStore={this.props.userStore}
            />
          </div>
        </div>
        
        )
    
  }
}

const mapStateToProps = (state) => {
  return {
    callStore: state.callStore,
    userStore: state.userInfoReducer,
    RTCResults: state.loginStore.detectRTCResults
  }
}

const mapDispatchToProps = (dispatch) => {
  return bindActionCreators({getUserProfileInformation,
      getFriendList,
      getPendingRequests,
      getSentInvitations,
      answerCall,
      rejectCall
  }, dispatch) 
}
export default connect(mapStateToProps, mapDispatchToProps)(App);



/*

<div style={{backgroundColor: '#f0f0f0'}}>
          <Grid>
            <Cell style={{height:"60px"}} col={12}>
                <Navbar toggleSideBar={this.toggleSideBar}/>
            </Cell>
            <Cell col={12}>
                <Route exact path="/" component={(props) => <HomeWebcam turnOffVideo={this.state.turnOffVideo} _handleVideoOff={this._handleVideoOff} {...props}/>}/>
                <Route path="/directory" component={Directory}/>
                <Route path="/profileSettings" component={Profile}/>
                <Route path="/activeCallRoom" component={ActiveCallRoom}/>
            </Cell>
            <Cell col={12}> 
                <Sidebar openSideBar={this.state.openSideBar} addContactDialog={this.addContactDialog} _handleVideoOff={this._handleVideoOff}/>
            </Cell>
          </Grid>
          <AddContact openAddContactDialog={this.state.openAddContactDialog} closeAddContactDialog={this.closeAddContactDialog}/>
          <IncomingCallModal 
            onIncomingCallDialog={this.props.callStore.incomingCall}
            answerCall={this.props.answerCall}
            callStore={this.props.callStore}
            userStore={this.props.userStore}
          />
        </div>

*/