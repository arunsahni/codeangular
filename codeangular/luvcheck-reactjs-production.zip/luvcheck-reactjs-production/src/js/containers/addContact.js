import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Row, Grid, Col} from 'react-bootstrap';

import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import TextField from 'material-ui/TextField';
import MenuItem from 'material-ui/MenuItem';
import Avatar from 'material-ui/Avatar';
import AddCircleIcon from 'material-ui/svg-icons/content/add-circle';
import {ListItem} from 'material-ui/List';
import Alert from 'react-s-alert';

import {Button} from 'react-bootstrap';

//Custom imports
import {updateSearchValue, getContactProps, sendInvitation} from '../actions/addContactAction'

//Showing an alert success message on invitation success
const successAlert = (name) => {
	var message = 'Successfully sent an invitation to ' + name
	console.log('alert: ' ,message);
	Alert.success(message, {
		position: 'top',
		effect: 'slide',
		timeout: 5000
	})
}
const errorAlert = (message) => {
	console.log('alert: ',message);
	Alert.error(message, {
		position: 'top',
		effect: 'slide',
		timeout: 5000
	})
}
const infoAlert = () => {
	var message = 'Invitation already sent'
	console.log('alert: ',message);
	Alert.info(message, {
		position: 'top',
		effect: 'slide',
		timeout: 5000
	})
}
//Invite User Action call
const inviteExistingUser = (props) => {
	console.log(props.resultSet.userData, 'userProps');
	var data = {
		receiverUid: props.resultSet.userData.uid,
		email: props.resultSet.userData.profile.email,
		phone: props.resultSet.userData.profile.name,
		countryCode: props.resultSet.userData.profile.countryCode,
		invitedPersonName: props.resultSet.userData.profile.name

	}
	var userProfile = props.resultSet.userData;
	console.log(data);
	//Get the authtoken to send as headers
	var token = localStorage.getItem('authToken');

	//call action creator to send invitation
	props.sendInvitation(data, userProfile, token)
		.then((response) => {
			console.log('Invitation successfully sent', response)
			successAlert(data.invitedPersonName);
			handleInputChange('', props.otherProps)
		})
		.catch((error) => {
			console.log('Error Sending invitation', error);
			errorAlert(error)
		})
}

//Contact Name display
const AddContactSuggestion = (props) => {
	console.log(props.resultSet)
	if(!props.resultSet.foundMatchedUser && !props.resultSet.alreadySentInvitation) {
		
		return (
				<ListItem leftIcon={<Avatar src={require('../../../public/resources/images/user.png')} size={40}/>}
					primaryText={props.resultSet.searchValue}
					rightIcon={<a href="#">Invite</a>}
					/>
			)
	}
	else if(props.resultSet.foundMatchedUser && !props.resultSet.alreadySentInvitation) {
		return (
			<ListItem leftIcon={<Avatar src={require('../../../public/resources/images/user.png')} size={40}/>}
					primaryText={props.resultSet.userData.profile.name}
					rightIcon={<AddCircleIcon onClick={() => inviteExistingUser(props)}/>}
					/>
		)
	}  else if(props.resultSet.foundMatchedUser && props.resultSet.alreadySentInvitation){
		return (
			<ListItem leftIcon={<Avatar src={require('../../../public/resources/images/user.png')} size={40}/>}
					primaryText={props.resultSet.userData.profile.name}/>
		)
	}
	
}

//Debounce custom implementation
const debounce = (func, wait, immediate) =>{
	var timeout;
	return function() {
		var context = this, args = arguments;
		clearTimeout(timeout);
		timeout = setTimeout(function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		}, wait);
		if (immediate && !timeout) func.apply(context, args);
	};
}

//Call the GetUser API after a 1 sec debounce
const getContactInfo = debounce((props, newValue) => {

	//Get token and uid 
	var authToken = localStorage.getItem('authToken');
	console.log(props.userStore)
	var uid = props.userStore.uid
	props.getContactProps(newValue, authToken, uid);

}, 1000);


//Contact Parent
const handleInputChange = (newValue, props) => {
	console.log(newValue, props)
	//checking if the user exists
	props.updateSearchValue(newValue)
	getContactInfo(props, newValue);
}
const AddContact = (props) => {
	const action = [
		/*<FlatButton 
			label="Cancel"
			primary={true}
			onTouchTap={props.closeAddContactDialog}
		/>*/
		<Button style={{marginRight: 20}} bsSize="small" onClick={props.closeAddContactDialog}>
			<span>Cancel</span>
		</Button>
	]
	return (
		<div>
			<Dialog 
				title="Add Contact"
				actions ={action}
				modal={false}
				open = {props.openAddContactDialog}
				contentStyle={{maxWidth:'none'}}
				onRequestClose={props.closeAddContactDialog}
			>		<Alert stack={{limit: 3}} html={true} offSet={50}/>
					<Row>
						<Col smOffset={3} sm={6}>
							<TextField 
								label="Enter phone or email"
								floatingLabelText="Enter phone or email"
								value={props.contactStore.searchValue}
								onChange={(e, newValue) => handleInputChange(newValue, props)}
							/>
						</Col>
					</Row>
					{props.contactStore.isSearchValid ? 
						<Row>
							<Col smOffset={3} sm={6}>
								<AddContactSuggestion resultSet={props.contactStore}
								 userInfo={props.userStore} sendInvitation={props.sendInvitation}
								 closeDialog={props.closeAddContactDialog}
								 otherProps={props}
								 />
							</Col>
						</Row>
						: null
					}
				
			</Dialog>
			
		</div>
	)
}

function mapStateToProps(state){
	return {
		contactStore: state.addContactStore,
		userStore: state.userInfoReducer
	}
}
function mapDispatchToProps(dispatch) {
	return bindActionCreators({updateSearchValue, getContactProps, sendInvitation}, dispatch)
}
export default connect(mapStateToProps, mapDispatchToProps)(AddContact);