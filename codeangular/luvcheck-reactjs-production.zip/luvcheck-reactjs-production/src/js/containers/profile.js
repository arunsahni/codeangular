import React from 'react';

//Material-ui imports
import {Card, CardText, CardHeader, CardTitle, CardActions} from 'material-ui/Card';
import Divider from 'material-ui/Divider';
import Dialog from 'material-ui/Dialog';
import Avatar from 'material-ui/Avatar';
import {Grid, Cell} from 'react-mdl';
import {Tabs, Tab} from 'material-ui/Tabs';
import {connect} from 'react-redux';
import {Button} from 'react-bootstrap';
// import {Row, Col} from 'react-bootstrap';
//Custom imports
import ProfileSettings from './components/profileSettings';
import PasswordSettings from './components/passwordSettings';
import ProfileImageCropDialog from './components/profileImageCropDialog';

//Import actions
import {updateProfilePic, updateProfileInfo} from '../actions/profileSettingsActions';
import styles from '../../../public/resources/styles/profile.css'
import DefaultUserImage from '../../../public/resources/images/user-icon.png';

class Profile extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			imagePreviewUrl: '',
			file: null,
			openImageCropper: false,
			openPassDialog: false,
			scaledImage: null
		}
	}
	//Get the file URL
	fileInputChange = (e) => {
		e.preventDefault();
		console.log('onChange called', e.target.files[0])
		let reader = new FileReader();
	    let file = e.target.files[0];

	    reader.onloadend = () => {
	      this.setState({
	        file: file,
	        imagePreviewUrl: reader.result, 
	        openImageCropper: true
	      });
	    }
	    reader.readAsDataURL(file)
	}
	//Trigger click on file upload input
	_changeProfilePic = () => {
		console.log('fileReader')
		this.fileInput.click();
		
	}
	//Close Dialog
	closeImageDialog = () => {
		this.setState({openImageCropper: false})
	}
	//Get the cropped image
	getCroppedImage = () => {
		this.closeImageDialog();
		//Getting the scaled Image
		const scaledImage = this.profileImg.editedRef.getImageScaledToCanvas().toDataURL();
		//Calling redux action creators to update image
		const {updateProfilePic} = this.props;
		updateProfilePic(scaledImage);
		this.setState({scaledImage});
	}
	//handle Profile Update
	handleProfileUpdate=(values)=>{
		
	}
	_openPassChangeDialog = () => {
		this.setState({
			openPassDialog: true
		})
	}
	_handleDialogClose = () => {
		this.setState({
			openPassDialog: false
		})
	}
	render() {
		const actions = [];
		const {profile} = this.props.userStore;
		var image = profile.avatar === ''? DefaultUserImage : profile.avatar;
		return (
			<Grid>
				<Cell col={10} className='cardStyle'>
					<Card style={{minHeight: 350}}>
					    <CardHeader 
					    	titleStyle={{}}
					    	textStyle={{}}
					    	style={{backgroundColor: '#d9edf7'}}
					    	title='Profile'
					    />
					    <Divider />
					    <CardText>
							<Grid>
								<Cell col={5}>
									<div className='detailStyle'>
										<Avatar style={{width: '50%'}} size={300} onClick={this._changeProfilePic}
										src={image}/>
										<input type="file" ref={(fp) => {this.fileInput = fp}} onChange={this.fileInputChange} style={{display: 'none'}}/>
									</div>
								</Cell>
								<Cell col={7}>
									<Divider/>
									<div className='detailStyle'>Name: {profile.name}</div>
									<Divider/>
									<div className='detailStyle'>Phone: {profile.countryCode}-{profile.phone}</div>
									<Divider/>
									<div className='detailStyle'>Email: {profile.email}</div>
									<Divider/>
									<div className='detailStyle'>Country: {profile.country}</div>
									<Divider/>
									<div className='detailStyle'>Password: <a style={{cursor: 'pointer'}} onClick={this._openPassChangeDialog}>Change Password</a></div> 
									<Divider/>
									<Button bsStyle="primary" style={{marginTop: 20, float: 'right'}} bsSize="small">
										<span>Update Profile</span>
									</Button>
								</Cell>
							</Grid>	
							<Dialog
			                    modal={false}
			                    action={actions}
			                    title="Password Change"
			                    contentStyle={{maxWidth:'none'}}
			                    open={this.state.openPassDialog}
			                    autoScrollBodyContent = {true}
			                    onRequestClose={this._handleDialogClose}
			                >
			                	<PasswordSettings _handleDialogClose={this._handleDialogClose}/>
			                </Dialog>
			                <Dialog
			                    modal={false}
			                    action={actions}
			                    title="Password Change"
			                    contentStyle={{maxWidth:'none'}}
			                    open={this.state.openPassDialog}
			                    autoScrollBodyContent = {true}
			                    onRequestClose={this._handleDialogClose}
			                >
			                	<PasswordSettings _handleDialogClose={this._handleDialogClose}/>
			                </Dialog>
			                <ProfileImageCropDialog openImageCropper={this.state.openImageCropper}
								 previewImg={this.state.imagePreviewUrl} closeImageDialog={this.closeImageDialog}
								 getCroppedImage={this.getCroppedImage} ref={(prImg) => this.profileImg = prImg}/> 						
					    </CardText>
					</Card>
				</Cell>
			</Grid>
		)
	}
}
const mapStateToProps = (state) => {
	return {
		userStore: state.userInfoReducer,
	}	
}

const mapDispatchToProps = (dispatch) => {
	return {
		updateProfilePic: (img) => dispatch(updateProfilePic(img)),
		updateProfileInfo: () => dispatch(updateProfileInfo())
	}
}	

export default connect(mapStateToProps, mapDispatchToProps)(Profile);

/*
<Row>
	<Col xs={12}>
		<Tabs
			value={this.state.value}
			onChange={this.handleChange}
			className="profileTabs"
			>
			<Tab label="Profile" value="profileSettings">
				<ProfileSettings/>
			</Tab>
			<Tab label="Password" value="password">
				<PasswordSettings/>
			</Tab>
			
		</Tabs>
	</Col>
</Row>
*/