import React from 'react';
import {Link, withRouter} from 'react-router-dom';
import {Field, reduxForm, getFormValues} from 'redux-form';

// import {Grid, Col, Row, Modal} from 'react-bootstrap';

import {Grid, Cell} from 'react-mdl';

import {Card, CardTitle, CardText} from 'material-ui/Card';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import axios from 'axios';

//Custom imports
import LoginForm from './reduxForms/loginReduxForm';
import RegisterForm from './reduxForms/registerReduxForm';
import UrlHelper from '../../utils/UrlHelper';
import {loggingInUser, loginRequestComplete, loginUser} from '../actions/loginRegisterActions';

const logo_img = require('../../../public/resources/images/logo.png');

//Import css
import styles from "../../../public/resources/styles/login.css"

class Login extends React.Component {
	
	constructor(props){
		super(props);
		this.state = {
			openRegisterModal: false
		}
	}

	loginUser = (values) => {

		this.props.loggingInUser();
		var data = {
			username: values.loginUserId,
			password: values.loginPassword
		}

		this.props.loginUser(data) 
			.then((response) => {
				var {from} = this.props.location.state || {from : {pathname: '/'}}
				this.props.history.push(from.pathname)
			})
			.catch((error) => {
				if (error.response) {
			      	// The request was made and the server responded with a status code
					  // that falls out of the range of 2xx
					  this.props.errorAlert(error.response.data.msg,"top");
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
					  // http.ClientRequest in node.js
					  console.log(error.request);
					  this.props.errorAlert('No Response Received from the server.',"top");
			    } else {
					  // Something happened in setting up the request that triggered an Error
					  console.log('Error', error.message);
					  this.props.errorAlert('Your Request could not be processed',"top");
			    }				
			})		
	}
	
	
	render() {
        console.log("ved Prakash")
		var {registerValues} = this.props;
		return (
			<div>
				<Grid>
					<Cell col={6}>
						<img style={{marginTop: '20%', marginLeft:'22%', width:'55%'}} src={logo_img}/>
					</Cell>
					<Cell col={6}>
						<Card style={{marginTop: '15%'}}>
							<CardTitle titleStyle={{textAlign: 'center'}} title="Login" />
							<CardText>
								<LoginForm onSubmit={this.loginUser}/>
								<div style={{marginTop: '20px', marginLeft: '35%'}}>
									<Link to="/register">Not a member? Sign Up</Link>
								</div>
							</CardText>
						</Card>
					</Cell>
				</Grid>
			</div>
		);
	}
}

function mapDispatchToProps(dispatch){
	return bindActionCreators({loggingInUser, 
		loginRequestComplete, 
		loginUser}, dispatch);
}
export default connect(null, mapDispatchToProps)(withRouter(Login));

/*
<Grid>
				<Row>
					<Col xsOffset={4} xs={4}>
						<img className="logo" src={logo_img} width="230px"/>
					</Col>
				</Row>
				<Row>
					<Col smOffset={2} sm={7}>
						<Card>
							<CardTitle titleStyle={{textAlign: 'center'}} title="Login" />
							<CardText>
								<LoginForm onSubmit={this.loginUser}/>
								<div style={{marginTop: '20px', marginLeft: '35%'}}>
									<Link to="/register">Not a member? Sign Up</Link>
								</div>
							</CardText>
						</Card>
					</Col>
				</Row>
				<Alert stack={{limit: 3}} html={true} />
			</Grid>
*/