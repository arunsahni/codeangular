import React from 'react';
import {withRouter, Prompt} from 'react-router';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import img from '../../../public/resources/images/user.png';

//Material-ui imports
import Avatar from 'material-ui/Avatar';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import VoiceSettingsIcon from 'material-ui/svg-icons/action/settings-voice';
import CallEndIcon from 'material-ui/svg-icons/communication/call-end';
import MicOffIcon from 'material-ui/svg-icons/av/mic-off';
import VideoIcon from 'material-ui/svg-icons/av/videocam';
import VideoOffIcon from 'material-ui/svg-icons/av/videocam-off';
import {red500} from 'material-ui/styles/colors';
import CircularProgress from 'material-ui/CircularProgress';
import ReactHowler from 'react-howler';

//Custom imports
import {placeCall, endCall, leaveCall} from '../actions/callActions';
import {connectToRoom, toggleAudio, toggleVideo} from '../actions/webRTCActions';

class ActiveCallRoom extends React.Component {
	constructor(props) {
		super(props);
		this.contactVideo = null;
	}
	componentDidMount(){
		console.log(this.props);

		var {userStore} = this.props;
		var {friendInfo} = this.props.location.state;
		console.log(this.props.location.state)
		if(this.props.location.state.from === '/directory') 
			this.props.placeCall(userStore.socket, friendInfo.uid, friendInfo.profile.name);

	}
	componentDidUpdate(prevProps, prevState) {
		var {callStore} = prevProps;
		console.log(callStore.callStarted, 'old');
		console.log(this.props.callStore.callStarted , 'new');
		if(callStore.callStarted === false && this.props.callStore.callStarted === true ) {
			this.props.connectToRoom(this.contactVideo, this.callerVideo)
			
		}
		if(this.props.callStore.activeCall === false) {
			this.props.history.push('/');
		}
	}
	// componentWillReceiveProps(nextProps) {
	// 	console.log(nextProps.callStore.activeCall)
	// 	if(nextProps.callStore.activeCall === false) {
	// 		this.props.history.push('/');
	// 	}
	// }
	componentWillUnmount() {
		this.endCall();
	}
	endCall = () => {
		this.props.leaveCall();
	}
	render() {
		const {callStarted, activeCall, pendingCallDetails, isMuted, isPaused, userVideoState} = this.props.callStore;
		

		return(

			<div id="video-wrap">
				{callStarted? <div>
								<video id="myVideo" ref={ref => this.contactVideo = ref} autoPlay/> 
								{userVideoState? null: <Avatar className="callAvatar" src={img} size={200} style={{position: 'absolute', margin: '0 auto', top:'35%', left: '45%'}}/>} 

								<div id="callerVideo">
									<video ref={ref=> this.callerVideo = ref} autoPlay muted/>
									{isPaused? <img style={{position: 'absolute', width: '100%', height: '100%'}} 	src={img}/>: null }
								</div>
							</div> :
				<div>
					<ReactHowler
						src="../resources/sounds/phone.wav"
						playing={true}
						loop={true}
					/>
					<div className="call-animation"></div>
					<Avatar className="callAvatar" src={img} size={200} style={{position: 'absolute', margin: '0 auto', top:'35%', left: '45%'}}/>
				</div>
				}
				<div className="callActionButtons">
					<FloatingActionButton style={{padding: '5px'}} onTouchTap={this.props.toggleAudio}>
						{ isMuted? <MicOffIcon/>:<VoiceSettingsIcon/> }
					</FloatingActionButton>
					<FloatingActionButton style={{padding: '5px'}} backgroundColor={red500} onTouchTap={this.endCall}>
						<CallEndIcon  />
					</FloatingActionButton>
					<FloatingActionButton style={{padding: '5px'}} onTouchTap={this.props.toggleVideo}>
						{ isPaused? <VideoOffIcon/> :<VideoIcon/> }
					</FloatingActionButton>
				</div>
				{activeCall? <Prompt message="Are you sure you want to navigate away? Your call will be disconnected"/>: null}
			</div>
		)
	}
}


const mapStateToProps = (state) => {
	
	return {
		userStore: state.userInfoReducer,
		callStore: state.callStore
	}
}
const mapDispatchToProps = (dispatch) => {
	return bindActionCreators({placeCall,
							connectToRoom,
							toggleAudio,
							toggleVideo,
							leaveCall
						}, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(ActiveCallRoom);