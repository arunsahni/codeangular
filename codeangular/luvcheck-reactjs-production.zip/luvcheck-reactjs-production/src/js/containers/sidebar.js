import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import {withRouter} from 'react-router';
import Drawer from 'material-ui/Drawer';
import {connect} from 'react-redux';

//Material-ui imports
import {List, ListItem} from 'material-ui/List';
import Avatar from 'material-ui/Avatar';
import Toggle from 'material-ui/Toggle';

/*-------------------icons-------------------------------*/
	import ContentInbox from 'material-ui/svg-icons/content/inbox';
	import ActionGrade from 'material-ui/svg-icons/action/grade';
	import ContentSend from 'material-ui/svg-icons/content/send';
	import ContentDrafts from 'material-ui/svg-icons/content/drafts';
	import Divider from 'material-ui/Divider';
	import ActionInfo from 'material-ui/svg-icons/action/info';
	import MessageIcon from 'material-ui/svg-icons/communication/email';
	import EventInfo from 'material-ui/svg-icons/action/event';
	import HomeIcon from 'material-ui/svg-icons/action/home';
	import HelpIcon from 'material-ui/svg-icons/action/help';
	import SettingsIcon from 'material-ui/svg-icons/action/settings';
	import FeedbackIcon from 'material-ui/svg-icons/action/feedback';
	import LogoutIcon from 'material-ui/svg-icons/action/lock';
	import PersonIcon from 'material-ui/svg-icons/social/person';
/*-------------------icon part ends here-----------------*/

import {Card, CardMedia, CardTitle} from 'material-ui/Card';


//importing css
import Styles from '../../../public/resources/styles/sidebar.css';
import img from '../../../public/resources/images/user.png';

var imgUrl = require('../../../public/resources/images/sidebar_bg.jpg');
const styles = {
	backgroundImage: 'url(' + imgUrl + ')',
	height: '200px'
}
const drawerStyles1={
	marginTop: '62px',
	backgroundColor: '#30426a',
}
const drawerStyles2={
	marginTop: '62px',
	backgroundColor: 'white'
}

const listItemStyle = {
	color: 'white',
}

const iconStyle = {
	fill: 'white'
}

class Sidebar extends Component {

	render() {
		const {userStore} = this.props;
		return (
			<div className="leftNav" style={this.props.openSideBar? {display: 'flex'}: {display: 'none'}}>
				<Drawer open={this.props.openSideBar} containerStyle={drawerStyles1}>
					<List>
					    <ListItem style={listItemStyle} primaryText="Home" leftIcon={<HomeIcon style={iconStyle}/>} onClick={()=> this.props.history.push('/')}/>
					    <ListItem style={listItemStyle} primaryText="Messages" leftIcon={<MessageIcon style={iconStyle} />} />
					    <ListItem style={listItemStyle} primaryText="Connect" leftIcon={<ContentSend style={iconStyle} />} onClick={this.props.addContactDialog}  />
				      	<ListItem style={listItemStyle} primaryText="Events" leftIcon={<EventInfo style={iconStyle}/>} />
				      	<ListItem style={listItemStyle} primaryText="Contacts" leftIcon={<PersonIcon style={iconStyle} />} onClick={()=> this.props.history.push('/directory')}/>
				      	<ListItem style={listItemStyle} primaryText="Settings" leftIcon={<SettingsIcon style={iconStyle}/>} />
				      	<ListItem style={listItemStyle} primaryText="Toggle Video" leftIcon={<Toggle onToggle={this.props._handleVideoOff} style={iconStyle}/>} />
				    </List>
				    <Divider />
				    <List>
				        <ListItem style={listItemStyle} primaryText="Feedback" rightIcon={<FeedbackIcon style={iconStyle} />} />
				      	<ListItem style={listItemStyle} primaryText="Help" rightIcon={<HelpIcon style={iconStyle}/>} />
				      	<ListItem style={listItemStyle} primaryText="Sign Out" rightIcon={<LogoutIcon style={iconStyle}/>} onClick={()=> {localStorage.clear(); this.props.history.push('/login')}} />
				    </List>
				</Drawer>
			</div>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		userStore: state.userInfoReducer
	}
}
export default connect(mapStateToProps)(withRouter(Sidebar));

/*
<List style={styles}>
    <div style={{marginLeft: '10%', marginTop: '15%'}}>
    	<Avatar src={userStore.profilePic || img} size={60}/>
    </div>
    <ListItem 
    	style={{marginTop: '5%', color: 'white'}}
    	primaryText={this.props.userStore.firstName + ' ' + this.props.userStore.lastName}
    	secondaryText={<span style={{color: 'white'}}>{this.props.userStore.email}</span>}
    />					
</List>
<List>
    <ListItem primaryText="Home" leftIcon={<HomeIcon />} onClick={()=> this.props.history.push('/')}/>
    <ListItem primaryText="Messages" leftIcon={<MessageIcon />} />
    <ListItem primaryText="Connect" leftIcon={<ContentSend />} onClick={this.props.addContactDialog}  />
  	<ListItem primaryText="Events" leftIcon={<EventInfo />} />
  	<ListItem primaryText="Directory" leftIcon={<EventInfo />} onClick={()=> this.props.history.push('/directory')}/>			      	
  	<ListItem primaryText="Settings" leftIcon={<SettingsIcon />} />
</List>
<Divider />
<List>
    <ListItem primaryText="Feedback" rightIcon={<FeedbackIcon />} />
  	<ListItem primaryText="Help" rightIcon={<HelpIcon/>}/>
  	<ListItem primaryText="Sign Out" rightIcon={<LogoutIcon />} onClick={()=> {localStorage.clear(); this.props.history.push('/login')}} />
</List>
*/