import React from 'react';
import {Link, withRouter} from 'react-router-dom';
import {Field, reduxForm, getFormValues, submit} from 'redux-form';
// import {Grid, Col, Row} from 'react-bootstrap';

import {Grid, Cell} from 'react-mdl';

import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import axios from 'axios';
import Alert from 'react-s-alert';

import Dialog from 'material-ui/Dialog'
import {Card, CardTitle, CardText} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
//Custom imports
import LoginForm from './reduxForms/loginReduxForm';
import RegisterForm from './reduxForms/registerReduxForm';
import OTPForm from './OTPForm';
import UrlHelper from '../../utils/UrlHelper';
import {registeringUser, registerRequestComplete, confirmingOTP, confirmingOTPComplete, registerUser, verifyRegisterOTP, callMeOTPAction} from '../actions/loginRegisterActions';

//Import css
import styles from "../../../public/resources/styles/login.css"


///import json
import countryDetails from '../../../public/resources/common/countryCode';

const spinner_img = require('../../../public/resources/images/spinner.gif');
const img = require('../../../public/resources/images/logo.png');

//Setting OTP dialog width 
var dialogStyle={
	width: '40%',
	maxWidth: 'none'
}
//Action buttons style
var actionsContainerStyle = {
	textAlign: 'center'
}


class Register extends React.Component {
	constructor(props){
		super(props);
		this.state = {
			openRegisterModal: false,
			authyId: '',
			dialogMobileNo: '',
			callmeTimer: null
		}
		this.interval = null;
	}
	componentWillUnmount() {
		clearInterval(this.interval);
	}
	//Error Alert on OTP form
	errorAlert = (message) => {
		console.log('alert: ',message);
		Alert.error(message, {
			position: 'top',
			effect: 'slide',
			timeout: 5000
		})
	}
	//success Alert on OTP form
	successAlert = (message) => {
		console.log('alert: ',message);
		Alert.success(message, {
			position: 'top',
			effect: 'slide',
			timeout: 5000
		})
	}

	// Register User
	registerUser = (values) => {
		var country = countryDetails.filter((countryDetail) => countryDetail.Country === values.registerCountry)[0]
		console.log(values, country, countryDetails)
		var data = {
			profile: {
				name: values.registerName,
				phone: values.registerPhoneNo,
				email: values.registerEmail,
				country: values.registerCountry,
				countryCode: country.Code,
			},
			password: values.registerPassword,
			password_confirm: values.registerConfirmPassword,
		}
		console.log('data', data);
		this.props.registeringUser();

		this.props.registerUser(data)
			.then((response) => {
				this.setState({openRegisterModal: true, authyId: response.data.authyId})
				//set the phone number to be displayed in OTP form

				var dialogMobileNo = values.registerPhoneNo
				dialogMobileNo = dialogMobileNo.replace(/^\d{6}/, '*******');
				
				//Call me option timer
				
				this.setState({dialogMobileNo, callmeTimer: 30}, ()=> {
					
					this.interval = setInterval(() => {
						this.setState((prevState) => ({callmeTimer: prevState.callmeTimer - 1}))
					}, 1000)
					if(this.state.callmeTimer === 0) {
						clearInterval(this.interval);
					}
				})

				
			})
			.catch((error) => {
				console.log(error);
				this.props.errorAlert(error, 'bottom')
			})
		
	}
	closeRegister = () => {
		this.setState({openRegisterModal: false});
	}
	confirmRegistration = (values) => {
	    var {registerValues} = this.props;
	    this.props.confirmingOTP();

        var country = countryDetails.filter((countryDetail) => countryDetail.Country === registerValues.registerCountry)[0]
		
		var data = {
			profile: {
				name: registerValues.registerName,
				phone: registerValues.registerPhoneNo,
				email: registerValues.registerEmail,
				country: registerValues.registerCountry,
				countryCode: country.Code,
			},
			otp: values.OTP,
			authyId: this.state.authyId,
			password: registerValues.registerPassword,
			password_confirm: registerValues.registerConfirmPassword,
		}
		this.props.verifyRegisterOTP(data)
			.then((response) => {
				this.closeRegister();
				this.props.successAlert('You have been registered successfully. Log in to Continue', 'bottom-left');
				this.props.history.push('/login');
			})
			.catch((error)=> {
				this.errorAlert(error);
			})
	}
	callMeOTP = () => {
		this.props.callMeOTPAction(this.state.authyId)
			.then((response) => {
				this.successAlert('You will Receive a call shortly', 'top');
			})
			.catch((error) => {
				this.errorAlert('Error while initiating a call', top);
			})
	}
	render() {
		var {registerValues} = this.props;
		var {confirmingRegisterOTP} = this.props.regiterStates;

	    const spinner = ( <img  className="spinner_gif" src={spinner_img} />);
		// OTP Dialog Actions
		var disabledCallmeString = "Get OTP on Call ( 00: " + ("0" + this.state.callmeTimer).slice(-2) + " )";
		var enabledCallmeString = "GET OTP on Call";
		var dialogActions=[
			<FlatButton 
				label={this.state.callmeTimer > 0? disabledCallmeString: enabledCallmeString}
				disabled={this.state.callmeTimer > 0? true: false}
				style={{width: '50%'}}
				onTouchTap={()=> this.callMeOTP()}
			/>,
			<RaisedButton 
				label="Submit"
				primary={true}
				onTouchTap={() => this.props.submit('OTPConfirm')}
				style={{width: '50%'}}
			>{confirmingRegisterOTP? spinner: null}</RaisedButton>
		]
		return (
			<div>
				<Grid>
					<Cell col={6}>
						<img style={{marginTop: '30%', marginLeft:'22%', width:'55%'}} className="logo img-responsiv" src={img}/>
					</Cell>
					<Cell col={6} >
						<Card>
							<CardTitle titleStyle={{textAlign: 'center'}} title="Register" />
							<CardText>
								<RegisterForm onSubmit={this.registerUser}/>
								<div style={{marginTop: '20px', marginLeft: '35%'}}>
									<Link to="/login">Already a member? Login In</Link>
								</div>
							</CardText>
						</Card>
					</Cell>				
				</Grid>
				<Dialog 
						title={"Enter Security Code"}
						open={this.state.openRegisterModal}
						modal={false}
						actions={dialogActions}
						contentStyle={dialogStyle}
						actionsContainerStyle={actionsContainerStyle}
						onRequestClose={this.closeRegister}
					>
					Security code has been sent to your mobile {this.state.dialogMobileNo}. Please enter the same  here to confirm registration.
					<OTPForm timer={this.state.callmeTime} authyId={this.state.authyId} onSubmit={this.confirmRegistration} callMeOTP={this.callMeOTP}/>
					<Alert stack={{limit: 3}} html={true} offSet={50}/>
				</Dialog>
			</div>
		);
	}
}
function mapStateToProps(state) {
	return {
		registerValues: getFormValues('RegisterForm')(state),
		regiterStates: state.loginStore
	}
}
function mapDispatchToProps(dispatch){
	return bindActionCreators({
				registeringUser, 
				registerRequestComplete, 
				confirmingOTP, 
				confirmingOTPComplete,
				registerUser,
				verifyRegisterOTP,
				callMeOTPAction,
				submit
			}, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(withRouter(Register));


/*
<Grid>
				<Row>
					<Col xsOffset={4} xs={4}>
						<img className="logo img-responsiv" src={img} width="100%"/>
					</Col>
					<Col xsOffset={3} xs={6} >
						<Card>
							<CardTitle titleStyle={{textAlign: 'center'}} title="Register" />
							<CardText>
								<RegisterForm onSubmit={this.registerUser}/>
								<div style={{marginTop: '20px', marginLeft: '35%'}}>
									<Link to="/login">Already a member? Login In</Link>
								</div>
							</CardText>
						</Card>
					</Col>
				</Row>
				<Dialog 
					title={"Enter Security Code"}
					open={this.state.openRegisterModal}
					modal={false}
					actions={dialogActions}
					contentStyle={dialogStyle}
					actionsContainerStyle={actionsContainerStyle}
					onRequestClose={this.closeRegister}
				>
					Security code has been sent to your mobile {this.state.dialogMobileNo}. Please enter the same  here to confirm registration.
					<OTPForm onSubmit={this.confirmRegistration} callMeOTP={this.callMeOTP}/>
					<Alert stack={{limit: 3}} html={true} offSet={50}/>
				</Dialog>
			</Grid>
*/