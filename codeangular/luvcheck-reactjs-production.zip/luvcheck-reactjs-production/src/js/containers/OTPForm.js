import React from 'react';
import {Field, reduxForm, submit} from 'redux-form';
import {Button} from 'react-bootstrap';
import {connect} from 'react-redux';
import TextField from 'material-ui/TextField';
import Spinner from 'react-spinkit';
import Alert from 'react-s-alert';
import {bindActionCreators} from 'redux';
import {resendOTPAction} from '../actions/loginRegisterActions';

const renderTextField = ({input, label, meta: {touched, error}, ...custom}) => (
  <TextField
  	style={{width: '50%', marginLeft: '15%'}}
    hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

//Error Alert on OTP form
const errorAlert = (message) => {
	Alert.error(message, {
		position: 'top',
		effect: 'slide',
		timeout: 5000
	})
}
//success Alert on OTP form
const successAlert = (message) => {
	Alert.success(message, {
		position: 'top',
		effect: 'slide',
		timeout: 5000
	})
}

function resendOTP(props){
	console.log('get otp again');
	props.resendOTPAction({authyId: props.authyId})
		.then((response) => {
			successAlert('Security Code has been sent again');
		})
		.catch((error) => {
			errorAlert(error);
		})
}

let OTPForm = (props) => {
	const {handleSubmit, callMeOTP} = props;
	const {confirmingRegisterOTP} = props.loginStates
	const spinner = (<Spinner name="line-scale" color="white" />);
	return (
		<form onSubmit={handleSubmit}>
			<div>
				<Field name="OTP" component={renderTextField} type="text" label="Enter Security"/>
				<span style={{color: 'pink'}} onClick={props.timer> 0? (e)=> e.preventDefault() : () => resendOTP(props)}>Resend Code</span>
			</div> 
			
		</form>
		)
}

OTPForm = reduxForm({
	form: 'OTPConfirm',
	onSubmit: submit
})(OTPForm);

function mapStateToProps(state) {
	return {
		loginStates: state.loginStore
	}
}

function mapDispatchToProps(dispatch){
	return bindActionCreators({
				resendOTPAction,
			}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(OTPForm);