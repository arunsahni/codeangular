import React from 'react';
import { Field, reduxForm } from 'redux-form';	
import {Link, withRouter} from 'react-router-dom';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import {Button} from 'react-bootstrap';
import {connect} from 'react-redux';
import Spinner from 'react-spinkit';

const spinner_img = require('../../../../public/resources/images/spinner.gif');



// Synchronous validation on input fields
const validate = (values) => {
	const errors = {}
	const requiredFields = ['loginUserId', 'loginPassword']
	requiredFields.forEach((field) => {
		if(!values[field]) {
			errors[field] = 'Required'
		}
	})
	if(values.loginUserId && !( /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.loginUserId) || /^[2-9]{1}[0-9]{9}$/.test(values.loginUserId))) {
		errors.loginUserId = 'Enter a valid email or phone number'
	}
	return errors
}

// render function for material-ui text field
const renderTextField = ({input, label, meta: {touched, error}, ...custom}) => (
  <TextField
    style={{width: '70%', marginLeft: '15%'}}
    hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)
// render function for material-ui checkbox field
const renderCheckbox = ({input, label}) => (
  <Checkbox
    label={label}
    checked={input.value ? true : false}
    onCheck={input.onChange}
  />
)

//Action if forgotPassword is clicked
const forgotPassword = () => {
	console.log("Action forgot password");
}
let LoginForm = (props) => {
	var {loggingInUser} = props.loginStates;
	const spinner = (      <img  className="spinner_gif" src={spinner_img} />);
	return (
			<form onSubmit={props.handleSubmit}>
				<div >
		          	<Field name="loginUserId" component={renderTextField} type="text" disabled={loggingInUser} label="Email/Phone"/>
		        </div>			    
		        <div>
			        <Field name="loginPassword" component={renderTextField} type="password" disabled={loggingInUser}label="Password"/>
			    </div>
			    <div style={{marginTop: '10px', display: 'flex' , marginLeft: '15%'}}>
			    	<div style={{ width: '50%'}}><Link to="/resetPassword" >Forgot Password?</Link></div>
			    	<Field name="loginRememberMe" component={renderCheckbox} disabled={loggingInUser} label="Remember Me" />
			    </div>
			    <div style={{marginTop: '10px', width: '70%', marginLeft: '15%'}}>
			        <Button bsStyle="primary" bsSize="large" type="submit" block disabled={loggingInUser}>
						{loggingInUser? spinner: null }
						<span> Login</span>
					</Button>
			    </div>
			</form>
		)
}

LoginForm =  reduxForm({
	form: 'loginForm',
	validate
})(LoginForm)

function mapStateToProps(state) {
	return {
		loginStates: state.loginStore
	}
}
export default connect(mapStateToProps)(withRouter(LoginForm));


 