import React from 'react';
import { Field, reduxForm } from 'redux-form';	
import {Link, withRouter} from 'react-router-dom';
import TextField from 'material-ui/TextField';
import {Button} from 'react-bootstrap';
import {connect} from 'react-redux';
import Spinner from 'react-spinkit';

const spinner_img = require('../../../../public/resources/images/spinner.gif');



// Synchronous validation on input fields
const validate = (values) => {
	const errors = {}
	const requiredFields = ['profileOldPassword', 'profileNewPassword', 'profileConfirmPassword']
	requiredFields.forEach((field) => {
		if(!values[field]) {
			errors[field] = 'Required'
		}
	})
	if(values.profileNewPassword !== values.profileConfirmPassword) {
		errors.profileConfirmPassword = 'Passwords do not match'
	}
	return errors
}

// render function for material-ui text field
const renderTextField = ({input, label, meta: {touched, error}, ...custom}) => (
  <TextField
    style={{width: '70%', marginLeft: '15%'}}
    hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

let PasswordUpdateForm = (props) => {
	var {resettingUserPassword} = props.profileStore;
	const spinner = (<img  className="spinner_gif" src={spinner_img} />);
	return (
		<div>
			<form onSubmit={props.handleSubmit}>
				<div >
		          	<Field name="profileOldPassword" component={renderTextField} type="password" disabled={resettingUserPassword} label="Old Password"/>
		        </div>			    
		        <div >
		          	<Field name="profileNewPassword" component={renderTextField} type="password" disabled={resettingUserPassword} label="New Password"/>
		        </div>
		        <div >
		          	<Field name="profileConfirmPassword" component={renderTextField} type="password" disabled={resettingUserPassword} label="Confirm New Password"/>
		        </div>		
			    <div style={{marginTop: '20px', float: 'right'}}>
					<Button style={{marginRight: 20}} bsSize="small" onClick={props._handleDialogClose}>
						<span>Cancel</span>
					</Button>
			        <Button bsStyle="primary" bsSize="small" type="submit" disabled={resettingUserPassword}>
						{resettingUserPassword? spinner: null }
						<span> Reset Password</span>
					</Button>
			    </div>
			</form>
		</div>
		)
}

PasswordUpdateForm =  reduxForm({
	form: 'passwordResetForm',
	validate
})(PasswordUpdateForm)

function mapStateToProps(state) {
	return {
		profileStore: state.profileStore
	}
}
export default connect(mapStateToProps)(withRouter(PasswordUpdateForm));


 