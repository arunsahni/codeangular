import React from 'react';
import { Field, reduxForm } from 'redux-form';	
import {Link, withRouter} from 'react-router-dom';
import TextField from 'material-ui/TextField';
import {Button} from 'react-bootstrap';
import {connect} from 'react-redux';
import Spinner from 'react-spinkit';

const spinner_img = require('../../../../public/resources/images/spinner.gif');



// Synchronous validation on input fields
const validate = (values) => {
	const errors = {}
	const requiredFields = ['profileFirstName']
	requiredFields.forEach((field) => {
		if(!values[field]) {
			errors[field] = 'Required'
		}
	})
	
	return errors
}

// render function for material-ui text field
const renderTextField = ({input, label, meta: {touched, error}, ...custom}) => (
  <TextField
    style={{width: '70%', marginLeft: '15%'}}
    hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

let ProfileUpdateForm = (props) => {
	var {updatingUserInformation} = props.profileStore;
	const spinner = (<img  className="spinner_gif" src={spinner_img} />);
	console.log('form called');
	return (
			<form onSubmit={props.handleSubmit}>
				<div >
		          	<Field name="profileFirstName" component={renderTextField} type="text" disabled={updatingUserInformation} label="First Name"/>
		        </div>			    
		        <div>
			        <Field name="profileLastName" component={renderTextField} type="text" disabled={updatingUserInformation}label="Last Name"/>
			    </div>
			    <div style={{marginTop: '10px', width: '70%', marginLeft: '15%'}}>
			        <Button bsStyle="primary" bsSize="large" type="submit" block disabled={updatingUserInformation}>
						{updatingUserInformation? spinner: null }
						<span> Update Profile</span>
					</Button>
			    </div>
			</form>
		)
}

ProfileUpdateForm =  reduxForm({
	form: 'profileUpdateForm',
	validate
})(ProfileUpdateForm)

function mapStateToProps(state) {
	return {
		profileStore: state.profileStore
	}
}
export default connect(mapStateToProps)(withRouter(ProfileUpdateForm));


 