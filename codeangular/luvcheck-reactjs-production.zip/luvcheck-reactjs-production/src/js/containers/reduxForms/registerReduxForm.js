import React from 'react';
import {connect} from 'react-redux';
import { Field, reduxForm } from 'redux-form';	
import {Button} from 'react-bootstrap';
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Spinner from 'react-spinkit';

const spinner_img = require('../../../../public/resources/images/spinner.gif');


///import json
import countryDetails from '../../../../public/resources/common/countryCode';

// Synchronous validation on input fields
const validate = (values) => {
	const errors = {}
	const requiredFields = ['registerName', 
							'registerEmail', 'registerPassword', 
							'registerConfirmPassword', 'registerPhoneNo']
	requiredFields.forEach((field) => {
		if(!values[field]) {
			errors[field] = 'Required'
		}
	})
	if(values.registerEmail && ! /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.registerEmail)) {
		errors.registerEmail = 'Enter a valid email address'
	}
	if(values.registerPassword !== values.registerConfirmPassword) {
		errors.registerConfirmPassword = 'Passwords do not match'
	}
	return errors
}

const renderTextField = ({input, label, meta: {touched, error}, ...custom}) => (
  <TextField
    style={{width: '70%', marginLeft: '15%'}}
    hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

const renderSelectField = ({
  input,
  label,
  meta: {touched, error},
  children,
  ...custom
}) => (
  <SelectField
    style={{width: '70%', marginLeft: '15%'}}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    onChange={(event, index, value) => input.onChange(value)}
    children={children}
    {...custom}
  />
)

let RegisterForm = (props) => {
	const {handleSubmit} = props;
	var {registeringUser} = props.loginStates;
	const spinner = ( <img  className="spinner_gif" src={spinner_img} />);
	return (
			<form onSubmit={handleSubmit}>
				<div>
			        <Field name="registerName" component={renderTextField} disabled={registeringUser} type="text" label="Name"/>
			    </div>
			    {/*<div>
			        <Field name="registerLastName" component={renderTextField} disabled={registeringUser} type="text" label="Last Name"/>
			    </div>*/}
			    <div>
			        <Field name="registerEmail" component={renderTextField} disabled={registeringUser} disabled={registeringUser} type="email" label="Email Address"/>
			    </div>
			    <div>
			        <Field name="registerPassword" component={renderTextField} disabled={registeringUser} type="password" label="Password"/>
			    </div>
			    <div>
			        <Field name="registerConfirmPassword" component={renderTextField} disabled={registeringUser} type="password" label="Confirm Password"/>
			    </div>
			    <div>
			        <Field name="registerCountry" component={renderSelectField} disabled={registeringUser} label="Country (CountryCode)">
			        	{countryDetails.map((data) => (
		        			<MenuItem  key={data.Country} value={data.Country} primaryText={data.Country  + "   ( " + data.Code + 	" )"}/>
		        		))}
			        </Field>
			    </div>
			    {/*}
			    <div>
			        <Field name="country" component={renderTextField} disabled={registeringUser} type="text" label="Country"/>
			    </div>
				*/}
			    <div>
			        <Field name="registerPhoneNo" component={renderTextField} disabled={registeringUser} type="text" label="Phone Number"/>
			    </div>
			    <div style={{marginTop: '10px', width: '70%', marginLeft: '15%'}}>
			        <Button bsStyle="primary" bsSize="large" type="submit" block disabled={registeringUser}>
						{registeringUser? spinner: null }
						<span> Register</span>
					</Button>
			    </div>
			</form>
		)
}

RegisterForm = reduxForm({
	form: 'RegisterForm',
	validate
})(RegisterForm)

function mapStateToProps(state) {
	return {
		loginStates: state.loginStore
	}
}
export default connect(mapStateToProps)(RegisterForm);