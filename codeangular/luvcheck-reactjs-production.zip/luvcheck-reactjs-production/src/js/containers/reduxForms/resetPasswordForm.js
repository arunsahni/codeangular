import React from 'react';
import {Field, reduxForm} from 'redux-form';
import {Button} from 'react-bootstrap';
import {connect} from 'react-redux';
import TextField from 'material-ui/TextField';
import Spinner from 'react-spinkit';
const spinner_img = require('../../../../public/resources/images/spinner.gif');

// Synchronous validation on input fields
const validate = (values) => {
	const errors = {}
	const requiredFields = ['resetPassUserId', 'resetNewPassword','resetConfirmPassword']
	requiredFields.forEach((field) => {
		if(!values[field]) {
			errors[field] = 'Required'
		}
	})
	if(values.resetPassUserId && !( /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.resetPassUserId) || /^[2-9]{1}[0-9]{9}$/.test(values.resetPassUserId))) {
		errors.resetPassUserId = 'Enter a valid email or phone number'
	}
	if(values.resetNewPassword !== values.resetConfirmPassword) {
		errors.resetConfirmPassword = 'Passwords do not match'
	}
	return errors
}

const renderTextField = ({input, label, meta: {touched, error}, ...custom}) => (
  <TextField
  	style={{width: '70%', marginLeft: '15%'}}
    hintText={label}
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
    {...custom}
  />
)

let ResetPasswordForm = (props) => {
	const {handleSubmit} = props
	const {resettingUserPassword} = props.loginStates
	const spinner = (      <img  className="spinner_gif" src={spinner_img} />)
	return (
		<form onSubmit={handleSubmit}>
			<div>
				<Field name="resetPassUserId" component={renderTextField} type="text" label="Enter Email or Phone Number"/>
			</div> 
			<div>
				<Field name="resetNewPassword" component={renderTextField} type="password" label="Enter New Password"/>
			</div>
			<div>
				<Field name="resetConfirmPassword" component={renderTextField} type="password" label="Confirm Password"/>
			</div>
			<div style={{marginTop: '10px', width: '70%', marginLeft: '15%'}}>
			    <Button bsStyle="primary" bsSize="large" type="submit" block disabled={resettingUserPassword}><i style={{display: 'flex', align: 'center'}}>{resettingUserPassword? spinner: null }</i><span> Reset Password</span></Button>
			</div>
		</form>
		)
}

ResetPasswordForm = reduxForm({
	form: 'resetPasswordForm',
	validate
})(ResetPasswordForm);

function mapStateToProps(state) {
	return {
		loginStates: state.loginStore
	}
}

export default connect(mapStateToProps)(ResetPasswordForm);