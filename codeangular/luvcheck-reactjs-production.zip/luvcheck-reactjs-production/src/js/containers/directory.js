import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

//Material-ui imports
import {Tabs, Tab} from 'material-ui/Tabs';
import {Row, Col} from 'react-bootstrap';

//Custom imports
import FriendList from './components/friendPage';
import InvitedList from './components/invited';
import PendingRequests from './components/pendingRequests';
import {getFriendList, getPendingRequests, getSentInvitations} from '../actions/directoryActions';
import styles from '../../../public/resources/styles/directory.css'

class Directory extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			tabValue: 'friendList'
		}
		//For polling interval
		this.friendListInterval = null
		this.pendingRequestsInterval = null
		this.invitedListInterval = null
	}

	componentWillMount(){

		var token = localStorage.getItem('authToken');
		this.props.getFriendList(token);
	    /*var token = localStorage.getItem('authToken');

	    //Get Friend List
	    this.props.getFriendList(token);
		this.friendListInterval = setInterval(()=>{
			this.props.getFriendList(token);
		}, 5000)

		// Get pending requests
		this.props.getPendingRequests(token);
		this.pendingRequestsInterval = setInterval(()=>{
			this.props.getPendingRequests(token);
		}, 5000)

		//Get sent Invitations
	    this.props.getSentInvitations(token);
		this.invitedListInterval = setInterval(()=>{
			this.props.getSentInvitations(token);
		}, 5000)*/
	}
	handleChange = (val) => {
		var token = localStorage.getItem('authToken');
		this.setState({tabValue: val})
		if(val === 'friendList') {
			this.props.getFriendList(token);
		}
		else if(val === 'invitedList') {
			this.props.getSentInvitations(token);
		}
		else if(val === 'pendingRequests') {
			this.props.getPendingRequests(token);
		}
	}
	render() {
		let friendCount = this.props.userStore && this.props.userStore.contactList.friendList.length ;
		let pendingCount = this.props.userStore && this.props.userStore.contactList.pendingRequests.length ;
		let inviteCount = this.props.userStore && this.props.userStore.contactList.invitations.length ;
		return (
			<div style={{height:"calc(100vh - 100px"}} className="directory">
				<Row>
					<Col xs={12}>
						<Tabs
							value={this.state.tabValue}
							onChange={this.handleChange}
							style={{}}
							inkBarStyle={{backgroundColor:'#237bfb'}} 
							tabItemContainerStyle={{backgroundColor:'#ffffff'}}
						>
							<Tab style={{color: 'black'}} label={"Friends ("+friendCount+")"} value="friendList">
								<FriendList/>
							</Tab>
							<Tab style={{color: 'black'}} label={"Sent Invitations ("+inviteCount+")"} value="invitedList">
								<InvitedList/>
							</Tab>
							<Tab style={{color: 'black'}} label={"Pending Requests ("+pendingCount+")"} value="pendingRequests">
								<PendingRequests/>
							</Tab>
						</Tabs>
					</Col>
				</Row>
			</div>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		userStore: state.userInfoReducer
	}
}

const mapDispatchToProps = (dispatch) => {
	return {
		getFriendList: (token, uid) => dispatch(getFriendList(token, uid)),
		getPendingRequests: (token, uid) => dispatch(getPendingRequests(token, uid)),
		getSentInvitations: (token, uid) => dispatch(getSentInvitations(token, uid)),
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(Directory);

/*
<div className="directory">
	<Row>
		<Col xs={12}>
			<Tabs
				value={this.state.tabValue}
				onChange={this.handleChange}
				className="directoryTabs"
				>
				<Tab label="Friends" value="friendList">
					<FriendList/>
				</Tab>
				<Tab label="Sent Invitations" value="invitedList">
					<InvitedList/>
				</Tab>
				<Tab label="Pending Requests" value="pendingRequests">
					<PendingRequests/>
				</Tab>
			</Tabs>
		</Col>
	</Row>
</div>
*/