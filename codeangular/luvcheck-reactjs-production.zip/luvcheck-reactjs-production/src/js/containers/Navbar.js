import React, {Component} from 'react';
import {Link, withRouter} from 'react-router';
import {Navbar, Nav, NavItem, NavDropdown,/*MenuItem*/} from 'react-bootstrap';
import {IndexLinkContainer} from 'react-router-bootstrap';

import Badge from 'material-ui/Badge';
import IconButton from 'material-ui/IconButton';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import CallIcon from 'material-ui/svg-icons/communication/call';
import GroupAddIcon from 'material-ui/svg-icons/social/group-add';
import Avatar from 'material-ui/Avatar';
import {Popover, PopoverAnimationVertical} from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';
//importing css
import styles from '../../../public/resources/styles/navbar.css'
const header_img = require('../../../public/resources/images/LuvCheckFinal2.png');

class Navigation extends Component {
	
	constructor() {
		super();
		this.state = {
			openUserOption: false,
			anchorUserOption: null
		}
	}

	_openUserOption = (e) => {
		this.setState({
			openUserOption: true,
			anchorUserOption: e.target
		})
	};

	_handleUserOptionClose = () => {
		console.log('hello');
		this.setState({
			openUserOption: false
		})
	};

	_handleProfileClick = () => {
		this.setState({
				openUserOption: false
			}, 
			() => this.props.history.push('/profileSettings')
		)		
	};

	_handleSignOut = () => {
		this.setState({
				openUserOption: false
			}, 
			() => {
			localStorage.clear(); 
			this.props.history.push('/login');
		})	
	};

	render() {
		return (
			<div className="header">
				<Navbar  fluid collapseOnSelect fixedTop className="topNavbar">
					<Navbar.Header>
						<Navbar.Brand>
						<div style={{display: 'flex'}}>
							<i className="material-icons" style={{color: 'black', marginRight: 10, cursor: 'pointer'}} onClick={this.props.toggleSideBar}>dehaze</i>
							<a href="#" className="navbar-left"><img  style={{width:"142px"}} src={header_img}/></a>
						</div>
						</Navbar.Brand>
						<Navbar.Toggle />					
					</Navbar.Header>
					<Nav pullRight>
						<NavItem><NotificationsIcon/></NavItem>
						<NavItem>
							<Avatar style={{width: 28, height: 28}}>
								<i onClick={this._openUserOption} className="material-icons">person</i>
	                        </Avatar>
						</NavItem>
					</Nav>
				</Navbar>
				<Popover
                    open={this.state.openUserOption}
                    anchorEl={this.state.anchorUserOption}
                    style = {{width: '200px'}}
                    onRequestClose={this._handleUserOptionClose}
                    animation={PopoverAnimationVertical}
                >
                    <Menu desktop={true}>
                        <MenuItem value='profile' primaryText='Profile' onClick={this._handleProfileClick}/>
                        <MenuItem value='signout' primaryText='Sign Out' onClick={this._handleSignOut}/>
                    </Menu>
                </Popover>
			</div>
		)
	}
}

export default (withRouter(Navigation));

//<ListItem primaryText="Profile" leftIcon={<PersonIcon />} onClick={()=> this.props.history.push('/profileSettings')}/>