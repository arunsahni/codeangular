import React from 'react';
import {Link, withRouter} from 'react-router-dom';
import {Field, reduxForm, getFormValues, submit} from 'redux-form';
import {Grid, Col, Row, Modal} from 'react-bootstrap';
import {Card, CardTitle, CardText} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Dialog from 'material-ui/Dialog';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import axios from 'axios';

//Custom imports
import UrlHelper from '../../utils/UrlHelper';
import {resettingPassword, passwordResetReqComplete, confirmingOTP, confirmingOTPComplete, callMeOTPAction, confirmPassResetAction, resetPasswordAction} from '../actions/loginRegisterActions';
import ResetPasswordForm from './reduxForms/resetPasswordForm';
import OTPForm from './OTPForm';

var img = require('../../../public/resources/images/logo.png')
const spinner_img = require('../../../public/resources/images/spinner.gif');

class ResetPassword extends React.Component {
	
	constructor(props){
		super(props);
		this.state = {
			openPasswordResetDialog: false,
			callmeTimer: null
		}
		this.interval = null;
	}
	componentWillUnmount() {
		clearInterval(this.interval);
	}
	resetPassword = (values) => {

		this.props.resettingPassword();
		console.log(values);
		var data = {
			username: values.resetPassUserId
		}
		console.log(data);

		this.props.resetPasswordAction(data)
			.then((response) => {
				console.log(response);
				this.setState({authyId: response.data.authyId, cellphone: response.data.cellphone, openPasswordResetDialog: true})

				//Call me option timer
				this.setState({callmeTimer: 30}, ()=> {
					this.interval = setInterval(() => {
						this.setState((prevState) => ({callmeTimer: prevState.callmeTimer - 1}))
					}, 1000)
					if(this.state.callmeTimer === 0) {
						clearInterval(this.interval);
					}
				});

			})
			.catch((error)=> {
				console.log(error);
				this.props.errorAlert(error, 'bottom');
			})
	}
	callMeOTP = () => {
		console.log('call me called')
		this.props.callMeOTPAction(authyId)
			.then((response) => {
				console.log('call made', response)
				this.props.successAlert('You will Receive a call shortly', 'top');
			})
			.catch((error) => {
				console.log(error)
				this.props.errorAlert('Error while initiating a call', 'top');
			})
	}

	closeOTPForm = () => {
		this.setState({openPasswordResetDialog: false})
	}
	confirmPassReset = (values) => {
	    var {resetPassValues} = this.props;
	    this.props.confirmingOTP();
        console.log(values);
		var data = {
			username: resetPassValues.resetPassUserId,
			password: resetPassValues.resetNewPassword,
			password_confirm: resetPassValues.resetConfirmPassword,
			otp: values.OTP,
			authyId: this.state.authyId
		}
		console.log('OTP', data)
		this.props.confirmPassResetAction(data)
			.then((response) => {
				console.log(response);
				this.closeOTPForm();
				this.props.successAlert('Password Reset SuccessFully', 'bottom-left')
				this.props.history.push('/login')
				this.props.confirmingOTPComplete(response)
			})
			.catch((error)=> {
				console.log(error);
				this.props.errorAlert(error, 'top');
				this.props.confirmingOTPComplete(error)
			})
	}
	render() {
		//Setting OTP dialog width 
		var dialogStyle={
			width: '40%',
			maxWidth: 'none'
		}
		//Action buttons style
		var actionsContainerStyle = {
			textAlign: 'center'
		}
		var disabledCallmeString = "Get OTP on Call ( 00: " + ("0" + this.state.callmeTimer).slice(-2) + " )";
		var enabledCallmeString = "GET OTP on Call";

		var {confirmingRegisterOTP} = this.props.resetPassStates;
		const spinner = (      <img  className="spinner_gif" src={spinner_img} />)
		var dialogActions=[
			<FlatButton 
				label={this.state.callmeTimer > 0? disabledCallmeString: enabledCallmeString}
				disabled={this.state.callmeTimer > 0? true: false}
				style={{width: '50%'}}
				onTouchTap={()=>this.callMeOTP()}
			/>,
			<RaisedButton 
				label="Submit"
				primary={true}
				onTouchTap={() => this.props.submit('OTPConfirm')}
				style={{width: '50%'}}

			>{confirmingRegisterOTP? spinner: null}</RaisedButton>
		]
		return (
			<Grid>
				<Row>
					<Col xsOffset={4} xs={4}>
						<img className="logo" src={img} width="230px"/>
					</Col>
				</Row>
				<Row>
					<Col smOffset={2} sm={7}>
						<Card>
							<CardTitle titleStyle={{textAlign: 'center'}} title="Reset Password" />
							<CardText>
								<ResetPasswordForm onSubmit={this.resetPassword}/>
							</CardText>
						</Card>
					</Col>
				</Row>
				<Dialog 
					title={"Enter Security Code"}
					open={this.state.openPasswordResetDialog}
					modal={false}
					actions={dialogActions}
					contentStyle={dialogStyle}
					actionsContainerStyle={actionsContainerStyle}
					onRequestClose={this.closeOTPForm}
				>
					Security code has been sent to your mobile {this.state.cellphone}. Please enter the same  here to reset Password.
					<OTPForm onSubmit={this.confirmPassReset} callMeOTP={this.callMeOTP}/>
				</Dialog>
			</Grid>
		);
	}
}
function mapStateToProps(state) {
	return {
		resetPassValues: getFormValues('resetPasswordForm')(state),
		resetPassStates: state.loginStore
	}

}

function mapDispatchToProps(dispatch){
	return bindActionCreators({
			resettingPassword, 
			passwordResetReqComplete,
			confirmingOTP,
			confirmingOTPComplete,
			callMeOTPAction,
			confirmPassResetAction,
			resetPasswordAction,
			submit
		}, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(withRouter(ResetPassword));