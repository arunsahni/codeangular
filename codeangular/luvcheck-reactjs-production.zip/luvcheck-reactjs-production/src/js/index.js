import React from 'react';
import ReactDOM from 'react-dom';
import {HashRouter as Router, Route} from 'react-router-dom';
import {Switch} from 'react-router';
import {Provider} from 'react-redux';
import {createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import DetectRTC from 'detectrtc';
// Needed for onTouchTap
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();

//Importing custom components
import reducers from './reducers'
import App from './containers/App';
import Login from './containers/login';
import Register from './containers/register';
import ResetPassword from './containers/forgotPassword';
import {setDetectRTCResults} from './actions/webRTCActions.js';

import Alert from 'react-s-alert';
import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';


var store = createStore(reducers, applyMiddleware(thunk));

//Showing an alert success message on invitation success
const successAlert = (message, position) => {
	Alert.success(message, {
		position: position,
		effect: 'slide',
		timeout: 5000
	})
}
const errorAlert = (message, position) => {
	Alert.error(message, {
		position: position,
		effect: 'slide',
		timeout: 5000
	})
}
const infoAlert = (message, position) => {
	Alert.info(message, {
		position: position,
		effect: 'slide',
		timeout: 5000
	})
}

setTimeout(function () {
	DetectRTC.load(function() {
		store.dispatch(setDetectRTCResults({
			isChromeFirefox: DetectRTC.browser.isChrome || DetectRTC.browser.isFirefox,
			webcamPermission: DetectRTC.isWebsiteHasWebcamPermissions,
			microphonePermission: DetectRTC.isWebsiteHasMicrophonePermissions,
			hasWebcam: DetectRTC.hasWebcam,
			hasMicrophone: DetectRTC.hasMicrophone,
			webRTCSupport: DetectRTC.isWebRTCSupported
		}))
	});
}, 100) 

ReactDOM.render(
  	<Provider store={store}>
  		<MuiThemeProvider>
		<Router>
			<div>
				<Switch>
					<Route exact path="/login" render={()=> <Login errorAlert={errorAlert} successAlert={successAlert} infoAlert={infoAlert}/>}/>
					<Route exact path="/register" render={() => <Register errorAlert={errorAlert} successAlert={successAlert} infoAlert={infoAlert}/>}/>
					<Route exact path="/resetPassword" component={ResetPassword}/>
					<Route path="/" component={App}/>
				</Switch>
				<Alert stack={{limit: 3}} html={true} offSet={50}/>
			</div>   
		</Router> 
		</MuiThemeProvider> 
  	</Provider>,
  document.getElementById('react-app')
);
