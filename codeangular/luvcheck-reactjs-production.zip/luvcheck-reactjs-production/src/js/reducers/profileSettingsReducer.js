const intialState = {
	updatingUserInformation: false,
	resettingUserPassword: false
}

const profileReducer = (state=intialState, action)  => {
	switch(action) {
		case 'UPDATING_USER_INFO': 
			return {
				...state,
				updatingUserInformation: true
			}
		case 'USER_INFO_UPDATED':
			return {
				...state,
				updatingUserInformation: false
			}
		case 'UPDATING_USER_PASSWORD': 
			return {
				...state,
				resettingUserPassword: true
			}
		case 'USER_PASSWORD_UPDATED':
			return {
				...state,
				resettingUserPassword: false
			}
		default: 
			return state
	}
}
export default profileReducer;