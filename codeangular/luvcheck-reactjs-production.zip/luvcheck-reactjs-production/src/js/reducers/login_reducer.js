import {LOGGING_IN_USER, REGISTERING_USER, 
    LOGIN_REQUEST_COMPLETE, REGISTERING_REQUEST_COMPLETE,
    CONFIRMING_OTP,CONFIRM_OTP_COMPLETE,
    RESETTING_USER_PASSWORD, RESET_REQ_COMPLETE
} from '../actions/loginRegisterActions.js'
import {DETECT_RTC} from '../actions/webRTCActions';

const initialState = {
    loggingInUser: false,
    registeringUser: false,
    loginSuccess: false,    
    confirmingRegisterOTP: false,
    resettingUserPassword: false,
    detectRTCResults: null
}

const loginPage = (state=initialState, action) => {
	switch(action.type) {
		case LOGGING_IN_USER: 
            console.log('loggingInUser')
            return {...state, loggingInUser: true}

        case LOGIN_REQUEST_COMPLETE:
            if(action.status === 'success') 
                return {...state, loggingInUser: false, loginSuccess: true}
            else {
                return {...state, loggingInUser: false, loginSuccess: false}
            }
        case REGISTERING_USER:
            return {...state, registeringUser: true}
        case REGISTERING_REQUEST_COMPLETE: 
            return {...state, registeringUser: false}
        case CONFIRMING_OTP: 
            return {...state, confirmingRegisterOTP: true}
        case CONFIRM_OTP_COMPLETE:
            return {...state, confirmingRegisterOTP: false}
        case RESETTING_USER_PASSWORD:
            return {...state, resettingUserPassword: true}
        case RESET_REQ_COMPLETE:
            return {...state, resettingUserPassword: false}
        case DETECT_RTC:
            return {
                ...state, detectRTCResults: action.results
            }
		default: return state
	}
}
export default loginPage;