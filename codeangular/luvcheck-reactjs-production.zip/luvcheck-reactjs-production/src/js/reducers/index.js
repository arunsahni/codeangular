import {combineReducers} from 'redux';
import {reducer as formReducer} from 'redux-form';
import loginStore from './login_reducer';
import userInfoReducer from './userInfoReducer';
import addContactStore from './addContactReducer';
import profileStore from './profileSettingsReducer';
import callStore from './callReducer';

const allReducers = combineReducers({
	addContactStore,
	userInfoReducer,
	loginStore,
	profileStore,
	callStore,
	form: formReducer 
})
export default allReducers;