import {USER_LOGIN_INFORMATION, BEGIN_SESSION} from '../actions/loginRegisterActions';
import {UPDATE_USER_PROFILEPIC} from '../actions/profileSettingsActions';
import {INVITATION_SENT} from '../actions/addContactAction';
import {UPDATE_SENT_INVITATIONS, UPDATE_PENDING_REQUESTS, UPDATE_FRIEND_LIST,
	 FRIEND_REQUEST_REJECTED, FRIEND_REQUEST_ACCEPTED, INVITATION_RECEIVED,
	INVITATION_ACCEPTED} from '../actions/directoryActions';

const initialState = {
	_id: '',
	uid: '',
	profile: {
		name: '',
		email: '',
		phone: '',
		countryCode: '',
		avatar: ''
	},
	authyId: '',
	accountExpiresOn: '',
	createdDate: '',
	devices:[],
	idDeleted: '',
	isTrial: false,
	updatedDate: '',
	socket: null,
	contactList: {
		friendList: [],
		invitations: [],
		pendingRequests: []	
	}
}

const userInfoReducer = (state = initialState, action) => {
	
	switch(action.type) {

		case 'UPDATE_USER_INFO': 
			return {
				...state,
				firstname: action.payload.firstname,
				lastname: action.payload.lastname,
				email: action.payload.email,
				uid: action.payload.uid
			}
		case BEGIN_SESSION: 
			console.log(action.payload)
			return {
				...state,
				socket: action.payload.socket
			}
		case USER_LOGIN_INFORMATION:
			if(action.status === 'success') {
				return {
					...state,
					_id: action.data._id,
					verified: action.data.verified,
					updatedDate: action.data.updatedDate,
					uid: action.data.uid,
					profile: {
						...state.profile,
						...action.data.profile
					},
					isTrial: action.data.isTrial,
					isDeleted: action.data.isDeleted,
					devices: action.data.devices,
					createdDate: action.data.createdDate,
					authyId: action.data.authyId,
					accountExpiresOn: action.data.accountExpiresOn

				}
			}
			return state
		case UPDATE_USER_PROFILEPIC: 
			return {
				...state,
				profile: {
					...state.profile,
					avatar: action.profilePic
				}
			}
		case UPDATE_SENT_INVITATIONS:
			return {
				...state,
				contactList: {
					...state.contactList,
					invitations: [
						...action.invitations
					]
				}
			}
		case UPDATE_PENDING_REQUESTS: 

			return {
				...state,
				contactList: {
					...state.contactList,
					pendingRequests: [
						...action.pendingRequests
					]
				}
			}
		case UPDATE_FRIEND_LIST: 
			return {
				...state,
				contactList: {
					...state.contactList,
					friendList: [
						...action.friendList
					]
				}
			}
		case FRIEND_REQUEST_ACCEPTED: 
			console.log(action, state, 'reducer')
			return {
				...state,
				contactList: {
					...state.contactList,
					friendList: [
						...state.contactList.friendList,
						action.data
					],
					pendingRequests: [
						...state.contactList.pendingRequests.slice(0, action.index),
						...state.contactList.pendingRequests.slice(action.index + 1)
					]
				}

			}
		case FRIEND_REQUEST_REJECTED: 
			return {
				...state,
				contactList: {
					...state.contactList,
					pendingRequests: [
						...state.contactList.pendingRequests.slice(0, action.index),
						...state.contactList.pendingRequests.slice(action.index + 1)
					]
				}
			}
		case INVITATION_RECEIVED: 
			return {
				...state,
				contactList: {
					...state.contactList,
					pendingRequests: [
						...state.contactList.pendingRequests,
						action.data
					]
				}
			}
		case INVITATION_ACCEPTED:
			return {
				...state,
				contactList: {
					...state.contactList,
					friendList: [
						...state.contactList.friendList,
						action.data
					]
				}
			}
		case INVITATION_SENT:
			return {
				...state,
				contactList: {
					...state.contactList,
					invitations: [
						...state.contactList.invitations,
						action.data
					]
				}
			}
		default:
			return state
	}
}

export default userInfoReducer;