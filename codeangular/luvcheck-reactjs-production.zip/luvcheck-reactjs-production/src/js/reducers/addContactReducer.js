import {UPDATE_SEARCH_VALUE, INVALID_SEARCH_VALUE, 
	FOUND_EXISTING_USER, USER_NOT_FOUND, 
	VALID_SEARCH_VALUE, INVITATION_ALREADY_SENT} from '../actions/addContactAction'

const initialValue = {
	searchValue: '',
	foundMatchedUser: false,
	alreadySentInvitation: false,
	isSearchValid: false,
	userData: {},
}

const addContactReducer = (state = initialValue, action) => {
	switch(action.type) {
		case UPDATE_SEARCH_VALUE: 
		    
			return {
				...state, 
				searchValue: action.value
			}
		case INVALID_SEARCH_VALUE: 
			return {
				...state,
				isSearchValid: false,
			}
		case VALID_SEARCH_VALUE: 
			return {
				...state,
				isSearchValid: true,
			}
		case FOUND_EXISTING_USER: 
			return {
				...state,
				foundMatchedUser: true,
				alreadySentInvitation: false,
				userData: action.data.data
			}
		case USER_NOT_FOUND:
			return {
				...state,
				foundMatchedUser: false,
				alreadySentInvitation: false,
				userData: {}
			}
		case INVITATION_ALREADY_SENT:
			return {
				...state,
				foundMatchedUser: true,
				alreadySentInvitation: true,
				userData: action.data.data
			}
		default: return state
	}
}

export default addContactReducer;