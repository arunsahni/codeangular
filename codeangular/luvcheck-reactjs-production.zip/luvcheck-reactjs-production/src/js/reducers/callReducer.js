import {INCOMING_CALL, SET_TWILLIO_CRED, PLACED_CALL, CALL_NOT_PICKED, ANSWER_CALL, MISSED_CALL, CALL_STARTED, CALL_CONNECTED, END_CALL} from '../actions/callActions';
import {PARTICIPANT_CONNECTED, UPDATE_ROOM, TOGGLE_AUDIO, TOGGLE_VIDEO, VIDEO_ENABLE, VIDEO_DISABLE} from '../actions/webRTCActions';

const intitialState = {
	incomingCall: false,
	screenSharing: false,
	activeCall: false,
	pendingCallDetails: null,
	callStarted: false,
	callDetails: null,
	twilioCredentials: null,
	participantsInfo: null,
	room: null,
	isMuted: false,
	isPaused: false,
	userVideoState: true
}
const callReducer = (state=intitialState, action) => {
	switch(action.type) {
		case SET_TWILLIO_CRED:
			return {
				...state,
				twilioCredentials: action.cred
			}
		case UPDATE_ROOM:
			return {
				...state,
				room: action.room
			}
		case PLACED_CALL: 
			return {
				...state,
				pendingCallDetails: action.payload,
				activeCall:true
			}
		case INCOMING_CALL: 
			return {
				...state,
				incomingCall: true,
				pendingCallDetails: action.payload
			}
		case ANSWER_CALL: 
			return {
				...state,
				activeCall: true,
				incomingCall: false
			}
		case PARTICIPANT_CONNECTED: 
			return {
				...state,
				participantsInfo: {
					...state.participantsInfo,
					room: action.room,
					participant: action.participant,
					track: action.track
				}
			}
		case CALL_STARTED: 
			return {
				...state,
				callStarted: true,
				callDetails: action.callData
			}
		case END_CALL:
			return {
				...state,
				callStarted: false,
				callDetails: null,
				activeCall: false,
				incomingCall: false,
				pendingCallDetails: null, 
				isMuted: false,
				isPaused: false,	
				userVideoState: true
			}
		case MISSED_CALL:
			return {
				...state,
				incomingCall: false,
				activeCall: false,
				room: null,
				pendingCallDetails: null
			}
		case CALL_CONNECTED:
			return {
				...state,
				incomingCall: false
			}
		case CALL_NOT_PICKED:
			return {
				...state,
				activeCall: false,
				incomingCall: false,
				room: null,
				pendingCallDetails: null
			}
		case TOGGLE_AUDIO:
			return {
				...state,
				isMuted: action.isMuted
			}
		case TOGGLE_VIDEO:
			return {
				...state,
				isPaused: action.isPaused
			}
		case VIDEO_DISABLE:
			return {
				...state,
				userVideoState: false
			}
		case VIDEO_ENABLE:
			return {
				...state,
				userVideoState: true
			}
		default:
			return state
	}
}

export default callReducer;