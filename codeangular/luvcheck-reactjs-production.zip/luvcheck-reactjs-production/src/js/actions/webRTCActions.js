//import Video from 'twilio-video';
import {END_CALL} from './callActions';
import {leaveCall} from './callActions';
var Video = Twilio.Video;

export const PARTICIPANT_CONNECTED='PARTICIPANT_CONNECTED';
export const UPDATE_ROOM='UPDATE_ROOM';
export const TOGGLE_AUDIO='TOGGLE_AUDIO';
export const TOGGLE_VIDEO='TOGGLE_VIDEO';
export const VIDEO_DISABLE='VIDEO_DISABLE';
export const VIDEO_ENABLE='VIDEO_ENABLE';
export const TRACK_ADDED='TRACK_ADDED';
export const DETECT_RTC='DETECT_RTC';

export function setDetectRTCResults (results) {
	return { type: DETECT_RTC, results }
}
export const startAudioVideo = (videoDOM) => {
	
	return (dispatch) => {
		console.log(location.protocol);

		var finishTime = new Date()
		finishTime.setSeconds(finishTime.getSeconds()+5);
		console.log(videoDOM, "video");
		//Checking if Video DOM is available within 5 seconds
		var intervalId = setInterval(()=> {

			if (new Date()>finishTime) {
				console.error("Error: Couldn't assign feed in allowed time. Try again")
				clearInterval(intervalId)
			}
			
			if (videoDOM) {
				console.log('connecting to element', videoDOM)
				if(location.protocol === 'https:' || location.protocol === 'http:' || location.protocol === 'localhost') {
					navigator.mediaDevices.getUserMedia({video: true, audio: true})
						.then((stream) => {
							console.log(videoDOM)
							videoDOM.srcObject = stream
							videoDOM.play();
						})
						.catch((err) => {
							console.log("Error during video initialisation ", err);
								console.log('dispatch')
						    
						})
				}
				clearInterval(intervalId)
			} else {
				console.log('could not find dom');
			}
		}, 250)

	}	
	
}

export const updateRoom = (room) => {
	return {type: UPDATE_ROOM, room}
}
//Connect to room
export const connectToRoom  = (videoDOM, callerVideo) => {

	console.log(videoDOM, "video");
	return (dispatch, getState) => {
		console.log(getState(), 'In room');
		var {pendingCallDetails, twilioCredentials} = getState().callStore;

		Video.Client(twilioCredentials.token).connect(
			{ to: pendingCallDetails.roomInfo.roomId, localMedia: window.localStream }	)
			.then((room) => {
				console.log('Connected To Room', room);

				dispatch({type: UPDATE_ROOM, room})
				//video screen for local user
				room.localParticipant.on('trackAdded', track=> {
					console.log('localParticipant', track);
					dispatch({type: UPDATE_ROOM, room})
					//addStreamToDom(videoDOM, null, track.mediaStream)
				})

				room.localParticipant.on('trackRemoved', track=> {
					console.log('localParticipant removed', track);
					dispatch({type: UPDATE_ROOM, room})
					//addStreamToDom(videoDOM, null, window.localStream.videoTracks.values().next().value.mediaStream)
				})

				//Add my video too
				console.log('setting up myVideo', callerVideo);
				addStreamToDom(callerVideo, null, window.localStream.videoTracks.values().next().value.mediaStream)

				//Room participant connected
				room.participants.forEach((participant) => participantConnected(participant, videoDOM, room, dispatch));
				room.on('participantConnected', (participant) => participantConnected(participant, videoDOM, room, dispatch));

				//Room participant disconnected
				room.on('participantDisconnected', (participant) => participantDisconnected(participant, room, dispatch));
				room.once('disconnected', error => {
					room.participants.forEach((participant) => participantDisconnected(participant, room, dispatch))
				})

			})
	}
	
}

//Toggle Audio
export const toggleAudio = () => {
	return (dispatch, getState) => {
		console.log('toggleCalled', getState().callStore.roomId);
		if(getState().callStore.room) {
			var {room} = getState().callStore
			//if not muted play else pause
			if(!room.localParticipant.media.isMuted) {
				room.localParticipant.media.mute();
				dispatch({type: TOGGLE_AUDIO, isMuted: true});
			}
			else {
				room.localParticipant.media.unmute();
				dispatch({type: TOGGLE_AUDIO, isMuted: false});
			}
			console.log(room.localParticipant, 'participant muting');
		}

	}
}

//Toggle Video
export const toggleVideo = () => {
	return (dispatch, getState) => {
		console.log('toggleCalled', getState().callStore.roomId);
		if(getState().callStore.room) {
			var {room} = getState().callStore
			//if not muted play else pause
			room.localParticipant.media.tracks.forEach((track) => {
				console.log(track, 'track');
				if(track.kind === 'video') {
					if (track.isEnabled) {
						dispatch({type: TOGGLE_VIDEO, isPaused: true});
				        track.disable();
				      } else {
				      	dispatch({type: TOGGLE_VIDEO, isPaused: false});
				        track.enable();
				      }
				}
			})
			/*if(!room.localParticipant.media.isPaused) {
				console.log(room.localParticipant.media, 'media');
				room.localParticipant.media.pause();
			}
			else {
				room.localParticipant.getVideoTrack()[0].enabled = true;
				dispatch({type: TOGGLE_VIDEO, isPaused: false});
			}*/
			console.log(room.localParticipant, 'participant pausing');
		}

	}
}
const participantDisconnected = (participant, room, dispatch) => {
	console.log('Room participant size', room.participants.size);

	//leave the call if all participants have left
	if(room.participants.size == 0)  {
		room.localParticipant.media.detach();
		room.disconnect();
		room.localParticipant.media.stop();
		window.localStream.stop();
		window.localStream = null;
	}

	dispatch({type: UPDATE_ROOM, room });
	/*dispatch({type: END_CALL})*/
	dispatch(leaveCall())
}

const participantConnected = (participant, videoDOM, room, dispatch) => {

	participant.on('trackAdded', track => {
		console.log('trackAdded', track);
		dispatch({type: UPDATE_ROOM, room})
		if(track.kind === "video") {
			if (participant.media.videoTracks.size == 2) {
				dispatch({type: TRACK_ADDED});
				addStreamToDom(videoDOM, null, track.mediaStream)
				//addStreamToDom(domStringFromParticipant(participant)+'-mini-vid', participant)
			} else {
				addStreamToDom(videoDOM, participant)
			}
		}
	})

	participant.on('trackRemoved', track => {
		console.log('trackRemoved', track)
		dispatch({type: UPDATE_ROOM, room})
		if (track.kind == 'video') {
			addStreamToDom(videoDOM, participant)
		}

	})

	participant.on('trackDisabled', track => {
		console.log('trackDisabled');
		if(track.kind == 'video') {
			dispatch({type: VIDEO_DISABLE})
		}
		
	})

	participant.on('trackEnabled', track => {
		console.log('trackEnabled', track);
		addStreamToDom(videoDOM, null, track.mediaStream)
		dispatch({type: VIDEO_ENABLE})
	})
}

const addStreamToDom = (videoDOM, participant, override) => {

	var finishTime = new Date()
	finishTime.setSeconds(finishTime.getSeconds()+5);
	console.log(videoDOM, "video");
	var intervalId = setInterval(()=> {

		if (new Date()>finishTime) {
			console.error("Error: Couldn't assign feed in allowed time. Try again")
			clearInterval(intervalId)
		}
		
		if (videoDOM) {
			console.log('connecting to element')	
			if (override) {
				console.log(override, 'override')
				videoDOM.srcObject = override
			} else {
				videoDOM.srcObject = participant.media.mediaStreams.values().next().value
			}
			clearInterval(intervalId)
		} else {
			console.log('could not find dom for')
		}
	}, 250)
}

/*addVideoToDOM = (props) => {
		const {participant, track} = props.participantsInfo;
		//If two people in room
		setInterval(() => {

			
			if(participant.media.videoTracks.size == 1) {
				
				this.contactVideo.srcObject = track.mediaStream	;
			}
		}, 250);
		
	}*/