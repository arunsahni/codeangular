//import Video from 'twilio-video';
import {connectToRoom} from './webRTCActions';

export const PLACED_CALL = 'PLACED_CALL';
export const INCOMING_CALL = 'INCOMING_CALL';
export const ANSWER_CALL = 'ANSWER_CALL';
export const END_CALL = 'END_CALL';
export const MISSED_CALL = 'MISSED_CALL';
export const LEAVE_CALL = 'LEAVE_CALL';
export const CALL_RESPONSE = 'CALL_RESPONSE'
export const CALL_STARTED = 'CALL_STARTED';
export const SET_TWILLIO_CRED = 'SET_TWILLIO_CRED';
export const START_STREAM = 'START_STREAM';
export const CALL_NOT_PICKED='CALL_NOT_PICKED';
export const CALL_CONNECTED='CALL_CONNECTED';

var Video = Twilio.Video;

//Settin Twilio credentials

export function setTwillioCred(cred) {
	return {type: SET_TWILLIO_CRED, cred}
}

//export function makeCall(connectionId, callType, dispatch, activeCall) {
export function placeCall(socket, callerUid, callerName, token) {

	console.log('placeCall', callerUid, callerName);
	return (dispatch, getState) =>  {
		if (socket) {

			socket.emit('placeCall', {
				toUser: {
					uid: callerUid,
					name: callerName
				},
				callType: 'normal',
				activeCall: false,

			}, function (callData) {
				console.log('placed call', callData);
				dispatch( {type: PLACED_CALL, payload: callData} )
			});
		}
	}
}


export function incomingCall(callData) {
	return {type: INCOMING_CALL, payload: callData}
}

export function answerCall(socket, callId, response, activeCall) {

	return (dispatch) => {
		if (socket) {

			socket.emit('answerCall', {
				callId,
				response,
				activeCall
			}, (response) => {
				console.log('response');
			})

			dispatch( {type: ANSWER_CALL, callId, response, activeCall} )	
		}
	}
		
}

export function rejectCall(socket, callId, response, activeCall) {
	return (dispatch) => {
		if (socket) {
			console.log('rejectCall')
			socket.emit('answerCall', {
				callId,
				response,
				activeCall
			})
			dispatch({type: END_CALL});
		}
	}
	//return {type: END_CALL}
}

export function endCall() {
	console.log('endCall socket event');

	return (dispatch, getState) => {

		const {pendingCallDetails} = getState().callStore;
		const {socket} = getState().userInfoReducer;
		if (socket && pendingCallDetails !== null) {
			socket.emit('endCall', {
				callId: pendingCallDetails.roomInfo.callId
			})

		}
		window.localStream = undefined;

		dispatch({type: END_CALL});
	}
		
}

export function missedCall() {
	console.log('missedCall');
	return {type: MISSED_CALL }
}

export function callResponse(data) {
	console.log('call response', data);
	return (dispatch) => {
		if(data.status=== 'missed') {
			dispatch({type: CALL_NOT_PICKED})
		}
	}
}

export function callStarted(callData) {
	return {type: CALL_STARTED, callData}
}


export function leaveCall() {

	return (dispatch, getState) => {
		var {room} = getState().callStore;

		if(room) {
			room.disconnect();
			room.localParticipant.media.stop()
			room.localParticipant.media.detach();

			navigator.mediaDevices.getUserMedia({audio:true,video:true})
				.then(stream => {

					stream.getTracks().forEach(track => {
						track.stop()
					});

				})
				.catch( (err) =>{
					console.log(err);
				});
		}
		dispatch(endCall())
	}
}

export function toggleScreenSharing(current, dispatch) {
	var localMedia = window.localStream;

	if (current) {


		localMedia.tracks.forEach(track=> {
			if (track.mediaStreamTrack.label== 'Screen') {
				localMedia.removeTrack(track);
			}
		});


		dispatch({type: TOGGLE_SCREENSHARING, screenSharing: false})
	} else {
		getScreenId(function (error, sourceId, screen_constraints) {
			// error    == null || 'permission-denied' || 'not-installed' || 'installed-disabled' || 'not-chrome'
			// sourceId == null || 'string' || 'firefox'
			navigator.getUserMedia(screen_constraints, function (stream) {

				localMedia.addStream(stream);
				dispatch({type: TOGGLE_SCREENSHARING, screenSharing: true})

			}, function (error) {
				alert('Please install screensharing plugin here. https://chrome.google.com/webstore/detail/screen-capturing/ajhifddimkapgcifgcodmmfdlknahffk')
				console.error(error);
			});
		});
	}
}

//Call actions attached to socket on refresh of page or when the user logs in
export function attachToSocket(socket, getState, dispatch) {
	socket.on('incomingCall', function (data) {
		dispatch ( incomingCall(data) )
	})

	socket.on('missedCall', function () {
		dispatch ( missedCall() )
	})

	socket.on('twillio-log', function (cred) {
		dispatch ( setTwillioCred(cred) )
	})

	socket.on('callResponse', function (data) {
		dispatch ( callResponse(data) )
	})

	//socket event when the OP cancelled the call without me picking up
	socket.on('callEnded', function(data){
		dispatch({type: END_CALL})
	})
	//OP rejected to call
	socket.on('rejectedCall', function(data) {
		dispatch({type: END_CALL});
	});
	
	socket.on('callStarted', function (data) {
		//var socket = userStore.getState().socket
		window.localStream = new Video.LocalMedia();
		if(getState().callStore.activeCall === false) {
			dispatch({type: CALL_CONNECTED})
		}
		else {

			function errorMessage(message, e) {
				alert(message, typeof e == 'undefined' ? '' : e);
				//alert(message);
			}

			var start = new Date()

			if (location.protocol === 'https:' || window.location.hostname === 'localhost') {
				navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
				if (navigator.getUserMedia) {
					navigator.getUserMedia({ audio: true, video: true }, function (stream) {


						//actually run the stream
						Video.getUserMedia().then(mediaStream => {
							window.localStream.addStream(mediaStream);
							dispatch ( callStarted(data) )
						});


						var mediaStreamTrack = stream.getVideoTracks()[0];
						if (typeof mediaStreamTrack != "undefined") {
							mediaStreamTrack.onended = function () {//for Chrome.

							}
						} else errorMessage('Permission denied! Please enable Video Permissions on this page and refresh');
					
					}, function (e) {
						//only show this error when the chat is starting
						if (new Date() > start.setSeconds(start.getSeconds()+10)) {
							return
						}

						var message;
						switch (e.name) {
							case 'NotFoundError':
							case 'DevicesNotFoundError':
								message = 'No webcam found. Please refresh the page';
								break;
							case 'PermissionDeniedError':
							case 'SecurityError':
								message = 'Permission denied! Please enable Video Permissions on this page and refresh';
								break;
							default: errorMessage('Rejected!', e);
								return;
						}
						errorMessage(message);
					});
				} else errorMessage('This is an uncompatible browser! Please use the latest version of chrome');
			} else errorMessage('Use https protocol in order to do video chats on this page.')
		}
	})
}