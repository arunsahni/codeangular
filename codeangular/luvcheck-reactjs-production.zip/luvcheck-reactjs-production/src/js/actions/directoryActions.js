import axios from 'axios';
import UrlHelper from '../../utils/UrlHelper'

export const UPDATE_FRIEND_LIST='UPDATE_FRIEND_LIST';
export const UPDATE_SENT_INVITATIONS='UPDATE_SENT_INVITATIONS';
export const UPDATE_PENDING_REQUESTS='UPDATE_PENDING_REQUESTS';
export const FRIEND_REQUEST_ACCEPTED='FRIEND_REQUEST_ACCEPTED';
export const FRIEND_REQUEST_REJECTED='FRIEND_REQUEST_REJECTED';
export const INVITATION_RECEIVED='INVITATION_RECEIVED';
export const INVITATION_ACCEPTED='INVITATION_ACCEPTED';
export const getFriendList = (token) => {
	return (dispatch) => {
		const headers = {
			'Content-Type': 'application/json',
			'Authorization': 'JWT ' + token
		}

		axios.get(UrlHelper.getFriendListUrl(), {headers: headers})
			.then((response) => {
				console.log(response, 'friendList')
				if(Array.isArray(response.data)) {
					dispatch({type: UPDATE_FRIEND_LIST, friendList: response.data})
				} else {
					dispatch({type: UPDATE_FRIEND_LIST, friendList: []})
				}
				
			})
			.catch((error) => {
				console.log(error);
			})
	}
}

export const getPendingRequests = (token) => {
	return (dispatch) => {
		const headers = {
			'Content-Type': 'application/json',
			'Authorization': 'JWT ' + token
		}

		axios.get(UrlHelper.getPendingRequestUrl(), {headers: headers})
			.then((response) => {
				console.log(response, 'pendingRequests')
				if(Array.isArray(response.data)) {
					dispatch({type: UPDATE_PENDING_REQUESTS, pendingRequests: response.data})
				} else {
					dispatch({type: UPDATE_PENDING_REQUESTS, pendingRequests: []})
				}
				
			})
			.catch((error) => {
				console.log(error);
			})
	}
}

export const getSentInvitations = (token) => {
	return (dispatch) => {
		const headers = {
			'Content-Type': 'application/json',
			'Authorization': 'JWT ' + token
		}

		axios.get(UrlHelper.getSentInvitationsUrl(), {headers: headers})
			.then((response) => {
				console.log(response, 'sentInvitations')
				if(Array.isArray(response.data)) {
					dispatch({type: UPDATE_SENT_INVITATIONS, invitations: response.data})
				} else {
					dispatch({type: UPDATE_SENT_INVITATIONS, invitations: []})
				}
				
			})
			.catch((error) => {
				console.log(error);
			})
	}
	
}

export const acceptPendingRequest = (token, data, personInfo, index) => {
	return (dispatch) => 

		new Promise((resolve, reject) => {
			const headers = {
				'Content-Type': 'application/json',
				'Authorization': 'JWT ' + token
			}
			console.log(UrlHelper.getAcceptRequestUrl(), data)
			axios.post(UrlHelper.getAcceptRequestUrl(), data, {headers:headers}) 
				.then((response) => {
					dispatch({type: FRIEND_REQUEST_ACCEPTED, data: personInfo, index: index})
					resolve(response)
				})
				.catch((error) => {
					console.log(error);
					reject(error);
					/*if (error.response) {
				      	// The request was made and the server responded with a status code
				      	// that falls out of the range of 2xx
				      	console.log(error.response.data);
				      	reject(error.response.data);
				    } else if (error.request) {
				    	  // The request was made but no response was received
				    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
				    	  // http.ClientRequest in node.js
				    	  console.log(error.request);
				    	  reject({msg: "No Response received from server"});
				    } else {
				    	  // Something happened in setting up the request that triggered an Error
				    	  console.log('Error', error.message);
				    	  reject({msg: 'Unknown error'})
				    }*/
				})

		})
		
	
}

export const rejectPendingRequest = (token, data, index) => {
	return (dispatch) => 

		new Promise((resolve, reject) => {
			const headers = {
				'Content-Type': 'application/json',
				'Authorization': 'JWT ' + token
			}
			console.log(data, headers, index, UrlHelper.getRejectRequestUrl());
			axios.post(UrlHelper.getRejectRequestUrl(), data, {headers:headers}) 
				.then((response) => {
					console.log(response);
					dispatch({type: FRIEND_REQUEST_REJECTED, data: data, index: index})
					resolve(response)
				})
				.catch((error) => {
					if (error.response) {
				      	// The request was made and the server responded with a status code
				      	// that falls out of the range of 2xx
				      	console.log(error.response.data.msg);
				      	reject(error.response.data);
				    } else if (error.request) {
				    	  // The request was made but no response was received
				    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
				    	  // http.ClientRequest in node.js
				    	  console.log(error.request);
				    	  reject({msg: "No Response received from server"});
				    } else {
				    	  // Something happened in setting up the request that triggered an Error
				    	  console.log('Error', error.message);
				    	  reject({msg: 'Unknown error'})
				    }
				})

		})
		
	
}

//Attach Socket events
export const attachToSocket = (socket, dispatch) => {
	socket.on('invitationReceived', (data) => {
		console.log('Got an invitation', data)
		/*var payload = {
			uid: data.senderUid,
			profile: {
				name: data.invitedByName,
				email: data.email
			}
		}*/
		dispatch({type:'INVITATION_RECEIVED', data})
	})
	
	socket.on('invitationAccepted', (data) => {
		console.log('Invitation Accepted', data)

		dispatch({type: INVITATION_ACCEPTED, data});
	})
}