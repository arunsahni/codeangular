import io from 'socket.io-client';

//import url helper class and axios
import UrlHelper from '../../utils/UrlHelper.js'
import EnvHandler from '../../utils/EnvHandler.js'
import axios from 'axios';

export const LOGGING_IN_USER='LOGGING_IN_USER'
export const LOGIN_REQUEST_COMPLETE = 'LOGIN_REQUEST_COMPLETE'
export const REGISTERING_USER = 'REGISTERING_USER'
export const REGISTERING_REQUEST_COMPLETE = 'REGISTERING_REQUEST_COMPLETE'
export const CONFIRMING_OTP	= 'CONFIRMING_OTP'
export const CONFIRM_OTP_COMPLETE	= 'CONFIRM_OTP_COMPLETE'
export const RESETTING_USER_PASSWORD = 'RESETTING_USER_PASSWORD'
export const RESET_REQ_COMPLETE = 'RESET_REQ_COMPLETE'
export const USER_LOGIN_INFORMATION='USER_LOGIN_INFORMATION'
export const BEGIN_SESSION='BEGIN_SESSION';

import {attachToSocket as attachInvitationActions} from './directoryActions'
import {attachToSocket as callSocketActions} from './callActions';

/* LOGIN Related Actions */
export const loggingInUser = () => {
	return {type: LOGGING_IN_USER}
}


export const loginRequestComplete = (status, msg) => {
	return dispatch => {
		dispatch({type: LOGIN_REQUEST_COMPLETE, status: status, payload: msg})
	}
}

/* Register Form Actions */
export const registeringUser = () => {
	return {type: REGISTERING_USER}
} 

export const registerRequestComplete = (msg) => {
	return {type: REGISTERING_REQUEST_COMPLETE, payload: msg}
}

/* OTP Actions */
export const confirmingOTP = () =>{
	return {type: CONFIRMING_OTP}
}

export const confirmingOTPComplete = (msg) => {
	return {type: CONFIRM_OTP_COMPLETE, payload: msg}
}

//Password Reset Actions
export const resettingPassword = () => {
	return {type: RESETTING_USER_PASSWORD}
}

export const passwordResetReqComplete = (msg) => {
	return {type: RESET_REQ_COMPLETE, payload: msg}
}

//get the user details if he is logged in 

export const getUserProfileInformation = (token, uid) => {
	console.log(token, uid, 'action');
	//Dispatch info on success and return a promise to user
	return (dispatch, getState) => 

		new Promise((resolve, reject) => {
			var query = {
				uid: uid
			}
			var headers = {
				'Content-Type': 'application/json',
				'Authorization': 'JWT ' + token
			}
			axios.get(UrlHelper.getUserProfileUrl(), {params:  query, headers: headers} )
				.then((response) => {
					/*const res = (({_id, uid, firstName, lastName, email, phone, countryCode, authyId}) => (
				    		{_id, uid, firstName, lastName, email, phone, countryCode, authyId}
				    	))(response.data)*/
				    console.log(response);
					dispatch({type: USER_LOGIN_INFORMATION, status: "success", data: response.data})
					dispatch({type: BEGIN_SESSION, payload: {user: response.data.profile.name, socket:initializeSocket(dispatch, getState, token)}});
			    	resolve(response);
					//send the resolve result
					console.log('in resolve', response)
					resolve(response);
				}).catch((error) => {
					//send the error result
					console.log('here in reject', error);
					reject(error)
				})
		})
}

//call CallLoginUser API
export const loginUser = (data) => {

	return (dispatch) => 

		new Promise((resolve, reject) => {

			axios.post(UrlHelper.getLoginUrl(), data)
			.then((response) => {

				/*//destructure only required keys
			    const res = ((name, email, phone, countryCode, authyId}) => (
			    		{ name, email, phone, countryCode, country, avatar}
			    	))(response.data.data.profile)*/
                
			   	//Complete the login request and then save the user info
				dispatch(loginRequestComplete('success', response.data));
				const token  = response.data && response.data.token;
    			localStorage.setItem('authToken', response.data.token);
    			localStorage.setItem('authUid', response.data.data.uid);
    			
			    resolve(response.data)
			})
			.catch((error)=> {
				if (error.response) {
			      	// The request was made and the server responded with a status code
			      	// that falls out of the range of 2xx
			      	console.log(error.response.data.msg);
			      	dispatch(loginRequestComplete('error', error.response.data));
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
			    	  // http.ClientRequest in node.js
			    	  console.log(error.request);
			    	  dispatch(loginRequestComplete('error', {msg: 'No Response Received from the server.'}));
			    } else {
			    	  // Something happened in setting up the request that triggered an Error
			    	  console.log('Error', error.message);
			    	  dispatch(loginRequestComplete('error', {msg: 'Your Request could not be processed'}));
			    }
				reject(error);
			})
		})
	
}

//Initialize sockets
const initializeSocket = (dispatch, getState, token) => {
	return getSocketFactory(token, getState, (socket) => {
		attachInvitationActions(socket, dispatch),
		callSocketActions(socket, getState, dispatch)
	})
}
//Socket interface
const getSocketFactory = (token, getState, attach) => {
	var socket = io.connect(EnvHandler.getServerUrl(), {
		'query':  {token: 'JWT ' + token}
	}, (data) => {
		console.log('getSocketFactory Data: ' , data);
	})
	socket.on('connect', (data) => {
		console.log('Connected to Socket', data);
	})
	socket.on('disconnect', () => {
		console.log('Disconnected from Socket');
	})
	attach(socket);
	return socket;
}

//call RegisterUserApi
export const registerUser = (data) => {
	return (dispatch) => 

		new Promise((resolve, reject) => {

			axios.post(UrlHelper.getRegisterUrl(), data)
			.then((response) => {

				console.log(response.data);
				dispatch(registerRequestComplete(response));
			    resolve(response);
			    
			})
			.catch((error)=> {
				if (error.response) {
			      	// The request was made and the server responded with a status code
			      	// that falls out of the range of 2xx
			      	console.log(error.response.data);
			      	dispatch(registerRequestComplete('error', error.response.data));
			      	reject(error.response.data.msg);
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
			    	  // http.ClientRequest in node.js
			    	  console.log(error.request);
			    	  dispatch(registerRequestComplete('No Response Received from the server.'));
			    	  reject('No Response Received from the server.');
			    } else {
			    	  // Something happened in setting up the request that triggered an Error
			    	  console.log('Error', error.message);
			    	  dispatch(registerRequestComplete('Your Request could not be processed'));
			    	  reject('Your Request could not be processed');
			    }
			})
		})
}

//Call OTP Verify Url
export const verifyRegisterOTP = (data) => {
	return (dispatch) => 

		new Promise((resolve, reject) => {

			axios.post(UrlHelper.getVerifyOPTUrl(), data)
			.then((response) => {

				console.log(response.data);
				dispatch(confirmingOTPComplete(response));
			    resolve(response);
			    
			})
			.catch((error)=> {
				if (error.response) {
			      	// The request was made and the server responded with a status code
			      	// that falls out of the range of 2xx
			      	console.log(error.response.data.message);
			      	dispatch(confirmingOTPComplete(error.response.data.message));
			      	reject(error.response.data.message);
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
			    	  // http.ClientRequest in node.js
			    	  console.log(error.request);
			    	  dispatch(confirmingOTPComplete('No Response Received from the server.'));
			    	  reject('No Response Received from the server.');
			    } else {
			    	  // Something happened in setting up the request that triggered an Error
			    	  console.log('Error', error.message);
			    	  dispatch(confirmingOTPComplete('Your Request could not be processed'));
			    	  reject('Your Request could not be processed');
			    }
			})
		})
}

export const resendOTPAction = (data) => {

	return (dispatch) =>
		new Promise((resolve, reject) => {
			axios.post(UrlHelper.getResendOTP(), data)
			.then((response) => {
				resolve(response);
				console.log("response", response);
			})
			.catch((error)=> {				
				if (error.response) {
			      	reject(error.response.data.msg.message);
			    } else if (error.request) {
			    	reject('No Response Received from the server.');
			    } else {
			    	reject('Your Request could not be processed');
			    }

			})
		})
}

export const callMeOTPAction = (authyId) => {

	return (dispatch) => 

		new Promise((resolve, reject) => {
			axios.get(UrlHelper.getCallmeUrl() + '/' + authyId)
			.then((response) => {
				console.log('call made', response)
				resolve(resolve);
			})
			.catch((error) => {
				if (error.response) {
			      	// The request was made and the server responded with a status code
			      	// that falls out of the range of 2xx
			      	console.log(error.response.data);
			      	dispatch(confirmingOTPComplete(error.response.data.message));
			      	reject(error.response.data);
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
			    	  // http.ClientRequest in node.js
			    	  console.log(error.request);
			    	  dispatch(confirmingOTPComplete('No Response Received from the server.'));
			    	  reject('No Response Received from the server.');
			    } else {
			    	  // Something happened in setting up the request that triggered an Error
			    	  console.log('Error', error.message);
			    	  dispatch(confirmingOTPComplete('Your Request could not be processed'));
			    	  reject('Your Request could not be processed');
			    }
			})
		})
}

export const confirmPassResetAction = (data) => {

	return (dispatch) =>

		new Promise((resolve, reject) => {

			axios.post(UrlHelper.getResetPassOTPUrl(), data)
			.then((response) => {
				console.log(response);
				dispatch(confirmingOTPComplete(response));
				resolve(response);
			})
			.catch((error)=> {
				console.log(error);
				
				if (error.response) {
			      	// The request was made and the server responded with a status code
			      	// that falls out of the range of 2xx
					console.log(error.response.data);
					dispatch(confirmingOTPComplete(error.response.data.msg.message));
					reject(error.response.data.msg.message);
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
			    	  // http.ClientRequest in node.js
			    	  console.log(error.request);
			    	  dispatch(confirmingOTPComplete('No Response Received from the server.'));
			    	  reject('No Response Received from the server.');
			    } else {
			    	  // Something happened in setting up the request that triggered an Error
			    	  console.log('Error', error.message);
			    	  dispatch(confirmingOTPComplete('Your Request could not be processed'));
			    	  reject('Your Request could not be processed');
			    }
			})
		})
}

export const resetPasswordAction = (data) => {

	return (dispatch) =>

		new Promise((resolve, reject) => {

			axios.post(UrlHelper.getForgotPasswordUrl(), data)
			.then((response) => {
				console.log(response);
				dispatch(passwordResetReqComplete(response));
				resolve(response);

			})
			.catch((error)=> {
				console.log(error);
				
				if (error.response) {
			      	// The request was made and the server responded with a status code
			      	// that falls out of the range of 2xx
			      	console.log(error.response.data);
					dispatch(passwordResetReqComplete(error.response.data.msg.message));
					reject(error.response.data.msg.message);
			    } else if (error.request) {
			    	  // The request was made but no response was received
			    	  // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
			    	  // http.ClientRequest in node.js
			    	  console.log(error.request);
			    	  dispatch(passwordResetReqComplete('No Response Received from the server.'));
			    	  reject('No Response Received from the server.');
			    } else {
			    	  // Something happened in setting up the request that triggered an Error
			    	  console.log('Error', error.message);
			    	  dispatch(passwordResetReqComplete('Your Request could not be processed'));
			    	  reject('Your Request could not be processed');
			    }
			})
		})
}