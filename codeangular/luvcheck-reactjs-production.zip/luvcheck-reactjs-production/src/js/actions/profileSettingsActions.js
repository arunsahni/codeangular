import axios from 'axios';
import UrlHelper from '../../utils/UrlHelper'

export const UPDATING_USER_INFO='UPDATING_USER_INFO';
export const USER_INFO_UPDATED='USER_INFO_UPDATED';
export const UPDATE_USER_PROFILEPIC='UPDATE_USER_PROFILEPIC';

export const updatingUserInfo = () => {
	return {type:UPDATING_USER_INFO}
}

export const userInfoUpdated = () => {
	return {type:USER_INFO_UPDATED}
}
export const updateProfileInfo = () => {
	return (dispatch) => {

	}
}
export const changeProfilePassword = (data, token)=> {

	return (dispatch) => 
		new Promise((resolve, reject) => {
			console.log('in Promise', UrlHelper.getChangePasswordUrl(), token, data)
			var headers={
				'Content-Type': 'application/json',
				'Authorization': 'JWT ' + token
			}
			axios.post(UrlHelper.getChangePasswordUrl(), data, {headers: headers})
				.then((response) => {
					console.log(response);
					resolve(response);
				})
				.catch((error) => {
					console.log(error);
					reject(error)
				})
		})
	
}
export const updateProfilePic = (imgCode,token, uid) => {
	/*return (dispatch) => {
		var headers = {
			'Content-Type': 
		}
		axios.post(UrlHelper.getProfilePicUploadUrl(), )
	}*/
	return {type: UPDATE_USER_PROFILEPIC, profilePic: imgCode}
}