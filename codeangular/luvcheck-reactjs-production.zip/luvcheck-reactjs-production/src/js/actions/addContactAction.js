import axios from 'axios';
import UrlHelper from '../../utils/UrlHelper';


export const UPDATE_SEARCH_VALUE='UPDATE_SEARCH_VALUE'
export const INVALID_SEARCH_VALUE='INVALID_SEARCH_VALUE'
export const FOUND_EXISTING_USER='FOUND_EXISTING_USER'
export const USER_NOT_FOUND='USER_NOT_FOUND'
export const VALID_SEARCH_VALUE='VALID_SEARCH_VALUE'
export const INVITATION_ALREADY_SENT = 'INVITATION_ALREADY_SENT'
export const INVITATION_SENT='INVITATION_SENT'

export const getContactProps = (newValue, token, uid) => {
	console.log('search', token, uid)
	return (dispatch) => {
		var valid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(newValue) || /^[2-9]{1}[0-9]{9}$/.test(newValue)
		if(valid) {
			dispatch({type: VALID_SEARCH_VALUE})
			var query = {
				uid: uid,
				username: newValue
			}
			var headers = {
				'Content-Type': 'application/json',
				'Authorization': 'JWT ' + token
			}

			axios.get(UrlHelper.getSearchUserUrl(), {params: query, headers: headers})
				
				.then((response) => {
					if(response.status===200)
						dispatch({type: FOUND_EXISTING_USER, data: response.data})
					else if(response.status===201) 
						dispatch({type: INVITATION_ALREADY_SENT, data: response.data})
				})
				.catch((error) => {
					dispatch({type: USER_NOT_FOUND})
				})
		}
		else {
			dispatch({type: INVALID_SEARCH_VALUE})
		}
	}
	return {type:UPDATE_SEARCH_VALUE, value: newValue}
}

//Send Friend invitation

//have to return a promise here
export const sendInvitation = (data, userProfile, token) => {
	return (dispatch) => 

		new Promise((resolve, reject) => {
			var headers = {
				'Content-Type': 'application/json',
				'Authorization': 'JWT ' + token
			}
			console.log(headers)
			console.log(data, 'sendInvitation');
			axios.post(UrlHelper.getSendInvitationUrl(), data, {headers: headers})
				.then((response) => {
					console.log("Send Invitation success", response);
					dispatch({type: INVITATION_SENT, data: userProfile})
					resolve(response)
				})
				.catch((error) => {
					if (error.response) {
						console.log("Send invitation error", error.response.data.msg)
				      	reject(error.response.data.msg);
				    } else if (error.request) {
				    	reject('No Response Received from the server.');
				    } else {
				    	reject('Your Request could not be processed');
				    }
				})
		})
}

export const updateSearchValue = (val) => {
	console.log(val);
	return {type: UPDATE_SEARCH_VALUE, value: val}
}