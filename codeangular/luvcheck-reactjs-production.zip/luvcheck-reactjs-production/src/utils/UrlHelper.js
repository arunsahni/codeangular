var EnvHandler = require('./EnvHandler');

const urlHelper = function() {
	return {
		getRegisterUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getRegisterApi();
		},
		getVerifyOPTUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getVerifyOTPApi();
		},
		getLoginUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getLoginApi();
		},
		getForgotPasswordUrl: function(){
			return EnvHandler.getServerUrl() + EnvHandler.getForgotPasswordApi();
		},
		getResetPassOTPUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getResetPasswordApi();
		},
		getResendOTP: function(){
			return EnvHandler.getServerUrl() + EnvHandler.getResendOTPApi();
		},
		getCallmeUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getCallmeApi();
		},
		getSearchUserUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getSearchUserApi();
		},
		getSendInvitationUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getSendInvitationApi();
		},
		getUserProfileUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getUserProfileApi();
		},
		getProfilePicUploadUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getProfilePicUploadApi();
		},
		getFriendListUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getFriendListApi();
		},
		getPendingRequestUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getPendingRequestApi();
		},
		getSentInvitationsUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getSentInvitationsApi();
		},
		getChangePasswordUrl: function() {
			return EnvHandler.getServerUrl() + EnvHandler.getChangePasswordApi();
		},
		getAcceptRequestUrl: function () {
			return EnvHandler.getServerUrl() + EnvHandler.getAcceptRequestApi();
		},
		getRejectRequestUrl: function () {
			return EnvHandler.getServerUrl() + EnvHandler.getRejectRequestApi();
		}
	}
}();

export default urlHelper;