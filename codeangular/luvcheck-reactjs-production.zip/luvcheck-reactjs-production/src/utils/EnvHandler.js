const devConfig = require('../../public/resources/EnvConfigs/dev/envConfig');
const prodConfig = require('../../public/resources/EnvConfigs/prod/envConfig');
const liveConfig = require('../../public/resources/EnvConfigs/live/envConfig');
var config = function() {
	var envInfo = [];
	envInfo['dev'] = devConfig.getEnvConfigs();
	envInfo['production'] = prodConfig.getEnvConfigs();
	envInfo['live'] = liveConfig.getEnvConfigs();
	var processEnv = process.env.NODE_ENV ? process.env.NODE_ENV : "dev";
	
	//temp solution
	// processEnv = 'production';

	return {
		getSelfUrl: function(env) {
			if(env) {
				return envInfo[env].selfUrl;
			}
			return envInfo[processEnv].selfUrl;
		},
		getServerUrl: function(env) {
			if(env) {
				return envInfo[env].serverUrl;
			}
			return envInfo[processEnv].serverUrl;
		},
		getRegisterApi: function(env) {
			if(env) {
				return envInfo[env].registerApi;
			}
			return envInfo[processEnv].registerApi;
		},
		getVerifyOTPApi: function(env) {
			if(env) {
				return envInfo[env].verifyOTPApi;
			}
			return envInfo[processEnv].verifyOTPApi;
		},
		getResendOTPApi: function(env){
			if(env) {
				return envInfo[env].resendOTP;
			}
			return envInfo[processEnv].resendOTP;
		},
		getLoginApi: function(env) {
			if(env) {
				return envInfo[env].loginApi;
			}
			return envInfo[processEnv].loginApi;
		},
		getForgotPasswordApi: function(env) {
			if(env){
				return envInfo[env].forgotPasswordApi
			}
			return envInfo[processEnv].forgotPasswordApi
		},
		getResetPasswordApi: function(env) {
			if(env) {
				return envInfo[env].resetPasswordApi;
			}
			return envInfo[processEnv].resetPasswordApi;
		},
		getCallmeApi: function(env) {
			if(env) {
				return envInfo[env].callmeApi;
			}
			return envInfo[processEnv].callmeApi;
		},
		getSearchUserApi: function(env) {
			if (env) {
				return envInfo[env].searchUserApi;
			}
			return envInfo[processEnv].searchUserApi;
		},
		getSendInvitationApi: function(env) {
			if(env) {
				return envInfo[env].sendInvitationApi;
			}
			return envInfo[processEnv].sendInvitationApi;
		},
		getUserProfileApi: function(env) {
			if(env) {
				return envInfo[env].userProfileApi;
			}
			return envInfo[processEnv].userProfileApi;
		},
		getProfilePicUploadApi: function(env) {
			if(env) {
				return envInfo[env].profilePicUploadApi;
			}
			return envInfo[processEnv].profilePicUploadApi;
		},
		getFriendListApi: function(env) {
			if(env) {
				return envInfo[env].friendListApi;
			}
			return envInfo[processEnv].friendListApi;
		},
		getPendingRequestApi: function(env) {
			if(env) {
				return envInfo[env].pendingRequestApi;
			}
			return envInfo[processEnv].pendingRequestApi;
		},
		getSentInvitationsApi: function(env) {
			if(env) {
				return envInfo[env].sentInvitationsApi;
			}
			return envInfo[processEnv].sentInvitationsApi;
		},
		getChangePasswordApi: function(env) {
			if(env) {
				return envInfo[env].changePaswordApi;
			}
			return envInfo[processEnv].changePaswordApi;
		},
		getAcceptRequestApi: function(env) {
			if(env) {
				return envInfo[env].acceptRequestApi;
			}
			return envInfo[processEnv].acceptRequestApi;
		},
		getRejectRequestApi: function(env) {
			if(env) {
				return envInfo[env].rejectRequestApi;
			}
			return envInfo[processEnv].rejectRequestApi;
		},
		getRunOnPort: function(env) {
			if(env) {
				return envInfo[env].runOnPort;
			}
			return envInfo[processEnv].runOnPort;
		},
		getProcessEnv: function() {
			if(processEnv) {
				return processEnv;
			}
			return 'qa2';
		}
		
	}
}();

module.exports = config;