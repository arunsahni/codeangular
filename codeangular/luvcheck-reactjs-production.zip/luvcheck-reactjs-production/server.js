//Defining imports

var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var fetch = require('node-fetch');
var fs = require('fs');
var http = require('http');
var jwt = require('jsonwebtoken');
var mongoose = require('mongoose');
var io = require('socket.io')(http);
var apn = require('apn');
var socketioJwt = require('socketio-jwt');
//var AccessToken = require('twilio').AccessToken
var fileUpload = require('express-fileupload');
var favicon = require('serve-favicon');
var logger = require('morgan');
var EnvHandler = require('./src/utils/EnvHandler.js');
var debug = require('debug')('luvcheck-react:server');
//var videoGrant = AccessToken.videoGrant
var app = express();
var processPort = EnvHandler.getRunOnPort();


var options = {
	token: {
		key: "APNsAuthKey_9MKS3KKTWV.p8",
		keyId: "9MKS3KKTWV",
		teamId: "BEZT7S56PZ"
	},
	production: true
};

//var apnProvider = new apn.Provider(options); 

//favicon
app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

//CORS
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});


var port = normalizePort(processPort || '3000');
app.set('port', port);

/*
  Serve a ejs template
*/
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.get('/', function(req, res){ 
  res.render('index', {authInfo: 'sfaafsagasgasgasg'});
});

/**
 * Create HTTP server.    
 */

var server = http.createServer(app);

/**
 * Listen on provided port, on all network interfaces.
 */

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  var bind = typeof port === 'string'
    ? 'Pipe ' + port
    : 'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
  var addr = server.address();
  var bind = typeof addr === 'string'
    ? 'pipe ' + addr
    : 'port ' + addr.port;
  debug('Listening on ' + bind);
}

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}


server.listen(process.env.PORT||port);
server.on('error', onError);
server.on('listening', onListening);