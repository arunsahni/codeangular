var config = function() {
	var envProperties = {
		selfUrl: "http://localhost:4000",
		serverUrl: "https://luvcheck-backend.herokuapp.com",
		registerApi: "/api/register",
		// verifyRegister: '/api/verify_register',
		verifyOTPApi: "/api/verify_register",
		resendOTP: '/api/resend_otp',
		loginApi: "/api/login",
		forgotPasswordApi: "/api/forgot_password",
		resetPasswordApi: "/api/reset_password",
		callmeApi: "/api/request_call",
		searchUserApi: "/users/search",
		sendInvitationApi: "/invitations/sendInvitation",
		userProfileApi: "/users/userProfile",
		profilePicUploadApi: "/users/upload-profilepic",
		friendListApi: "/users/getFriends",
		pendingRequestApi: "/invitations/receivedInvitation",
		sentInvitationsApi: "/invitations/sentInvitation",
		logOutApi: "/users/logout",
		changePaswordApi: "/users/changePassword",
		acceptRequestApi: "/invitations/invitationStatus",
		rejectRequestApi: "/invitations/invitationStatus",
		runOnPort: "4000"
	}
	return {
		getEnvConfigs: function() {
			return envProperties;
		}
	}
}();

module.exports = config;