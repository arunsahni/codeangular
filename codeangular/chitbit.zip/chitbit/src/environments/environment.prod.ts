export const environment = {
  production: true,
  apiUrl: 'http://server.localhostsro.sk:8723',
  oauthUrl: 'http://server.localhostsro.sk:9867'
};
