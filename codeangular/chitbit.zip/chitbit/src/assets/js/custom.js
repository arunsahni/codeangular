$(document).ready(function(){    

	$('.smstart').click(function(event) {
		$('.side-menu.sm_left').css('left','0');
	});
	$('.sm_left .smclose').click(function(event) {
		$('.side-menu.sm_left').css('left','-380px');
	});
	
	$('.lnk-signup').click(function(event) {
		$('.side-menu.sm_right').css('right','0');
		$('.sdmn_cont').css('width','380px');
	});
	$('.sm_right .smclose').click(function(event) {
		$('.side-menu.sm_right').css('right','-380px');
		$('.sdmn_cont').css('width','0px');
	});
});



