import {Component} from '@angular/core';

@Component({
  selector: 'app-leftbar',
  styleUrls: ['./leftSideBar.component.scss'],
  templateUrl: './leftSideBar.component.html'
})
export class LeftSideBarComponent {
}
