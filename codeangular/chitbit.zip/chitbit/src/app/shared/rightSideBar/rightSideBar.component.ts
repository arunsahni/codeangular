import {Component} from '@angular/core';
import {GlobalService} from '../../global';
@Component({
  selector: 'app-rightbar',
  styleUrls: ['./rightSideBar.component.scss'],
  templateUrl: './rightSideBar.component.html'
})
export class RightSideBarComponent {
  public isVisible: boolean = false;
  public rightBarStyle;
  public rightBarContStyle;
  constructor(private globalService: GlobalService) {
    this.globalService.visibleCheck.subscribe(res => {
      this.isVisible = res;
      console.log(this.isVisible, '**********');
    });
    this.globalService.rightBarCheck.subscribe(res => {
      if (res === true) {
        this.rightBarStyle = {right: '0px'};
        this.rightBarContStyle = {width: '380px'};
      } else {
        this.rightBarStyle = {right: '-380px'};
        this.rightBarContStyle = {width: '0px'};
      }
    });
  }
}
