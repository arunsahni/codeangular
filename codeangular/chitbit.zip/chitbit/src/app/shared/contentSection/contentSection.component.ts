import {Component} from '@angular/core';
import {GlobalService} from '../../global';

@Component({
  selector: 'app-content',
  styleUrls: ['./contentSection.component.scss'],
  templateUrl: './contentSection.component.html'
})
export class ContentSectionComponent {
  email: string;
  constructor(private globalService: GlobalService) {
  }

  getStarted() {
    this.globalService.initEmail.next(this.email);
    this.globalService.rightBarCheck.next(true);
  }
}
