import {Component, OnInit} from '@angular/core';
import {UserService} from '../../services/user.service';
import {GlobalService} from '../../global';
@Component({
  selector: 'app-header',
  styleUrls: ['./header.component.scss'],
  templateUrl: './header.component.html',
  providers: []
})

export class HeaderComponent implements OnInit {
  isLogged = false;
  constructor(private userService: UserService, public globalService: GlobalService) {
    this.isLogged = this.userService.isLogged();
  }

  ngOnInit() {

  }

  logOut() {
    this.userService.logout();
    this.isLogged = false;
  }

}
