import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnableComponent } from './userEnable.component';
import { UserService } from '../../services/user.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { GrowlModule } from 'primeng/primeng';
import { GlobalService } from '../../global';
import { ActivatedRoute, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';

describe('EnableComponent', () => {
  let component: EnableComponent;
  let fixture: ComponentFixture<EnableComponent>;
  const userServiceStub = { getUserEnabled() { return Observable.of({}); }};
  const globalServiceStub = {};
  const routerStub = { navigateByUrl(url: string) { return url; } };
  class MockActivatedRoute {
    params = Observable.of({});
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        GrowlModule
      ],
      declarations: [ EnableComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub },
        {provide: GlobalService, useValue: globalServiceStub },
        {provide: Router, useValue: routerStub },
        {provide: ActivatedRoute, useClass: MockActivatedRoute },
        MessageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnableComponent);
    component = fixture.componentInstance;
    spyOn(component, 'enableUser').and.returnValue(null);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('enableUser() should have been called', () => {
    expect(component.enableUser).toHaveBeenCalled();
  });
});
