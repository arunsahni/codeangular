import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {UserService} from '../../services/user.service';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';
@Component({
  selector: 'app-enable',
  styleUrls: ['./userEnable.component.scss'],
  templateUrl: './userEnable.component.html'
})

export class EnableComponent implements OnInit{
  key: any = '';
  msgs: Message[] = [];

  constructor(private userService: UserService, private router: Router, private activatedRoute: ActivatedRoute,
              private messageService: MessageService) {
    this.activatedRoute.params.subscribe((params: Params) => {
      this.key = params['key'];
    });
  }

  ngOnInit() {
    this.enableUser();
  }

  enableUser() {
    this.userService.getUserEnabled(this.key)
      .subscribe(
        data => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Account is enabled successfully.'
          });
          this.router.navigate(['home']);
        },
        error => {
          const err = JSON.parse(error._body);
          if (err.status === 404) {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: err.errorMessage
            });
          }
        });
  }
}
