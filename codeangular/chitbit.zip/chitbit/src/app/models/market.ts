export interface Market {
  market: string;
  currency: string;
  volume: number;
  change: number;
  lastprice: number;
  highestprice: number;
  lowestprice: number;
  spread: number;
  added: any;
};
