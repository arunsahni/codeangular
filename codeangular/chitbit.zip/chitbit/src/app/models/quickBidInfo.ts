export class QuickBidInfo {
  approxPrice: number;
  approxReceive: number;
  subtotal: number;
  fee: number;
}
