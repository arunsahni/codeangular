import {Offer} from './offer';

export interface OffersPage {
  content: Array<Offer>;
  last: boolean;
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  sort: boolean;
  first: boolean;
  numberOfElements: number;
}
