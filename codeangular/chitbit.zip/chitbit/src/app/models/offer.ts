export interface Offer {
  bidType: string;
  status: string;
  amount: number;
  bidModel: string;
  ratio: number;
  fromCurrency: string;
  fromAcronym: string;
  toCurrency: string;
  toAcronym: string;
  created: any;

  // additionaly calculated
  toAmount: number;
  sum: number;
}
