import {Market} from './market';

export interface MarketsPage {
  content: Array<Market>;
  last: boolean;
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  sort: boolean;
  first: boolean;
  numberOfElements: number;
}
