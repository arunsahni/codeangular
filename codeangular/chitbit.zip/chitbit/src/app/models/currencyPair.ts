export class CurrencyPair {
  uuid: number;
  fromCurrency: string;
  fromAcronym: string;
  toCurrency: string;
  toAcronym: string;
}
