export class Balance {
  availableBalance: number;
}
