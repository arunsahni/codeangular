export class FeeResponse {
  TakerTransactionFee: number;
}
