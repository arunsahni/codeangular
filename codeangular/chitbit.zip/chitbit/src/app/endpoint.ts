import {environment} from '../environments/environment';

export class Endpoints {
  public static apiUrl = environment.apiUrl;
  public static oauthUrl = environment.oauthUrl;

  public static register = `${Endpoints.apiUrl}/user/registration`;
  public static resetPasswordEmail = `${Endpoints.apiUrl}/user/generateResetPasswordEmail`;
  public static getAccounts = `${Endpoints.apiUrl}/account/`;
  public static changePassword = `${Endpoints.apiUrl}/user/changePassword`;
  public static enable2fa = `${Endpoints.apiUrl}/user/enable2fa`;
  public static verifyEnable2fa = `${Endpoints.apiUrl}/user/enable2fa/verify`;
  public static disable2fa = `${Endpoints.apiUrl}/user/disable2fa`;
  public static getCurrencyPairs = `${Endpoints.apiUrl}/bid/pairs`;
  public static quickInfo = `${Endpoints.apiUrl}/bid/quickInfo`;
  public static quickBid = `${Endpoints.apiUrl}/bid/quickBid`;
  public static getFee = `${Endpoints.apiUrl}/fee`;
  public static getUserEnabled = (key: string) =>
    `${Endpoints.apiUrl}/user/enable/${key}`;
  public static login = (username: string, password: string) =>
    `${Endpoints.oauthUrl}/oauth/token?grant_type=password&username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&scope=read`;
  public static login2fa = (code: string) =>
    `${Endpoints.apiUrl}/user/verify2faCode?code=${encodeURIComponent(code)}`;
  public static resetPassword = (key: string) =>
    `${Endpoints.apiUrl}/user/resetPassword/${encodeURIComponent(key)}`;
  public static getBalance = (acronym: string) =>
    `${Endpoints.apiUrl}/account/disposableBalance?acronym=${encodeURIComponent(acronym)}`;
  public static getMarket = (acronym: string) =>
    `${Endpoints.apiUrl}/market?acronym=${acronym}`;
  public static getOffers = (uuid: number, type: string) =>
    `${Endpoints.apiUrl}/bid/availableBids?pair=${uuid}&type=${type}`;
  public static createBid = () =>
    `${Endpoints.apiUrl}/bid`;
}
