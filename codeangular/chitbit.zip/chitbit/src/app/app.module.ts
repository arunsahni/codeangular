import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {GrowlModule} from 'primeng/primeng';
import {GlobalService} from './global';
import {UserService} from './services/user.service';
import {ChecktokenService} from './services/auth.route';
import {MessageService} from 'primeng/components/common/messageservice';
import {AppComponent} from './app.component';
import {FormWizardModule} from 'angular2-wizard';
import {HomeComponent} from './components/home/home.component';
import {SignUpComponent} from './components/signUp/signup.component';
import {LoginComponent} from './components/login/login.component';
import {ForgotPwdComponent} from './components/forgotPwd/forgotPwd.component';
import {ResetPwdComponent} from './components/resetPwd/resetPwd.component';
import {ChangePwdComponent} from './components/changePwd/changePwd.component';

import {HeaderComponent} from './shared/header/header.component';
import {LeftSideBarComponent} from './shared/leftSideBar/leftSideBar.component';
import {RightSideBarComponent} from './shared/rightSideBar/rightSideBar.component';
import {ContentSectionComponent} from './shared/contentSection/contentSection.component';
import {FooterComponent} from './shared/footer/footer.component';
import {EnableComponent} from './shared/userEnable/userEnable.component';
import {DashboardComponent} from './components/dashboard/dashboard.component';

import {routing} from './app.routing';
import {DataTableModule} from 'angular2-datatable';
import {DataFilterPipe} from './shared/pipes/data-filter';
import {EmailFilterPipe} from './shared/pipes/email-filter';
import {DepositPageComponent} from './components/depositPage/depositPage.component';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {Enable2faComponent} from './components/enable-2fa/enable-2fa.component';
import {SettingsPageComponent} from './components/settings-page/settings-page.component';
import {Disable2faComponent} from './components/disable-2fa/disable-2fa.component';
import {Endpoints} from './endpoint';
import {QuickBidComponent} from './components/quick-bid/quick-bid.component';
import {BidService} from './services/bid.service';
import {MarketsComponent} from './components/markets/markets.component';
import {MarketsTableComponent} from './components/markets/markets-table/markets-table.component';
import {MatCheckboxModule, MatDialogModule, MatSelectModule, MatTabsModule} from '@angular/material';
import {TfaDialogComponent} from './components/enable-2fa/tfa-dialog/tfa-dialog.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ExchangeComponent} from './components/exchange/exchange.component';
import {CreateBidComponent} from './components/create-bid/create-bid.component';
import {CreateBidFormComponent} from './components/create-bid/create-bid-form/create-bid-form.component';
import {OfferTableComponent} from './components/offers/offer-table/offer-table.component';
import {OffersComponent} from './components/offers/offers.component';
import {LeftbarIconComponent} from './components/dashboard/leftbar-icon/leftbar-icon.component';
import {ContentSwitcherComponent} from './components/exchange/content-switcher/content-switcher.component';
import {OnlyNumberDirective} from './utils/directives/only-number.directive';
import {MarketsService} from './services/markets.service';
import {MarketsWindowComponent} from './components/markets-window/markets-window.component';
import {MarketsWindowTableComponent} from './components/markets-window/markets-window-table/markets-window-table.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SignUpComponent,
    LoginComponent,
    ForgotPwdComponent,
    ResetPwdComponent,
    HeaderComponent,
    LeftSideBarComponent,
    RightSideBarComponent,
    FooterComponent,
    EnableComponent,
    ContentSectionComponent,
    DashboardComponent,
    DataFilterPipe,
    EmailFilterPipe,
    DepositPageComponent,
    ChangePwdComponent,
    Enable2faComponent,
    SettingsPageComponent,
    Disable2faComponent,
    QuickBidComponent,
    MarketsComponent,
    MarketsTableComponent,
    TfaDialogComponent,
    ExchangeComponent,
    CreateBidComponent,
    CreateBidFormComponent,
    OfferTableComponent,
    OffersComponent,
    LeftbarIconComponent,
    ContentSwitcherComponent,
    OnlyNumberDirective,
    MarketsWindowComponent,
    MarketsWindowTableComponent
  ],
  entryComponents: [
    TfaDialogComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    routing,
    HttpModule,
    FormWizardModule,
    DataTableModule,
    NgxDatatableModule,
    GrowlModule,
    MatDialogModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTabsModule
  ],
  providers: [
    BidService,
    Endpoints,
    GlobalService,
    UserService,
    MessageService,
    ChecktokenService,
    MarketsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
