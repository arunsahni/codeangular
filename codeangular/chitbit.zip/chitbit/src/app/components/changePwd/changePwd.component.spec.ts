import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

import { ChangePwdComponent } from './changePwd.component';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import {MessageService} from 'primeng/components/common/messageservice';
import {GrowlModule} from 'primeng/primeng';

describe('ChangePwdComponent', () => {
  let component: ChangePwdComponent;
  let fixture: ComponentFixture<ChangePwdComponent>;
  let userService;
  let inputs;
  let button;
  const userServiceStub = {};
  const routerStub = { navigateByUrl(url: string) { return url; } };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        GrowlModule,
        FormsModule,
        ReactiveFormsModule,
      ],
      declarations: [ ChangePwdComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub }, {provide: Router, useValue: routerStub }, MessageService ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePwdComponent);
    component = fixture.componentInstance;
    userService = fixture.debugElement.injector.get(UserService);
    inputs = fixture.debugElement.queryAll(By.css('.form-control'));
    button = fixture.debugElement.query(By.css('.btn_frm'));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('inputs should not be valid', () => {
    for (const inpName in component.changePwdForm.controls) {
      expect(component.changePwdForm.controls[inpName].valid).toBe(false);
    }
  });

  it('new password input should not be valid', () => {
    component.changePwdForm.patchValue({newPwd: 'Password'});
    fixture.detectChanges();
    expect(component.changePwdForm.controls.newPwd.valid).toBe(false);
    component.changePwdForm.patchValue({newPwd: 'p@S3'});
    fixture.detectChanges();
    expect(component.changePwdForm.controls.newPwd.valid).toBe(false);
    component.changePwdForm.patchValue({newPwd: 'p@ssword'});
    fixture.detectChanges();
    expect(component.changePwdForm.controls.newPwd.valid).toBe(false);
    component.changePwdForm.patchValue({newPwd: 'pa55word'});
    fixture.detectChanges();
    expect(component.changePwdForm.controls.newPwd.valid).toBe(false);
  });

  it('inputs should be valid', () => {
    component.changePwdForm.setValue({oldPwd: 'oldPassword', newPwd: 'p@5Word', confNewPwd: 'p@5Word'});
    fixture.detectChanges();
    expect(component.changePwdForm.controls.oldPwd.valid).toBe(true);
    expect(component.changePwdForm.controls.newPwd.valid).toBe(true);
    expect(component.changePwdForm.controls.confNewPwd.valid).toBe(true);
  });

  it('Form submit should be called after button click', () => {
    component.changePwdForm.setValue({oldPwd: 'oldPassword', newPwd: 'p@5Word', confNewPwd: 'p@5Word'});
    fixture.detectChanges();
    spyOn(component, 'formSubmit').and.returnValue(null);
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.formSubmit).toHaveBeenCalled();
  });
});
