import {Component} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {Message} from 'primeng/primeng';
import {MessageService} from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-change',
  styleUrls: ['./changePwd.component.scss'],
  templateUrl: './changePwd.component.html'
})
export class ChangePwdComponent {
  changePwdForm: FormGroup;
  diffPwdWarn = false;
  requestError = false;
  wrongPassword = false;
  samePassword = false;
  networkError = false;
  emptyFieldsError = false;
  msgs: Message[] = [];
  private requestPending = false;

  constructor(public formBuilder: FormBuilder, private userService: UserService, private messageService: MessageService) {
    this.changePwdForm = this.formBuilder.group({
      oldPwd: ['', [Validators.required]],
      newPwd: ['', [Validators.required, Validators.pattern('(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&]).{5,}')]],
      confNewPwd: ['', [Validators.required]]
    });
  }

  public formSubmit() {
    this.requestError = false;
    this.wrongPassword = false;
    this.networkError = false;
    this.emptyFieldsError = false;
    if (
      this.changePwdForm.value.newPwd === '' ||
      this.changePwdForm.value.oldPwd === '' ||
      this.changePwdForm.value.confNewPwd === '') {
      this.emptyFieldsError = true;
    } else if (this.changePwdForm.value.newPwd !== this.changePwdForm.value.confNewPwd) {
      this.diffPwdWarn = true;
    } else if (this.changePwdForm.value.newPwd === this.changePwdForm.value.oldPwd) {
      this.samePassword = true;
    } else if (this.changePwdForm.valid && !this.requestPending) {
      this.diffPwdWarn = false;
      this.samePassword = false;
      this.requestPending = true;
      this.userService.changePassword(this.changePwdForm.value.oldPwd, this.changePwdForm.value.newPwd)
        .subscribe(
          () => {
            this.changePwdForm.reset();
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Password changed'
            });
            this.userService.logout();
            this.requestPending = false;
          },
          (error) => {
            if (error.status === 0) {
              this.networkError = true;
            } else if (error.status === 401) {
              this.wrongPassword = true;
            } else {
              this.requestError = true;
            }
            this.requestPending = false;
          });
    }
  }
}
