import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {MessageService} from 'primeng/components/common/messageservice';
import {Message} from 'primeng/primeng';
import {GlobalService} from '../../global';
import {TfaDialogComponent} from './tfa-dialog/tfa-dialog.component';
import {MatDialog} from '@angular/material';

@Component({
  selector: 'app-enable-2fa',
  templateUrl: './enable-2fa.component.html',
  styleUrls: ['./enable-2fa.component.scss']
})
export class Enable2faComponent implements OnInit {
  triedToSubmit = false;
  wrongPwd = false;
  responseUrl: string = '';
  secretCode: string = '';
  enable2faForm: FormGroup;
  codeEnterForm: FormGroup;
  msgs: Message[] = [];
  private requestPending = false;
  constructor(
    private _fb: FormBuilder,
    private userService: UserService,
    private messageService: MessageService,
    private globalService: GlobalService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.enable2faForm = this._fb.group({
      password: ['', [Validators.required]],
    });
    this.codeEnterForm = this._fb.group({
      code: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  submitPassword() {
    if (!this.requestPending) {
      this.triedToSubmit = true;
      this.wrongPwd = false;
      this.requestPending = true;
      this.userService.enable2faWithPassword(this.enable2faForm.value.password)
        .subscribe(response => {
            this.responseUrl = response.json().url;
            this.secretCode = response.json().key;
            this.openDialog();
            this.requestPending = false;
          },
          error => {
            if (error.status === 401) {
              this.wrongPwd = true;
            } else {
              this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'Submit failed'
              });
            }
            this.requestPending = false;
          });
    }
  }

  openDialog(): void {
    this.dialog.open(TfaDialogComponent, {
      width: '348px',
      data: { responseUrl: this.responseUrl, secretCode : this.secretCode }
    });
  }
}
