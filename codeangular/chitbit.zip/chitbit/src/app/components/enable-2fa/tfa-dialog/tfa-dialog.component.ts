import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MessageService} from 'primeng/components/common/messageservice';
import {Message} from 'primeng/components/common/message';
import {UserService} from '../../../services/user.service';
import {GlobalService} from '../../../global';

@Component({
  selector: 'app-tfa-dialog',
  templateUrl: './tfa-dialog.component.html',
  styleUrls: ['./tfa-dialog.component.scss']
})
export class TfaDialogComponent implements OnInit {
  @ViewChild('printBox') printBox;
  codeEnterForm: FormGroup;
  checked;
  msgs: Message[] = [];
  private requestPending = false;
  constructor(
    private globalService: GlobalService,
    private userService: UserService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    public dialogRef: MatDialogRef<TfaDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {
    this.codeEnterForm = this.formBuilder.group({
      code: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  printCodes() {
    window.print();
  }

  submitCode() {
    if (!this.requestPending) {
      this.requestPending = true;
      this.userService.enable2faWithCode(this.codeEnterForm.value.code)
        .subscribe(() => {
            localStorage.setItem('2fa_status', 'true');
            this.globalService.tfaChange.next(true);
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: '2FA enabled'
            });
            this.dialogRef.close();
            this.userService.logout();
            this.requestPending = false;
          },
          error => {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Submit failed'
            });
            this.requestPending = false;
          }
        );
    }
  }
}
