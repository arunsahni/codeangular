import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {Enable2faComponent} from './enable-2fa.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {GrowlModule} from 'primeng/primeng';
import {UserService} from '../../services/user.service';
import {GlobalService} from '../../global';
import {Router} from '@angular/router';
import {MessageService} from 'primeng/components/common/messageservice';
import {By} from '@angular/platform-browser';
import {MatDialog, MatDialogModule} from '@angular/material';

describe('Enable2faComponent', () => {
  let component: Enable2faComponent;
  let fixture: ComponentFixture<Enable2faComponent>;
  const userServiceStub = {};
  const globalServiceStub = {};
  const routerStub = { navigateByUrl(url: string) { return url; } };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        GrowlModule,
        MatDialogModule
      ],
      declarations: [ Enable2faComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub },
        {provide: GlobalService, useValue: globalServiceStub },
        {provide: Router, useValue: routerStub },
        MessageService,
        MatDialog
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Enable2faComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('password input should not be valid', () => {
    expect(component.enable2faForm.controls.password.valid).toBe(false);
  });

  it('password input should be valid', () => {
    component.enable2faForm.setValue({
      password: 'kV3tin@c'
    });
    fixture.detectChanges();
    expect(component.enable2faForm.controls.password.valid).toBe(true);
  });

  it('submitPassword() should have been called', () => {
    component.enable2faForm.setValue({
      password: 'kV3tin@c'
    });
    const button = fixture.debugElement.query(By.css('.btn_frm'));
    spyOn(component, 'submitPassword').and.returnValue(null);
    fixture.detectChanges();
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.submitPassword).toHaveBeenCalled();
  });
});
