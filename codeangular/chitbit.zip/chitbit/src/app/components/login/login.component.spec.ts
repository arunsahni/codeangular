import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LoginComponent } from './login.component';
import { UserService } from '../../services/user.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { GrowlModule } from 'primeng/primeng';
import { By } from '@angular/platform-browser';
import { GlobalService } from '../../global';
import { Router } from '@angular/router';
import * as Rx from 'rxjs/Rx';
import 'rxjs/Rx';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let userService;
  const userServiceStub = {};
  const globalServiceStub = {
    initEmail: new Rx.Subject<any>()
  };
  const routerStub = { navigateByUrl(url: string) { return url; } };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        GrowlModule
      ],
      declarations: [ LoginComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub },
        {provide: GlobalService, useValue: globalServiceStub },
        {provide: Router, useValue: routerStub },
        MessageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    userService = fixture.debugElement.injector.get(UserService);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('inputs should not be valid', () => {
    for (const inpName in component.loginForm.controls) {
      expect(component.loginForm.controls[inpName].valid).toBe(false);
    }
  });

  it('password input should be valid', () => {
    component.loginForm.patchValue({password: 'kV3tin@c'});
    fixture.detectChanges();
    expect(component.loginForm.controls.password.valid).toBe(true);
  });

  it('email input should be valid', () => {
    component.loginForm.patchValue({username: 'example@email.domain'});
    fixture.detectChanges();
    expect(component.loginForm.controls.username.valid).toBe(true);
  });

  it('login() should have been called', () => {
    component.loginForm.setValue({
      username: 'example@email.domain',
      password: 'kV3tin@c'
    });
    const button = fixture.debugElement.query(By.css('.btn_frm'));
    spyOn(component, 'login').and.returnValue(null);
    fixture.detectChanges();
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.login).toHaveBeenCalled();
  });

  it('code input should not be valid', () => {
    component.codeSubmitView = true;
    fixture.detectChanges();
    expect(component.codeEnterForm.controls.code.valid).toBe(false);
  });

  it('code input should be valid', () => {
    component.codeSubmitView = true;
    fixture.detectChanges();
    component.codeEnterForm.patchValue({code: '123456'});
    fixture.detectChanges();
    expect(component.codeEnterForm.controls.code.valid).toBe(true);
  });

  it('submitCode() should have been called', () => {
    component.codeSubmitView = true;
    component.codeEnterForm.setValue({
      code: '123456'
    });
    fixture.detectChanges();
    const button = fixture.debugElement.query(By.css('.btn_frm'));
    spyOn(component, 'submitCode').and.returnValue(null);
    fixture.detectChanges();
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.submitCode).toHaveBeenCalled();
  });
});
