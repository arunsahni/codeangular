import {Component, OnInit, ViewChild} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {GlobalService} from '../../global';
import {Router} from '@angular/router';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-login',
  styleUrls: ['./login.component.scss'],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  @ViewChild('passwordInput') passwordInput;
  loginForm: FormGroup;
  user: any = {};
  msgs: Message[] = [];
  codeSubmitView = false;
  codeEnterForm: FormGroup;
  recCodeEnterForm: FormGroup;
  public triedToSubmit = false;
  public userDisabled = false;
  public badCredentials = false;
  private requestPending = false;
  constructor(public _fb: FormBuilder, private userService: UserService, private globalService: GlobalService,
              private messageService: MessageService, private router: Router) {
  }

  ngOnInit() {
    this.formInitilization();
  }

  formInitilization() {
    this.loginForm = this._fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
    this.codeEnterForm = this._fb.group({
      code: ['', [Validators.required, Validators.minLength(6)]],
    });
    this.recCodeEnterForm = this._fb.group({
      code: ['', [Validators.required, Validators.minLength(8)]],
    });
    this.globalService.initEmail.subscribe(
      (res) => {
        this.loginForm.patchValue({username: res});
        this.passwordInput.nativeElement.focus();
      });
  }

  login(user) {
    if (this.loginForm.valid && !this.requestPending) {
      this.userDisabled = false;
      this.badCredentials = false;
      this.triedToSubmit = true;
      this.requestPending = true;
      this.userService.login(user)
        .subscribe(
          () => {
            if (JSON.parse(localStorage.getItem('2fa_status'))) {
              this.codeSubmitView = true;
            } else {
              this.messageService.add({
                severity: 'success',
                summary: 'Success',
                detail: 'Login successfull.'
              });
              this.globalService.loginCheck.next(true);
              this.router.navigate(['dashboard/markets']);
            }
            this.requestPending = false;
          },
          error => {
            if (error.status === 401) {
              if (error.json().error_description === 'ERROR_BAD_CREDENTIALS') {
                this.badCredentials = true;
              } else if (error.json().error_description === 'ERROR_USER_NOT_ENABLED') {
                this.userDisabled = true;
              }
            }
            this.requestPending = false;
          });
    }
  }

  forgotPwd() {
    this.globalService.visibleCheck.next(true);
  }

  submitCode() {
    if (!this.requestPending) {
      this.requestPending = true;
      this.userService.login2fa(this.codeEnterForm.value.code)
        .subscribe(() => {
          this.globalService.loginCheck.next(true);
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Login successfull.'
          });
          this.requestPending = false;
          this.router.navigate(['dashboard/markets']);
          }, error => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Login failed.'
          });
          this.requestPending = false;
        });
    }
  }
}
