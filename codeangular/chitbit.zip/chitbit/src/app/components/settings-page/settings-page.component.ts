import { Component, OnInit } from '@angular/core';
import {GlobalService} from '../../global';

@Component({
  selector: 'app-settings-page',
  templateUrl: './settings-page.component.html',
  styleUrls: ['./settings-page.component.scss']
})
export class SettingsPageComponent implements OnInit {
  showDisable: boolean;
  constructor(private globalService: GlobalService) { }

  ngOnInit() {
    const status = localStorage.getItem('2fa_status');
    if (status) {
      this.showDisable = JSON.parse(status);
    }
    this.globalService.tfaChange.subscribe(
      (res) => {
        this.showDisable = res;
      });
  }

}
