import {Component, Input, OnInit} from '@angular/core';
import {CurrencyPair} from '../../../models/currencyPair';
import {GlobalService} from '../../../global';
import {BidService} from '../../../services/bid.service';
import {OffersPage} from '../../../models/offersPage';
import {Offer} from '../../../models/offer';

@Component({
  selector: 'app-offer-table',
  templateUrl: './offer-table.component.html',
  styleUrls: ['./offer-table.component.scss']
})
export class OfferTableComponent implements OnInit {
  @Input() buy;
  currencyPair: CurrencyPair = null;
  rows: Array<Offer> = [];

  constructor(private globalService: GlobalService, private bidService: BidService) { }

  ngOnInit() {
    this.globalService.currencyPair.subscribe((currencyPair: CurrencyPair) => {
      this.currencyPair = currencyPair;
      this.updateOffers();
    });
  }

  updateOffers() {
    this.bidService.getOffers(this.currencyPair.uuid, this.buy ? 'BUY' : 'SELL', 0, 100)
      .subscribe((offersPage: OffersPage) => {
        this.rows = offersPage.content;
        this.rows.sort((a: Offer, b: Offer) => a.ratio - b.ratio);
        let cumulativeSum = 0;
        for (let i = 0; i < this.rows.length; i++) {
          this.rows[i].sum = (cumulativeSum += (this.rows[i].toAmount = this.rows[i].amount * this.rows[i].ratio));
        }
      });
  }

}
