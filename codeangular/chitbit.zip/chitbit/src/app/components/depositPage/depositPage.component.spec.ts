import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

import { DepositPageComponent } from './depositPage.component';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {Observable} from 'rxjs';

describe('DepositPageComponent', () => {
  const fakeRows = [
    {
      acronym: 'ABC',
      name: 'abece',
      totalBalance: 1,
      onOrders: 2,
      btcValue: 3
    }
  ];
  let component: DepositPageComponent;
  let fixture: ComponentFixture<DepositPageComponent>;
  let userService;
  let title;
  let datatable;
  let zeroBalances;
  let dataRows;
  const userServiceStub = {
    getAccounts: () => Observable.of(fakeRows)
  };
  const routerStub = { navigateByUrl(url: string) { return url; } };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        NgxDatatableModule
      ],
      declarations: [ DepositPageComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub }, {provide: Router, useValue: routerStub }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositPageComponent);
    component = fixture.componentInstance;
    userService = fixture.debugElement.injector.get(UserService);
    title = fixture.debugElement.query(By.css('.title'));
    datatable = fixture.debugElement.query(By.css('ngx-datatable'));
    zeroBalances = fixture.debugElement.query(By.css('.hide-checkboxes-wrapper > label'));
    dataRows = fixture.debugElement.queryAll(By.css('datatable-body-row'));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should have correct title', () => {
    expect(title.nativeElement.textContent).toEqual('Balances, Deposits & Withdrawals');
  });

  it('should have datatable element', () => {
    expect(datatable).toBeTruthy();
  });

  it('Hide 0 balances checkbox should have correct label', () => {
    expect(zeroBalances.nativeElement.textContent).toEqual('Hide 0 Balances');
  });

  it('Datatable should have correct data inside', () => {
    expect(component.rows).toEqual(fakeRows);
    expect(component.filteredData).toEqual(fakeRows);
  });
});
