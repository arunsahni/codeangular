import {Component, ViewChild, OnInit} from '@angular/core';
import {UserService} from '../../services/user.service';

@Component({
  selector: 'app-deposit',
  styleUrls: ['./depositPage.component.scss'],
  templateUrl: 'depositPage.component.html'
})
export class DepositPageComponent implements OnInit{
  rows = [];
  filteredData = [];
  columns = [
    { name: 'Coin', prop: 'acronym'},
    { name: 'Name' , prop: 'name'},
    { name: 'Total Balance', prop: 'totalBalance' },
    { name: 'On Orders', prop: 'onOrders'},
    { name: 'BTC Value', prop: 'btcValue' },
    { name: 'Actions', sortable: false }
  ];

  showZeroBalance = true;
  showDelisted = true;
  filterText = '';
  @ViewChild('myTable') table: any;

  constructor(private userService: UserService) {
  }

  ngOnInit() {
    this.userService.getAccounts()
      .subscribe(data => {
        this.rows = data;
        this.filteredData = this.rows;
      });
  }

  toggleZeroBalances($event) {
    this.showZeroBalance = !$event.target.checked;
    this.filterTableData();
  }

  toggleDelisted($event) {
    this.showDelisted = !$event.target.checked;
    this.filterTableData();
  }

  filterTableData() {
    if (this.showDelisted && this.showZeroBalance) {
      this.filteredData = this.rows;
    }
    if (!this.showZeroBalance) {
      this.filteredData = this.rows.filter(item => item.totalBalance > 0);
    } else if (!this.showDelisted) {
      this.filteredData = this.rows.filter(item => item.delisted);
    } else if (!this.showZeroBalance && !this.showDelisted) {
      this.filteredData = this.rows.filter(item => item.totalBalance > 0 && item.delisted)
    }

    // filter our data
    this.filteredData = this.filteredData.filter(item => item.name.toLowerCase().indexOf(this.filterText) !== -1 || !this.filterText);
  }

  updateFilter(event) {
    this.filterText = event.target.value.toLowerCase();
    this.filterTableData();
  }

  showDepositAddress(row) {
    this.table.rowDetail.collapseAllRows();
    if (row.deposit) {
      row.deposit = undefined;
      this.rows.forEach(item => item.deposit = undefined);
      this.table.rowDetail.collapseAllRows();
    } else {
      this.rows.forEach(item => item.deposit = undefined);
      row.deposit = true;
      this.table.rowDetail.toggleExpandRow(row);
    }
  }

  showWithdrawAddress(row) {
    this.table.rowDetail.collapseAllRows();
    if (row.deposit === false) {
      row.deposit = undefined;
      this.rows.forEach(item => item.deposit = undefined);
      this.table.rowDetail.collapseAllRows();
    } else {
      this.rows.forEach(item => item.deposit = undefined);
      row.deposit = false;
      this.table.rowDetail.toggleExpandRow(row);
    }
  }
}
