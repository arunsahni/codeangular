import {Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {UserService} from '../../services/user.service';
@Component({
  selector: 'app-reset',
  styleUrls: ['./resetPwd.component.scss'],
  templateUrl: './resetPwd.component.html'
})
export class ResetPwdComponent implements OnInit {
  key: any = '';
  resetForm: FormGroup;
  user: any = {};
  public errorMessage = false;
  public diffPwdWarn = false;
  public emptyFieldsError = false;
  private requestPending = false;
  constructor(public _fb: FormBuilder, private userService: UserService, private router: Router,
              private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe((params: Params) => {
      this.key = params['key'];
    });
  }

  ngOnInit() {
    this.formInitilization();
  }

  formInitilization() {
    this.resetForm = this._fb.group({
      newPassword: ['', [Validators.required, Validators.pattern('(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&]).{5,}')]],
      confNewPassword: ['', [Validators.required]]
    });
  }

  resetPassword(user) {
    this.diffPwdWarn = false;
    this.errorMessage = false;
    if (this.resetForm.value.newPassword === '' || this.resetForm.value.confNewPassword === '') {
      this.emptyFieldsError = true;
    } else if (this.resetForm.value.newPassword !== this.resetForm.value.confNewPassword) {
      this.diffPwdWarn = true;
    } else if (this.resetForm.valid && !this.requestPending) {
      this.requestPending = true;
      this.userService.resetPassword(this.key, user)
        .subscribe(
          () => {
            this.requestPending = false;
            this.router.navigate(['home']);
          },
          () => {
            this.requestPending = false;
            this.errorMessage = true;
          });
    }
  }

  returnHome() {
    this.router.navigate(['home']);
  }
}
