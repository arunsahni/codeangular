import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ResetPwdComponent } from './resetPwd.component';
import { UserService } from '../../services/user.service';
import { By } from '@angular/platform-browser';
import { GlobalService } from '../../global';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

describe('ResetPwdComponent', () => {
  let component: ResetPwdComponent;
  let fixture: ComponentFixture<ResetPwdComponent>;
  let button;
  let backButton;
  const userServiceStub = {};
  const globalServiceStub = {};
  const routerStub = { navigateByUrl(url: string) { return url; } };
  class MockActivatedRoute {
    params = Observable.of({});
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [ ResetPwdComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub },
        {provide: GlobalService, useValue: globalServiceStub },
        {provide: Router, useValue: routerStub },
        {provide: ActivatedRoute, useClass: MockActivatedRoute }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetPwdComponent);
    component = fixture.componentInstance;
    button = fixture.debugElement.query(By.css('.btn_frm'));
    backButton = fixture.debugElement.query(By.css('.backlink'));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('inputs should not be valid', () => {
    for (const inpName in component.resetForm.controls) {
      expect(component.resetForm.controls[inpName].valid).toBe(false);
    }
  });

  it('password input should be valid', () => {
    component.resetForm.patchValue({newPassword: 'kV3tin@c'});
    fixture.detectChanges();
    expect(component.resetForm.controls.newPassword.valid).toBe(true);
  });

  it('resetPassword() should have been called', () => {
    component.resetForm.setValue({newPassword: 'kV3tin@c', confNewPassword: 'kV3tin@c'});
    spyOn(component, 'resetPassword').and.returnValue(null);
    fixture.detectChanges();
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.resetPassword).toHaveBeenCalled();
  });

  it('returnHome() should have been called', () => {
    spyOn(component, 'returnHome').and.returnValue(null);
    fixture.detectChanges();
    backButton.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.returnHome).toHaveBeenCalled();
  });
});
