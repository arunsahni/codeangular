import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {CurrencyPair} from '../../../models/currencyPair';
import {GlobalService} from '../../../global';
import {BidService} from '../../../services/bid.service';
import {Balance} from '../../../models/balance';
import {MessageService} from 'primeng/components/common/messageservice';
import {FeeResponse} from '../../../models/feeResponse';

@Component({
  selector: 'app-create-bid-form',
  templateUrl: './create-bid-form.component.html',
  styleUrls: ['./create-bid-form.component.scss']
})
export class CreateBidFormComponent implements OnInit {
  @Input() buy: boolean;
  fromAmount = null;
  toAmount = null;
  lowestAsk = null;
  highestBid = null;
  bidForm: FormGroup;
  fee = 0;
  currencyPair: CurrencyPair;
  requestPending = false;

  constructor(
    private formBuilder: FormBuilder,
    private globalService: GlobalService,
    private bidService: BidService,
    private messageService: MessageService
  ) { }

  ngOnInit() {
    this.bidForm = this.formBuilder.group({
      price: ['', [Validators.required]],
      amount: ['', [Validators.required]],
      total: ['', [Validators.required]]
    });
    this.globalService.currencyPair.subscribe((currencyPair: CurrencyPair) => {
      this.currencyPair = currencyPair;
      this.refreshBalance();
    });
    this.bidService.getFee()
      .subscribe((response: FeeResponse) => this.fee = response.TakerTransactionFee);
  }

  refreshBalance() {
    if (this.currencyPair) {
      this.bidService.getBalance(this.buy ? this.currencyPair.toAcronym : this.currencyPair.fromAcronym)
        .subscribe((balance: Balance) => {
          if (this.buy) {
            this.toAmount = balance.availableBalance;
          } else {
            this.fromAmount = balance.availableBalance;
          }
        });
    }
  }

  priceAmountInputHandler() {
    if (this.bidForm.value.price && this.bidForm.value.amount) {
      this.bidForm.patchValue({total: this.bidForm.value.amount * this.bidForm.value.price});
    }
  }

  totalInputHandler() {
    if (this.bidForm.value.total && this.bidForm.value.price) {
      this.bidForm.patchValue({amount: this.bidForm.value.total / this.bidForm.value.price});
    }
  }

  submit() {
    if (!this.requestPending) {
      this.requestPending = true;
      this.bidService.createBid(
        this.buy ? 'BUY' : 'SELL',
        this.bidForm.value.amount,
        this.currencyPair.uuid,
        this.bidForm.value.price
      ).subscribe((res) => {
        console.log(res);
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'The bid was created successfully.'
        });
        this.bidForm.reset();
        this.requestPending = false;
      }, error => {
        const err = JSON.parse(error._body);
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: err.errorMessage
          });
        this.requestPending = false;
      });
    }
  }
}
