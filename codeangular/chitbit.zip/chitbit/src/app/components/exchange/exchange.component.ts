import { Component, OnInit } from '@angular/core';
import {GlobalService} from '../../global';

@Component({
  selector: 'app-exchange',
  templateUrl: './exchange.component.html',
  styleUrls: ['./exchange.component.scss']
})
export class ExchangeComponent implements OnInit {
  layout: number;
  constructor(private globalService: GlobalService) { }

  ngOnInit() {
    this.globalService.exchangeLayout.subscribe(
      (res) => {
        this.layout = res;
      });
  }

}
