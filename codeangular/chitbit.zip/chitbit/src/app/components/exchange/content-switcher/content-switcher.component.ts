import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-switcher',
  templateUrl: './content-switcher.component.html',
  styleUrls: ['./content-switcher.component.scss']
})
export class ContentSwitcherComponent implements OnInit {
  contentSelect = 0;
  switchlist = false;

  constructor() { }

  ngOnInit() {
  }

}
