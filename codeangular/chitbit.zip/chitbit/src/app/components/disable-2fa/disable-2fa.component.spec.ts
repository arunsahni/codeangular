import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Disable2faComponent } from './disable-2fa.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MessageService} from 'primeng/components/common/messageservice';
import {Router} from '@angular/router';
import {GrowlModule} from 'primeng/primeng';
import {GlobalService} from '../../global';
import {UserService} from '../../services/user.service';
import {By} from '@angular/platform-browser';

describe('Disable2faComponent', () => {
  let component: Disable2faComponent;
  let fixture: ComponentFixture<Disable2faComponent>;
  const userServiceStub = {};
  const globalServiceStub = {};
  const routerStub = { navigateByUrl(url: string) { return url; } };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        GrowlModule
      ],
      declarations: [ Disable2faComponent ],
      providers: [ {provide: UserService, useValue: userServiceStub },
        {provide: GlobalService, useValue: globalServiceStub },
        {provide: Router, useValue: routerStub },
        MessageService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Disable2faComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('code input should be valid', () => {
    component.codeEnterForm.patchValue({code: '123456'});
    fixture.detectChanges();
    expect(component.codeEnterForm.controls.code.valid).toBe(true);
  });

  it('code input should not be valid', () => {
    expect(component.codeEnterForm.controls.code.valid).toBe(false);
  });

  it('code input should not be valid', () => {
    component.codeEnterForm.patchValue({code: '123'});
    fixture.detectChanges();
    expect(component.codeEnterForm.controls.code.valid).toBe(false);
  });

  it('submitPassword() should have been called', () => {
    component.codeEnterForm.setValue({
      code: '123456'
    });
    const button = fixture.debugElement.queryAll(By.css('.btn_frm'))[0];
    spyOn(component, 'submitCode').and.returnValue(null);
    fixture.detectChanges();
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.submitCode).toHaveBeenCalled();
  });
});
