import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {MessageService} from 'primeng/components/common/messageservice';
import {GlobalService} from '../../global';

@Component({
  selector: 'app-disable-2fa',
  templateUrl: './disable-2fa.component.html',
  styleUrls: ['./disable-2fa.component.scss']
})
export class Disable2faComponent implements OnInit {
  codeEnterForm: FormGroup;
  private requestPending = false;
  constructor(
    private _fb: FormBuilder,
    private userService: UserService,
    private messageService: MessageService,
    private globalService: GlobalService
  ) { }

  ngOnInit() {
    this.codeEnterForm = this._fb.group({
      code: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  submitCode() {
    if (!this.requestPending) {
      this.requestPending = true;
      this.userService.disable2fa(this.codeEnterForm.value.code)
        .subscribe(() => {
            this.globalService.tfaChange.next(false);
            localStorage.setItem('2fa_status', 'false');
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: '2FA disabled'
            });
            this.requestPending = false;
          },
          () => {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Submit failed'
            });
            this.requestPending = false;
          }
        );
    }
  }
}
