import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {MarketsService} from '../../../services/markets.service';
import {MarketsPage} from '../../../models/marketsPage';
import {Market} from '../../../models/market';
import {BidService} from '../../../services/bid.service';
import {CurrencyPair} from '../../../models/currencyPair';
import {GlobalService} from '../../../global';
import {Router} from '@angular/router';

@Component({
  selector: 'app-markets-table',
  templateUrl: './markets-table.component.html',
  styleUrls: ['./markets-table.component.scss']
})
export class MarketsTableComponent implements OnInit {
  @ViewChild('myTable') table: any;
  @Input() titleText: string;
  @Input() acronym: string;
  rows: Array<Market> = [];

  filteredData: Array<Market> = [];
  filterText = '';
  currencyPairs: Array<CurrencyPair> = [];

  constructor(
    private marketsService: MarketsService,
    private bidService: BidService,
    private globalService: GlobalService,
    private router: Router) {
  }

  ngOnInit() {
    this.marketsService.getMarket(this.acronym, 0, 500)
      .subscribe((page: MarketsPage) => {
        this.rows = page.content;
        this.getCurrencies();
        this.filteredData = this.rows;
      });
  }

  filterTableData() {
    this.filteredData = this.rows.filter(
      item => {
        return (item.market.toLowerCase().indexOf(this.filterText) !== -1 || !this.filterText)
        || (item.currency.toLowerCase().indexOf(this.filterText) !== -1 || !this.filterText);
      });
  }

  updateFilter(event) {
    this.filterText = event.target.value.toLowerCase();
    this.filterTableData();
  }

  getCurrencies() {
    this.bidService.getCurrencyPairs()
      .subscribe((currencyPairs: Array<CurrencyPair>) => {
        this.currencyPairs = currencyPairs;
      });
  }

  chooseMarket(market: string) {
    for (let i = 0; i < this.currencyPairs.length; i++) {
      if (market.slice(0, 3) === this.currencyPairs[i].toAcronym && market.slice(4, 7) === this.currencyPairs[i].fromAcronym) {
        this.globalService.currencyPair.next(this.currencyPairs[i]);
      }
    }
    this.router.navigate(['dashboard/exchange']);
  }
}
