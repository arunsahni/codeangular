import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {BidService} from '../../services/bid.service';
import {Message} from 'primeng/primeng';
import {MessageService} from 'primeng/components/common/messageservice';
import {Balance} from '../../models/balance';
import {QuickBidInfo} from '../../models/quickBidInfo';

@Component({
  selector: 'app-quick-bid',
  templateUrl: './quick-bid.component.html',
  styleUrls: ['./quick-bid.component.scss']
})
export class QuickBidComponent implements OnInit {
  msgs: Message[] = [];
  selectedPair;
  currencyPairs = [];
  available = 0;
  subtotal = 0;
  approxReceive = 0;
  approxPrice = 0;
  bitstampFee: number;
  fromCurrency = '';
  toCurrency = '';
  buttonLabel = '';
  buyActive = true;
  infoRequestPending = false;
  submitRequestPending = false;
  infoQueue = false;
  bidForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private bidService: BidService,
    private messageService: MessageService) { }

  ngOnInit() {
    this.bidForm = this.formBuilder.group({
      sum: ['', [Validators.required]],
    });
    this.getCurrencyPairs();
  }

  switchToBuy() {
    this.buyActive = true;
    this.updateButtonLabel();
    this.getInfo();
  }

  switchToSell() {
    this.buyActive = false;
    this.updateButtonLabel();
    this.getInfo();
  }

  getCurrencyPairs() {
    this.bidService.getCurrencyPairs()
      .subscribe(
        response => {
          this.currencyPairs = response;
          this.fromCurrency = this.currencyPairs[0].fromAcronym;
          this.toCurrency = this.currencyPairs[0].toAcronym;
          this.selectedPair = 0;
          this.updateButtonLabel();
          this.getInfo();
        },
        (error) => console.log(error));
  }

  currencyPairSelect() {
    this.fromCurrency = this.currencyPairs[this.selectedPair].fromAcronym;
    this.toCurrency = this.currencyPairs[this.selectedPair].toAcronym;
    this.updateButtonLabel();
    this.getInfo();
  }

  inputEventHandler() {
    this.getInfo();
  }

  updateButtonLabel() {
    this.buttonLabel = (this.buyActive ? 'Buy ' : 'Sell ') + this.fromCurrency;
  }

  getInfo() {
    if (!this.infoRequestPending) {
      this.infoRequestPending = true;
      this.bidService.getBalance(this.buyActive ? this.toCurrency : this.fromCurrency)
        .subscribe((balance: Balance) => {
          this.available = balance.availableBalance;
        });
      this.bidService.quickInfo(
        this.buyActive ? 'BUY' : 'SELL',
        this.bidForm.value.sum ? this.bidForm.value.sum : 0,
        this.currencyPairs[this.selectedPair].uuid
      ).subscribe((quickBidInfo: QuickBidInfo) => {
        this.approxPrice = isNaN(quickBidInfo.approxPrice) ? 0 : quickBidInfo.approxPrice;
        this.approxReceive = quickBidInfo.approxReceive;
        this.subtotal = quickBidInfo.subtotal;
        this.bitstampFee = quickBidInfo.fee * 100;
        this.infoRequestPending = false;
        if (this.infoQueue) {
          this.infoQueue = false;
          this.getInfo();
        }
      }, error => {
          const err = JSON.parse(error._body);
          if (err.status === 412) {
            if (err.error === 'ERROR_NOT_ENOUGH_BIDS') {
              this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'There are not enough bids on the market to realize the exchange.'
              });
            }

            if (err.error === 'ERROR_WRONG_PARAM') {
              this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: err.errorMessage
              });
            }
          }
          this.infoRequestPending = false;
      });
    } else {
      this.infoQueue = true;
    }
  }

  submit() {
    if (this.bidForm.value.sum < 0) {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'You cannot submit a bid with a negative value.'
      });
    } else if (!this.submitRequestPending && this.bidForm.value.sum) {
      this.submitRequestPending = true;
      this.bidService.quickBid(
        this.buyActive ? 'BUY' : 'SELL',
        this.bidForm.value.sum,
        this.currencyPairs[this.selectedPair].uuid
      ).subscribe(() => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'The exchange was completed successfully.'
        });
        this.bidForm.reset();
        this.getInfo();
        this.submitRequestPending = false;
      }, error => {
        const err = JSON.parse(error._body);
        if (err.status === 412) {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: err.errorMessage
          });
        }
        this.submitRequestPending = false;
      });
    }
  }
}
