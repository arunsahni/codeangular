import {Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {Router} from '@angular/router';
import {UserService} from '../../services/user.service';
import {GlobalService} from '../../global';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';
@Component({
  selector: 'app-forgot',
  styleUrls: ['./forgotPwd.component.scss'],
  templateUrl: './forgotPwd.component.html'
})
export class ForgotPwdComponent implements OnInit {
  forgotForm: FormGroup;
  user: any = {};
  msgs: Message[] = [];
  public errorMessage = false;
  public noEmailMsg = false;
  public userDisabled = false;
  public notRegistered = false;
  private requestPending = false;
  constructor(public _fb: FormBuilder, private userService: UserService, private router: Router,
              private messageService: MessageService, private globalService: GlobalService) {
  }

  ngOnInit() {
    this.formInitilization();
  }

  formInitilization() {
    this.forgotForm = this._fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  resetPasswordEmail(user) {
    this.noEmailMsg = false;
    this.userDisabled = false;
    this.notRegistered = false;
    if (this.forgotForm.value.email === '') {
      this.noEmailMsg = true;
    } else if (this.forgotForm.valid && !this.requestPending) {
      user.language = '';
      this.requestPending = true;
      this.userService.resetPasswordEmail(user)
        .subscribe(
          () => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Please check your Email.'
            });
            this.requestPending = false;
          },
          error => {
            if (error.status === 409) {
              this.userDisabled = true;
            } else if (error.status === 404) {
              this.notRegistered = true;
            } else {
              this.errorMessage = true;
            }
            this.requestPending = false;
          });
    }
  }
  returnHome() {
    this.globalService.visibleCheck.next(false);
  }
}
