import {Component, OnInit, ChangeDetectorRef} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {UserService} from '../../services/user.service';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';
import {GlobalService} from '../../global';

@Component({
  selector: 'app-signup',
  styleUrls: ['./signup.component.scss'],
  templateUrl: './signup.component.html'
})
export class SignUpComponent implements OnInit {
  signUpForm: FormGroup;
  user: any = {};
  msgs: Message[] = [];
  isPasswordOk = false;
  isPrivacyAccepted = false;
  isCaptchaOK = false;
  private requestPending = false;

  constructor(
    public _fb: FormBuilder,
    private userService: UserService,
    private messageService: MessageService,
    private chRef: ChangeDetectorRef,
    private globalService: GlobalService) {
    window['verifyCallback'] = this.verifyCallback.bind(this);
  }

  ngOnInit() {
    this.formInitilization();
    this.displayRecaptcha();
  }

  formInitilization() {
    this.signUpForm = this._fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern('(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&]).{5,}')]],
      confPassword: ['', [Validators.required]]
    });
    this.globalService.initEmail.subscribe(
      (res) => {
        this.signUpForm.patchValue({email: res});
      });
  }

  register(user) {
    this.handleConfPassword();
    if (this.signUpForm.valid
      && this.isPrivacyAccepted
      && this.isCaptchaOK
      && this.isPasswordOk
      && !this.requestPending) {

      user.language = '';
      this.requestPending = true;
      this.userService.register(user)
        .subscribe(
          data => {
            if (data.status === 201) {
              this.messageService.add({
                severity: 'success',
                summary: 'Success',
                detail: 'Please check your email to enable account.'
              });
            }
            this.requestPending = false;
          },
          error => {
            const err = JSON.parse(error._body);
            if (err.status === 409) {
              this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: err.error
              });
            }
            this.requestPending = false;
          });
    }
  }

  handleAcceptPrivacy($event) {
    this.isPrivacyAccepted = $event.target.checked;
  }

  displayRecaptcha() {
    var doc = <HTMLDivElement>document.getElementById('signup-form');
    var script = document.createElement('script');
    script.innerHTML = '';
    script.src = 'https://www.google.com/recaptcha/api.js';
    script.async = true;
    script.defer = true;
    doc.appendChild(script);
  }

  verifyCallback(response) {
    if (response.length > 0) {
      this.isCaptchaOK = true;
      this.chRef.detectChanges();
    }
  }

  handleConfPassword() {
    this.isPasswordOk = this.signUpForm.value.password === this.signUpForm.value.confPassword;
  }
}
