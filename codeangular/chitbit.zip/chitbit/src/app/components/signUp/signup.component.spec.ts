import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SignUpComponent } from './signup.component';
import { UserService } from '../../services/user.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { GrowlModule } from 'primeng/primeng';
import { By } from '@angular/platform-browser';
import * as Rx from 'rxjs/Rx';
import 'rxjs/Rx';
import { GlobalService } from '../../global';

describe('SignUpComponent', () => {
  let component: SignUpComponent;
  let fixture: ComponentFixture<SignUpComponent>;
  let userService;
  let button;
  const userServiceStub = {};
  const globalServiceStub = {
    initEmail: new Rx.Subject<any>()
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        GrowlModule
      ],
      declarations: [ SignUpComponent ],
      providers: [
        {provide: UserService, useValue: userServiceStub },
        {provide: GlobalService, useValue: globalServiceStub },
        MessageService ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignUpComponent);
    component = fixture.componentInstance;
    userService = fixture.debugElement.injector.get(UserService);
    button = fixture.debugElement.query(By.css('.btn_frm'));
    spyOn(component, 'displayRecaptcha').and.returnValue(null);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('inputs should not be valid', () => {
    for (const inpName in component.signUpForm.controls) {
      expect(component.signUpForm.controls[inpName].valid).toBe(false);
    }
  });

  it('password input should not be valid', () => {
    component.signUpForm.patchValue({password: 'Password'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.password.valid).toBe(false);
    component.signUpForm.patchValue({password: 'p@S3'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.password.valid).toBe(false);
    component.signUpForm.patchValue({password: 'p@ssword'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.password.valid).toBe(false);
    component.signUpForm.patchValue({password: 'pa55word'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.password.valid).toBe(false);
  });

  it('password input should be valid', () => {
    component.signUpForm.patchValue({password: 'kV3tin@c'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.password.valid).toBe(true);
  });

  it('email input should not be valid', () => {
    component.signUpForm.patchValue({email: 'examp'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.email.valid).toBe(false);
    component.signUpForm.patchValue({email: 'example@'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.email.valid).toBe(false);
    component.signUpForm.patchValue({email: 'example@email.'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.email.valid).toBe(false);
    component.signUpForm.patchValue({email: 'example@email..com'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.email.valid).toBe(false);
  });

  it('email input should be valid', () => {
    component.signUpForm.patchValue({email: 'example@email.domain'});
    fixture.detectChanges();
    expect(component.signUpForm.controls.email.valid).toBe(true);
  });

  it('register() should have been called', () => {
    component.signUpForm.setValue({
      email: 'example@email.domain',
      password: 'kV3tin@c',
      confPassword: 'kV3tin@c'
    });
    spyOn(component, 'register').and.returnValue(null);
    fixture.detectChanges();
    button.triggerEventHandler('click', null);
    fixture.detectChanges();
    expect(component.register).toHaveBeenCalled();
  });
});
