import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-markets-window',
  templateUrl: './markets-window.component.html',
  styleUrls: ['./markets-window.component.scss']
})
export class MarketsWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
