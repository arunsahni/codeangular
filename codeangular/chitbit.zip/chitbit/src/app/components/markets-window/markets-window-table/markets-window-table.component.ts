import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {Market} from '../../../models/market';
import {CurrencyPair} from '../../../models/currencyPair';
import {MarketsService} from '../../../services/markets.service';
import {BidService} from '../../../services/bid.service';
import {GlobalService} from '../../../global';
import {Router} from '@angular/router';
import {MarketsPage} from '../../../models/marketsPage';

@Component({
  selector: 'app-markets-window-table',
  templateUrl: './markets-window-table.component.html',
  styleUrls: ['./markets-window-table.component.scss']
})
export class MarketsWindowTableComponent implements OnInit {

  @ViewChild('myTable') table: any;
  @Input() titleText: string;
  @Input() acronym: string;
  rows: Array<Market> = [];

  filteredData: Array<Market> = [];
  filterText = '';
  currencyPairs: Array<CurrencyPair> = [];

  constructor(
    private marketsService: MarketsService,
    private bidService: BidService,
    private globalService: GlobalService,
    private router: Router) {
  }

  ngOnInit() {
    this.marketsService.getMarket(this.acronym, 0, 500)
      .subscribe((page: MarketsPage) => {
        this.rows = page.content;
        this.getCurrencies();
        this.filteredData = this.rows;
      });
  }

  filterTableData() {
    this.filteredData = this.rows.filter(
      item => {
        return (item.market.toLowerCase().indexOf(this.filterText) !== -1 || !this.filterText)
          || (item.currency.toLowerCase().indexOf(this.filterText) !== -1 || !this.filterText);
      });
  }

  updateFilter(event) {
    this.filterText = event.target.value.toLowerCase();
    this.filterTableData();
  }

  getCurrencies() {
    this.bidService.getCurrencyPairs()
      .subscribe((currencyPairs: Array<CurrencyPair>) => {
        this.currencyPairs = currencyPairs;
      });
  }

  chooseMarket(market: string) {
    for (let i = 0; i < this.currencyPairs.length; i++) {
      if (market.slice(0, 3) === this.currencyPairs[i].toAcronym && market.slice(4, 7) === this.currencyPairs[i].fromAcronym) {
        this.globalService.currencyPair.next(this.currencyPairs[i]);
      }
    }
    this.router.navigate(['dashboard/exchange']);
  }

}
