import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-leftbar-icon',
  templateUrl: './leftbar-icon.component.html',
  styleUrls: ['./leftbar-icon.component.scss']
})
export class LeftbarIconComponent {
  @Output() click = new EventEmitter();
  @Input() minWidth = 50;
  @Input() maxWidth = 160;
  @Input() titleText: string;
  @Input() icon: string;
  @Input() link: string;
  @Input() disabled = false;
  linkStyle = {width: this.minWidth + 'px'};

  onClick() {
    this.click.emit();
  }

  mouseEnter() {
    if (!this.disabled) {
      this.linkStyle = {width: this.maxWidth + 'px'};
    }
  }
}
