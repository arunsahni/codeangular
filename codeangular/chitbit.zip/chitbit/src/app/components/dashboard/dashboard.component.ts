import {Component, OnInit} from '@angular/core';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';
import {Router} from '@angular/router';
import {UserService} from '../../services/user.service';
import {GlobalService} from '../../global';
import {BidService} from '../../services/bid.service';
import {CurrencyPair} from '../../models/currencyPair';

@Component({
  selector: 'app-dashboard',
  styleUrls: ['./dashboard.component.scss'],
  templateUrl: './dashboard.component.html'
})

export class DashboardComponent implements OnInit {
  msgs: Message[] = [];
  layoutPopupInvisible = true;

  constructor(
    private messageService: MessageService,
    private router: Router,
    private userService: UserService,
    private globalService: GlobalService,
    private bidService: BidService) {
    this.messageService.add({
      severity: 'success',
      summary: 'Success',
      detail: 'Welcome to Dashboard.'
    });
  }

  ngOnInit() {
    if (!this.globalService.currencyPair.getValue()) {
      this.bidService.getCurrencyPairs()
        .subscribe((currencyPairs: Array<CurrencyPair>) => {
          this.globalService.currencyPair.next(currencyPairs[0]);
        });
    }
  }

  gotoMarkets() {
    this.router.navigate(['dashboard/markets']);
    this.layoutPopupInvisible = true;
  }

  gotoAccounts() {
    // this.router.navigate(['dashboard/deposit']);
    this.layoutPopupInvisible = true;
  }

  gotoSettings() {
    this.router.navigate(['dashboard/settings']);
    this.layoutPopupInvisible = true;
  }

  gotoCreateBid() {
    this.router.navigate(['dashboard/bid']);
    this.layoutPopupInvisible = true;
  }

  gotoExchange() {
    this.router.navigate(['dashboard/exchange']);
  }

  clickLogOut() {
    this.userService.logout();
  }

  layoutClick() {
    this.layoutPopupInvisible = !this.layoutPopupInvisible;
  }

  layoutFourWindows() {
    this.globalService.exchangeLayout.next(4);
    this.layoutPopupInvisible = true;
  }

  layoutThreeWindows() {
    this.globalService.exchangeLayout.next(3);
    this.layoutPopupInvisible = true;
  }

  layoutTwoWindows() {
    this.globalService.exchangeLayout.next(2);
    this.layoutPopupInvisible = true;
  }

  layoutOneWindow() {
    this.globalService.exchangeLayout.next(1);
    this.layoutPopupInvisible = true;
  }
}
