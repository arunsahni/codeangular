import {RequestOptions, Headers} from '@angular/http';

export function createRequestOptions(isAuthorized = true): RequestOptions {
  const headers = new Headers({
    'Content-Type': 'application/json',
  });
  if (isAuthorized) {
    headers.append('Authorization', 'bearer ' + getAccessToken());
  }
  return new RequestOptions({headers});
}

export function getAccessToken() {
  return localStorage.getItem('access_token');
}

export function setAccessToken(token: string) {
  localStorage.setItem('access_token', token);
}
