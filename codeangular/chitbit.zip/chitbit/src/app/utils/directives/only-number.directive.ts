import {Directive, ElementRef, HostListener, Input} from '@angular/core';
import {AbstractControl} from '@angular/forms';

@Directive({
  selector: '[appOnlyNumber]'
})
export class OnlyNumberDirective {


  @Input('appOnlyNumber') control: AbstractControl;

  private numberKeysPattern = '^[0-9.]$';
  private dotCanPutPattern = '^[0-9]+$';
  private decimalNumberPattern = '^[0-9]+([.][0-9]*)?$';

  constructor(private el: ElementRef) {
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event) {
    const e = <KeyboardEvent> event;
    if ([8, 27, 13].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.keyCode === 65 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+C
      (e.keyCode === 67 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+V
      (e.keyCode === 86 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+X
      (e.keyCode === 88 && (e.ctrlKey || e.metaKey)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 40)) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number or dot
    const numberKeysRegex = new RegExp(this.numberKeysPattern);
    if (!(e.ctrlKey || e.metaKey) && !numberKeysRegex.test(e.key)) {
      e.preventDefault();
    }
    // check only one dot is use
    const dotCanPut = new RegExp(this.dotCanPutPattern);
    if (e.key === '.' && !dotCanPut.test(event.target.value)) {
      e.preventDefault();
    }
  }

  @HostListener('input', ['$event'])
  onInput(event) {
    const regEx = new RegExp(this.decimalNumberPattern);
    // check if pasted value is decimal number
    if (event.inputType === 'insertFromPaste' && !regEx.test(event.target.value)) {
      // check if value is good with trim function
      if (regEx.test(event.target.value.trim())) {
        this.control.setValue(event.target.value.trim());
      } else {
        this.control.setValue(null);
      }
    }
    if (event.data || event.inputType === 'deleteContentBackward') {
      const str = event.target.value.toString().split('.')[1];
      if (str) {
        event.target.step = 1 / Math.pow(10, str.length);
      } else {
        event.target.step = 1;
      }
    }
  }

  @HostListener('change', ['$event'])
  onChange(event) {
    // if there is value use parseFloat to omit zero before and after example: 000600.100 -> 600.1
    if (event.target.value) {
      this.control.setValue(parseFloat(event.target.value));
    }
  }


}
