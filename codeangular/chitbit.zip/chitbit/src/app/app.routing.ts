import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {HomeComponent} from './components/home/home.component';
import {ResetPwdComponent} from './components/resetPwd/resetPwd.component';
import {DepositPageComponent} from './components/depositPage/depositPage.component';

import {EnableComponent} from './shared/userEnable/userEnable.component';
import {DashboardComponent} from './components/dashboard/dashboard.component';
import {ChecktokenService} from './services/auth.route';
import {ChangePwdComponent} from './components/changePwd/changePwd.component';
import {SettingsPageComponent} from './components/settings-page/settings-page.component';
import {QuickBidComponent} from './components/quick-bid/quick-bid.component';
import {MarketsComponent} from './components/markets/markets.component';
import {ExchangeComponent} from './components/exchange/exchange.component';
import {OffersComponent} from './components/offers/offers.component';

const appRoutes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: 'user/reset/:key', component: ResetPwdComponent},
  {path: 'user/enable/:key', component: EnableComponent},
  {path: 'change', component: ChangePwdComponent, canActivate: [ChecktokenService]},
  {path: 'dashboard', component: DashboardComponent, canActivate: [ChecktokenService],
    children: [
      {path: 'settings', component: SettingsPageComponent, canActivate: [ChecktokenService]},
      {path: 'deposit', component: DepositPageComponent, canActivate: [ChecktokenService]},
      {path: 'bid', component: QuickBidComponent, canActivate: [ChecktokenService]},
      {path: 'markets', component: MarketsComponent, canActivate: [ChecktokenService]},
      {path: 'exchange', component: ExchangeComponent, canActivate: [ChecktokenService]},
      {path: 'offers', component: OffersComponent, canActivate: [ChecktokenService]}
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
