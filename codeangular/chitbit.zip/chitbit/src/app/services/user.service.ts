import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {Http, Response} from '@angular/http';
import {User} from '../models/user';
import {GlobalService} from '../global';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {Endpoints} from '../endpoint';
import {createRequestOptions, getAccessToken, setAccessToken} from '../utils/utils';

@Injectable()
export class UserService {

  constructor(
    private http: Http,
    private globalService: GlobalService,
    private router: Router) {
  }

  register(user: User) {
    return this.http.post(Endpoints.register, user)
      .map((response: Response) => response);
  }

  getUserEnabled(key: string) {
    return this.http.get(Endpoints.getUserEnabled(key)).map(
      (response: Response) => response);
  }

  login(user: User) {
    return this.http.post(Endpoints.login(user.username, user.password), {})
      .map((response: Response) => {
          const loggedUser = response.json();
          if (loggedUser['2FA']) {
            localStorage.setItem('2fa_status', JSON.stringify(loggedUser['2FA']));
          } else {
            localStorage.setItem('2fa_status', 'false');
          }
          setAccessToken(loggedUser.access_token);
      })
      .catch(error => {
        return Observable.throw(error);
      });
  }

  login2fa(code: string) {
    return this.http.get(Endpoints.login2fa(code), createRequestOptions(true))
      .map((response: Response) => {
        const loggedUser = response.json();
        setAccessToken(loggedUser.access_token);
      })
      .catch(error => {
        return Observable.throw(error);
      });
  }

  isLogged() {
    return !!getAccessToken();
  }

  resetPasswordEmail(user: User) {
    return this.http.post(Endpoints.resetPasswordEmail, user)
      .map((response: Response) => response);
  }

  resetPassword(key: string, user: User) {
    return this.http.post(Endpoints.resetPassword(key), user)
      .map((response: Response) => response);
  }

  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('2fa_status');
    this.globalService.loginCheck.next(false);
    this.router.navigate(['/home']);
  }

  getAccounts() {
    return this.http.get(Endpoints.getAccounts, createRequestOptions())
      .map((response: Response) => {
        return response.json();
      });
  }

  changePassword(oldPwd: string, newPwd: string) {
    return this.http.post(Endpoints.changePassword,
        {'oldPassword': oldPwd, 'newPassword': newPwd},
        createRequestOptions());
  }

  enable2faWithPassword(pwd: string) {
    return this.http.post(Endpoints.enable2fa,
      {'password': pwd},
      createRequestOptions());
  }

  enable2faWithCode(code: string) {
    return this.http.post(Endpoints.verifyEnable2fa,
      {'code': code},
      createRequestOptions());
  }

  disable2fa(code: string) {
    return this.http.post(Endpoints.disable2fa,
      {'code': code},
      createRequestOptions());
  }
}
