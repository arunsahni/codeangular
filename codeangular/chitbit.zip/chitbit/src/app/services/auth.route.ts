import {Injectable} from '@angular/core';
import {CanActivate, Router} from '@angular/router';
import {JwtHelper} from 'angular2-jwt';
import {getAccessToken} from '../utils/utils';

@Injectable()
export class ChecktokenService implements CanActivate {
  jwtHelper: JwtHelper = new JwtHelper();
  constructor(private router: Router) {
  }

  canActivate() {
    const accessToken = getAccessToken();
    if (accessToken && (this.jwtHelper.decodeToken(accessToken).authorities.indexOf('USER') !== -1)) {
      return true;
    }
    this.router.navigate(['home']);
    return false;
  }
}
