import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Endpoints} from '../endpoint';
import {createRequestOptions} from '../utils/utils';
import {MarketsPage} from '../models/marketsPage';

@Injectable()
export class MarketsService {

  constructor(private http: Http) { }

  getMarket(acronym: string, page: number, pageSize: number) {
    return this.http.post(Endpoints.getMarket(acronym),
      {
        'page': page,
        'pageSize': pageSize
      },
      createRequestOptions(true))
      .map((response: Response) => response.json() as MarketsPage);
  }
}
