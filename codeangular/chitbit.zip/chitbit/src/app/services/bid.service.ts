import {Injectable} from '@angular/core';
import {Endpoints} from '../endpoint';
import {Http, Response} from '@angular/http';
import {createRequestOptions} from '../utils/utils';
import {QuickBidInfo} from '../models/quickBidInfo';
import {Balance} from '../models/balance';
import {CurrencyPair} from '../models/currencyPair';
import {OffersPage} from '../models/offersPage';
import {FeeResponse} from '../models/feeResponse';

@Injectable()
export class BidService {

  constructor(
    private http: Http) {
  }

  getCurrencyPairs() {
    return this.http.get(Endpoints.getCurrencyPairs)
      .map((response: Response) => response.json() as Array<CurrencyPair>);
  }

  quickInfo(bidType: string, amount: number, currencyPairUuid: number) {
    return this.http.post(Endpoints.quickInfo,
      {
        bidType: bidType,
        amount: amount,
        currencyPairUuid: currencyPairUuid
      }, createRequestOptions())
      .map((response: Response) => response.json() as QuickBidInfo);
  }

  quickBid(bidType: string, amount: number, currencyPairUuid: number) {
    return this.http.post(Endpoints.quickBid,
      {
        bidType: bidType,
        amount: amount,
        currencyPairUuid: currencyPairUuid
      }, createRequestOptions());
  }

  getBalance(acronym: string) {
    return this.http.get(Endpoints.getBalance(acronym), createRequestOptions())
      .map((response: Response) => response.json() as Balance);
  }

  getOffers(uuid: number, type: string, page: number, pageSize: number) {
    return this.http.post(Endpoints.getOffers(uuid, type),
      {
        'page': page,
        'pageSize': pageSize
      },
      createRequestOptions())
      .map((response: Response) => response.json() as OffersPage);
  }

  createBid(bidType: string, amount: number, currencyPairUuid: number, ratio: number) {
    return this.http.post(Endpoints.createBid(),
      {
        'bidType': bidType,
        'amount': amount,
        'currencyPairUuid': currencyPairUuid,
        'ratio': ratio
      }, createRequestOptions());
  }

  getFee() {
    return this.http.get(Endpoints.getFee, createRequestOptions())
      .map((response: Response) => response.json() as FeeResponse);
  }
}
