import {Injectable} from '@angular/core';
import * as Rx from 'rxjs/Rx';
import 'rxjs/add/observable/of';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';
import {CurrencyPair} from './models/currencyPair';

@Injectable()
export class GlobalService {
  loginCheck: Rx.Subject<any> = new Rx.Subject<any>();
  visibleCheck: Rx.Subject<any> = new Rx.Subject<any>();
  rightBarCheck: Rx.Subject<any> = new Rx.Subject<any>();
  initEmail: Rx.Subject<any> = new Rx.Subject<any>();
  tfaChange: Rx.Subject<any> = new Rx.Subject<any>();
  exchangeLayout: Rx.BehaviorSubject<number> = new Rx.BehaviorSubject<number>(1);
  currencyPair: Rx.BehaviorSubject<CurrencyPair> = new Rx.BehaviorSubject<CurrencyPair>(null);
  constructor() {
  }
}
