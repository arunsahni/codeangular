var express = require('express');
var passport = require('passport');
var router = express.Router();
require('../config/passport')(passport);
var user = require('../app/controllers/users.js');
var auth = require('../config/auth');


router.get('/', function(req, res, next) {
  res.render('index.html');
});

/* To register a user. */
router.post('/signup', user.signUp);

/* To verify email. */
router.get('/verifyemail/:token', user.verifyEmail);

 /* To upload avatar of a user. */
router.post('/upload-profilepic', user.uploadProfilePic);
router.post('/upload-profile-image', user.uploadProfileImage); // for dekstop version

    
/* To login. */
router.post('/login', user.login);

 /* To recover password. */
router.post('/forgot-password', user.forgotPassword);

/* To reset password. */
router.post('/reset-password/:token', user.resetPassword);

/* To add a staff. */
router.post('/add-staff', user.addStaff);

/* To update a staff. */
router.post('/update-staff', user.updateStaff);

/* To delete a staff. */
router.post('/delete-staff', user.deleteStaff);

/* To view a staff. */
router.get('/view-staff/:staffId', user.viewStaff);

/* To get all staff list. */
router.post('/view-all-staff', user.viewAllStaff);

/* To search staff info. */
router.post('/search-staff', user.searchStaff);

/* To update user info. */
router.post('/update-userinfo', user.updateUser);

/* To view a business owner. */
router.get('/view-owner/:ownerId/:addedBy', user.viewOwner);

/* To get all business owners. */
router.post('/view-all-owners', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), user.viewAllBusinessOwners);

/* To get count of all sales owners. */
router.post('/count-all-staff', user.countStaff);

/* To update membership details of user. */
router.post('/membership', user.updateMembership);

router.post('/view-membership', user.viewMembership);

router.post('/update-membership', user.updateMembership);

router.post('/renew-membership', user.renewMembership);
router.post('/cancel-membership', user.cancelMembership);

/* To get details of user. */
router.post('/get-userdetails', user.userDetails);

/* To get all business owners by latest. */
router.post('/get-business-owners-latest', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}) ,user.businessOwnersByLatest);

/* To get all business owners via category. */
router.post('/get-businessowner-category', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), user.businessOwnersViaCategory);

/* To get all business owners via category. */
router.post('/search-businessowner', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), user.searchBusinessOwner);

 /* To end the user session. */
router.post('/logout', user.logout);


router.post('/contact-us', user.contact);

router.post('/register-card', user.registerCard);

router.post('/staff-visibility', user.updateVisibility);
router.post('/update-token', user.updateToken);
router.post('/update-push-status', user.updatePushStatus);

router.post('/get-plans-admin', user.getPlansAdmin);
router.post('/get-static-data', user.getStaticData);

router.get('/downloadcsv/:filename', function(req, res, next) {
  var file = __dirname + '/../public/images/user/'+req.params.filename;
  res.download(file); // Set disposition and send it.
});



//router.get('/membership-cron', user.membershipCron);
//router.get('/membership-subscription-cron', user.membershipSubscriptionCron);

//user.startNotificationCron();

module.exports = router;
