var express = require('express');
var passport = require('passport');
var router = express.Router();
require('../config/passport')(passport);
var offer = require('../app/controllers/offers.js');
var auth = require('../config/auth');

router.get('/', function(req, res, next) {
  res.render('index.html');
});

/* To get count of all offers. */
router.post('/count-all-offer', offer.countOffer);

/* To get all business offers. */
router.post('/view-all-offers-mob', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), offer.viewAllOffersMobi);

/* To view a business offer. */
router.get('/view-offer/:offerId', offer.viewOffer);

/* To add a offer. */
router.post('/add-offer', offer.addOffer);
router.get('/edit-offer/:offerId', offer.editOffer);
router.post('/update-offer', offer.updateOffer);
router.post('/delete-offer-media', offer.deleteOfferMedia);
router.post('/delete-offer', offer.deleteOffer);

/* To refer a friend for a offer. */
router.post('/refer-friend', offer.referOfferToFriend);
router.post('/search-coupon', offer.searchCoupon);
router.post('/redeem-coupon', offer.redeemCoupon);

/* To get business offers sorted by latest. */
router.post('/list-current-offers', offer.listCurrentOffers);
router.post('/count-current-offers', offer.countCurrentOffers);
router.post('/search-current-offer', offer.searchCurrentOffer);

router.post('/list-past-offers', offer.listPastOffers);
router.post('/count-past-offers', offer.countPastOffers);
router.post('/search-past-offer', offer.searchPastOffer);

/* To get business offers sorted by latest. */
router.post('/get-offerdetails-latest', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), offer.offerDetailsByLatest);

/* To get business offers by business. */
router.post('/get-offers-business', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), offer.viewAllOffersByBusiness);

/* To get business offers by business. */
router.post('/get-latest-offers-business', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), offer.viewAllLatestOffersByBusiness);

/* To get business offers by business. */
router.post('/search-offers', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), offer.searchOffer);

/* To upload avatar of a user. */
router.post('/upload-offer-image', offer.uploadOfferImage);

/* To get business offers by business. */
router.post('/get-offers-by-category', auth.authenticationMiddleware(), passport.authenticate('jwt', { session: false}), offer.offersViaCategory);


/* To get categories. */
router.get('/get-category', offer.getCategories);

/* To get categories. */
router.post('/save-category', offer.saveCategory);

router.post('/import-offers', offer.importOffers);

router.post('/all-offers', offer.viewAllOffers);



module.exports = router;
