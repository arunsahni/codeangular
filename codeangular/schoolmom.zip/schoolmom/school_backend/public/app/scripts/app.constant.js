
var imagePaths = {
    "userAvatar" : "images/user/avatar/original/"
};