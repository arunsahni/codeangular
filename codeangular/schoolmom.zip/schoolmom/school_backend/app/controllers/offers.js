/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var Promise = require("bluebird"); 
var formidable = require("formidable"); 
var offerObj = require('../models/offers.js');
var usersObj = require('../models/users.js');
var categoryObj = require('../models/categories.js');
var referredDetailsObj = require('../models/referredDetails.js');
var constantObj = require('../../config/constants.js');
var pushNotifyObj = require('../../config/pushNotify.js');
var passport = require('../../config/passport.js');
var cfg = require('../../config/passport_config.js');
var memberConfig = require('../../config/membership.js');

var crypto = require('crypto');
var nodemailer = require('nodemailer');
var smtp = require("nodemailer-smtp-transport");
var bcrypt = require('bcrypt-nodejs');
var jwt = require('jwt-simple');
var fs = require('fs');
var twilio = require('twilio')(constantObj.twilioCredentials.ACCOUNTSID, constantObj.twilioCredentials.AUTHTOKEN);
var otp = require('otplib/lib/totp');
var moment = require('moment');
var csv = require('csv-array');



var mongoose = require('mongoose');
// smtp settings
var smtpTransport = nodemailer.createTransport(smtp({
    host: constantObj.gmailSMTPCredentials.host,
    secureConnection: constantObj.gmailSMTPCredentials.secure,
    port: constantObj.gmailSMTPCredentials.port,
    auth: {
        user: constantObj.gmailSMTPCredentials.username,
        pass: constantObj.gmailSMTPCredentials.password
    }
}));

var transporter = nodemailer.createTransport();

mongoose.set('debug', true);


/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	uploadImage
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to upload pic of offer.
 _________________________________________________________________________
 */


var uploadOfferImage = function (req, res) {
     var form = new formidable.IncomingForm();
     var RecordLocator = "";
     form.parse(req, function (err, fields, files) 
        {
            console.log(files);
            var file_name = "";
            if (files.file.name) 
            {
                uploadDir = __dirname + constantObj.imagePaths.offer;
                file_name = files.file.name;
                var name = Math.floor(Date.now() / 1000).toString() + '_' + file_name;
                RecordLocator = file_name[0];
                fs.renameSync(files.file.path, uploadDir + "/" + name)
                var url = 'http://' + req.headers.host + constantObj.imagePaths.offerurl+ '/' + name; 
                console.log("dynamic url:::",url);
                var response = {status: 200, msg: "image saved successfully.", data: url};
                res.jsonp(response);
            }
    });

};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	addOffer
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to add new offer.
 _________________________________________________________________________
 */


var addOffer = function (req, res) {
    var offer = {};
    var imageArray = [];
    offer = req.body.offerObj || req.body;
    offer.endDate =  new Date(offer.endDate).toISOString();
    offer.startDate= new Date(offer.startDate).toISOString();
    
    return memberConfig.checkOffersLimit(offer.userId)
    .then(function(checkLimit) {
        
       console.log("aaaaaaaa",checkLimit);
       if(checkLimit == "invalid"){
            return "invalid";
       }else if(checkLimit == "invalid_renew_error"){
            return "invalid_renew_error";
       }else{ 
            return categoryObj.findOne({_id:  mongoose.Types.ObjectId(offer.offerCategory)});
       }
    }).then(function(response) {

       if(response=="invalid"){
            console.log(response);
            res.jsonp({status: 501, msg: 'Offer limit reached'});
       }else if(response== "invalid_renew_error"){
            res.jsonp({status: 505, msg: 'Offer limit reached'});
       }else{ 

        offer.offerCategory = response.category;
        console.log(offer.offerCategory); 
        if(offer.publishStatus==true)
            {
                offer.publishStatus = "published";
            }else{
                offer.publishStatus = "unpublished";
            }
        
        offerObj(offer).save(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    var conditions = {
                        _id: req.body.userId
                    };
                   
                    usersObj.findOneAndUpdate(conditions, { $inc : { 'noofOffers' : 1, 'membershipDetails.offers_limit' : -1} }, function(err, data){
                          if (err) {
                            res.jsonp(err);
                        } else{
                             return data;
                             
                        }
                    });             
                }
            });

        }

    }).then(function(dataSaved) {
        
        var approved_by =  mongoose.Types.ObjectId(offer.userId);
        usersObj.findOne({_id:  mongoose.Types.ObjectId(offer.userId)}, function (err, currentUser) { 
            usersObj.find({visibility: true,role: "referrer" , "approvalDetails": { $elemMatch: { approved_by:approved_by } }}).exec(function (err, acceptedReferer) {
                if (err) {
                        res.jsonp(err);
                    } else{
                       var message = "A new offer "+ offer.offerName +" has been added by "+currentUser.business.name+"." 
                       console.log(message);
                       if(acceptedReferer.length>0){ 
                            for(var i=0;i< acceptedReferer.length;i++)
                            {
                              pushNotifyObj.iosPushFunction(acceptedReferer[i].deviceToken,message,1,acceptedReferer[i].pushStatus);
                              pushNotifyObj.androidPushFunction(acceptedReferer[i].deviceToken,message,acceptedReferer[i].pushStatus,1);
                            }
                       } 
                        res.jsonp({status: 200, msg: 'offer added successfully.', data: dataSaved});
                    }
            });
       });  
    });
};



var importOffers = function (req, res) {
    var form = new formidable.IncomingForm();
    var RecordLocator = "";
    form.parse(req, function (err, fields, files) 
    {
        var userId = fields.userId;
        var file_name = "";
        if (files.file.name) 
        {
            var csvFilePath=files.file.path;
             csv.parseCSV(csvFilePath, function(data){
               var offer = data;
              var arrOffers = [];
               for(var i=0;i<offer.length;i++)
                {
                   offer[i].userId = userId;
                    if(fields.salesUserId)
                    {
                        offer[i].salesUserId = fields.salesUserId;
                    }
                               
                   offer[i].endDate =  new Date(offer[i].endDate).toISOString();
                   offer[i].startDate= new Date(offer[i].startDate).toISOString();
                   console.log(offer[i]);
                   offerObj(offer[i]).save(function (err, data) {
                        if (err) {
                            res.jsonp(err);
                        } else {
                            arrOffers.push(data);
                            var conditions = {
                                _id: userId
                            };
                           
                            usersObj.findOneAndUpdate(conditions, { $inc : { noofOffers : 1 , 'membershipDetails.offers_limit' : -1} }, function(err, data){
                                  if (err) {
                                    res.jsonp(err);
                                } else{
                                     
                                }
                            });             
                        }
                    });
                    
                }
                res.jsonp({status: 200, msg: 'offer added successfully.'});
             });
        }
    });


};



/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	updateOffer
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to update a offer.
 _________________________________________________________________________
 */

var updateOffer = function (req, res) {
    
    var offerFields = req.body.offerObj || req.body;
    

    offerFields.endDate = new Date(offerFields.endDate).toISOString();
    offerFields.startDate= new Date(offerFields.startDate).toISOString();

    var pushOfferVideos = offerFields.offerVideos;
    var pushOfferImages = offerFields.offerImages;
    
    console.log(offerFields);
    
    if(offerFields.publishStatus==true)
    {
        offerFields.publishStatus = "published";
    }else{
        offerFields.publishStatus = "unpublished";
    }
    var conditions = {
        _id: req.body._id
    };
    delete offerFields._id;
    delete offerFields.offerVideos;
    delete offerFields.offerImages;

    offerObj.update(conditions, {$set: offerFields, $pushAll: { offerVideos: pushOfferVideos , offerImages: pushOfferImages }}, function (err, offer) {
        if (err) {
            res.jsonp(err);
        } else {
           
                    pushNotifyObj.iosPushFunction();
                    res.jsonp({status: 200, msg: 'updated successfully.', data: offer});
            
        }
    });

};


/*________________________________________________________________________
 * @Date:       08 Feb,2017
 * @Method :    deleteOfferMedia
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is delete offer media.
 _________________________________________________________________________
 */

var deleteOfferMedia = function (req, res) {
    
    var mediaFields = req.body.offerObj || req.body;
    var conditions = {
        _id:  mongoose.Types.ObjectId(req.body.id)
    };
    console.log(conditions);
    if(req.body.type=="image"){
        offerObj.update(conditions, { '$pull': { 'offerImages' : { '_id' :  mongoose.Types.ObjectId(req.body.media_id) }}} , { safe: true, multi:true }, function (err, offer) {
            if (err) {
                res.jsonp(err);
            } else {
                res.jsonp({status: 200, msg: 'updated successfully.', data: offer});
            }
        });
    }else{

        offerObj.update(conditions, { '$pull': { 'offerVideos' : { '_id' :  mongoose.Types.ObjectId(req.body.media_id) }}} , { safe: true, multi:true }, function (err, offer) {
            if (err) {
                res.jsonp(err);
            } else {
                res.jsonp({status: 200, msg: 'updated successfully.', data: offer});
            }
        });
    }

};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	deleteOffer
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to remove a offer.
 _________________________________________________________________________
 */

var deleteOffer = function (req, res) {
    var fields = {
        isDeleted: true
    };
    var conditions = {
        _id: req.body._id
    };

    offerObj.update(conditions, {$set: fields}, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            var conditions = {
                _id: req.body.userId
            };
                   
            usersObj.findOneAndUpdate(conditions, { $inc : { noofOffers : -1 } }, function(err, data){
                  if (err) {
                    res.jsonp(err);
                } else{
                    res.jsonp({status: 200, msg: 'offer deleted successfully.', data: data});
                }
            });  
            
        }
    });
};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	viewOffer
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to view a offer detail.
 _________________________________________________________________________
 */

var viewOffer = function (req, res) {
    var fields = {
    };
    var conditions = {
        _id: req.params.offerId
    };
    
    offerObj.findOne(conditions, fields, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {

                    var a= moment(data.endDate).format('DD MMM,YYYY');
                    var b= moment(data.startDate).format('DD MMM,YYYY');
                    data.endDate = a;
                    data.startDate = b;
            res.jsonp({status: 200, msg: "get offer info successfully.", data: data});
        }
    });
};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	viewAllOffers
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to get list of all offers.
 _________________________________________________________________________
 */

var viewAllOffers = function (req, res) {
    console.log("====================================================");
    console.log("skip",req.body.skip);
    console.log("limit",req.body.limit);
    console.log("====================================================");
    var fields = {
    };
    var conditions = {
        $and: [ {isDeleted: false},
                {userId:  req.body.userId}
            ]
    };
    offerObj.find(conditions, fields).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get all offers.", data: data});
        }
    });
};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	viewAllOffersMobi
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to get list of all offers.
 _________________________________________________________________________
 */

var viewAllOffersMobi = function (req, res) {
    
    var fields = {
    };
   
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
       if (err) {
            res.jsonp(err);
        }else{
//            console.log("----------------------",mongoose.Types.ObjectId("58906e126cdb6351013d0753"));
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
//                console.log("============",data.approvalDetails[i]);
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
//                console.log("--------------",arr[i]);
            }
//            console.log(arr);
            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);
            var conditions = {
                $or: [ 
                        { 
                            $and: [
                                {isDeleted: false} ,
                                {userId: { $in: arr}},
                            ]
                        },
                        {
                            $and: [ 
                                {isDeleted: false} ,
                                {publishStatus:"published"},
                            ]
                        }
                    ]
                }    

        /*    var conditions = {
                                userId: { $in: arr}
                             }; */

            offerObj.find(conditions, fields).skip(skipVal).limit(parseInt(req.body.limit)).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    if(data){
                        for(var i=0;i< data.length;i++)
                        {
                            var a= moment(data[i].endDate).format('DD MMM,YYYY');
                            var b= moment(data[i].startDate).format('DD MMM,YYYY');
                            data[i].endDate = a;
                            data[i].startDate = b;
                        }
                        res.jsonp({status: 200, msg: "get all offers.", data: data});
                    }
                   
                }
            });
        } 
    });

};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	searchOffer
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to search offer info.
 _________________________________________________________________________
 */

var searchOffer = function (req, res) {
    var fields = {
        
    };
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
       if (err) {
            res.jsonp(err);
        }else{
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
            }

            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);
    
            console.log("Data to search: ",req.body.searchData);
//            var terms = req.body.searchData.split(' ');
//            var regexString = "";
//            for (var i = 0; i < terms.length; i++)
//            {
//                regexString += terms[i];
//                if (i < terms.length - 1) regexString += '?=';
//            }
//
//            var searchName = new RegExp(regexString, 'i');
            
            var searchName = new RegExp(req.body.searchData , 'i');
//            console.log("Search: ",search11);
            var arr1 =[];
            if(parseInt(req.body.isOfferByBusiness) == 0){
                if(req.body.category.length){
                    var category = req.body.category.split(",");
                    console.log(category);
                    if(category.length){
                        for(var i=0;i< category.length;i++)
                        {
                            arr1.push(category[i]);
                        }
                        console.log("True");
                        var conditions = {
                                $and: [
                                        { 
                                            $or: [
                                               {"offerCategory": searchName},
                                               {"offerName": searchName}
                            //               {"personalInfo.name": new RegExp('/'+req.body.searchData+'$/', "i")}
                                            ]
                                        },
                                        {
                                              $or: [ 
                                                { 
                                                    $and: [
                                                            {userId: { $in: arr}},
                                                            {offerCategory: { $in: arr1}},
                                                            {isDeleted: false}
                                                    ]
                                                },
                                                {
                                                    $and: [ 
                                                            {offerCategory: { $in: arr1}},
                                                            {isDeleted: false},
                                                            {publishStatus:"published"}
                                                    ]
                                                }
                                            ]  

                                        }
                                ]

                            }; 

                    /*    var conditions = {
                            $and : [
                                { 
                                 $or: [
                                       {"offerCategory": searchName},
                                       {"offerName": searchName}
                                    ]
                                },
                                {userId: { $in: arr}},
                                {offerCategory: { $in: arr1}},
                                {isDeleted: false}
                            ]
                        };*/
                    }
                } else{
                    var conditions = {
                                $and: [
                                        { 
                                            $or: [
                                               {"offerCategory": searchName},
                                               {"offerName": searchName}
                            //               {"personalInfo.name": new RegExp('/'+req.body.searchData+'$/', "i")}
                                            ]
                                        },
                                        {
                                              $or: [ 
                                                { 
                                                    $and: [
                                                            {userId: { $in: arr}},
                                                            {isDeleted: false}
                                                    ]
                                                },
                                                {
                                                    $and: [ 
                                                            {isDeleted: false},
                                                            {publishStatus:"published"}
                                                    ]
                                                }
                                            ]  

                                        }
                                ]

                            }; 

                /*    var conditions = {
                       $and : [
                           { 
                            $or: [
                                  {"offerCategory": searchName},
                                  {"offerName": searchName}
                               ]
                           },
                           {userId: { $in: arr}},
                           {isDeleted: false}
                       ]
                   }; */
                   console.log("False");
               }
            } else if(parseInt(req.body.isOfferByBusiness) == 1){
                if(req.body.businessId){
                    var conditions = {
                        $and : [
                            {"offerName": searchName},
                            {userId: mongoose.Types.ObjectId(req.body.businessId)},
                            {isDeleted: false}
                        ]
                    };
                }else{
                    res.jsonp({status: 201, msg: "No business id found."});
                }
                    
            } else{
                res.jsonp({status: 201, msg: "No parameters found."});
            }
        
            
            var sort = {};
            if(parseInt(req.body.isLatest) == 1){
                sort.updatedAt = -1;
            } else{
                 sort.updatedAt = 1;
            }
            offerObj.find(conditions, fields).skip(skipVal).limit(parseInt(req.body.limit)).sort(sort).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    if(data){
                        for(var i=0;i< data.length;i++)
                        {
                            var a= moment(data[i].endDate).format('DD MMM,YYYY');
                            var b= moment(data[i].startDate).format('DD MMM,YYYY');
                            data[i].endDate = a;
                            data[i].startDate = b;
                        }
                       
                    }
                    res.jsonp({status: 200, msg: "get all offers.", data: data});
                }
            });
        }
    });
};

/*________________________________________________________________________
 * @Date:      	08 Feb,2017
 * @Method :   	countOffer
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to get count of all offers.
 _________________________________________________________________________
 */

var countOffer = function (req, res) {
    var fields = {
        
    };
    var conditions = {
        $and: [ {isDeleted: false},
                {userId:  req.body.userId}
            ]
    };
    offerObj.find(conditions, fields).count().exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get owners count.", data: data});
        }
    });
};


/*________________________________________________________________________
	* @Date:      	09 Feb,2017
	* @Method :   	referOfferToFriend
	* Created By: 	arun sahani
	* Modified On:	-
	* @Purpose:   	This function is used to refer a friend for a offer.
_________________________________________________________________________
*/

var referOfferToFriend = function (req, res) {
    // user secret key 
    var secret = otp.utils.generateSecret();
    //  code 
    var code = otp.generate(secret);
    
    offerObj.findOne({_id:mongoose.Types.ObjectId(req.body.offerId)}).exec(function (err, offerDetails) {
        console.log(offerDetails);
        var offerArray = {
            offerName: offerDetails.offerName,
            offerImage: offerDetails.offerImage,
            offerAmount: offerDetails.offerAmount,
            startDate: offerDetails.startDate,
            endDate: offerDetails.endDate,
            description: offerDetails.description,
            discount: offerDetails.discount,
            discount_description: offerDetails.discount_description,
            remuneration: offerDetails.remuneration,
            remuneration_description: offerDetails.remuneration_description,
            offerCategory: offerDetails.offerCategory,
            storeLocator: offerDetails.storeLocator,
            termsConditions: offerDetails.termsConditions,
            createdDate:offerDetails.createdDate
        };

        console.log(offerArray);
        var fields = {
            couponCode: code,
            email: req.body.email || '',
            phone : req.body.mobileno || '',
            offerId: req.body.offerId,
            referrerId: req.body.referrerId,
            businessOwner: req.body.businessOwner,
            createdDate : new Date().toISOString(),
            offerDetails:offerArray
        };
        var conditions = {};
        console.log(req.body);
        if (req.body.offerId && req.body.referrerId && req.body.businessOwner) {
            //     res.jsonp({status: 200, msg: 'referred person added successfully.', data: data});
            referredDetailsObj(fields).save(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    if(req.body.mobileno && req.body.email) {
                           Promise.resolve().then(function() {
                                 return sendOfferEmail(req,code);
                              }).then(function(response) {
                                return sendOfferSMS(req,code);
                              }).then(function(responseMobile) {
                                   res.jsonp({status: 200, msg: "Coupon code sent on your email and mobile"});      
                              });    
                          // sendOfferSMSAndEmail(req,code);   
                    } else if (req.body.mobileno) {
                        Promise.resolve().then(function() {
                            return sendOfferSMS(req,code);
                        }).then(function(response) {
                            res.jsonp({status: 200, msg: "Coupon code sent on your mobile"});      
                        })

                        
                    } else if (req.body.email) {
                        Promise.resolve().then(function() {
                            return sendOfferEmail(req,code);
                        }).then(function(response) {
                            res.jsonp({status: 200, msg: "Coupon code sent on your email"});     
                        })
                    } else {
                        res.jsonp({status: 201, msg: "No parameters found."});
                    }
                }
            });
        } else {
           
            res.jsonp({status: 201, msg: "Oops ! Something went wrong."});
        }

    });

};

/*________________________________________________________________________
 * @Date:      	14 Feb,2017
 * @Method :   	offerDetailsByLatest
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to view offers sorted by latest.
 _________________________________________________________________________
 */

var offerDetailsByLatest = function (req, res) {

    var fields = {
        
    };
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
       if (err) {
            res.jsonp(err);
        }else{
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
            }
            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);

             var conditions = {
                $or: [ 
                        { 
                            $and: [
                                {isDeleted: false} ,
                                {userId: { $in: arr}},
                            ]
                        },
                        {
                            $and: [ 
                                {isDeleted: false} ,
                                {publishStatus:"published"},
                            ]
                        }
                    ]
                }; 
    
            offerObj.find(conditions, fields).skip(skipVal).limit(parseInt(req.body.limit)).sort({'updatedAt': -1}).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    if(data){
                        for(var i=0;i< data.length;i++)
                        {
                            var a= moment(data[i].endDate).format('DD MMM,YYYY');
                            var b= moment(data[i].startDate).format('DD MMM,YYYY');
                            data[i].endDate = a;
                            data[i].startDate = b;
                        }
                        res.jsonp({status: 200, msg: "get all offers sorted by latest.", data: data});
                    }
                }
            });
        } 
    });
};

/*________________________________________________________________________
 * @Date:      	14 Feb,2017
 * @Method :   	viewAllOffersByBusiness
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to get list of all offers.
 _________________________________________________________________________
 */

var viewAllOffersByBusiness = function (req, res) {
   
    var fields = {
    };
    var conditions = {
        $and: [ {isDeleted: false},
                {userId:  req.body.userId}
            ]
    };
    var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
    console.log(skipVal);
   
    offerObj.find(conditions, fields).skip(skipVal).limit(parseInt(req.body.limit)).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(data){
                for(var i=0;i< data.length;i++)
                {
                    var a= moment(data[i].endDate).format('DD MMM,YYYY');
                    var b= moment(data[i].startDate).format('DD MMM,YYYY');
                    data[i].endDate = a;
                    data[i].startDate = b;
                }
               res.jsonp({status: 200, msg: "get all offers by business.", data: data});        
            }
        }
    });
};

/*________________________________________________________________________
 * @Date:      	15 Feb,2017
 * @Method :   	viewAllLatestOffersByBusiness
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to get list of all latest offers by business.
 _________________________________________________________________________
 */

var viewAllLatestOffersByBusiness = function (req, res) {
   
    var fields = {
    };
    var conditions = {
        $and: [ {isDeleted: false},
                {userId:  req.body.userId}
            ]
    };
    var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
    console.log(skipVal);
    
    offerObj.find(conditions, fields).skip(skipVal).limit(parseInt(req.body.limit)).sort({'updatedAt': -1}).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(data){
                for(var i=0;i< data.length;i++)
                {
                    var a= moment(data[i].endDate).format('DD MMM,YYYY');
                    var b= moment(data[i].startDate).format('DD MMM,YYYY');
                    data[i].endDate = a;
                    data[i].startDate = b;
                }
               res.jsonp({status: 200, msg: "get all offers by business.", data: data});        
            }
        }
    });
};


/*________________________________________________________________________
 * @Date:      	20 Feb,2017
 * @Method :   	offersViaCategory
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to view offers via category.
 _________________________________________________________________________
 */

var offersViaCategory = function (req, res) {

    var fields = {
    };
   
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
       if (err) {
            res.jsonp(err);
        }else{
            
//            console.log("----------------------",mongoose.Types.ObjectId("58906e126cdb6351013d0753"));
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
//                console.log("============",data.approvalDetails[i]);
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
//                console.log("--------------",arr[i]);
            }
//            console.log(arr);
            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log("skip value:",skipVal);
            var arr1 =[];
            category = req.body.category.split(",");
            
            for(var i=0;i< category.length;i++)
            {
                arr1.push(category[i]);
            }

            var conditions = {
                $or: [ 
                        { 
                            $and: [
                                {isDeleted: false} ,
                                {userId: { $in: arr}},
                                {offerCategory: { $in: category}}
                            ]
                        },
                        {
                            $and: [ 
                                {isDeleted: false} ,
                                {publishStatus:"published"},
                                {offerCategory: { $in: category}}
                            ]
                        }
                    ]
                }; 
           
            /*var conditions = {
                $and: [  
                        {isDeleted: false},
                        {userId: { $in: arr}},
                        {offerCategory: { $in: category}}
                    ]
            }; */
            var sort = {};
            if(parseInt(req.body.isLatest) == 1){
                sort.updatedAt = -1;
            } else{
                 sort.updatedAt = 1;
            }
            offerObj.find(conditions, fields).skip(skipVal).limit(parseInt(req.body.limit)).sort(sort).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    if(data){
                       
                        for(var i=0;i< data.length;i++)
                        {
                            var a= moment(data[i].endDate).format('DD MMM,YYYY');
                            var b= moment(data[i].startDate).format('DD MMM,YYYY');
                            data[i].endDate = a;
                            data[i].startDate = b;
                        }
                        res.jsonp({status: 200, msg: "get all offers.", data: data});
                    }
                   
                }
            });
        } 
    });
};
/*________________________________________________________________________
 * @Date:      	20 Feb,2017
 * @Method :   	getCategories
 * Created By: 	arun sahani
 * Modified On:	-
 * @Purpose:   	This function is used to get all category.
 _________________________________________________________________________
 */

var getCategories = function (req, res) {
    var fields = {
        
    };
    var conditions = {
        
    };
    categoryObj.find(conditions, fields, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get all categories.", data: data});
        }
    });
};

var saveCategory = function (req, res) {
    categoryObj(req.body).save(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "save categories.", data: data});
        }
    });
};


/*________________________________________________________________________
 * @Date:       15 Feb,2017
 * @Method :    listCurrentOffers
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get list of all latest offers of a user.
 _________________________________________________________________________
 */

var listCurrentOffers = function (req, res) {
   
    var today =  moment().format("YYYY-MM-DD");
    var currentDate = today+"T00:00:00.000Z";

    var fields = {
    };
    var conditions = {
        "endDate": {"$gte": currentDate},
        'isDeleted': false,
        "userId": req.body.userId
    };
    
    //"userId": req.body.userId
    offerObj.find(conditions, fields).sort({'updatedAt': -1}).skip(req.body.skip).limit(req.body.limit).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(data){
                
                for(var i=0;i< data.length;i++)
                {
                    var a= moment(data[i].endDate).format('DD MMM,YYYY');
                    var b= moment(data[i].startDate).format('DD MMM,YYYY');
                    data[i].endDate = a;
                    data[i].startDate = b;
                }
               res.jsonp({status: 200, msg: "get all latest offers.", data: data}); 
            }
        }
    });

};


/*________________________________________________________________________
 * @Date:       02 Feb,2017
 * @Method :    countCurrentOffers
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get count current offers.
 _________________________________________________________________________
 */

var countCurrentOffers = function (req, res) {
    var today =  moment().format("YYYY-MM-DD");
    var currentDate = today+"T00:00:00.000Z";
    var fields = {
        
    };
     var conditions = {
        "endDate": {"$gte": currentDate},
        'isDeleted': false,
        "userId": req.body.userId
    };
    
    //"userId": req.body.userId
    offerObj.find(conditions, fields).count().exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get current offers count.", data: data});
        }
    });
};


/*________________________________________________________________________
 * @Date:       08 Feb,2017
 * @Method :    searchOffer
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to search offer info.
 _________________________________________________________________________
 */

var searchCurrentOffer = function (req, res) {
    var today =  moment().format("YYYY-MM-DD");
    var currentDate = today+"T00:00:00.000Z";
    var fields = {
    };



    var conditions = {
        $and : [
                { 
                 $or: [
                       {"description": new RegExp(req.body.searchData, "i")},
                       {"offerName": new RegExp(req.body.searchData, "i")}
                    ]
                },
            {endDate: { $gte : currentDate}},
            {isDeleted : false},
            {userId : req.body.addedBy}
         ]   
    };
    
    //"userId": req.body.userId
    offerObj.find(conditions, fields).sort({'updatedAt': -1}).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(data){
                
                for(var i=0;i< data.length;i++)
                {
                    var a= moment(data[i].endDate).format('DD MMM,YYYY');
                    var b= moment(data[i].startDate).format('DD MMM,YYYY');
                    data[i].endDate = a;
                    data[i].startDate = b;
                }
               res.jsonp({status: 200, msg: "get all latest offers.", data: data}); 
            }
        }
    });

};







/*________________________________________________________________________
 * @Date:       15 Feb,2017
 * @Method :    listCurrentOffers
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get list of all latest offers of a user.
 _________________________________________________________________________
 */

var listPastOffers = function (req, res) {
   
    var today =  moment().format("YYYY-MM-DD");
    var currentDate = today+"T00:00:00.000Z";
    console.log(currentDate);
    var fields = {
    };
    var conditions = {
        $and : [
                { 
                 $or: [
                       {"endDate": {"$lt": currentDate}},
                       {"isDeleted": true }
                    ]
                },
            {userId : req.body.userId}
         ]  
        
    };
    //"userId": req.body.userId
    offerObj.find(conditions, fields).sort({'updatedAt': -1}).skip(req.body.skip).limit(req.body.limit).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(data){
                console.log(data);
                for(var i=0;i< data.length;i++)
                {
                    var a= moment(data[i].endDate).format('DD MMM,YYYY');
                    var b= moment(data[i].startDate).format('DD MMM,YYYY');
                    data[i].endDate = a;
                    data[i].startDate = b;
                }
               res.jsonp({status: 200, msg: "get all past offers.", data: data}); 
            }
        }
    });

};


/*________________________________________________________________________
 * @Date:       02 Feb,2017
 * @Method :    countCurrentOffers
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get count current offers.
 _________________________________________________________________________
 */

var countPastOffers = function (req, res) {
    var today =  moment().format("YYYY-MM-DD");
    var currentDate = today+"T00:00:00.000Z";
    var fields = {
        
    };
    var conditions = {
        $and : [
                { 
                 $or: [
                       {"endDate": {"$lt": currentDate}},
                       {"isDeleted": true }
                    ]
                },
            {userId : req.body.userId}
         ]  
        
    };
    
    //"userId": req.body.userId
    offerObj.find(conditions, fields).count().exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get past offers count.", data: data});
        }
    });
};


/*________________________________________________________________________
 * @Date:       08 Feb,2017
 * @Method :    searchOffer
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to search offer info.
 _________________________________________________________________________
 */

var searchPastOffer = function (req, res) {
    var today =  moment().format("YYYY-MM-DD");
    var currentDate = today+"T00:00:00.000Z";
    var fields = {
    };

    var conditions = {
        $and : [
                { 
                 $or: [
                       {"description": new RegExp(req.body.searchData, "i")},
                       {"offerName": new RegExp(req.body.searchData, "i")}
                    ]
                },
                { 
                 $or: [
                       {"endDate": {"$lt": currentDate}},
                       {"isDeleted": true }
                    ]
                },
            {userId : req.body.addedBy}
         ]   
    };
    
    //"userId": req.body.userId
    offerObj.find(conditions, fields).sort({'updatedAt': -1}).exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(data){
                
                for(var i=0;i< data.length;i++)
                {
                    var a= moment(data[i].endDate).format('DD MMM,YYYY');
                    var b= moment(data[i].startDate).format('DD MMM,YYYY');
                    data[i].endDate = a;
                    data[i].startDate = b;
                }
               res.jsonp({status: 200, msg: "get all latest offers.", data: data}); 
            }
        }
    });

};


/*________________________________________________________________________
 * @Date:       03 Feb,2017
 * @Method :    edit-offer
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to edit a offer.
 _________________________________________________________________________
 */

var editOffer = function (req, res) {
    var fields = {
    };
    var conditions = {
        _id: req.params.offerId
    };

    offerObj.findOne(conditions, fields, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {

           /* var a= moment(data.endDate).subtract(1, "days");
            var b= moment(data.startDate).subtract(1, "days");
            data.endDate = a;
            data.startDate = b; */
            res.jsonp({status: 200, msg: "get offer info successfully.", data: data});
        }
    });
};


/*________________________________________________________________________
 * @Date:       03 Feb,2017
 * @Method :    search-coupon
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to edit a offer.
 _________________________________________________________________________
 */

var searchCoupon = function (req, res) {
    var fields = {
    };
    var conditions = {
        couponCode: req.body.couponCode
    };

     Promise.resolve().then(function() {
        return categoryObj.findOne({_id:  mongoose.Types.ObjectId(req.body.userCateogry)});
    }).then(function(response) {
        referredDetailsObj.find(conditions).populate('offerId referrerId').exec(function (err, data) {
            if (err) {
                res.jsonp(err);
            } else {
                //return categoryObj.findOne({_id:  mongoose.Types.ObjectId(offer.offerCategory)})    
                var a= moment(data[0].offerDetails.endDate).format('DD MMM,YYYY');
                var b= moment(data[0].offerDetails.startDate).format('DD MMM,YYYY');
                data[0].offerDetails.endDate = a;
                data[0].offerDetails.startDate = b;
                
                res.jsonp({status: 200, msg: "get offer info successfully.", data: data});
               
            }
        });

     });
};


/*________________________________________________________________________
 * @Date:       03 Feb,2017
 * @Method :    redeem-coupon
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to redeem coupon.
 _________________________________________________________________________
 */

var redeemCoupon = function (req, res) {
    
    var fields = {
        redeemed: req.body.redeemed,
        redeemedBy: req.body.redeemedBy,
        status: req.body.status,
        redeemedDate: new Date(req.body.date).toISOString(),
        referrerEarning: req.body.referrerEarning
    };
  
    var conditions = {
        couponCode: req.body.couponCode
    };

    Promise.resolve().then(function() {
        return usersObj.findOne({_id:  mongoose.Types.ObjectId(req.body.userId)});
    }).then(function(response) {
        fields.businessOwnerName = response.business.name;
        referredDetailsObj.findOne(conditions).populate('offerId referrerId businessOwner').exec(function (err, data) {

            if(data.redeemed == true)
            {
                res.jsonp({status: 201, msg: 'This coupon is used already.'});
            }else{

                referredDetailsObj.update(conditions, {$set: fields}, function (err, staff) {
                    if (err) {
                        console.log("aaaaaaaaaa",err);
                        res.jsonp(err);
                    } else {
                        sendRedeemCouponEmail(fields.redeemed,fields.redeemedBy,fields.status,fields.redeemedDate,fields.referrerEarning,data);
                        res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                    }
                });
            }
        });

    });
};


function sendRedeemCouponEmail(redeemed,redeemedBy,status,redeemedDate,referrerEarning,otherDetails)
{
    //var businessOwner = usersObj.findOne({_id: mongoose.Types.ObjectId(businessOwnerId)});

    usersObj.findOne({_id: mongoose.Types.ObjectId(redeemedBy)}).exec(function (err, data) {
            var redeemedDate= moment(redeemedDate).format('DD MMM,YYYY');
            var subject = 'Referral Max Coupon Redeemed';
            if(status=="Valid"){
                var html = 'Hello,<br><br>' +
                        'A new coupon has redeemed <br/><br/>'+
                        'Coupon Code :'+ otherDetails.couponCode+ '<br/><br/>'+
                        'Referral Email :'+ otherDetails.email+ '<br/><br/>'+
                        'Referral Mobile :'+ otherDetails.phone+ '<br/><br/>'+
                        'Offer Name :'+ otherDetails.offerId.offerName+ '<br/><br/>'+
                        'Redeemed By :'+ data.personalInfo.name+ '<br/><br/>'+
                        'Business Owner :'+ otherDetails.businessOwner.business.name+ '<br/><br/>'+
                        'Status :'+ status+ '<br/><br/>'+
                        'Redeemed Date :'+ redeemedDate+ '<br/><br/>'+
                        'Earning : $'+ referrerEarning+ '<br/><br/>';

                var message =  otherDetails.couponCode+ " has been redeemed.";      
            }else{

                var html = 'Hello,<br><br>' +
                        'A new coupon has redeemed <br/><br/>'+
                        'Coupon Code :'+ otherDetails.couponCode+ '<br/><br/>'+
                        'Referral Email :'+ otherDetails.email+ '<br/><br/>'+
                        'Referral Mobile :'+ otherDetails.phone+ '<br/><br/>'+
                        'Offer Name :'+ otherDetails.offerId.offerName+ '<br/><br/>'+
                        'Redeemed By :'+ data.personalInfo.name+ '<br/><br/>'+
                        'Business Owner :'+ otherDetails.businessOwner.business.name+ '<br/><br/>'+
                        'Status :'+ status+ '<br/><br/>'+
                        'Redeemed Date :'+ redeemedDate+ '<br/><br/>';

                var message =  otherDetails.couponCode+ " has been redeemed.";      

            }            
      
       // console.log(otherDetails);
            pushNotifyObj.iosPushFunction(otherDetails.referrerId.deviceToken,message,5,otherDetails.referrerId.pushStatus);
            pushNotifyObj.androidPushFunction(otherDetails.referrerId.deviceToken,message,otherDetails.referrerId.pushStatus,2);
            var mailOptions = {
                from: constantObj.gmailSMTPCredentials.username,
                to: otherDetails.referrerId.email,
                subject: subject,
                html: html
            };
            // send mail with defined transport object
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    return console.log(error);
                }

                var mailOptions = {
                    from: constantObj.gmailSMTPCredentials.username,
                    to: otherDetails.businessOwner.email,
                    subject: subject,
                    html: html
                };
                // send mail with defined transport object
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        return console.log(error);
                    }

                    
                    console.log('Message sent: ' + info.response);

                });

            });
            return true;
    });

    

 }



function sendOfferEmail(req,code)
{
    
    offerObj.findOne({_id: mongoose.Types.ObjectId(req.body.offerId)}).populate('userId').exec(function (err, offerData) {
       usersObj.findOne({_id: mongoose.Types.ObjectId(req.body.referrerId)}).exec(function (err, referrerData) { 
            var mailOptions = {
                from: constantObj.gmailSMTPCredentials.username,
                to: req.body.email,
                subject: 'Referral Max Coupon Code',
                html: 'Hello,<br><br>' +
                        'This is your coupon code. ' + code + '<br><br>' +
                        'Referred By :'+ referrerData.personalInfo.name + '<br/><br/>'+
                        'Referrer Email and Phone :'+ referrerData.email+' Phone: '+ referrerData.personalInfo.mobileNo + '<br/><br/>'+
                        'Business Name :'+ offerData.userId.business.name + '<br/><br/>'+
                        'Offer Name :'+ offerData.offerName + '<br/><br/>'+
                        'Store Location :'+ offerData.storeLocator + '<br/><br/>'+
                        'Please click on the following link to view,<br><br>' +
                        '<a href="' + 'http://referralmax.net/' + '#!/view-offer-referrar/' + req.body.offerId + '/'+code +'" target="_blank" >Click here to see</a><br><br>'
            };
            // send mail with defined transport object
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    return console.log(error);
                }
                console.log('Message sent: ' + info.response);

            });
            return true;
        });
    });


}


function sendOfferSMS(req,code)
{

    var mobileNo = '+91' + req.body.mobileno;
    twilio.sendMessage({
        to: mobileNo, //'+917409575518', // Any number Twilio can deliver to   
        from: constantObj.twilioCredentials.TwilioNumber, // A number you bought from Twilio and can use for outbound communication
        body: code + ' : use this coupon code ' + 'http://referralmax.net/' +'/#!/view-offer-referrar/' + req.body.offerId + '/'+code
                // mediaUrl: "https://www.google.com" 
                // body of the SMS message
    }, function (err, responseData) { //this function is executed when a response is received from Twilio
        if (!err) {
            return false;
            //res.jsonp({status: 200, msg: "Coupon code sent on your mobile"});
            console.log(responseData.from); // outputs "+14506667788"
            console.log(responseData.body); // outputs "word to your mother."
        } else {
            return true;
           // res.jsonp({status: 201, msg: "Wasn't able to send coupon code."});
        }
    });
}






/*________________________________________________________________________
 * @Date:       08 Feb,2017
 * @Method :    Uploading Pics in base 64
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to upload pics in base64
 _________________________________________________________________________
 */

//  functions


exports.addOffer = addOffer;
exports.updateOffer = updateOffer;
exports.deleteOffer = deleteOffer;
exports.viewOffer = viewOffer;
exports.viewAllOffers = viewAllOffers;
exports.viewAllOffersMobi = viewAllOffersMobi;
exports.searchOffer = searchOffer;
exports.countOffer = countOffer;
exports.referOfferToFriend = referOfferToFriend;
exports.offerDetailsByLatest = offerDetailsByLatest;
exports.viewAllOffersByBusiness = viewAllOffersByBusiness;
exports.viewAllLatestOffersByBusiness = viewAllLatestOffersByBusiness;
exports.offersViaCategory = offersViaCategory;
exports.getCategories = getCategories;
exports.saveCategory = saveCategory;
exports.uploadOfferImage = uploadOfferImage;
exports.listCurrentOffers = listCurrentOffers;
exports.listPastOffers = listPastOffers;
exports.countCurrentOffers = countCurrentOffers;
exports.countPastOffers = countPastOffers;
exports.editOffer = editOffer;
exports.deleteOfferMedia = deleteOfferMedia;
exports.searchCurrentOffer = searchCurrentOffer;
exports.searchPastOffer = searchPastOffer;
exports.searchCoupon = searchCoupon;
exports.redeemCoupon = redeemCoupon;
exports.importOffers = importOffers;









