/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var formidable = require("formidable");
var schoolObj = require('../models/schools.js');
var usersObj = require('../models/users.js');
var constantObj = require('../../config/constants.js');
var passport = require('../../config/passport.js');
var cfg = require('../../config/passport_config.js');
var pushNotifyObj = require('../../config/pushNotify.js');

var nodemailer = require('nodemailer');
var smtp = require("nodemailer-smtp-transport");
var crypto = require('crypto');
var async = require("async");
var bcrypt = require('bcrypt-nodejs');
var jwt = require('jwt-simple');
var fs = require('fs');
var formidable = require('formidable');
var mongoose = require('mongoose');
var moment = require('moment');
var otp = require('otplib/lib/totp');

mongoose.set('debug', true);
var smtpTransport = nodemailer.createTransport(smtp({
    host: constantObj.gmailSMTPCredentials.host,
    secureConnection: constantObj.gmailSMTPCredentials.secure,
    port: constantObj.gmailSMTPCredentials.port,
    auth: {
        user: constantObj.gmailSMTPCredentials.username,
        pass: constantObj.gmailSMTPCredentials.password
    }
}));

var transporter = nodemailer.createTransport();



/*________________________________________________________________________
 * @Date:       10 Sept,2017
 * @Method :    addSchool
 * Created By:  Abhijeet Singh
 * Modified On: -
 * @Purpose:    This function is used to register new user.
 _________________________________________________________________________
 */


var addSchool = function (req, res) {
    console.log("aaaaaaaaaaaaaa");
    school = req.body.schoolObj || req.body;
    errorMessage = "";
            schoolObj(school).save(function (err, data) {
                if (err) {
                    console.log("aaaa",err.name);
                    switch (err.name) {
                        case 'ValidationError':
                            for (field in err.errors) {
                                console.log("bbbbb",err.errors[field].path);
                                
                            }//for
                            break;
                    }
                } else {
                    console.log("success");
                     res.jsonp({status: 200, msg: "success",data:data}); 
                    
                }
            });

    
};



/*________________________________________________________________________
 * @Date:       10 Sept,2017
 * @Method :    searchSchool
 * Created By:  Abhijeet Singh
 * Modified On: -
 * @Purpose:    This function is used to register new user.
 _________________________________________________________________________
 */


var searchSchool = function (req, res) {
    school = req.body.schoolObj || req.body;
    errorMessage = "";
    var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
    if(req.body.search_type=="cords"){

        var coords = [];  
        coords[0] = req.body.longitude || 0;  
        coords[1] = req.body.latitude || 0;  

        var maxDistance = req.body.distance || 8;
        maxDistance /= 6371; 

        schoolObj.find({ loc: {  $near: coords, $maxDistance: maxDistance }}).skip(skipVal).limit(parseInt(req.body.limit)).exec(function(err, locations) {
            if (err) {
                return res.json(500, err);
            }

            res.jsonp({status: 200, msg: "get all schools.", data: locations});
        });

    }

    if(req.body.search_type=="name"){
        var searchName = new RegExp(req.body.searchData , 'i');
        var conditions = {
          $or: [
                   {"schoolName": searchName},
                   {"city": searchName},
                   {"address": searchName}

               ]
          };

        schoolObj.find(conditions).skip(skipVal).limit(parseInt(req.body.limit)).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    res.jsonp({status: 200, msg: "get all schools.", data: data});
                }
            });

    }


    
};


/*________________________________________________________________________
 * @Date:       10 Sept,2017
 * @Method :    schoolById
 * Created By:  Abhijeet Singh
 * Modified On: -
 * @Purpose:    This function is used to register new user.
 _________________________________________________________________________
 */


var schoolById = function (req, res) {
    school = req.body.schoolObj || req.body;
    errorMessage = "";
    schoolObj.findOne({_id:  mongoose.Types.ObjectId(school.id)}, function (err, currentSchool) { 

           if(currentSchool){
                res.jsonp({status: 200, msg: "get all schools.", data: currentSchool});
           }else{
                res.jsonp({status: 201, msg: "No data found"});
           }
         
    }); 
    
};


/*________________________________________________________________________
 * @Date:       10 Sept,2017
 * @Method :    schoolById
 * Created By:  Abhijeet Singh
 * Modified On: -
 * @Purpose:    This function is used to register new user.
 _________________________________________________________________________
 */


var addChildSchool = function (req, res) {
    school = req.body.schoolObj || req.body;
    errorMessage = "";
    Promise.resolve().then(function() {
       return schoolObj.findOne({"_id": mongoose.Types.ObjectId(school.school_id)});
    }).then(function(schoolData) {

        if(schoolData){ //if school data is exist
            schoolObj.findOne({ "_id": mongoose.Types.ObjectId(school.school_id),
                classes: { $elemMatch: { class_name: school.class_name } } },{ 'classes.$': 1 }, 
                function(err, classData) {
                if(err){
                    console.log("class find",err);
                    res.jsonp(err);
                }

                if(classData) //if class data is exist
                {
                   // console.log("this is class data",classData);
                   schoolObj.aggregate({

					    $match: { _id: mongoose.Types.ObjectId(school.school_id) }

					}, {

					    $project: {

					        '_id': 1,
					        'classes.class_name': 1,
					        'classes.sections': 1

					    }

					}, {

					    $redact: {
					        $cond: {
					            $eq: ['$id', mongoose.Types.ObjectId(school.section_id)]
					        }
					    }

					},
                        function(err,sectionData) {

                            if (err) {
                                 console.log("section find",err);
                                 res.jsonp(err);
                            }
                           
                            if(sectionData){ //if section data is exist
                                 console.log("section data is there",sectionData);
                                 res.jsonp({status: 200, msg: "section updated.", data: sectionData});
                            }else{
                                //console.log("section data is there",sectionData);
                                var fields = { "classes.$.sections": { section_name: school.section_name } };
                                schoolObj.findOneAndUpdate({"_id": mongoose.Types.ObjectId(school.school_id),
                                    "classes.class_name": school.class_name}, {$push: fields}, function (err, sectionUpdateData) {
                                    if (err) {
                                        console.log("section add",err);
                                        res.jsonp(err);
                                    } else {

                                       res.jsonp({status: 200, msg: "section updated.", data: sectionUpdateData});
                                        
                                    }
                                });

                            }



                    });



                }else{  //if class data is exist

                    var fields = { "classes": { class_name: school.class_name } };
                    schoolObj.update({"_id": mongoose.Types.ObjectId(school.school_id)}, {$push: fields}, function (err, classUpdateData) {
                        if (err) {
                            console.log("class add",err);
                            res.jsonp(err);
                        } else {

                            console.log("section data is new and class is new",classUpdateData);
                            var fields = { "classes.$.sections": { section_name: school.section_name } };
                            schoolObj.findOneAndUpdate({"_id": mongoose.Types.ObjectId(school.school_id),
                                "classes.class_name": school.class_name}, {$push: fields}, function (err, sectionUpdateData) {
                                if (err) {
                                    console.log("section add",err);
                                    res.jsonp(err);
                                } else {

                                   res.jsonp({status: 200, msg: "section updated.", data: sectionUpdateData});
                                    
                                }
                            });

                            
                        }
                    });

                }

                
            });



        }else{ 

             res.jsonp({status: 201, msg: "School Not found"});

        }

        
    }); 
   
};




//  functions
exports.addSchool = addSchool;
exports.searchSchool = searchSchool;
exports.schoolById = schoolById;
exports.addChildSchool = addChildSchool;


















