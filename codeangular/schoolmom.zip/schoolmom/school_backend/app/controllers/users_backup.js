/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var formidable = require("formidable");
var usersObj = require('../models/users.js');
var offerObj = require('../models/offers.js');
var memberShipObj = require('../models/membership.js');
var pagesObj = require('../models/pages.js');
var categoryObj = require('../models/categories.js');
var constantObj = require('../../config/constants.js');
var passport = require('../../config/passport.js');
var cfg = require('../../config/passport_config.js');
var memberConfig = require('../../config/membership.js');

var crypto = require('crypto');
var async = require("async");
var nodemailer = require('nodemailer');
var smtp = require("nodemailer-smtp-transport");
var bcrypt = require('bcrypt-nodejs');
var jwt = require('jwt-simple');
var fs = require('fs');
var formidable = require('formidable');
var mongoose = require('mongoose');
var moment = require('moment');
var stripe = require('stripe')('sk_test_nnN4aPfXjPstPUZLEcXhXzpY');
var CronJob = require('cron').CronJob;

const PATTERNS = {
        EVERY_MINUTE : '00 */59 * * * *'
    }

// smtp settings
var smtpTransport = nodemailer.createTransport(smtp({
    host: constantObj.gmailSMTPCredentials.host,
    secureConnection: constantObj.gmailSMTPCredentials.secure,
    port: constantObj.gmailSMTPCredentials.port,
    auth: {
        user: constantObj.gmailSMTPCredentials.username,
        pass: constantObj.gmailSMTPCredentials.password
    }
}));

var transporter = nodemailer.createTransport();

var startNotificationCron = function (req, res) {
    //Start New Message Notification Cron
    // It is changed to every 5 seconds.
    new CronJob( PATTERNS.EVERY_MINUTE , membershipCron ).start();
    new CronJob( PATTERNS.EVERY_MINUTE , membershipSubscriptionCron ).start();
}

/*________________________________________________________________________
 * @Date:       03 Jan,2017
 * @Method :    signUp
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to register new user.
 _________________________________________________________________________
 */


var signUp = function (req, res) {
    var user = {};
    user = req.body.usersObj || req.body;
    user.email = req.body.email.toLowerCase();
    console.log(user);
    var token;
    crypto.randomBytes(10, function (err, buf) {
        token = buf.toString('hex');
        user.verificationToken = token;
        user.verifyEmail = {
            email: req.body.email.toLowerCase(),
            verificationStatus: false
        };

       
       var errorMessage = "";

       Promise.resolve().then(function() {
                if(user.role=="b_owner"){
                    return categoryObj.findOne({_id:  mongoose.Types.ObjectId(req.body.business.category)});
                }else{ return 1; }
            }).then(function(response) {
             if(user.role=="b_owner"){ 
                    user.business.category_name = response.category;  
                    memberShipObj.findOne({'_id' : mongoose.Types.ObjectId(user.membershipDetails.plan_id)}, function (err, membershipDb) {
                    console.log(err);
                    if(user.role=="b_owner"){ 
                        user.membershipDetails.sowner_limit = membershipDb.sowner_limit;
                        user.membershipDetails.offers_limit = membershipDb.offers_limit;
                        user.membershipDetails.refferer_limit = membershipDb.refferer_limit;
                        user.membershipDetails.refill_date = moment().add(13, 'months').format('YYYY-MM-DD');
                    }    

                            usersObj(user).save(function (err, data) {
                                if (err) {
                                    console.log("aaaa",err); 
                                    switch (err.name) {
                                        case 'ValidationError':
                                            for (field in err.errors) {
                                                console.log(err.errors);
                                                if (err.errors[field].path === 'email') {
                                                    errorMessage = 'This email id is already in use. Please select another email id.';
                                                }else if (err.errors[field].path === 'password') {
                                                    errorMessage = 'Please enter the password.';
                                                }else if (err.errors[field].path === 'personalInfo.name') {
                                                    errorMessage = 'Please enter the full name.';
                                                }
                                                
                                                
                                            }//for
                                        case 'MongoError':
                                            errorMessage = 'This email id is already in use. Please select another email id.'; 
                                            break;
                                    }//switch
                                    res.jsonp({status: 201, msg: errorMessage});
                                } else {
                                    console.log("success");     
                                    var verifyurl = 'verifyemail/' + user.verificationToken;
                    //                     var verifyurl = 'verify-email/';
                                    //console.log("Referrer:", req.headers);
                                    var mailOptions = {
                                        from: constantObj.gmailSMTPCredentials.username,
                                        to: req.body.email,
                                        subject: 'Referral Max Registration',
                                        html: 'You are receiving this because you have successfully registered for Referral Max.<br><br>' +
                                                'Please click on the following link, or paste into your browser to complete the verification process:<br><br>' +
                    //                                    '<a href="' + req.headers.referer + '#!/' + verifyurl + '" target="_blank" >' + req.headers.referer + '#!/'+ verifyurl +'</a><br><br>' +
                                                '<a href="' + 'http://referralmax.net/' + '#!/' + verifyurl + '" target="_blank" >' + 'http://referralmax.net/' + '#!/' + verifyurl + '</a><br><br>' +
                                                'If you did not request this, please ignore.<br><br>'
                                    };

                                    // send mail with defined transport object
                                    transporter.sendMail(mailOptions, function (error, info) {
                                        if (error) {
                                            return console.log(error);
                                        }
                                        console.log('Message sent: ' + info);

                                    });
                                    res.jsonp({status: 200, msg: "user registered successfully."});
                                }
                            });
                    });  


                }else{

                            usersObj(user).save(function (err, data) {
                                if (err) {
                                    //console.log("aaaaa",err.name); 
                                    switch (err.name) {
                                        case 'ValidationError':
                                            for (field in err.errors) {
                                                console.log()
                                                if (err.errors[field].path === 'email') {
                                                    errorMessage = 'This email id is already in use. Please select another email id.';
                                                }else if (err.errors[field].path === 'password') {
                                                    errorMessage = 'Please enter the password.';
                                                }else if (err.errors[field].path === 'personalInfo.name') {
                                                    errorMessage = 'Please enter the full name.';
                                                }
                                                
                                            }
                                        case 'MongoError':
                                            errorMessage = 'This email id is already in use. Please select another email id.'; 
                                            break;
                                    }//switch
                                    res.jsonp({status: 201, msg: errorMessage});
                                } else {
                                    console.log("success");     
                                    var verifyurl = 'verifyemail/' + user.verificationToken;
                    //                     var verifyurl = 'verify-email/';
                                    //console.log("Referrer:", req.headers);
                                    var mailOptions = {
                                        from: constantObj.gmailSMTPCredentials.username,
                                        to: req.body.email,
                                        subject: 'Referral Max Registration',
                                        html: 'You are receiving this because you have successfully registered for Referral Max.<br><br>' +
                                                'Please click on the following link, or paste into your browser to complete the verification process:<br><br>' +
                    //                                    '<a href="' + req.headers.referer + '#!/' + verifyurl + '" target="_blank" >' + req.headers.referer + '#!/'+ verifyurl +'</a><br><br>' +
                                                '<a href="' + 'http://referralmax.net/' + '#!/' + verifyurl + '" target="_blank" >' + 'http://referralmax.net/' + '#!/' + verifyurl + '</a><br><br>' +
                                                'If you did not request this, please ignore.<br><br>'
                                    };

                                    // send mail with defined transport object
                                    transporter.sendMail(mailOptions, function (error, info) {
                                        if (error) {
                                            return console.log(error);
                                        }
                                        console.log('Message sent: ' + info);

                                    });
                                    res.jsonp({status: 200, msg: "user registered successfully."});
                                }
                            });
                        

                }
               
                  
        }); 
    });

};

/*________________________________________________________________________
 * @Date:       03 Jan,2017
 * @Method :    verifyEmail
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to verify user email.
 _________________________________________________________________________
 */

var verifyEmail = function (req, res) {
    var outputJSON = "";

    usersObj.findOne({verificationToken: req.params.token}, function (err, data) {
        if (err) {

            outputJSON = {status: 203, msg: constantObj.messages.errorRetreivingData};
            res.jsonp(outputJSON);
        } else {
            if (!data) {
                outputJSON = {status: 203, msg: constantObj.messages.errorVerification};
                res.jsonp(outputJSON);
            } else {
                var verificationStatus = data.verifyEmail.verificationStatus;
                var user_id = data._id;
                if (verificationStatus === true) { // already verified
                    console.log("account verified");
                    outputJSON = {status: 200, msg: 'Account Already verified.'};
                    res.jsonp(outputJSON);
                } else { // to be verified
                    data.email = data.verifyEmail.email;
                    data.verifyEmail = {
                        email: data.verifyEmail.email,
                        verificationStatus: true
                    };
                    data.save(function (err, data) {
                        if (err) {
                            outputJSON = {status: 201, msg: constantObj.messages.errorRetreivingData};
                            res.jsonp(outputJSON);
                        } else {

                            var mailOptions = {
                                from: constantObj.gmailSMTPCredentials.username,
                                to: data.email,
                                subject: 'Account Activation',
                                html: 'Hello,<br><br>' +
                                        'This is a confirmation that your account has been activated.<br><br>' +
                                        'Please click on the following link to login,<br><br>' +
                                        '<a href="' + 'http://referralmax.net/' +'#!/'+ '" target="_blank" >' + 'http://referralmax.net/' +'#!/'+ '</a><br><br>'

                            };

                            // send mail with defined transport object
                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) {
                                    return console.log(error);
                                }
                                console.log('Message sent: ' + info.response);
                               /* console.log("ROLE",data.role);
                                var idToSend = data._id;
                                console.log("ID TO SEND ",idToSend);
                                if(data.role == "referrer"){
                                    usersObj.find({role: "b_owner"}, function (err, data) {
                                            for(var i=0;i< data.length;i++)
                                            {
                                                console.log("EMAIL ID",data[i].email);
                                                listofemails.push(data[i].email);
                                            }    
                                           
                                           console.log(listofemails); 

                                           async.each(listofemails,function(){
                                                   async.waterfall([
                                                     function(Email,callback) {                
                                                         var mailOptionsRefferer = {
                                                            from: constantObj.gmailSMTPCredentials.username,
                                                            to: Email,
                                                            subject: 'New Refferer Added',
                                                            html: 'Hello,<br><br>' +
                                                                    'A new refferer has been registered.<br><br>' +
                                                                    'Please click on the following link to add refferer,<br><br>' +
                                                                    '<a href="' + 'http://' + req.headers.host + '#!/refferer/' + idToSend + '" target="_blank" >' + 'http://' + req.headers.host + '#!/refferer/' + idToSend +'</a><br><br>'

                                                                };

                                                            transporter.sendMail(mailOptionsRefferer, function (error, info) {
                                                                if (error) {
                                                                    return console.log(error);
                                                                }
                                                                console.log('Message sent: ' + mailOptionsRefferer.html);   
                                                            });
                                                     },
                                                     function(statusCode,Email,callback) {
                                                             console.log("Will update DB here for " + Email + "With " + statusCode);
                                                             callback();
                                                     }
                                                     ],function(){
                                                         //When everything is done return back to caller.
                                                         callback();
                                                 });
                                            });

                                           //new massMailer(listofemails);
                                        }); 
                                }*/

                            });

                              

                            //res.redirect('/#!/account-activation');
                            outputJSON = {status: 200, msg: 'Account Activated successfully'};
                            res.jsonp(outputJSON);
                        }
                    });
                }


            }
        }

    });
};

/*________________________________________________________________________
 * @Date:       03 Jan,2017
 * @Method :    login
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to authenticate user.
 _________________________________________________________________________
 */

var login = function (req, res) {
    console.log(req.body.password);
    usersObj.findOne({email: req.body.email.toLowerCase()}, function (err, data) {
        if (err) {
            outputJSON = {status: 203, msg: "Please enter a valid email."};
            res.jsonp(outputJSON);
        } else {
            if (data) {
                //console.log("aaaaaaaaaaaaaaa",data);
                var format_created_date = moment(data.createdDate).format('YYYY-MM-DD');
                var format_today = moment().format('YYYY-MM-DD');

                var created = moment(format_created_date);
                var today = moment(format_today);

                var diff =  today.diff(created, 'days');

                if(diff >=31 && data.membershipDetails.account_type=="free" && data.role=="b_owner"){
                    res.jsonp({status: 205, msg: 'Your trial period has been expired.'});     
                }else if(data.userStatus==false){
                   res.jsonp({status: 203, msg: 'Your account is marked inactive. Please contact our support'}); 
                }
                else{    
                    if(data.verifyEmail.verificationStatus == false){
                       res.jsonp({status: 201, msg: "Your Email is not verified yet."});
                    } else{
                    bcrypt.compare(req.body.password, data.password, function (err, result) {
                        if (err) {
                            res.jsonp(err);
                        } else {
                            if (result === true) {
                                var token = jwt.encode(data._id, cfg.secret);
                                res.jsonp({status: 200, token: token, data: data});
                            } else {
                                res.jsonp({status: 203, msg: 'Authentication failed due to wrong email/password.'});
                            }
                        }
                    });
                    }
                
                    
                }    
            } else {
                res.jsonp({status: 201, msg: 'Authentication failed.'});
            }
        }
    });
};

/*________________________________________________________________________
 * @Date:       6 Jan,2017
 * @Method :    uploadProfilePic
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to upload pic of tutor.
 _________________________________________________________________________
 */

var uploadProfilePic = function (req, res) {
    console.log("Hi image:", req.body.file);
    var bitmap = new Buffer(req.body.file, 'base64');
    // write buffer to file
    //console.log(req.body.file.filename);
    var name = Math.floor(Date.now() / 1000).toString() + '.' + 'png';
    fs.writeFileSync(name, bitmap);
    uploadDir = __dirname + constantObj.imagePaths.user;
    
    fs.renameSync(name, uploadDir + "/" + name);
    var url = 'http://' + req.headers.host + constantObj.imagePaths.url+ '/' + name; 
    console.log("dynamic url:::",url)
    
//    var url = constantObj.imagePaths.user + "/" + name;
    var response = {status: 200, msg: "image saved successfully.", data: url};
    res.jsonp(response);
    console.log('******** File created from base64 encoded string ********');


};


/*________________________________________________________________________
 * @Date:       08 Feb,2017
 * @Method :    uploadImage
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to upload pic of offer.
 _________________________________________________________________________
 */


var uploadProfileImage = function (req, res) {
     var form = new formidable.IncomingForm();
     var RecordLocator = "";
     form.parse(req, function (err, fields, files) 
        {
            console.log(files);
            var file_name = "";
            if (files.file.name) 
            {
                uploadDir = __dirname + constantObj.imagePaths.user;
                file_name = files.file.name;
                var name = Math.floor(Date.now() / 1000).toString() + '_' + file_name;
                RecordLocator = file_name[0];
                fs.renameSync(files.file.path, uploadDir + "/" + name)
                var url = 'http://' + req.headers.host + constantObj.imagePaths.url+ '/' + name; 
                console.log("dynamic url:::",url);
                var response = {status: 200, msg: "image saved successfully.", data: url};
                res.jsonp(response);
            }
    });

};


/*________________________________________________________________________
 * @Date:       03 Jan,2017
 * @Method :    forgot_password
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used when user forgots password.
 _________________________________________________________________________
 */
var forgotPassword = function (req, res) {
    var outputJSON = "";
    crypto.randomBytes(10, function (err, buf) {
        var token = buf.toString('hex');

        usersObj.findOne({email: req.body.email.toLowerCase()}, function (err, data) {
            if (err) {
                outputJSON = {status: 203, msg: "Please enter a valid email."};
                res.jsonp(outputJSON);
            } else if (!data) {
                outputJSON = {status: 203, msg: "Email does not exist."};
                res.jsonp(outputJSON);
            } else {
                if (data) {
                    data.resetPasswordToken = token,
                    data.resetPasswordExpires = Date.now() + 3600000;

                    data.save(function (err, data) {
                        if (err) {
                            outputJSON = {status: 203, msg: "Please enter a valid email."};
                        } else {

                            var mailOptions = {
                                from: constantObj.gmailSMTPCredentials.username,
                                to: req.body.email.toLowerCase(),
                                subject: 'Reset Password',
                                html: 'You are receiving this because you (or someone else) has requested a reset of your account password.<br/>' +
                                        'Please click on the following link, or paste into your browser to complete the process:<br/>' +
                                        '<a href="' + 'http://referralmax.net/' +'#!'+'/reset-password/' + token + '" target="_blank" >' + 'http://referralmax.net/' + '#!' +'/reset-password/' + token + '</a><br><br>'
                            };

                            // send mail with defined transport object
                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) {
                                    return console.log(error);
                                }
                                console.log('Message sent: ' + info.response);
                            });

                            outputJSON = {status: 200, msg: "Email sent successfully."}

                        }
                        res.jsonp(outputJSON);
                    });
                } else {
                    outputJSON = {status: 200, msg: "Email sent successfully."}
                    res.jsonp(outputJSON);
                }
            }
        });

    });
};

/*________________________________________________________________________
 * @Date:       03 Jan,2017
 * @Method :    resetPassword
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to reset the password.
 _________________________________________________________________________
 */

var resetPassword = function (req, res) {

    if(req.body.newPassword1)
    {
        console.log(req.body.token);
            usersObj.findOne({resetPasswordToken: req.body.token}, function (err, data) {
            if (err) {
                outputJSON = {status: 203, msg: "No record found."};
                res.jsonp(outputJSON);
            } else {
    //             console.log(data);
    //             return;
                if (!data) {
                    outputJSON = {status: 203, msg: "Reset Password token has been expired"};
                    res.jsonp(outputJSON);
                } else {
                    
                    data.password = req.body.newPassword1;
                    data.resetPasswordToken = undefined;
                    data.resetPasswordExpires = undefined;
                   
                    data.save(function (err, data) {
                        if (err) {
                            outputJSON = {status: 203, msg: "No record found."};
                            res.jsonp(outputJSON);
                        } else {

                            var transporter = nodemailer.createTransport(
                                    constantObj.gmailSMTPCredentials.type,
                                    {
                                        service: constantObj.gmailSMTPCredentials.service,
                                        auth: {
                                            user: constantObj.gmailSMTPCredentials.username,
                                            pass: constantObj.gmailSMTPCredentials.password
                                        }
                                    });

                            var mailOptions = {
                                from: constantObj.gmailSMTPCredentials.username,
                                to: data.email.toLowerCase(),
                                subject: 'Reset Password',
                                html: 'Hello,\n\n' +
                                        'This is a confirmation that the password for your account ' + data.email + ' has just been changed.\n'
                            };

                            // send mail with defined transport object
                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) {
                                    return console.log(error);
                                }
                                console.log('Message sent: ' + info.response);

                            });

                            outputJSON = {status: 200, msg: 'Password has been successfully updated'};
                            res.jsonp(outputJSON);
                        }
                    });

                }
            }

        });

    }else{

        
//   return;
    usersObj.findOne({email: req.body.email.toLowerCase()}, function (err, data) {
        if (err) {
            outputJSON = {status: 203, msg: "No record found."};
            res.jsonp(outputJSON);
        } else {
            
                bcrypt.compare(req.body.password, data.password, function (err, result) {          

                   data.password = req.body.newPassword;
                   
                    if (result === true) {
                     
                        data.save(function (err, data) {
                            if (err) {
                                outputJSON = {status: 203, msg: "No record found."};
                                res.jsonp(outputJSON);
                            } else {

                                var transporter = nodemailer.createTransport(
                                        constantObj.gmailSMTPCredentials.type,
                                        {
                                            service: constantObj.gmailSMTPCredentials.service,
                                            auth: {
                                                user: constantObj.gmailSMTPCredentials.username,
                                                pass: constantObj.gmailSMTPCredentials.password
                                            }
                                        });

                                var mailOptions = {
                                    from: constantObj.gmailSMTPCredentials.username,
                                    to: data.email,
                                    subject: 'Reset Password',
                                    html: 'Hello,\n\n' +
                                            'This is a confirmation that the password for your account ' + data.email + ' has just been changed.\n'
                                };

                                // send mail with defined transport object
                                transporter.sendMail(mailOptions, function (error, info) {
                                    if (error) {
                                        return console.log(error);
                                    }
                                    console.log('Message sent: ' + info.response);

                                });

                                outputJSON = {status: 200, msg: 'Password has been successfully updated'};
                                res.jsonp(outputJSON);
                            }
                        });

                     }else {
                            res.jsonp({status: 203, msg: 'Authentication failed due to wrong password.'});
                      }
                });    
            }

         });

    }


};


/*________________________________________________________________________
 * @Date:       09 Jan,2017
 * @Method :    addStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to add or register new staff.
 _________________________________________________________________________
 */

var addStaff = function (req, res) {
    var staff = {};
    staff = req.body.staffObj || req.body;
    console.log("user: ", staff);
    var token;
    crypto.randomBytes(10, function (err, buf) {
        token = buf.toString('hex');
        staff.verificationToken = token;
        staff.verifyEmail = {
            email: req.body.email,
            verificationStatus: true
        };

        return memberConfig.checkStaffLimit(req.body.addedBy)
        .then(function(sOwnerCount) {
             if(sOwnerCount == "invalid"){
                   console.log("invalid");
                   res.jsonp({status: 501, msg: 'Sowner limit reached'});
             }else if(sOwnerCount == "invalid_renew_error"){
                   console.log("invalid");
                   res.jsonp({status: 505, msg: 'renew memebrship'});
             }else{ 

              usersObj.findOne({email: req.body.email}, function (err, dataUnique) {
                 console.log("aaaaaaaaa",dataUnique)   
                 if(dataUnique == null){     
                  crypto.randomBytes(4, function (err, buf) {
                    var dynamic_pwd = buf.toString('hex');
                    console.log("pwd",dynamic_pwd);
                    staff.password = dynamic_pwd;
                    usersObj(staff).save(function (err, data) {
                        if (err) {
                            console.log(err);
                            res.jsonp({status: 201, msg: "Email already exist."});
                        } else {

                            var conditions = {
                                _id: req.body.addedBy
                            };

                            usersObj.findOneAndUpdate(conditions, { $inc : { 'membershipDetails.sowner_limit' : -1 } }, function(err, done){
                            var mailOptions = {
                                    from: constantObj.gmailSMTPCredentials.username,
                                    to: req.body.email,
                                    subject: 'Password',
                                    html: 'Password for your account is &nbsp; : &nbsp;' +dynamic_pwd+'<br/>' +
                                        'Please click on the following link, or paste into your browser to login:<br/>' +
                                        '<a href="' + 'http://referralmax.net/' +'" target="_blank" >' + 'http://referralmax.net/' + '</a><br><br>'+
                                        'Thanks' 
                                };

                                // send mail with defined transport object
                                transporter.sendMail(mailOptions, function (error, info) {
                                    if (error) {
                                        return console.log(error);
                                    }
                                    console.log('Message sent: ' + info.response);
                                });

                                outputJSON = {status: 200, msg: "Email sent successfully."}
                                res.jsonp(outputJSON);
                           });     
                        }
                        
            //                res.jsonp({status: 200, msg: "New staff added successfully."});

                          });
                    });

                  }else{
                        res.jsonp({status: 201, msg: "Email already exist."});
                  }
               });
          }
        });
    });
};


/*________________________________________________________________________
 * @Date:       09 Jan,2017
 * @Method :    updateStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to update a user.
 _________________________________________________________________________
 */

var updateStaff = function (req, res) {
    
    var fields = {
        personalInfo:{
            name: req.body.personalInfo.name,
            mobileNo: req.body.personalInfo.mobileNo,
            profileImg: req.body.personalInfo.profileImg
        },
        address: {
            address: req.body.address.address
        },
        allow_offer: req.body.allow_offer,
        allow_refferer: req.body.allow_refferer,
        allow_redeem_coupon : req.body.allow_redeem_coupon,
        empId: req.body.empId,
        email: req.body.email
    };
    
    var conditions = {
        _id: req.body._id
    };
    
    usersObj.update(conditions, {$set: fields}, function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
        }
    });

};

/*________________________________________________________________________
 * @Date:       09 Jan,2017
 * @Method :    deleteStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to remove a staff.
 _________________________________________________________________________
 */

var deleteStaff = function (req, res) {
    var fields = {
        isDeleted: true
    };
    var conditions = {
        _id: req.body._id
    };

    usersObj.update(conditions, {$set: fields}, function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            var conditions = {
                    _id: req.body.addedBy
                };
            usersObj.findOneAndUpdate(conditions, { $inc : { 'membershipDetails.sowner_limit' : 1 } }, function(err, count){
                 res.jsonp({status: 200, msg: 'staff deleted successfully.', data: staff});
            });
        }
    });
};

/*________________________________________________________________________
 * @Date:       09 Jan,2017
 * @Method :    viewStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to view a staff.
 _________________________________________________________________________
 */

var viewStaff = function (req, res) {

    var fields = {
    };
    var conditions = {
        _id: req.params.staffId
    };

    usersObj.findOne(conditions, fields).populate('addedBy').exec(function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get staff info successfully.", data: staff});
        }
    });
};

/*________________________________________________________________________
 * @Date:       09 Jan,2017
 * @Method :    viewAllStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get list of all staff users.
 _________________________________________________________________________
 */

var viewAllStaff = function (req, res) {
    console.log("====================================================");
    console.log("skip",req.body.skip);
    console.log("limit",req.body.limit);
    console.log("====================================================");
    var fields = {
        
    };

    var conditions = {
        $and: [ { role: 's_owner'}, 
                {isDeleted: false},
                {addedBy:  req.body.addedBy}
            ]
    };
    
    if(req.body.pagination==false){
        usersObj.find(conditions, fields).sort({'updatedAt': -1}).exec(function (err, data) {
            if (err) {
                res.jsonp(err);
            } else {
                res.jsonp({status: 200, msg: "get all users.", data: data});
            }
        });
    }else{
        usersObj.find(conditions, fields).sort({'updatedAt': -1}).skip(req.body.skip).limit(req.body.limit).exec(function (err, data) {
            if (err) {
                res.jsonp(err);
            } else {
                res.jsonp({status: 200, msg: "get all users.", data: data});
            }
        });
    }
};

/*________________________________________________________________________
 * @Date:       09 Jan,2017
 * @Method :    searchStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to search staff info.
 _________________________________________________________________________
 */

var searchStaff = function (req, res) {
    var fields = {
        
    };
    console.log("Data to search: ",req.body.searchData);
    var terms = req.body.searchData.split(' ');
    var regexString = "";
    for (var i = 0; i < terms.length; i++)
    {
        regexString += terms[i];
        if (i < terms.length - 1) regexString += '|';
    }

    var searchName = new RegExp(regexString, 'ig');
    
    var conditions = {
        $and : [
            { 
             $or: [{"empId": new RegExp('^'+req.body.searchData+'$', "i")}, 
                   {"address.address": new RegExp('^'+req.body.searchData+'$', "i")},
                   {"business.category": new RegExp('^'+req.body.searchData+'$', "i")},
                   {"personalInfo.name": searchName}
    //               {"personalInfo.name": new RegExp('/'+req.body.searchData+'$/', "i")}
                ]
              
            },
            {"role":"s_owner"},
            {addedBy:  req.body.addedBy},
            {isDeleted: false}
        ]
    };
    

//db.getCollection('users').find({ "empId": {$regex: /E001$/ }})
    usersObj.find(conditions, fields, function (err, staffArray) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get all users.", data: staffArray});
        }
    });
};


/*________________________________________________________________________
 * @Date:       24 Jan,2017
 * @Method :    updateUser
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to update a user.
 _________________________________________________________________________
 */

var updateUser = function (req, res) {
    
    var fields = {
        personalInfo:{
            name: req.body.personalInfo.name,
            mobileNo: req.body.personalInfo.mobileNo,
            profileImg: req.body.personalInfo.profileImg
        },
        address: {
            address: req.body.address.address,
            city: req.body.address.city,
            state: req.body.address.state,
            zipcode: req.body.address.zipcode,
            country: req.body.address.country
        },
        visibility: req.body.visibility
    };
    
    var conditions = {
        _id: req.body._id
    };
    
    usersObj.findOne(conditions, {'password': 1}, function (err, data) {
         if (err) {
            res.jsonp(err);
        } else{
            if(req.body.newpassword){
                data.password = req.body.newpassword;
                data.save(function (err, data) { 
                    if (err) {
                        switch (err.name) {
                            case 'ValidationError':
                                for (field in err.errors) {
                                    if (errorMessage == "") {
                                        errorMessage = err.errors[field].message;
                                    } else {
                                        errorMessage += "\r\n" + err.errors[field].message;
                                    }
                                }//for
                                break;
                        }//switch
                        res.jsonp(err);     
                    }//if
                    else {
                        usersObj.update(conditions, {$set: fields}, function (err, staff) {
                            if (err) {
                                res.jsonp(err);
                            } else {
                                res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                            }
                        });
                    }
                });
            } else{
                usersObj.update(conditions, {$set: fields}, function (err, staff) {
                    if (err) {
                        res.jsonp(err);
                    } else {
                        res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                    }
                });
            }
        }
    });
};


/*________________________________________________________________________
 * @Date:       24 Jan,2017
 * @Method :    viewOwner
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to view a owner.
 _________________________________________________________________________
 */

var viewOwner = function (req, res) {

    var fields = {
    };
    var conditions = {
        _id: req.params.ownerId
    };

    usersObj.findOne(conditions, fields).populate('business.category').exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {

           if(req.params.addedBy!=0){ 
            if(data.approvalDetails.length>0){
              var addedBy = mongoose.Types.ObjectId(req.params.addedBy);
              for(var i=0;i< data.approvalDetails.length;i++)
                {
                    if(data.approvalDetails[i].approved_by == req.params.addedBy)
                    {
                        var salesOwnerApproved =  data.approvalDetails[i].sales_owner;
                    }

                    var dateTimeFormat = moment(data.approvalDetails[i].date).format('DD MMM,YYYY HH:mm');
                }
            }


            var extraData = {
                salesOwnerApproved: salesOwnerApproved,
                dateTimeFormat:dateTimeFormat
            };

           } 
            
            res.jsonp({status: 200, msg: "get staff info successfully.", data: data, extraData:extraData});
        }
    });
};

/*________________________________________________________________________
 * @Date:       24 Jan,2017
 * @Method :    viewAllBusinessOwners
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get list of all business owners.
 _________________________________________________________________________
 */

var viewAllBusinessOwners = function (req, res) {
    var fields = {
        
    };
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
        if (err) {
             res.jsonp(err);
        }else {
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
            }

            var conditions = {
                $or: [ 
                        { 
                            $and: [
                                { role: 'b_owner'}, 
                                {isDeleted: false} ,
                                {_id: { $in: arr}}
                            ]
                        },
                        {
                            $and: [ 
                                { role: 'b_owner'}, 
                                {isDeleted: false} ,
                                {visibility:true}
                            ]
                        }
                    ]
            };

            /*var conditions = {
                $and: [ { role: 'b_owner'}, 
                        {isDeleted: false} ,
                        {_id: { $in: arr}}
                    ]
            };*/
            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);
                
            usersObj.find(conditions, fields).populate('business.category').skip(skipVal).limit(parseInt(req.body.limit)).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    res.jsonp({status: 200, msg: "get all users.", data: data});
                }
            });
        }
    });
};

/*________________________________________________________________________
 * @Date:       02 Feb,2017
 * @Method :    countStaff
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to get count of all sales owners.
 _________________________________________________________________________
 */

var countStaff = function (req, res) {
    var fields = {
        
    };
    var conditions = {
        $and: [ { role: 's_owner'}, 
                {isDeleted: false},
                {addedBy:  req.body.addedBy}
            ]
    };
    usersObj.find(conditions, fields).count().exec(function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get owners count.", data: data});
        }
    });
};

/*________________________________________________________________________
 * @Date:       03 Feb,2017
 * @Method :    updateMembership
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to update a user membership plan.
 _________________________________________________________________________
 */

var updateMembership = function (req, res) {
    console.log("Membership",req.body);
    var fields = {
        membershipDetails:{
            plan_name: req.body.plan_name,
            amount: req.body.amount,
            offers_limit: req.body.offers_limit,
            refferer_limit: req.body.refferer_limit,
            duration: req.body.duration
        }
    };
    
    var conditions = {
        _id: req.body._id
    };
    
    usersObj.update(conditions, {$set: fields}, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: 'updated successfully.', data: data});
        }
    });

};

/*________________________________________________________________________
 * @Date:       03 Feb,2017
 * @Method :    userDetails
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to view a user.
 _________________________________________________________________________
 */

var userDetails = function (req, res) {

    var fields = {
    };
    var conditions = {
        _id: req.body._id
    };

    usersObj.findOne(conditions, fields, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: "get user info successfully.", data: data});
        }
    });
};

/*________________________________________________________________________
 * @Date:       03 Feb,2017
 * @Method :    businessOwnersByLatest
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to view all business owners by latest.
 _________________________________________________________________________
 */

var businessOwnersByLatest = function (req, res) {

    var fields = {
    };
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
        if (err) {
             res.jsonp(err);
        }else{
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
            }
            /*var conditions = {
                $and: [ { role: 'b_owner'}, 
                        {isDeleted: false},
                        {_id: { $in: arr}}
                    ]
            };*/

            var conditions = {
                $or: [ 
                        { 
                            $and: [
                                { role: 'b_owner'}, 
                                {isDeleted: false} ,
                                {_id: { $in: arr}}
                            ]
                        },
                        {
                            $and: [ 
                                { role: 'b_owner'}, 
                                {isDeleted: false} ,
                                {visibility:true}
                            ]
                        }
                    ]
            };

            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);
            usersObj.find(conditions, fields).populate('business.category').skip(skipVal).limit(parseInt(req.body.limit)).sort({'updatedAt': -1}).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    res.jsonp({status: 200, msg: "get user info successfully.", data: data});
                }
            });
        }
    });
};

/*________________________________________________________________________
 * @Date:       20 Feb,2017
 * @Method :    businessOwnersViaCategory
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to view all business owners via category.
 _________________________________________________________________________
 */

var businessOwnersViaCategory = function (req, res) {
    var fields = {
    };
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
        if (err) {
             res.jsonp(err);
        }else{
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
            }
            var arr1 =[];
                category = req.body.category.split(",");
               

                for(var i=0;i< category.length;i++)
                {
                    arr1.push(category[i]);
                }
                
            var conditions = {
                $or: [ 
                        { 
                            $and: [
                                { role: 'b_owner'}, 
                                {isDeleted: false} ,
                                {_id: { $in: arr}},
                                {"business.category_name": { $in: arr1}}
                            ]
                        },
                        {
                            $and: [ 
                                { role: 'b_owner'}, 
                                {isDeleted: false} ,
                                {visibility:true},
                                {"business.category_name": { $in: arr1}}
                            ]
                        }
                    ]
            };   
            /*var conditions = {
                $and: [ { role: 'b_owner'}, 
                        {isDeleted: false},
                        {"business.category_name": { $in: arr1}},
                        {_id: { $in: arr}}
                    ]
            };*/
            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);
            var sort = {};
            if(parseInt(req.body.isLatest) == 1){
                sort.updatedAt = -1;
            } else{
                 sort.updatedAt = 1;
            }
            usersObj.find(conditions, fields).populate('business.category').skip(skipVal).limit(parseInt(req.body.limit)).sort(sort).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    res.jsonp({status: 200, msg: "get user info successfully.", data: data});
                }
            });
        }
    });
};

/*________________________________________________________________________
 * @Date:       20 Jan,2017
 * @Method :    searchBusinessOwner
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to search business owner info.
 _________________________________________________________________________
 */

var searchBusinessOwner = function (req, res) {
    var fields = {
        
    };
    usersObj.findOne({_id: req.body.userId},{approvalDetails: 1}, function (err, data) {
       if (err) {
            res.jsonp(err);
        }else{
            var arr =[];
            for(var i=0;i< data.approvalDetails.length;i++)
            {
                arr[i] = mongoose.Types.ObjectId(data.approvalDetails[i].approved_by);
            }

            var skipVal = (parseInt(req.body.pageNo)- 1)*(parseInt(req.body.limit));
            console.log(skipVal);
    
            console.log("Data to search: ",req.body.searchData);
//            var terms = req.body.searchData.split(' ');
//            var regexString = "";
//            for (var i = 0; i < terms.length; i++)
//            {
//                regexString += terms[i];
//                if (i < terms.length - 1) regexString += '|';
//            }
//
//            var searchName = new RegExp(regexString, 'ig');
            var searchName = new RegExp(req.body.searchData , 'i');
            var arr1 =[];
              if(req.body.category.length){
                    var category = req.body.category.split(",");
                    if(category.length){
                        for(var i=0;i< category.length;i++)
                        {
                            arr1.push(category[i]);
                        }

                        var conditions = {
                        $and: [
                                { 
                                    $or: [
                                       {"address.address": searchName},
                                       {"business.category_name": searchName},
                                       {"business.name": searchName},
                    //               {"personalInfo.name": new RegExp('/'+req.body.searchData+'$/', "i")}
                                    ]
                                },
                                {
                                      $or: [ 
                                        { 
                                            $and: [
                                                    {_id: { $in: arr}},
                                                    {"business.category_name": { $in: arr1}},
                                                    {isDeleted: false}
                                            ]
                                        },
                                        {
                                            $and: [ 
                                                    { role: 'b_owner'}, 
                                                    {isDeleted: false} ,
                                                    {visibility:true},
                                                    {"business.category_name": { $in: arr1}}
                                            ]
                                        }
                                    ]  

                                }
                        ]


                            
                        }; 


                        /*var conditions = {
                            $and : [
                                { 
                                 $or: [
//                                       {"empId": new RegExp('^'+req.body.searchData+'$', "i")}, 
                                       {"address.address": searchName},
                                       {"business.category_name": searchName},
                                       {"business.name": searchName},
//                                      
                                    ]
                                },
                                {_id: { $in: arr}},
                                {"business.category_name": { $in: arr1}},
                                {isDeleted: false}
                            ]
                        };*/
                    }
                } else{
                   
                    var conditions = {
                        $and: [
                                { 
                                    $or: [
                                       {"empId": new RegExp('^'+req.body.searchData+'$', "i")}, 
                                       {"address.address": searchName},
                                       {"business.category_name": searchName},
                                       {"business.name": searchName}
                    //               {"personalInfo.name": new RegExp('/'+req.body.searchData+'$/', "i")}
                                    ]
                                },
                                {
                                      $or: [ 
                                        { 
                                            $and: [
                                                    { role: 'b_owner'}, 
                                                    {_id: { $in: arr}},
                                                    {isDeleted: false}
                                            ]
                                        },
                                        {
                                            $and: [ 
                                                    { role: 'b_owner'}, 
                                                    {isDeleted: false} ,
                                                    {visibility:true}
                                            ]
                                        }
                                    ]  

                                }
                        ]


                            
                        };  

                   /* var conditions = {
                            $and : [
                                { 
                                 $or: [{"empId": new RegExp('^'+req.body.searchData+'$', "i")}, 
                                       {"address.address": searchName},
                                       {"business.category_name": searchName},
                                       {"business.name": searchName}
                        //               {"personalInfo.name": new RegExp('/'+req.body.searchData+'$/', "i")}
                                    ]
                                },
                                {_id: { $in: arr}},
                                {isDeleted: false}
                            ]
                        }; */
                    
                }
         
            
            var sort = {};
            if(parseInt(req.body.isLatest) == 1){
                sort.updatedAt = -1;
            } else{
                 sort.updatedAt = 1;
            }
            usersObj.find(conditions, fields).populate('business.category').skip(skipVal).limit(parseInt(req.body.limit)).sort(sort).exec(function (err, data) {
                if (err) {
                    res.jsonp(err);
                } else {
                    if(data){
                        for(var i=0;i< data.length;i++)
                        {
                            var a= moment(data[i].endDate).format('DD MMM,YYYY');
                            var b= moment(data[i].startDate).format('DD MMM,YYYY');
                            data[i].endDate = a;
                            data[i].startDate = b;
                        }
                        res.jsonp({status: 200, msg: "get all users.", data: data});
                    }
                }
            });
        }
    });
};


/*________________________________________________________________________
    * @Date:        20 Feb,2017
    * @Method :     logout
    * Created By:   arun sahani
    * Modified On:  -
    * @Purpose:     This function is used to destroy the session of user.
_________________________________________________________________________
*/

var logout = function (req, res) {
    delete req.headers.authorization; 
    req.logout();
    res.jsonp({status: 200,msg: "logout successfully."});
};


/*________________________________________________________________________
 * @Date:       03 Jan,2017
 * @Method :    contact
 * Created By:  arun sahani
 * Modified On: -
 * @Purpose:    This function is used to contact.
 _________________________________________________________________________
 */
var contact = function (req, res) {
      var mailOptions = {
            from: req.body.email,
            to: constantObj.contact.useremail,
            subject: req.body.subject,
            html: 'Name: '+ req.body.name +'<br><br>' +
                            'Message: '+ req.body.message
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                return console.log(error);
            }
            console.log('Message sent: ' + info.response);
            res.jsonp({status: 200,msg: "Email sent successfully."});
        });

        
};


var registerCard = function (req, res) {
    console.log(req.body);
    stripe.customers.create({
            email: req.body.email
        }).then(function(customer){
          return stripe.customers.createSource(customer.id, {
            source: {
               object: 'card',
               exp_month: req.body.month,
               exp_year: req.body.year,
               number: req.body.card_number,
               cvc: req.body.cvc
            }
          });
        }).then(function(source) {
          console.log("data",source);
          res.jsonp({status: 200,msg: "Card register successfully", data: source.customer});  
        }).catch(function(err) {
          console.log(err);
          res.jsonp({status: 201,msg: "Card register successfully", data: err});
        });
};


var updateVisibility = function (req, res) {
    
    var fields = {
        visibility: req.body.visibility
    };
    
    var conditions = {
        _id: req.body._id
    };
    
    usersObj.update(conditions, {$set: fields}, function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
        }
    });

};


var updatePushStatus = function (req, res) {
    
    var fields = {
        pushStatus: req.body.pushStatus
    };
    
    var conditions = {
        _id: req.body.id
    };
    
    usersObj.update(conditions, {$set: fields}, function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
        }
    });

};

function membershipCron() {
   
    Promise.resolve().then(function() {
        return usersObj.find({'membershipDetails.account_type':  "free",'role':"b_owner",'isDeleted':false,'membership_type':'activated'});
    }).then(function(allUsers) {
       //console.log("step 1",allUsers);
       if(allUsers)
       {
            for(var i=0;i< allUsers.length;i++)
                {
                    var format_created_date = moment(allUsers[i].createdDate).format('YYYY-MM-DD');
                    var format_today = moment().format('YYYY-MM-DD');

                    var created = moment(format_created_date);
                    var today = moment(format_today);

                    var diff =  today.diff(created, 'days');

                    if(diff >= 30 && allUsers[i].membershipDetails.amount)
                    {
                        //console.log(allUsers[i].membershipDetails.plan_id);

                        stripe.charges.create({ 
                            amount: allUsers[i].membershipDetails.amount * 100,
                            currency: 'usd',
                            customer: allUsers[i].membershipDetails.stripe_customer_id 
                          })
                          .then(function(charge) {
                               
                                usersObj.findOne({'membershipDetails.stripe_customer_id' : charge.customer}, function (err, user) {
                                 //console.log(user);
                                /*if(user.membershipDetails.plan_id=='1')
                                    {
                                       console.log("1");
                                       var sowner_limit =  1;
                                       var offers_limit =  5;
                                       var refferer_limit =  50;

                                    }else if(user.membershipDetails.plan_id=='2'){
                                        console.log("2");
                                        var sowner_limit =  2;
                                        var offers_limit =  10;
                                        var refferer_limit = 100;

                                    }else if(user.membershipDetails.plan_id=='3'){
                                        console.log("3");
                                        var sowner_limit =  5;
                                        var offers_limit =  0;
                                        var refferer_limit = 0;

                                    } */

                                    if(user.membershipDetails.plan_type=="monthly")
                                    {
                                       var expiry_date = moment().add(1, 'months').format('YYYY-MM-DD');    
                                    
                                    }else if(user.membershipDetails.plan_type=="yearly")
                                    {
                                       var expiry_date = moment().add(12, 'months').format('YYYY-MM-DD');
                                    }

                                    var fields = {
                                        membershipDetails:{
                                            plan_id: user.membershipDetails.plan_id,
                                            plan_name: user.membershipDetails.plan_name,
                                            plan_type: user.membershipDetails.plan_type,
                                            account_type: "paid",
                                            stripe_customer_id: user.membershipDetails.stripe_customer_id,
                                            stripe_payment_id: charge.id,
                                            amount: user.membershipDetails.amount,
                                            expiry_date: expiry_date
                                        },
                                        membership_type: "activated",
                                        membership_renewed:"yes"
                                    };
                                    
                                    var conditions = {
                                        _id: user._id
                                    };
                                    
                                    usersObj.update(conditions, {$set: fields}, function (err, data) {
                                        if (err) {
                                            console.log(err);
                                        } else {
                                            console.log("success",data);
                                        }
                                    });
                                });  
                         }).catch(function(err) {
                              console.log(err);
                         });
                    }

                    
                }
        }
    })

};



function membershipSubscriptionCron() {
   
    Promise.resolve().then(function() {
        return usersObj.find({'membershipDetails.account_type': "paid",'role':"b_owner",'isDeleted':false,'membership_type':'activated'});
    }).then(function(allUsers) {
       //console.log("step 1",allUsers);
       if(allUsers)
       {
            for(var i=0;i< allUsers.length;i++)
                {
                    var format_account_expiry = moment(allUsers[i].membershipDetails.expiry_date).format('YYYY-MM-DD');
                    var format_today = moment().format('YYYY-MM-DD');

                    var expiry_date = moment(format_account_expiry);
                    var today = moment(format_today);

                    var diff =  expiry_date.diff(today, 'days');

                    if(diff <= 0 && allUsers[i].membershipDetails.amount)
                    {
                        //console.log(allUsers[i].membershipDetails.plan_id);

                        stripe.charges.create({ 
                            amount: allUsers[i].membershipDetails.amount * 100,
                            currency: 'usd',
                            customer: allUsers[i].membershipDetails.stripe_customer_id 
                          })
                          .then(function(charge) {
                                console.log(charge);
                                usersObj.findOne({'membershipDetails.stripe_customer_id' : charge.customer}, function (err, user) {
                                    
                                   memberShipObj.findOne({'_id' : mongoose.Types.ObjectId(user.membershipDetails.plan_id)}, function (err, membershipDb) { 
                                    
                                        if(user.membershipDetails.refill_date==today){

                                            var sowner_limit =   parseInt(membershipDb.sowner_limit);
                                            var offers_limit =   parseInt(membershipDb.offers_limit);
                                            var refferer_limit = parseInt(membershipDb.refferer_limit);

                                           var rifill_date =  moment().add(12, 'months').format('YYYY-MM-DD');
                                        }else{

                                            var sowner_limit =   user.membershipDetails.sowner_limit;
                                            var offers_limit =   user.membershipDetails.offers_limit;
                                            var refferer_limit =   user.membershipDetails.refferer_limit;
                                            var rifill_date =     user.membershipDetails.refill_date;
                                        }

                                        if(user.membershipDetails.plan_type=="monthly")
                                        {
                                           var expiry_date = moment(user.membershipDetails.expiry_date).add(1, 'months').format('YYYY-MM-DD');    
                                        }
                                        else if(user.membershipDetails.plan_type=="yearly")
                                        {
                                           var expiry_date = moment(user.membershipDetails.expiry_date).add(12, 'months').format('YYYY-MM-DD');
                                        }

                                       
                                    var fields = {
                                        membershipDetails:{
                                            plan_id: user.membershipDetails.plan_id,
                                            plan_name: user.membershipDetails.plan_name,
                                            plan_type: user.membershipDetails.plan_type,
                                            account_type: "paid",
                                            stripe_customer_id: user.membershipDetails.stripe_customer_id,
                                            stripe_payment_id: charge.id,
                                            amount: user.membershipDetails.amount,
                                            sowner_limit: sowner_limit,
                                            offers_limit: offers_limit,
                                            refferer_limit: refferer_limit,
                                            expiry_date: expiry_date,
                                            refill_date: rifill_date
                                        },
                                        membership_type: "activated",
                                        membership_renewed:"yes"
                                    };
                                    
                                    var conditions = {
                                        _id: user._id
                                    };
                                    
                                    usersObj.update(conditions, {$set: fields}, function (err, data) {
                                        if (err) {
                                            console.log(err);
                                        } else {
                                            console.log("success",data);
                                        }
                                    });
                                 });
                               });    
                         }).catch(function(err) {
                              console.log(err);
                            });
                    }

                    
                }
        }
    });

};


var viewMembership = function (req, res) {

    var fields = {
    };
    var conditions = {
        _id: req.body._id
    };

    usersObj.findOne(conditions, fields, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            if(!data.membershipDetails.expiry_date){
             data.membershipDetails.expiry_date = moment(data.createdDate).add(30, 'days').format('YYYY-MM-DD'); ;    
            }
            res.jsonp({status: 200, msg: "get user info successfully.", data: data});
        }
    });
};

var updateMembership = function (req, res) {

    console.log(req.body.membership);    
    
    var fields = {
        membershipDetails: req.body.membership,
        membership_renewed:"no"
    };
    
    var conditions = {
        _id: req.body.id
    };
    
    usersObj.findOne({'_id' : req.body.id}, function (err, user) { 

        var currentMemberShip = user.membershipDetails.plan_name;
        var selectedMemberShip = req.body.membership.plan_name;


        if(user.membershipDetails.plan_id == req.body.membership.plan_id){
            res.jsonp({status: 206, msg: 'same plan error'});
        }else{

            if(currentMemberShip=="Premium" && selectedMemberShip=="Pro")
            {
                if(user.membershipDetails.sowner_limit<=2)
                {
                    usersObj.update(conditions, {$set: fields}, function (err, staff) {
                        if (err) {
                            res.jsonp(err);
                        } else {
                            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                        }
                    });
                }else{
                    res.jsonp({status: 205, msg: 'downgrade error'});
                }
            }
            else if(currentMemberShip=="Premium" && selectedMemberShip=="Basic")
            {
                if(user.membershipDetails.sowner_limit<=1)
                {
                    usersObj.update(conditions, {$set: fields}, function (err, staff) {
                        if (err) {
                            res.jsonp(err);
                        } else {
                            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                        }
                    });
                }else{
                    res.jsonp({status: 205, msg: 'downgrade error'});
                }
            }
            else if(currentMemberShip=="Pro" && selectedMemberShip=="Basic")
            {
                if(user.membershipDetails.sowner_limit<=1 && user.membershipDetails.offers_limit<=5 && user.membershipDetails.refferer_limit<=50 )
                {
                    usersObj.update(conditions, {$set: fields}, function (err, staff) {
                        if (err) {
                            res.jsonp(err);
                        } else {
                            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                        }
                    });
                }else{
                    res.jsonp({status: 205, msg: 'downgrade error'});
                }
            }else{

                usersObj.update(conditions, {$set: fields}, function (err, staff) {
                    if (err) {
                        res.jsonp(err);
                    } else {
                        res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
                    }
                });

            }
        }



       /* usersObj.update(conditions, {$set: fields}, function (err, staff) {
            if (err) {
                res.jsonp(err);
            } else {
                res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
            }
        }); */
    });

};


var renewMembership = function (req, res) {
    
    var conditions = {
        _id: mongoose.Types.ObjectId(req.body.id)
    };
    
    Promise.resolve().then(function() {
        return usersObj.findOne(conditions);
    }).then(function(userDetails) {

        stripe.charges.create({ 
            amount: userDetails.membershipDetails.amount * 100,
            currency: 'usd',
            customer: userDetails.membershipDetails.stripe_customer_id 
          })
          .then(function(charge) {
                usersObj.findOne({'membershipDetails.stripe_customer_id' : charge.customer}, function (err, user) {
                    memberShipObj.findOne({'_id' : mongoose.Types.ObjectId(user.membershipDetails.plan_id)}, function (err, membershipDb) {
                        
                           if(user.membershipDetails.account_type=="free"){
                               var sowner_limit =  user.membershipDetails.sowner_limit;
                               var offers_limit =  user.membershipDetails.offers_limit;
                               var refferer_limit =  user.membershipDetails.refferer_limit;
                           }else{
                               var sowner_limit =  user.membershipDetails.sowner_limit + parseInt(membershipDb.sowner_limit);
                               var offers_limit =  user.membershipDetails.offers_limit + parseInt(membershipDb.offers_limit);
                               var refferer_limit =  user.membershipDetails.refferer_limit + parseInt(membershipDb.refferer_limit);
                           }

                            var refill_date = moment().add(12, 'months').format('YYYY-MM-DD');
                            
                            if(user.membershipDetails.plan_type=="monthly")
                            {
                               var expiry_date = moment().add(1, 'months').format('YYYY-MM-DD');    
                            }
                            else if(user.membershipDetails.plan_type=="yearly")
                            {
                               var expiry_date = moment().add(12, 'months').format('YYYY-MM-DD');
                            }
                            
                               
                            var fields = {
                                membershipDetails:{
                                    plan_id: user.membershipDetails.plan_id,
                                    plan_name: user.membershipDetails.plan_name,
                                    plan_type: user.membershipDetails.plan_type,
                                    account_type: "paid",
                                    stripe_customer_id: user.membershipDetails.stripe_customer_id,
                                    stripe_payment_id: charge.id,
                                    amount: user.membershipDetails.amount,
                                    sowner_limit: sowner_limit,
                                    offers_limit: offers_limit,
                                    refferer_limit: refferer_limit,
                                    expiry_date: expiry_date,
                                    refill_date:refill_date
                                },
                                membership_type: "activated",
                                membership_renewed:"yes"
                            };
                            
                            var conditions = {
                                _id: user._id
                            };
                            
                            usersObj.update(conditions, {$set: fields}, function (err, data) {
                                if (err) {
                                    console.log(err);
                                } else {
                                    console.log("success",data);
                                    res.jsonp({status: 200, msg: 'updated successfully.', data: fields});
                                }
                            });
                        });
               });   
         }).catch(function(err) {
              console.log(err);
              res.jsonp({status: 201, msg: 'updated successfully.', data: err});
    });

    });

};


var updateToken = function (req, res) {
    
    var fields = {
        deviceToken: req.body.deviceToken
    };
    
    var conditions = {
        _id: req.body.id
    };
    
    usersObj.update(conditions, {$set: fields}, function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
        }
    });

};


var cancelMembership = function (req, res) {
    
    var conditions = {
        _id:  req.body.id
    };

    var fields = {
        membership_type: "canceled",
        membership_cancel_date : moment().format('YYYY-MM-DD')
    };
    
    usersObj.update(conditions, {$set: fields}, function (err, staff) {
        if (err) {
            res.jsonp(err);
        } else {
            res.jsonp({status: 200, msg: 'updated successfully.', data: staff});
        }
    });

};


var getPlansAdmin = function (req, res) {
    
    
    var conditions = {
        duration: req.body.planType
    };
    
    memberShipObj.find(conditions).sort({'amount': 1}).exec( function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            console.log(data);
            res.jsonp({status: 200, msg: "get user info successfully.", data: data});
        }
    });

};

var getStaticData = function (req, res) {
    
    
    var conditions = {
        _id: mongoose.Types.ObjectId(req.body.id)
    };
    
    pagesObj.findOne(conditions, function (err, data) {
        if (err) {
            res.jsonp(err);
        } else {
            console.log(data);
            res.jsonp({status: 200, msg: "get pages info successfully.", data: data});
        }
    });

};




//  functions
exports.signUp = signUp;
exports.verifyEmail = verifyEmail;
exports.uploadProfilePic = uploadProfilePic;
exports.uploadProfileImage = uploadProfileImage;
exports.login = login;
exports.forgotPassword = forgotPassword;
exports.resetPassword = resetPassword;
exports.addStaff = addStaff;
exports.updateStaff = updateStaff;
exports.deleteStaff = deleteStaff;
exports.viewStaff = viewStaff;
exports.viewAllStaff = viewAllStaff;
exports.searchStaff = searchStaff;
exports.updateUser = updateUser;
exports.viewOwner = viewOwner;
exports.viewAllBusinessOwners = viewAllBusinessOwners;
exports.countStaff = countStaff;
exports.updateMembership = updateMembership;
exports.userDetails = userDetails;
exports.businessOwnersByLatest = businessOwnersByLatest;
exports.businessOwnersViaCategory = businessOwnersViaCategory;
exports.searchBusinessOwner = searchBusinessOwner;
exports.logout = logout;
exports.contact = contact;
exports.registerCard = registerCard;
exports.updateVisibility = updateVisibility;
//exports.membershipCron = membershipCron;
//exports.membershipSubscriptionCron = membershipSubscriptionCron;
exports.viewMembership = viewMembership;
exports.updateMembership = updateMembership;
exports.renewMembership = renewMembership;
exports.cancelMembership = cancelMembership;

exports.updateToken = updateToken;
exports.updatePushStatus = updatePushStatus;
exports.getPlansAdmin = getPlansAdmin;
exports.getStaticData = getStaticData;
exports.startNotificationCron = startNotificationCron;















