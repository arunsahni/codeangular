
module.exports = {
    'secret': 'referrerIsAwesome'
};
