//$(".chosen").chosen();
$("body").on("change",".selectpicker",function(){
    $("body").find(".selectpicker").selectpicker("refresh");
});

$("body").on("click",".btn-default",function(){
	$(".btn-default").removeClass('active');
	$(this).addClass('active');
});
