//$(".chosen").chosen();
$("body").on("change",".selectpicker",function(){
    $("body").find(".selectpicker").selectpicker("refresh");
});

$("body").on("click",".btn-default",function(){
	$(".btn-default").removeClass('active');
	$(this).addClass('active');
});

$("body").on("click",".dropdown-li",function(){
    $("body").find(".selectpicker").selectpicker("refresh");
});

$("body").find(".invest-btn").attr('disable',true);

$("#myModalpac").on("click",".btn-default",function(){
  $("body").find(".invest-btn").attr('disable',false);
});

$("input[type=radio]").prop('checked', false);