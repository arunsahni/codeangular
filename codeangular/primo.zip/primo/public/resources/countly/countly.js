/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
(function (angular) {

  angular.module('countlyWidget', [])
    .run([
      '$window',
      'countlyWidgetSettings',
      function ($window, countlyWidgetSettings) {
        if (!countlyWidgetSettings.app_key) {
          throw new Error('Missing app_key. Please set in app config via countlyWidgetProvider');
        }

        if (!countlyWidgetSettings.url) {
          throw new Error('Missing url. Please set in app config via countlyWidgetProvider');
        }

        var window = $window;
        //pasted from countly widget

        window.Countly   = window.Countly || {};
        window.Countly.q = window.Countly.q || [];

        //provide your app key that you retrieved from window.Countly dashboard
        window.Countly.app_key = countlyWidgetSettings.app_key;

        //provide your server IP or name. Use try.count.ly for EE trial server.
        //if you use your own server, make sure you have https enabled if you use
        //https below.
        window.Countly.url = countlyWidgetSettings.url;

        //start pushing function calls to queue
        //track sessions automatically
        window.Countly.q.push(['track_sessions']);

        //track sessions automatically
        window.Countly.q.push(['track_pageview']);

        //load countly script asynchronously
        (function () {
          var cly   = document.createElement('script');
          cly.type  = 'text/javascript';
          cly.async = true;
          //enter url of script here
          //cly.src    = 'https://cdn.jsdelivr.net/countly-sdk-web/latest/countly.min.js';
          cly.src    = 'resources/countly/countly.min.js';
          cly.onload = function () {
            window.Countly.init()
          };
          var s      = document.getElementsByTagName('script')[0];
          s.parentNode.insertBefore(cly, s);
        })();
      }
    ]);

})(angular);

(function (angular) {
  var
    settings = {
      url: '',
      app_key: '',
      beforePageLoad: angular.noop
    };

  angular.module('countlyWidget')
    .value('countlyWidgetSettings', settings)
    .provider('countlyWidget', [function () {
      this.init = function (opts) {
        angular.extend(settings, opts);
      };

      this.$get = [
        '$window',
        function ($window) {
          function countlyWidgetApi() {
          }

          angular.forEach(apiMethods, function (method) {
            countlyWidgetApi.prototype[method] = function () {
              $window.Countly[method].apply($window.Countly, arguments);
            };
          });

          return new countlyWidgetApi();
        }
      ];
    }]);

})(angular);
