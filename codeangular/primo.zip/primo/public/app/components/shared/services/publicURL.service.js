app.service('PublicURLService', function (PrimoService) {
  return {
    load: function () {
      return PrimoService.getPublicURLs().then(function (data) {
        return data;
      })
    }
  }
});