/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.service('PrimoService', function ($http, $rootScope, config, Base64, $httpParamSerializerJQLike,$window) {

  $http.defaults.headers.common['Authorization'] = 'Basic ' + Base64.encode(config.primo.username + ':' + config.primo.password);

  return {
    verifyUsername: function (user) {
      return $http({
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__VerifyUsername',
        data: $httpParamSerializerJQLike(user)
      });
    },
    getClientToken: function () {
      var user         = {};
      user.login_token = $rootScope.token;
      user.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/billingintl/3/primo/api/billingintl__ConveyCreditCardRegistration',
        data: $httpParamSerializerJQLike(user)
      });
    },
    login: function (user) {
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__LoginPinlessAccount',
        data: $httpParamSerializerJQLike(user)
      });
    },
    logout: function () {
      var user         = {};
      user.login_token = $rootScope.token;
      user.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__LogoutPinlessAccount',
        data: $httpParamSerializerJQLike(user)
      });
    },
    claimAccount: function (data, userId, token) {
      data.username    = userId;
      data.login_token = token;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__ClaimAccount',
        data: $httpParamSerializerJQLike(data)
      });
    },
    verifyMSISDN: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__VerifyMSISDN',
        data: $httpParamSerializerJQLike(data)
      });
    },
    getAccountInfo: function (user) {
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetPinlessAccountInfo',
        data: $httpParamSerializerJQLike(user)
      });
    },
    setSelectedBoltsOnPlans : function(planName, selectValuePlan) {
        return {planName: planName, selectValuePlan: selectValuePlan};
    },
    getServiceProductsCountry: function(promo) {
      var data = {
        preferred_language: 'en',
        group: 'COUNTRY'
      };
      if (promo)
        data.promo = promo;
      if ($rootScope.token) data.login_token = $rootScope.token;
      if ($rootScope.userId) data.username = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetServiceProducts',
        data: $httpParamSerializerJQLike(data)
      })
    },
    setAccountInfo: function (user) {
      user.login_token = $rootScope.token;
      user.username    = $rootScope.userId;
      delete user.partner;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__SetPinlessAccountFields',
        data: $httpParamSerializerJQLike(user)
      });
    },
    loadCountries: function () {
      return $http({
        method: 'POST',
        url: '/countries',
        data: {}
      });
    },
    searchUsers: function (user) {
      user.login_token = $rootScope.token;
      user.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/directoryintl/3/primo/api/directoryintl__SearchUserDirectory',
        data: $httpParamSerializerJQLike(user)
      });
    },
    retrievePublicInfo: function (user) {
      user.login_token = $rootScope.token;
      user.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: '/retrieve-public-info',
        data: $httpParamSerializerJQLike(user)
      });
    },
    getInternationalRates: function () {
      return $http({
        method: 'GET',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetInternationalRates'
      })
    },
    getSIPBalanace: function () {
      var user         = {};
      user.login_token = $rootScope.token;
      user.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetTSIPBalance',
        data: $httpParamSerializerJQLike(user)
      })
    },
    getBillingHistory: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetBillingHistory',
        data: $httpParamSerializerJQLike(data)
      })
    },
    getCallHistory: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetCallHistory',
        data: $httpParamSerializerJQLike(data)
      })
    },
    retrieveContactInfo: function (contact) {
      contact.login_token = $rootScope.token;
      contact.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/abintl/3/primo/api/abintl__RetrieveContactInfo',
        data: $httpParamSerializerJQLike(contact)
      });
    },
    changePassword: function (contact) {
      contact.login_token = $rootScope.token;
      contact.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__ChangePinlessAccountPassword',
        data: $httpParamSerializerJQLike(contact)
      });
    },
    attachUserDid: function (contact) {
      contact.login_token = $rootScope.token;
      contact.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__AttachUserDID',
        data: $httpParamSerializerJQLike(contact)
      });
    },
    getRewardTriggers: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/referral/3/primo/api/referral__GetRewardTriggers',
        data: $httpParamSerializerJQLike(data)
      });
    },
    getRewardDetails: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetRewardDetails',
        data: $httpParamSerializerJQLike(data)
      });
    },
    getProfilePicture: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetProfileImage',
        data: $httpParamSerializerJQLike(data)
      });
    },
    setProfilePicture: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__SetProfileImage',
        data: $httpParamSerializerJQLike(data)
      });
    },
    inviteFriends: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/referral/3/primo/api/referral__InviteEmail',
        data: $httpParamSerializerJQLike(data)
      });
    },
    getWorldLocation: function (text) {
      return $http({
        method: 'GET',
        url: '/world-location/' + text
      });
    },
    addToFriends: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      data.contact     = JSON.stringify(data.contact);

      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/abintl/3/primo/api/abintl__AddAddressBookContact',
        data: $httpParamSerializerJQLike(data)
      });
    },
    removeFromFriends: function (data) {
      var dataToSend = {
        login_token: $rootScope.token,
        un: data.un,
        username: $rootScope.userId
      };
      if (data.profile_image_base64) delete data.profile_image_base64; //prevent sending profile image over the network
      if (data.contact && data.contact.profile_image_base64) delete data.contact.profile_image_base64; //prevent sending profile image over the network
      data.contact = JSON.stringify(data.contact);

      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/abintl/3/primo/api/abintl__RemoveAddressBookContact',
        data: $httpParamSerializerJQLike(dataToSend)
      });
    },
    charge: function (params) {
      params.login_token = $rootScope.token;
      params.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/billingintl/3/primo/api/billingintl__ProcessBraintreePayment',
        data: $httpParamSerializerJQLike(params)
      })
    },
    chargePayment: function (params) {
      params.login_token = $rootScope.token;
      params.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/billingintl/3/primo/api/billingintl__ChargePaymentCreditCard',
        data: $httpParamSerializerJQLike(params)
      })
    },
    chargeRatePlan: function (params) {
      params.login_token = $rootScope.token;
      params.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/billingintl/3/primo/api/billingintl__ChargePaymentCreditCard',
        data: $httpParamSerializerJQLike(params)
      })
    },
    addEasyDialEntry: function (params) {
      params.login_token = $rootScope.token;
      params.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__AddStaticAutodialer',
        data: $httpParamSerializerJQLike(params)
      })
    },
    getEasyDialEntries: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetStaticAutodialer',
        data: $httpParamSerializerJQLike(data)
      });
    },
    deleteEasyDialEntry: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__RemoveStaticAutodialer',
        data: $httpParamSerializerJQLike(data)
      });
    },
    updateEasyDialEntry: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__UpdateStaticAutodialer',
        data: $httpParamSerializerJQLike(data)
      });
    },
    sendSMS: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/messageintl__SendOutboundSMS',
        data: $httpParamSerializerJQLike(data)
      });
    },

    getServiceProducts: function (group,country) {

      if($window.localStorage.selectedCoutry == undefined){

        if($window.localStorage.selectedCoutry){
          var selectedCoutry = JSON.parse($window.localStorage.selectedCoutry);  
          var chosedCountry = selectedCoutry.code;  
        }
        

      }else{

        var chosedCountry = "us";  
      }
      
      // var country = JSON.parse(localStorage.getItem('user')).msisdn_country_code || 'us';
      var data = {
        preferred_language: 'en',
        group: group ? group : 'ALL',
        user_country_code : country ? country : chosedCountry
      }

      // var data = {
      //   preferred_language: 'en',
      //   group: group ? group : 'RATE_PLANS',
      //   user_country_code : country ? country : 'IN'
      // }

      if ($rootScope.token) data.login_token = $rootScope.token;
      if ($rootScope.userId) data.username = $rootScope.userId;
      
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetServiceProducts',
        data: $httpParamSerializerJQLike(data)

      })
    },
    getServicesForDestination: function (group) {
      var data = {
        preferred_language: 'en',
        group: group ? group : 'ALL',
      }
      if ($rootScope.token) data.login_token = $rootScope.token;
      if ($rootScope.userId) data.username = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetServiceProducts',
        data: $httpParamSerializerJQLike(data)
      })
    },
    getCreditProducts: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'GET',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetGoogleProductIDs'
      })
    },
    getRatePlans: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'GET',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetRatePlans',
        data: data,
        cache: true
      })
    },
    getServicePlans: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: '/get-service-plans',
        data: data,
        cache: true
      })
    },
    getPublicURLs: function (data) {
      return $http({
        method: 'GET',
        url: config.primo.host + '/pr/publicintl/3/primo/api/publicintl__GetPublicURLs'
      })
    },
    resetPassword: function (data) {
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__ResetPinlessAccountPassword',
        data: $httpParamSerializerJQLike(data)
      })
    },
    submitDealerApplication: function (data) {
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/dealer/3/primo/api/dealer__SubmitApplication',
        data: $httpParamSerializerJQLike(data)
      })
    },
    recoverUsername: function (data) {
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__RecoverUsername',
        data: $httpParamSerializerJQLike(data)
      })
    },
    deactivateAccount: function (data) {
      data.login_token = $rootScope.token;
      data.username    = $rootScope.userId;
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__DeletePinlessAccount',
        data: $httpParamSerializerJQLike(data)
      })
    },
    getFAQ: function () {
      return $http({
        method: 'GET',
        url: '/list-faq'
      })
    },
    getTicketList: function () {
      return $http({
        method: 'GET',
        url: '/list-tickets/' + $rootScope.userId
      })
    },
    createTicket: function (data) {
      return $http({
        method: 'POST',
        url: '/create-ticket',
        data: data
      })
    },
    getPartnerToken: function (data) {
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetPartnerToken',
        data: $httpParamSerializerJQLike(data)
      });
    },
    checkProductAvailability:function(data){
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__CheckProductAvailability',
        data: $httpParamSerializerJQLike(data)
      });
    },
    getFacebookUserId: function(access_token){
      return $http({
        method: 'GET',
        url: 'https://graph.facebook.com/me?access_token='+access_token,
      })
    },
    getGoogleUserId: function(access_token){
        return $http({
            method: 'GET',
            url: 'https://graph.facebook.com/me?access_token='+access_token,
        })
    },
    socialLogin: function(data){
      return $http({
        method: 'POST',
        url: config.primo.host + '/pr/manageintl/3/primo/api/manageintl__CreateAndLoginSocialAccount',
        data: $httpParamSerializerJQLike(data)
      });
    }
  }
});