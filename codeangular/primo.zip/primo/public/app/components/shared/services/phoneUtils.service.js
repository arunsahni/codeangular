app.service('phoneUtils', function ($window) {
  return $window.phoneUtils;
});