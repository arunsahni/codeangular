app.service('InternationalRatesService', function (PrimoService, $window, $q) {
  return {
    /**
     * Calls primo service to load international rates
     * If rates are loaded in last hour return data from localStorage
     * @returns {*}
     */
    init: function () {

      var deferred = $q.defer();
      //if value is cached more than one hour it will be refreshed
      if (!$window.localStorage.dateRefreshed || (Date.now() - $window.localStorage.dateRefreshed > 3600 * 1000)) {
        return PrimoService.getInternationalRates().then(function (data) {
          //move all south africa rates under north america
          angular.forEach(data.data.international_rates, function (val, key) {
            if (val.region_code == 'sa') {
              val.region_code = 'na';
            }
          });

          $window.localStorage.rates         = JSON.stringify(data.data.international_rates);
          $window.localStorage.dateRefreshed = Date.now();

          deferred.resolve(data.international_rates);
        });
      } else {
        deferred.resolve(JSON.parse($window.localStorage.rates));
      }

      return deferred.promise;
    },
    /**
     * Returns a complete list of rates
     * @returns {Array}
     */
    getRates: function () {
      return ($window.localStorage.rates) ? JSON.parse($window.localStorage.rates) : [];
    },
    /**
     * Get rates for particular country
     * @param code
     * @returns {Array}
     */
    getRatesByCountryCode: function (code) {
      var retVal = {};
      if ($window.localStorage.rates) {
        var rates = JSON.parse($window.localStorage.rates);

        angular.forEach(rates, function (val, key) {
          if (rates[key].country_code == code) {
            retVal = rates[key];
          }
        });
      }

      return retVal;
    },
    getCountryByName: function (name) {
      var retVal = {};
      if ($window.localStorage.rates) {
        var rates = JSON.parse($window.localStorage.rates);

        retVal = rates.filter(function (rate) {
          if (rate) {
            return (rate.country.substring(0, name.length).toLowerCase() === name.toLowerCase());
          }
        });
      }

      return retVal;
    }
  }
});