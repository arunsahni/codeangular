app.constant('socialKeys', [
    {
        facebookDevCredentials: {
            "appId" : "820962658076707",
            "appSecret": "fece33a2b24be5f82f22a6ddf351b1c2",
            "responseType":"token"
        },
        facebookQaCredentials: {
            "appId" : "820962658076707",
            "appSecret": "fece33a2b24be5f82f22a6ddf351b1c2",
            "responseType":"token"
        },
        facebookProdCredentials: {
            "appId" : "820962658076707",
            "appSecret": "fece33a2b24be5f82f22a6ddf351b1c2",
            "responseType":"token"
        },
        googleDevCredentials: {
            "clientId" : "357812345587-k2jgk07hpds4mllulkl2tggdtn16oka1.apps.googleusercontent.com",
            "clientsecret" :  "qcJ40-_QL0OBqTn8tQIiAhn0"
        },
        googleQaCredentials: {
            "clientId" : "357812345587-k2jgk07hpds4mllulkl2tggdtn16oka1.apps.googleusercontent.com",
            "clientsecret" :  "qcJ40-_QL0OBqTn8tQIiAhn0"
        },
        googleProdCredentials: {
            "clientId" : "357812345587-k2jgk07hpds4mllulkl2tggdtn16oka1.apps.googleusercontent.com",
            "clientsecret" :  "qcJ40-_QL0OBqTn8tQIiAhn0"
        }
    }
]);
