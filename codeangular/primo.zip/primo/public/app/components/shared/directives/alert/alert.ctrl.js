/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

/**
 *
 * Displays alert message on top right corner. It is used to display errors and success messages
 *
 */
app.directive('alerts', function ($timeout, $filter) {
  return {
    restrict: 'E',
    replace: true,
    templateUrl: "partials/alert-template.html",
    controller: function ($scope) {

      $scope.isVisible = false;
      $scope.message   = '';

      $scope.$watch('alert', function (val) {
        if (val == undefined || val.context == undefined || val.context.msg == undefined) return;

        $scope.isVisible = true;
        $scope.message   = $filter('formatAlert')(val.context.msg);

        $scope.color = val.context.type || 'success';

        //fadeout
        $timeout(function () {
          $scope.isVisible = false;
        }, 3000);

      });
    }
  }
});