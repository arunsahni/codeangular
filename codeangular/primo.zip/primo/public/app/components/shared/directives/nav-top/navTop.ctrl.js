/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.directive('navTop', function () {
  return {
    transclude: true,
    restrict: "E",
    templateUrl: "partials/nav-top.html",
    controller: function ($scope, $rootScope, SessionService, AuthService,
     $state, UiService, $filter,AuthService, PrimoService, $timeout) {

      $scope.state    = $state;
      $scope.openMenu = function ($mdOpenMenu, ev) {
        originatorEv = ev;
        $mdOpenMenu(ev);
      };

    $scope.init = function(country){
      
      PrimoService.getServiceProducts('RATE_PLANS',country.toUpperCase()).then(function (response){
          if(response.status == 200){
            $scope.countries = response.data.groups[0].all_countries;
          }
      });

      $timeout( function(){
          var localCountry = localStorage.getItem('selectedCoutry');
          if(localCountry && localCountry !== "undefined") {
            $scope.countrySelectedValue = JSON.parse(localCountry); 
            $("#typeAheadId").css({backgroundImage:"url("+$scope.countrySelectedValue.flag+")"});
          }
      }, 2000);
    }

    $scope.redirectToHomeSection = function(val) {
      // event.preventdefault();
      $rootScope.stateToOpen = val;
      $state.go('/');
    }
      $scope.$watch('customSelected',function(newV,oldV){
        var selectedCoutry ='';
        if(newV){
          selectedCoutry = newV.code ? newV.code : oldV; 
        }
        else{
          selectedCoutry = $scope.user_country_code;
        }
      });  

      $rootScope.$on("countryChanges", function(evt,data){
          if(data)  $scope.countrySelectedValue = JSON.parse(data);
          else{
              $scope.countrySelectedValue = JSON.parse(localCountry);
              $("#typeAheadId").css({backgroundImage:"url("+$scope.countrySelectedValue.flag+")"});
           }
      });

      $scope.$watch('countrySelectedValue',function(newV,oldV){
          var selectedCoutry ='';
          if(newV){
            selectedCoutry = newV.code ? newV.code : oldV; 
          }
          else{
            selectedCoutry = $scope.user_country_code;  
          }
        
          if(selectedCoutry){
            selectedCoutry = selectedCoutry.code ?  selectedCoutry.code :  selectedCoutry ;

            $scope.init(selectedCoutry);
          }
          else{
            $scope.init('us');
          }
      },true);

      //on focus function 
     $scope.checkCountryAvaliable = function (selectedCoutry){
        
        localStorage.setItem('selectedCoutry', JSON.stringify(selectedCoutry));
        $("#typeAheadId").css({backgroundImage:"url("+selectedCoutry.flag+")"});
        $state.reload();
      };

      $scope.logOut = function () {
        SessionService.destroySession();
        localStorage.removeItem('selectedCoutry');
        localStorage.clear();
      };

      $scope.login = AuthService.login;
      $scope.init('us');
    },
    link: function (scope) {
      (function () {
        // Create mobile element
        var mobile       = document.createElement('div');
        mobile.className = 'nav-mobile';
        if(document.querySelector('.nav')){
          document.querySelector('.nav').appendChild(mobile);
        }

        // hasClass
        function hasClass(elem, className) {
          return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
        }

        // toggleClass
        function toggleClass(elem, className) {
          var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, ' ') + ' ';
          if (hasClass(elem, className)) {
            while (newClass.indexOf(' ' + className + ' ') >= 0) {
              newClass = newClass.replace(' ' + className + ' ', ' ');
            }
            elem.className = newClass.replace(/^\s+|\s+$/g, '');
          } else {
            elem.className += ' ' + className;
          }
        }
        // Mobile nav function
        var mobileNav     = document.querySelector('.nav-mobile');
        var toggle        = document.querySelector('.nav-list');
        if(mobileNav){
          mobileNav.onclick = function () {
            toggleClass(this, 'nav-mobile-open');
            toggleClass(toggle, 'nav-active');
          };
        }

        $('.nav-item a:not([ng-click])').click(function () {
          toggleClass(this, 'nav-mobile-open');
          toggleClass(toggle, 'nav-active');
        });
      })();
    }

     
    //test menu code
  }
});

