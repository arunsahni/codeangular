/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

/**
 *
 *  Directive used to add active class on navigation menu and profile submenu.
 *  Directive uses path from URL and matches to ui sref. If paths match adds active class to element.
 *
 **/
app.directive('activeLink', ['$location', function (location) {
  return {
    restrict: 'A',
    link: function (scope, element, attrs, controller) {
      var clazz = attrs.activeLink;
      var path  = attrs.href || attrs.ngHref;
      path      = path || "";
      path      = path.substr(1, path.length); //remove hashtag

      scope.location = location;
      scope.$watch('location.path()', function (newPath) {
        //match top level menu links ie. match account side nave when /account/list is selected
        var regex   = new RegExp('^/.*/');
        var subPath = newPath.match(regex); //remove hashtag
        //remove trailing / from path
        subPath = (subPath && subPath[0]) ? subPath[0].substr(0, subPath[0].length - 1) : "nosub";

        if (path === newPath || path == subPath) {
          element.addClass(clazz);
        } else {
          element.removeClass(clazz);
        }
      });
    }
  };
}]);