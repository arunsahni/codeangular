/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

app.controller('AddCreditController', function ($scope, $rootScope, PrimoService, SessionService,
                                                CountlyManager,
                                                $stateParams, $state, $filter, items) {

  CountlyManager.sendEventMessage('w: Usage Add Credit');

  $rootScope.clientTokenPath = '/get-client-token';

  $scope.buttonEnabled = true;
  //predefined set of credit items
  $scope.creditItems = items;

  //setup braintree dropin options
  $scope.dropinOptions = {

    /**
     * Intercept form submission when nonce is receiv_ed.
     * Collect nonce and invoke chargePayment with nonce and amount as parameters
     * @param payload
     */
    onPaymentMethodReceived: function (payload) {
      $scope.buttonEnabled = false;
      //call primo charge payment
      PrimoService.chargePayment({
          payment_method_nonce: payload.nonce,
          productID: $scope.selected.productID,
          amount: $scope.selected.value //TODO: check if this needs to be value*100?!
        })
        .success(function (data, status, headers) {
          //display alert message
          $scope.$root.alert   = {
            show: true,
            context: {type: 'success', msg: $filter('translate')('SUCCESSFULLY_ADDED_FUNDS')}
          };
          $scope.buttonEnabled = true;
          //update balance in session object
          var user = {
            balance: data.balance
          };
          SessionService.updateSession(user);
          // take him back to profile
          $scope.cancel();
        });
    }
  };

  $scope.selected = ($stateParams.plan) ? $scope.creditItems[$stateParams.plan] : $scope.creditItems[0];

  $scope.select = function (item) {
    $scope.selected = item;
  };

  $scope.isSelected = function (item) {
    return ($scope.selected.productID == item.productID );
  };

  $scope.cancel = function () {
    $state.go('profile');
  };
});