app.controller('PurchaseController', function(ServiceProductsService,
                                              $scope,
                                              $state,
                                              $stateParams,
                                              AuthService,
                                              UiService,
                                              $q,
                                              GAManager,
                                              config,
                                              $window,
                                              PrimoService,
                                              mParticleService,
                                              SessionService,
                                              _,
                                              $filter,
                                              $timeout,
                                              $cookies,
                                              $rootScope) {

  $("#myModalpac").modal("hide");
  $scope.promo        = $stateParams.promo ? $stateParams.promo : 'SUB_10';
  $scope.subscription = $stateParams.subscription;
  $scope.selectedAllProduct = "Select Plan";
  $scope.showingPurchaseButton = false;

  $scope.credit_group = [];
  $scope.data         = [];
  var country = '';
  
  if(window.localStorage.buydata){
    $scope.previousSelectedData = JSON.parse(window.localStorage.buydata);
    $window.localStorage.removeItem('buydata');
  }else{
    $scope.previousSelectedData = "";
  }
  
  $scope.rate_plans = [];
  $scope.init = function(){

    //Check payment Unsuccessfull is in localstorage If it is, showing error

    var payment_unsuccessfull = localStorage.getItem('payment_unsuccessfull');
    if(payment_unsuccessfull) {
      localStorage.removeItem('payment_unsuccessfull');
      $scope.paymentMessage = payment_unsuccessfull;
      $scope.statusType     = 'Error';
      $scope.successClass   = "danger";
      $("#myModalpac").modal("toggle");  
    }
    
          
    $scope.isLoadLocal = true;

    var localCountry = localStorage.getItem('selectedCoutry');

      if(localCountry && localCountry !== "undefined") {
        country = JSON.parse(localCountry).code; 
        $scope.customSelected = JSON.parse(localCountry);
      }
      else{
        country = country;
      }

      var localCountry = localStorage.getItem('sliderSelectedCoutry');
      if(localCountry && localCountry !== "undefined") {
        country = JSON.parse(localCountry).code; 
        $window.localStorage.removeItem('sliderSelectedCoutry');
      }
      
      country = country ? country :'us';

      PrimoService.getServiceProducts('RATE_PLANS_COUNTRY', country.toUpperCase()).then(function (response){

      if(response.status == 200) {
        $scope.isLoadLocal = false;
        var typeArray = [];
        $scope.productViaType = [];
        $scope.all_products = response.data.groups[0].user_country_plans;
        $scope.showingCountry = response.data.groups[0].all_countries[0];
        $scope.all_countries_product = response.data.groups[0].all_countries[0]['products'];

        if($scope.all_products != undefined){
            for (var i=0; i < $scope.all_products.length; i++) {
            if(!typeArray.length) {
              typeArray.push($scope.all_products[i].type);
            } else {
              //  
              if(typeArray.indexOf($scope.all_products[i].type) === -1) {
                typeArray.push($scope.all_products[i].type);
              }
            }
          }

          for(var j=0; j < typeArray.length; j++ ) {
            $scope.productViaType.push({type : typeArray[j], options : []});
          }

          $scope.preSelectedProduct = null;

          for (var k = 0; k < $scope.all_products.length; k++) { 
            for(var l = 0; l < $scope.productViaType.length; l++ ) {
              if($scope.productViaType[l].type == $scope.all_products[k].type) {
                $scope.productViaType[l].options.push($scope.all_products[k]);

                if($scope.all_products[k].product == $stateParams.new_product) {
                  $scope.preSelectedProduct = $scope.all_products[k];
                }

                if($scope.previousSelectedData){
                    if($scope.all_products[k].product == $scope.previousSelectedData.product) {
                      $scope.preSelectedProduct = $scope.all_products[k];
                    }                
                }

              }
            }
          }
        }else{
          $scope.selectedAllProduct = "No Plan found for selected country";
          $scope.productViaType = [];
        }

        //console.log('why this is not defined here: ' + $scope.selectedProduct);
        
        if ($scope.preSelectedProduct) {
          
          $scope.purchaseStep = 'ready';
          $scope.choosedCurrentProduct = $scope.preSelectedProduct;
          $scope.selectedAllProduct = $scope.preSelectedProduct.title;
          $scope.selected_credit_group_products = $scope.preSelectedProduct;
          $scope.data.credit_group  = $scope.selected_credit_group_products;

          angular.forEach($scope.all_countries_product,function(value,key){

            if(value.product == $scope.choosedCurrentProduct.product){
              $scope.selected_countries_product = value;
            }

          });

        }
        
        if($scope.data.credit_group == undefined){
          $scope.data.credit_group = $scope.productViaType;
          $scope.credit_group = $scope.productViaType;  
        }
        
      }
    });


    $scope.getPurchaseItemData();   
  };

  $scope.getPurchaseItemData = function(){
      // $scope.purchasedProducts = PrimoService.getSelectedBoltsOnPlans();

      /*Preset the data*/
      // var ratePlanProducts = JSON.parse(localStorage.getItem('buydata'));
      // if(ratePlanProducts){
      //   $scope.selectedAllProduct = ratePlanProducts.title;
      // }

      // var boltsProducts = JSON.parse(localStorage.getItem('butBoltOnProduct'));
      // if(boltsProducts){
      //   $scope.selectedAllProduct = boltsProducts.selectedProduct.title;
      // }
  }

  $scope.init();
  /**
   * Iterate throught country groups and populate rate plans where type is country
   */
  $scope.setRatePlans = function() {
    if ($scope.countryProducts.groups) {
      angular.forEach($scope.countryProducts.groups[0].countries, function(val, key) {
        angular.forEach(val.products, function(product, key) {
          if (product.type == 'COUNTRY') {
            product.flag = val.flag;
            $scope.rate_plans.push(product);
          }
        });
      });
    }

    if ($stateParams.rate_plan && $scope.data) {
      $scope.data.rate_plan = _.find($scope.rate_plans, {'product': $stateParams.rate_plan})
    }
  };

  if ($scope.promo) {
    ServiceProductsService.getServiceProductsForCountryWithPromoCode($scope.promo).then(function(data) {
      $scope.countryProducts = data;
      $scope.setRatePlans();
    });
  }

  //load service products
  ServiceProductsService.loadDidAndCreditProducts($scope.promo).then(function(data) {
    $scope.serviceProducts = data;

    angular.forEach($scope.serviceProducts.groups, function(val, key) {
      if (val.group == 'DID') {
        $scope.did_plans = val.products;
      }
      if (val.group == 'CREDIT') {
        $scope.credit_products = val.products;
      }
    });

    $scope.data = {
      credit: _.find($scope.credit_products, {'product': $stateParams.credit}),
      rate_plan: _.find($scope.rate_plans, {'product': $stateParams.rate_plan}),
      did_plan: _.find($scope.did_plans, {'product': $stateParams.did_plan})
    };
  });

  $scope.authStep              = 'login';
  $scope.purchaseStep          = 'ready';
  $scope.purchaseButtonEnabled = true;
  $scope.isLoadLocal           = true;
  $scope.isPaymentMethodReceived = false;

  $scope.cantLogin = function() {
    AuthService.forgotUsername();
  };

  /**
   * Call primo to check username
   */
  $scope.verifyUsername = function() {
    if($scope.user.username && $scope.user.password){
        $scope.isLoadLocal = true;
        PrimoService.verifyUsername({ username: $scope.user.username, language: 'en' })
            .success(function(data) {
                 if (data.success) {
                     $scope.user.username = data.username;
                     //enable password tab
                     $scope.isPasswordDisabled = false;
                     //$scope.isEpayUser = isEpayUser;
                     if ($scope.isRemember) {
                         $scope.rememberMe();
                     } else {
                         $scope.forgetUser();
                     }
                     //select password tab
                     AuthService.doLogin($scope.user).then(function(res){
                            $scope.invalidMsg = false;
                            var state = $rootScope.lastState || "profile";
                            $scope.isLoadLocal = false;
                            $state.go(state, $rootScope.stateParams);
                            $mdDialog.cancel();
                    
                    })
                    .catch(function(err){
                        $scope.isLoadLocal = false;
                        $scope.errorMsg = true;
                        $scope.invalidMsg = err.user_errors[0];
                    });
                 }

            })
            .error(function(err){
                $scope.isLoadLocal = false;
                $scope.errorMsg = true;
                $scope.invalidMsg = err.user_errors[0];
            });
        }else{

          if(!$scope.user.username){
            $scope.statusType = "Error";
            $scope.paymentMessage = "Username is required";
            $("#myModalpac").modal("toggle");
            return false;
          }

          if(!$scope.user.password){
            $scope.statusType = "Error";
            $scope.paymentMessage = "Password is required";
            $("#myModalpac").modal("toggle");
            return false;
          }

        }
  };

  $scope.resendVerificationCode = function() {
    // API not existing
  };
  /**
   * Add username to cookie
   */
  $scope.rememberMe = function() {
      $cookies.putObject('username', $scope.user.username);
  };

  /**
   * Remove username from cookie
   */
  $scope.forgetUser = function() {
      $cookies.remove('username');
  };  
  /**
   * Call Primo service login and get account info. Store to localStorage
   */
  $scope.login = function() {
    AuthService.doLogin($scope.user, {
      epay: function(data) {

        // remove "username" and "password" property from user object, as it will continue to registration
        $scope.user.username = null;
        $scope.user.password = null;

        $scope.claim = {
          alias: data.alias,
          token: data.login_token
        };

        $scope.authStep = 'register';

      },
      normal: function() {
        if ($scope.getTotalAmount()) {
          $scope.purchaseStep = 'final';
        }
      }
    })
  };

  $scope.resolve = function() {
    if ($scope.claim) {
      $scope.claimAccount();
    } else {
      $scope.register();
    }
  };

  $scope.register = function() {
    AuthService.doRegister($scope.user, {
      withMSISDN: function() {
        $scope.$root.alert = {
          show: true,
          context: {type: 'success', msg: $filter('translate')('SUCCESS_REGISTER')}
        };
        $scope.authStep    = 'verifyMSISDN';
      },
      withoutMSISDN: function() {
        $scope.authStep = false;
      }
    });
  };

  /**
   * Call Primo to Claim account
   * @returns {*}
   */
  $scope.claimAccount = function() {
    return AuthService.doClaimAccount($scope.claim.alias, $scope.claim.token, $scope.user, function() {
      if ($scope.getTotalAmount()) {
        $scope.purchaseStep = 'final';
      }
    })
  };

  /**
   * Call primo api to verify msisdn
   */
  $scope.verifyMSISDN = function() {
    PrimoService.verifyMSISDN($scope.user).success(function(data, status, headers) {
      $scope.$root.alert = {
        show: true,
        context: {type: 'success', msg: $filter('translate')('SUCCESS_VERIFIED')}
      };
    });
  };

  $scope.getTotalAmount = function() {
    var total = 0;

    if (!$scope.data) return;

    if ($scope.data.credit && _.some($scope.credit_products, {product: $scope.data.credit.product})) {
      if ($scope.data.credit.promotion)
        total += parseFloat($scope.data.credit.promotion);
      else
        total += parseFloat($scope.data.credit.rate);
    }

    if ($scope.data.rate_plan && _.some($scope.rate_plans, {product: $scope.data.rate_plan.product})) {
      if ($scope.data.rate_plan.promotion)
        total += parseFloat($scope.data.rate_plan.promotion);
      else
        total += parseFloat($scope.data.rate_plan.rate);
    }

    if ($scope.data.did_plan && _.some($scope.did_plans, {product: $scope.data.did_plan.product})) {
      if ($scope.data.did_plan.promotion)
        total += parseFloat($scope.data.did_plan.promotion);
      else
        total += parseFloat($scope.data.did_plan.rate);
    }

    if ($scope.data.credit_group) {
      if ($scope.data.credit_group.promotion)
        total += parseFloat($scope.data.credit_group.promotion);
      else
        total += parseFloat($scope.data.credit_group.rate);
    }

    return total;

  };

  //device data represents advanced braintree fraud data, it is populated onready
  $scope.deviceData = "";
  //setup braintree dropin options
  var env           = (config.mparticle.isSandbox) ? 'sandbox' : 'production';

  $scope.dropinOptions = {
    dataCollector: {
      kount: {environment: env}
    },
    onReady: function(braintreeInstance) {
      // At this point, you should access the braintreeInstance.deviceData value
      // and provide it to your server, e.g. by injecting it into your form as a
      // hidden input.
      $scope.deviceData = braintreeInstance.deviceData;
      
    },
    /**
     * Intercept form submission when nonce is received.
     * Collect nonce and invoke charge with nonce and params
     * @param payload
     */
    onPaymentMethodReceived: function(payload) {
      $scope.purchaseButtonEnabled = false;
      $scope.isLoadLocal           = true;
      //braintree bug which invokes onPaymentMethodReceived multiple times
      //so we need to set it only once and call purchase only once
      if ($scope.isPaymentMethodReceived) return;

      $scope.isPaymentMethodReceived = true;

      var params = {
        receipt: payload.nonce
      };

      //prepare array of google analytics items
      var gaItems = [];
      var item    = {};

      if ($scope.data.credit && _.some($scope.credit_products, {product: $scope.data.credit.product})) {
        params.product = $scope.data.credit.product;
        params.plan_country_code = country;
        params.amount  = $scope.data.credit.promotion ? $scope.data.credit.promotion * 100 : $scope.data.credit.rate * 100;
        item           = {
          id: $scope.data.credit.product,
          name: $scope.data.credit.title,
          category: 'Credit',
          value: $scope.data.credit.rate,
          minutes: $scope.data.credit.minutes || {}
        };

        gaItems.push(item);
      }

      if ($scope.data.rate_plan && _.some($scope.rate_plans, {product: $scope.data.rate_plan.product})) {
        params.product = $scope.data.rate_plan.product;
        params.plan_country_code = country;
        params.amount  = $scope.data.rate_plan.promotion ? $scope.data.rate_plan.promotion * 100 : $scope.data.rate_plan.rate * 100;

        if (!$scope.data.rate_plan.promotion) {
          $scope.promo = 0;
        }

        item = {
          id: $scope.data.rate_plan.product,
          name: $scope.data.rate_plan.title,
          category: 'Rate Plan',
          value: $scope.data.rate_plan.rate,
          minutes: $scope.data.rate_plan.minutes || {}
        };

        gaItems.push(item);
      }

      if ($scope.data.did_plan && _.some($scope.did_plans, {product: $scope.data.did_plan.product})) {
        params.product = $scope.data.did_plan.product;
        params.plan_country_code = country;
        params.amount  = $scope.data.did_plan.promotion ? $scope.data.did_plan.promotion * 100 : $scope.data.did_plan.rate * 100;

        item = {
          id: $scope.data.did_plan.product,
          name: $scope.data.did_plan.title,
          category: 'Rate Plan',
          value: $scope.data.did_plan.rate,
          minutes: $scope.data.did_plan.minutes || {}
        };

        gaItems.push(item);
      }

      if ($scope.data.credit_group ) {
        params.product = $scope.data.credit_group.product;
        params.plan_country_code = country;
        params.amount  = parseInt($scope.data.credit_group.promotion ? $scope.data.credit_group.promotion * 100 * 0.9 : $scope.data.credit_group.rate * 100*0.9);

        item = {
          id: $scope.data.credit_group.product,
          name: $scope.data.credit_group.title,
          category: 'Rate Plan',
          value: $scope.data.credit_group.rate,
          minutes: $scope.data.credit_group.minutes || {}
        };

        gaItems.push(item);
      }

      GAManager.sendConversion($scope.getTotalAmount());

      params.deviceData = $scope.deviceData;

      params.renew   = ($scope.subscription) ? 1 : 0;
      $scope.isRenew = params.renew;
      if ($scope.promo) {
        params.promo = $scope.promo;
      }

      PrimoService.charge(params).success(function(data, status, headers) {
        
        $scope.isLoadLocal = false;
        $window.localStorage.setItem('payment_success',1);
        
        $scope.$root.alert = {
          show: true,
          context: {type: 'success', msg: 'Thank you. Your payment was successful'}
        };

        //reset payment method nonce
        $scope.isPaymentMethodReceived = true;

        sendToGoogleAnalytics(data, $scope.getTotalAmount(), gaItems);
        mParticleService.logTransaction(data, $scope.getTotalAmount(), gaItems, $scope.isRenew);

        //update balance in session object
        var user = {
          balance: data.balance
        };

        SessionService.updateSession(user);
        // take him back to profile
        $timeout(function() {
          $state.go('profile');
        }, 1000);


      }).error(function(data){

          localStorage.setItem('payment_unsuccessfull',data.user_errors[0]);
          $state.reload();
          // $scope.paymentMessage = data.user_errors[0];
          // $scope.statusType     = 'Error';
          // $scope.successClass   = "danger";
          // $("#myModalpac").modal("toggle");
          // reloadBraintreeDropin();

      }).finally(function() {
        //reloadBraintreeDropin();
        $state.reload();
      });

    }
  };

  /**
   * Set purchase step to final and set mparticle attributes
   */
  $scope.finalizeOrder = function(isRenew) {
    $scope.isLoadLocal = true;
    var product_id = $scope.choosedCurrentProduct.product;
    var token = localStorage.getItem('token');
    var selectedCountry = localStorage.getItem('selectedCoutry');
    if(!selectedCountry){
      $scope.paymentMessage = "Please choose country first";
      $scope.statusType = "Error";
      $("#myModalpac").modal("toggle");
      $scope.isLoadLocal = false;
      return false;
    }

    PrimoService.checkProductAvailability({
        username: $rootScope.data.alias,
        login_token: $rootScope.data.login_token,
        product:product_id}).success(function(data, status, headers) {
        $scope.isLoadLocal = false;
        if(data.available != true){
          $scope.paymentMessage = data.limit_message;
          $scope.statusType = "Error";
          $("#myModalpac").modal("toggle");
          return false;
        }

        $window.scrollTo(0, 0);
        $scope.subscription = (isRenew) ? 1 : 0;
        $scope.isRenew      = isRenew;
        //if user has active unlimited plan pop confirmation message with lost minutes information
        if (($scope.data.rate_plan) && SessionService.hasActiveUnlimitedPlan($scope.data.rate_plan)) {
          UiService.showConfirmDialog('UnlimitedPlanChangeConfirmationController', 'partials/purchase-unlimited-plan-change-confirmation.html', function(res) {
            if (res == true) {
              $scope.setFinalizationStep();
            }
          });
        } else {
          $scope.setFinalizationStep();
        }

    }).error(function(response){
        $scope.isLoadLocal = false;
        if(response.user_errors.length > 0){
            $scope.paymentMessage = response.user_errors[0];
            $scope.statusType = "Error";
            $("#myModalpac").modal("toggle");
            return false;
        }
        
        $scope.paymentMessage = "Some problem occured. Please try again later.";
        $scope.statusType = "Error";
        $("#myModalpac").modal("toggle");
        return false;
    });
  };

  /**
   * Send data to mparticle and set purchase step to final
   */
  $scope.setFinalizationStep = function() {
    if ($scope.data.credit) mParticleService.addToCartCredit($scope.data.credit, $scope.isRenew);
    if ($scope.data.rate_plan) mParticleService.addToCartMonthly($scope.data.rate_plan, $scope.isRenew);
    if ($scope.data.did_plan) mParticleService.addToCartDid($scope.data.did_plan, $scope.isRenew);

    $scope.purchaseStep = 'final';
  };

  /**
   * Send data to mparticle and set purchase step to ready
   */
  $scope.resetOrder = function() {
    if ($scope.data.credit) mParticleService.removeFromCartCredit($scope.data.credit, $scope.isRenew);
    if ($scope.data.rate_plan) mParticleService.removeFromCartMonthly($scope.data.rate_plan, $scope.isRenew);
    if ($scope.data.did) mParticleService.removeFromCartDid($scope.data.did_plan, $scope.isRenew);

    $scope.purchaseStep = 'ready';
  };

  function reloadBraintreeDropin() {
    //reset payment method nonce
    $scope.isPaymentMethodReceived = true;

    $scope.isReloadBraintree     = true;
    $scope.purchaseButtonEnabled = false;
    $scope.isLoadLocal           = false;
    $timeout(function() {
      $scope.isReloadBraintree     = false;
      $scope.purchaseButtonEnabled = true;
      $scope.isLoadLocal           = false;
    }, 1000);
  }


  function sendToGoogleAnalytics(data, total, items) {
    var id = Date.now();
    ga('ecommerce:addTransaction', {
      'id': id,                     // Transaction ID. Required.
      'affiliation': 'wwww.primo.me',   // Affiliation or store name.
      'revenue': total               // Grand Total.
    });


    //Below given code sends item information to google analytics
    // It should come as many times as many items there in cart
    angular.forEach(items, function(item) {
      ga('ecommerce:addItem', {
        'id': id,                     // Transaction ID. Required.
        'name': item.name,    // Product name. Required.
        'category': item.category,         // Category or variation.
        'price': item.value,                 // Unit price.
        'quantity': '1'                   // Quantity.
      });
    });


//Finally, once you have configured all your ecommerce data , you send the data to Google Analytics using the ecommerce:send command
    ga('ecommerce:send');
  }

  $scope.$watch('data.rate_plan', function(newValue) {
    if (newValue) {
      $scope.data.credit            = false;
      $scope.data.did_plan          = false;
      $scope.showSubscriptionButton = true;
    }
  });


  $scope.$watch('data.did_plan', function(newValue) {
    if (newValue) {
      $scope.data.rate_plan         = false;
      $scope.data.credit            = false;
      $scope.showSubscriptionButton = false;
    }
  });

  $scope.$watch('data.credit', function(newValue) {
    if (newValue) {
      $scope.data.rate_plan         = false;
      $scope.data.did_plan          = false;
      $scope.showSubscriptionButton = false;
    }
  });

  $scope.$watch('data.credit_group', function(newValue) {
    if (newValue) {
      $scope.data.rate_plan         = false;
      $scope.data.did_plan          = false;
      $scope.showSubscriptionButton = true;
    }
  });

  /**
   * Selected Item
   */
  $scope.selectedCredutProducts = function(){
    $scope.data.credit  = JSON.parse($scope.selected_credit_products);
    $scope.selected_rate_plans = "";
    $scope.selected_service_plan = "";
    $scope.selected_did_plans = "";
    $scope.data.credit_group = "";
    $scope.selectedAllProduct = "Select Plan";
    $(".selectpicker").selectpicker("refresh");
  }

  $scope.selectedRatePlans = function(){
    $scope.data.rate_plan  = JSON.parse($scope.selected_rate_plans);
    $scope.selected_credit_products = "";
    $scope.selected_service_plan = "";
    $scope.selected_did_plans = "";
    $scope.data.credit_group = "";
    $scope.selectedAllProduct = "Select Plan";
    $(".selectpicker").selectpicker("refresh");
  }

  $scope.selectedServicePlans = function(){
    $scope.data.service_plan  = JSON.parse($scope.selected_service_plan);
    $scope.selected_credit_products = "";
    $scope.selected_rate_plans = "";
    $scope.selected_did_plans = "";
    $scope.data.credit_group = "";
    $scope.selectedAllProduct = "Select Plan";
    $(".selectpicker").selectpicker("refresh");
  }

  $scope.selectedDidPlans = function(){
    $scope.data.did_plan  = JSON.parse($scope.selected_did_plans);
    $scope.selected_credit_products = "";
    $scope.selected_rate_plans = "";
    $scope.selected_service_plan = "";
    $scope.data.credit_group = "";
    $scope.selectedAllProduct = "Select Plan";
    $(".selectpicker").selectpicker("refresh");
  }

  $scope.selectedCredutGroupProducts = function(input){
    $scope.purchaseStep = 'ready';
    $scope.choosedCurrentProduct = input.value;
    $scope.selectedAllProduct = input.value.title;
    $scope.selected_credit_group_products = input.value;
    $scope.data.credit_group  = $scope.selected_credit_group_products;
    $scope.selected_credit_products = "";
    $scope.selected_rate_plans = "";
    $scope.selected_service_plan = "";
    $scope.data.did_plan = "";

    angular.forEach($scope.all_countries_product,function(value,key){

      if(value.product == input.value.product){
        $scope.selected_countries_product = value;
      }

    });

    $(".selectpicker").selectpicker("refresh");
  }

});

app.filter('replacetagfilter',  ['$sce', function($sce){
  return function(string) {
    var updatedString = string.replace("##","<a href='/destinations'>").replace("##","</a>");
    return $sce.trustAsHtml(updatedString);
  }
}]);