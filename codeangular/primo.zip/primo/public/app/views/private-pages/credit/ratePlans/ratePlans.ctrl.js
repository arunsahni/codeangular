/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

app.controller('AddRatePlanController', function ($scope, $rootScope, PrimoService, SessionService, $filter,
                                                  $stateParams, $state, CountlyManager,
                                                  items) {

  CountlyManager.sendEventMessage('w: Usage Add Rate Plan');

  //remove free primo from list
  angular.forEach(items, function (val, key) {
    if (val.android_id == "") items.splice(key, 1);
  });

  $rootScope.clientTokenPath = '/get-client-token';

  $scope.buttonEnabled = true;
  //predefined set of credit items
  $scope.creditItems = items;

  //setup braintree dropin options
  $scope.dropinOptions = {

    /**
     * Intercept form submission when nonce is receiv_ed.
     * Collect nonce and invoke chargePayment with nonce and amount as parameters
     * @param payload
     */
    onPaymentMethodReceived: function (payload) {
      $scope.buttonEnabled = false;
      //call primo charge payment
      PrimoService.chargeRatePlan({
          payment_method_nonce: payload.nonce,
          android_product_id: $scope.selected.android_id,
          amount: $scope.selected.rate * 100 //TODO: check if needs to be rounded
        })
        .success(function (data, status, headers) {
          //display alert message
          $scope.$root.alert   = {
            show: true,
            context: {type: 'success', msg: $filter('translate')('SUCCESSFULLY_ADDED_FUNDS')}
          };
          $scope.buttonEnabled = true;

          //fetch latest balance for user and update session
          PrimoService.getSIPBalanace().then(function (data) {
            $rootScope.user.balance      = data.data.balance;
            $rootScope.user.intl_minutes = data.data.intl_minutes;
            $rootScope.user.current_plan = data.data.current_plan;
            SessionService.updateSession($rootScope.user);
            return data;
          });

          // take him back to account
          $scope.cancel();
        });
    }
  };

  $scope.selected = ($stateParams.plan) ? $scope.creditItems[$stateParams.plan] : $scope.creditItems[0];

  $scope.select = function (item) {
    $scope.selected = item;
  };

  $scope.isSelected = function (item) {
    return ($scope.selected.android_id == item.android_id);
  };

  $scope.cancel = function () {
    $state.go('profile');
  };
});