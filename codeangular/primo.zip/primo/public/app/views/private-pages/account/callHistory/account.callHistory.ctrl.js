/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller('AccountCallHistoryController', function ($rootScope, $scope, history, CountlyManager,
                                                         $filter,
                                                         mParticleService) {

  CountlyManager.sendEventMessage('w: Usage Call SMS History');
  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);

  $scope.csvData = [];
  $scope.history = history;

  $scope.csvExport = {
    filename: 'callHistory.csv',
    decimalSeparator: '.',
    separator: ','
  };

  var today             = Date.now();
  var dayInMilliseconds = 86400000;
  $scope.startDate      = today - (dayInMilliseconds * 1800); // last 30 days default
  $scope.endDate = today;

  $scope.changeFilterDates = function () {
    $scope.endDate   = Date.now();
    $scope.startDate = today - (dayInMilliseconds * $scope.periodVal);

    $scope.calEndDate   = new Date($scope.endDate);
    $scope.calStartDate = new Date($scope.startDate);
  };

  /**
   * Filter billing history in date range
   */
  $scope.applyFilter = function () {
    $scope.periodVal = -1;

    if ($scope.calStartDate) $scope.startDate = Date.parse($scope.calStartDate);
    if ($scope.calEndDate) $scope.endDate = Date.parse($scope.calEndDate);
  };

  /**
   * Iterate through history records and prepare csv data
   */
  $scope.prepareCSV = function () {
    angular.forEach($scope.history, function (value, key) {
      $scope.csvData.push({
        type: value.rate_plan.indexOf('SMS') != -1 ? $filter('translate')('SMS') : $filter('translate')('Call'),
        date: $filter('realTime')(value.history_epoch_pst, 'DD/MM/YYYY'),
        time: $filter('realTime')(value.history_epoch_pst, 'HH:mm a'),
        destination: value.destination,
        recipient: $filter('formatDid')(value.destination_number),
        minutes: value.rate_plan.indexOf('SMS') == -1 ? value.minutes : '-',
        rate: $filter('currency')(value.rate * value.minutes || 0),
        cost: value.AMOUNT
      });
    });
  };

  $scope.prepareCSV();

  $scope.periodVal = 30;
  $scope.changeFilterDates();

});