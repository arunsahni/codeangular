/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

app.controller('FreeCountriesController', function (filter, $scope, COUNTRIES, _) {

  $scope.filter = filter;

  $scope.countries = _.sortBy(_.filter(COUNTRIES, filter), [function (c) {
    return c.name;
  }, 'name']);

  $scope.columnCount = 6;

  $scope.rows = function () {
    var input = [];
    for (var i = 0; i < $scope.countries.length / $scope.columnCount; i++) input.push(i);
    return input;
  };

  $scope.columns = function (row) {
    var start = row * $scope.columnCount;
    var end   = start + $scope.columnCount;
    var input = [];
    for (var i = start; i < end; i++) {
      if ($scope.countries[i]) input.push($scope.countries[i]);
    }
    return input;
  };
});