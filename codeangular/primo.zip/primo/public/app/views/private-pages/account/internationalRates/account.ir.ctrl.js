/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller('AccountIRController', function ($location,
                                                $rootScope,
                                                $scope,
                                                $timeout,
                                                $q,
                                                UiService,
                                                CountlyManager,
                                                mParticleService,
                                                $filter,
                                                InternationalRatesService) {

  CountlyManager.sendEventMessage('w: Usage International Rates');

  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);

  //scroll to top of the element by passed location
  angular.element(document).ready(function () {
    if ($location.hash()) {
      $timeout(UiService.scrollToElement('#' + $location.hash()), 500);
    }
  });

  setTimeout(function () {
    $('.panel-group').on('hidden.bs.collapse', function(e){

      $(e.target).prev('.panel-heading').find(".more-less").toggleClass('glyphicon-plus glyphicon-minus');
    });
    
    $('.panel-group').on('shown.bs.collapse', function(e){
      $(e.target).prev('.panel-heading').find(".more-less").toggleClass('glyphicon-plus glyphicon-minus');
    });
    
    $('.faq-tabs .btn-pref .btn-group button').click(function(){
      $('.faq-tabs .btn-pref .btn-group button').removeClass('active');
      $(this).addClass('active');
    });
  }, 10);

  var groupedRatesOrderTemplate = ['na', 'eu', 'af', 'as', 'oc', 'me'];

  //fetch rates
  $scope.rates = InternationalRatesService.getRates();

  $scope.scrollToElement = UiService.scrollToElement;
  //list of all rates grouped by region
  $scope.tempGroupedRates = {};
  $scope.groupedRates     = {};
  //selected region (us, eu, ...)
  $scope.selectedRegion = null;

  //pack groups to temp regions which will be sorted later in groupedRates
  var region = "UNCATEGORIZED";
  angular.forEach($scope.rates, function (val, key) {
    region = (val.region_code) ? val.region_code : "UNCATEGORIZED";

    if (!$scope.tempGroupedRates[region]) $scope.tempGroupedRates[region] = [];
    $scope.tempGroupedRates[region].push(val);
  });

  //add regions in specific order
  angular.forEach(groupedRatesOrderTemplate, function (key) {
    $scope.groupedRates[key] = $scope.tempGroupedRates[key];
  });

  //used to calculate minutes on primo credit tab
  $scope.small  = 0;
  $scope.medium = 0;
  $scope.large  = 0;
  $scope.huge   = 0;

  $scope.searchTextPrimoCredit = "";

  $scope.selectedPrimoCreditCalc = null;

  /**
   * Calculate value of minutes available per packet/country
   * @param item
   */
  $scope.selectedItemPrimoCreditCalcChange = function (item) {
    $scope.selectedPrimoCreditCalc = item;

    if ($scope.selectedPrimoCreditCalc) {
      $scope.small  = 2.99 / $scope.selectedPrimoCreditCalc.pinless_mobile;
      $scope.medium = 4.99 / $scope.selectedPrimoCreditCalc.pinless_mobile;
      $scope.large  = 9.99 / $scope.selectedPrimoCreditCalc.pinless_mobile;
      $scope.huge   = 14.99 / $scope.selectedPrimoCreditCalc.pinless_mobile;
    }
  };

  /**
   * Search for country by name
   * @param text
   * @returns {*}
   */
  $scope.searchForPrimoCreditCalcLocation = function (text) {
    var deferred = $q.defer();
    if (text) {
      mParticleService.logSearchEvent('Primo Credit - Where are you calling?', text);
      return InternationalRatesService.getCountryByName(text);
    }
    return deferred.promise;
  };

  /**
   * Selects a region
   * @param name
   */
  $scope.selectRegion = function (name) {
    $scope.selectedRegion = ($scope.selectedRegion == name) ? null : name;
    mParticleService.logDestinationEvent($filter('translate')(name));
  };

  /**
   * Check if region is selected
   * @param name
   * @returns {boolean}
   */
  $scope.isSelectedRegion = function (name) {
    return name == $scope.selectedRegion;
  };

  $scope.select = function (item) {
    $scope.selectedMenuItem = item;
    $scope.scrollToElement(item);
  };

  $scope.isSelected = function (item) {
    return ($scope.selectedMenuItem && $scope.selectedMenuItem == item);
  };

  $scope.showDialog = function (filter) {
    UiService.showAlertDialog('FreeCountriesController', 'partials/free-countries-list.html', function () {
    }, filter)
  };

});