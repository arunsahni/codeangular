/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller('AccountTicketCreateController', function ($rootScope, $scope, PrimoService, SessionService, $mdDialog, CountlyManager) {

  CountlyManager.sendEventMessage('w: Usage Create Ticket');

  //drop down items possible values
  $scope.subjects = [
    {name: 'My Account'},
    {name: 'Product Information'},
    {name: 'Plans & Credits'},
    {name: 'Rewards'},
    {name: 'Calling Questions'},
    {name: 'Other'}
  ];

  $scope.subject      = "";
  $scope.subjectValue = "";
  /**
   * Set default values for all related fields
   */
  $scope.initFields = function () {
    $scope.subjectValue = "";
    $scope.description  = "";
    $scope.phone        = "";

    if ($rootScope.user) {
      //populate predefined fields
      $scope.name     = $rootScope.user.first_name + " " + $rootScope.user.last_name;
      $scope.email    = $rootScope.user.email || "";
      $scope.username = $rootScope.userId || "";
    }

  };

  /**
   * Depending on selected item set predefined subject value
   */
  $scope.setSelectedSubject = function () {
    $scope.subjectValue = ($scope.subject != 'Other') ? $scope.subject : "";
    return $scope.subject;
  };

  $scope.answer = function (answer) {
    if (answer) {
      $mdDialog.hide({
        username: $scope.username,
        name: $scope.name,
        email: $scope.email,
        phone: $scope.phone,
        subject: ($scope.subject != 'Other') ? $scope.subject : $scope.subjectValue,
        description: $scope.description
      });
    }
  };

  $scope.initFields();
});