/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
/**
 * Used to view/edit currently logged user details
 */
app.controller('AccountProfileController', function($rootScope,
  UiService,
  CountlyManager,
  mParticleService,
  $scope, $q, $http,
  UtilHelperService, $timeout,
  PrimoService, SessionService, $filter, AuthService, config, Base64,$window) {
  $scope.isEditing = false;
  $scope.isLoadLocal = false;
  $scope.isChangePassword = false;
  $scope.now = Date.now();
  //============== Billing & Calling Variables ========================
  $scope.csvDataCalling = [];
  $scope.csvDataBilling = [];
  $scope.callHistory;
  $scope.billingHistory;
  $scope.periodVal = 30;
  $scope.periodVal_bill = 30;
  $scope.userProfile = {};
  $scope.emailToInvite = null;
  $scope.emailToInviteArray = [];
  $scope.userEmail = '';
  CountlyManager.sendEventMessage('w: Usage My Account');
  setTimeout(function() {
    mParticleService.logPageView();
  }, 1000);
  //update balance received from get sip balance
  updateBalance($rootScope.user);
  //extract data from rootScope user
  $scope.currentUser = angular.copy($rootScope.user);
  //used to query from location
  $scope.searchTextFrom = '';
  $scope.searchResidenceText = '';
  $scope.username = $rootScope.userId;
  $scope.setProfileImageUrl = config.primo.host + '/pr/manageintl/3/primo/api/manageintl__SetProfileImage';
  $scope.AuthorizationKey = 'Basic ' + Base64.encode(config.primo.username + ':' + config.primo.password);

  $scope.currentPage = 1;
  $scope.maxSize = 10;
  $scope.callHistoryCurrentPage = 1;

  $scope.init = function() {

    if($scope.currentUser){
      $scope.selectCountryName = {contextname:$scope.currentUser.residence_location_string,latitude:$scope.currentUser.residence_latitude,longitude:$scope.currentUser.residence_longitude};
    }
    
    if($window.localStorage.getItem('payment_success') == 1){
        $window.localStorage.removeItem('payment_success');
        $scope.message = "Thank you. Your payment was successful";
        $scope.statusType     = 'Success';
        $scope.successClass = "success";
        $("#myModalpac").modal("toggle");
    }
    
    //Get Call History
    PrimoService.getCallHistory({page_size:50,page_ord:1}).then(function(response) {
      $scope.callHistory = response.data.call_history;
      $scope.prepareCSV_calling();
    });
    //Get Billing History
    PrimoService.getBillingHistory({page_size:50,page_ord:1}).then(function(response) {
      $scope.billingHistory = response.data.billing_history;
      $scope.prepareCSV_billing();
    })

    $('.myaccont-tab-ul li').click(function() {
      $('.myaccont-tab-ul li').find('a').removeClass('active');
      $(this).find('a').addClass('active');
      $('.myaccont-tab-panel').hide();
      var href = $(this).find('a').attr('href');
      $(href).fadeIn();
      return false;
    });

    $scope.getUserAccountInformation();
  }

  /*End of init function*/
  /**/
  $scope.getUserAccountInformation = function() {
    $scope.isLoadLocal = true;
    // we do this to check if the email and phone number are verified since we don't have sockets yet
    if ($rootScope.user.email == null || $rootScope.user.msisdn == null) {
      PrimoService.getAccountInfo({
        username: $rootScope.data.alias,
        login_token: $rootScope.data.login_token
      }).success(function(accountData) {
        $scope.isLoadLocal = false;
        $scope.currentUser = accountData;
        
        $scope.profileName = angular.copy($scope.currentUser);

        if(accountData.first_name){
          accountData.first_name = UtilHelperService.uniCodeToString(accountData.first_name);
        }

        if(accountData.last_name){
          accountData.last_name = UtilHelperService.uniCodeToString(accountData.last_name);
        }

        if(accountData.email){
          accountData.email      = UtilHelperService.uniCodeToString(accountData.email);
        }
        //$scope.isLoadLocal = false;
        // $scope.currentUser     = accountData;
        $scope.userEmail = accountData.email;
        SessionService.updateSession(accountData);
      });
    } else {
      $scope.userNameEmail = $rootScope.user.email;
      $scope.userPhoneNumber = $rootScope.user.direct_dial_in;
      PrimoService.getAccountInfo({
        username: $rootScope.data.alias,
        login_token: $rootScope.data.login_token
      }).success(function(accountData) {
        $scope.currentUser = accountData;
        $scope.isLoadLocal = false;
        if($scope.currentUser){
          $scope.selectCountryName = {contextname:$scope.currentUser.residence_location_string,latitude:$scope.currentUser.residence_latitude,longitude:$scope.currentUser.residence_longitude};
        }

        $scope.userEmail = accountData.email;
        localStorage.setItem('user', JSON.stringify(accountData));
        $scope.currentUser.profile_image_large = accountData.profile_image_large;
      });
      // $scope.username =$rootScope.user.first_name + " "+ $rootScope.user.last_name;
    }
  }
  /*Profile edit by kunvar singh*/
  $scope.profileEdit = function() {
    $scope.isProfileEdit = true;
  }
  $scope.resetProfile = function() {
    $scope.isProfileEdit = false;
    $scope.currentUser.email = $scope.userEmail;
    //$scope.getUserAccountInformation();
  }
  /*Profile image edit by kunvar singh*/
  $scope.changeImage = function() {
    $scope.isChangeImage = true;
    $('#fileinput').trigger('click');
    $("#fileinput").change(function() {
      readURL(this);
    });
  }
  // To watch email value
  $scope.isEmailChanged = false;
  $scope.$watch('currentUser.email', function(newValue, oldValue) {
    if(newValue !== oldValue){
      $scope.isEmailChanged = true;
    }
  });
  
  $scope.isAddress = false;
  var address = angular.copy($scope.currentUser.residence_location_string);
  if(address) {
    $scope.isAddress = true;
  }

  $scope.saveProfile = function() {
    $scope.isLoadLocal = true;
    //if($scope.userNameEmail && $scope.userPhoneNumber){
    PrimoService.setAccountInfo({
      first_name: $scope.currentUser.first_name,
      last_name: $scope.currentUser.last_name,
      email: $scope.currentUser.email,
      residence_location_string : $scope.currentUser.from_location_string,
      residence_longitude : $scope.currentUser.from_longitude,
      residence_latitude : $scope.currentUser.from_latitude
    }).success(function(accountData) {
     
      $scope.getUserAccountInformation();
      $scope.isLoadLocal = false;
      if(accountData.success){

        if($scope.isEmailChanged == true){
          $scope.message = "Updated information is sent to respective Email.Please verify your Email.";
          $scope.statusType     = 'Success';
          $scope.successClass = "success";
          $('#myModalpac').modal('toggle');
          $scope.isEmailChanged == false;
        } else{
          $scope.message = "Profile Information has been updated";
          $scope.statusType     = 'Success';
          $scope.successClass = "success";
          $('#myModalpac').modal('toggle');
        }
        $scope.isProfileEdit = false;
      } 
      else {
        alert('Unable to save the profile..');
      }
    }).error(function(err) {
      $scope.getUserAccountInformation();
      $scope.isLoadLocal = false;
      $scope.paymentMessage = err[0];
      $scope.statusType     = 'Error';
      $scope.successClass   = "danger";
      $("#myModalpac").modal("toggle");
    })
  }

  function readURL(input) {
    
    if (input.files && input.files[0]) {
      $scope.isLoadLocal = true;
      var reader = new FileReader();
      reader.onload = function(e) {
        // $('#newImage').attr('src', e.target.result);
        $scope.currentUser.profile_image_large = e.target.result;
        PrimoService.setProfilePicture({
            username: $rootScope.data.alias,
            login_token: $rootScope.data.login_token,
            base64_data: e.target.result
          }).success(function(accountData) {
            $scope.isLoadLocal = false;
            if (accountData.success) {
                $scope.message = "Profile picture has been uploaded";
                $scope.statusType     = 'Success';
                $scope.successClass = "success";
                $('#myModalpac').modal('toggle');
            } else {
               $scope.message = "Unable to save profile picture";
               $scope.statusType     = 'Success';
               $scope.successClass = "success";
               $('#myModalpac').modal('toggle');
            }
          })
          .error(function(err) {
            $scope.isLoadLocal = false;
            console.log('Unable to save the Image' + err);
          });
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  /*End of init function*/
  $scope.changePassword = function() {
    $scope.passwordComparisonText = "";

    if ($scope.changePasswordForm.$valid) {
      if ($scope.secret && $scope.secret.length < 6) {
        $scope.passwordComparisonText = 'New Password should be atleast 6 digits';
        $scope.toShowPasswordCamparison = true;
        return;
      }
      if ($scope.secret != $scope.secret1) {
        $scope.passwordComparisonText = 'New Password should be same';
        $scope.toShowPasswordCamparison = true;
        return;
      }
      var data = {
        old_password: $scope.checkSecret,
        new_password: $scope.secret
      };
      $scope.isLoadLocal = true;
      PrimoService.changePassword(data)
        .success(function(response) {
          $scope.checkSecret = '';
          $scope.secret = '';
          $scope.secret1 = '';
          $scope.confirmation = '';
          $scope.toShowPasswordCamparison = false;
          $scope.changePasswordForm.submitted = false;
          $scope.changePasswordForm.$setPristine();
          $scope.isLoadLocal = false;
          $scope.isChangePassword = false;

          if(response.user_errors[0]){
            $scope.message = response.user_errors[0];
            $scope.statusType     = 'Success';
            $('#myModalpac').modal('toggle');
            return false; 
          }

          if(response.user_errors[1]){
            
            $scope.message = response.user_errors[1];
            $scope.statusType     = 'Success';
            $('#myModalpac').modal('toggle');  
            return false;
          }

          $scope.message = "Your password has been changed";
          $scope.statusType     = 'Success';
          $('#myModalpac').modal('toggle');  

        })
        .error(function(err) {
          if(err.user_errors[0]){
            $scope.isLoadLocal = false;
            $scope.message = err.user_errors[0];  
            $scope.statusType     = 'Error';
            $('#myModalpac').modal('toggle');
            return false;
          }
          
          if(err.user_errors[1]){
            $scope.isLoadLocal = false;
            $scope.message = err.user_errors[1];  
            $scope.statusType     = 'Error';
            $('#myModalpac').modal('toggle');
            return false;
          }
          
        });
    } else {
      $scope.changePasswordForm.submitted = true;
    }
  };

  $scope.closeButtonClicked = function() {
    $scope.isChangePassword = false;
  };
  /**
   * set selected from item location in md-autocomplete
   * @type {{contextname: (string|*), longitude: (string|*), latitude: (string|*)}}
   */
  function _setFromLocation() {
    if ($scope.currentUser.from_location_string) {
      $scope.selectedFromItem = {
        contextname: $scope.currentUser.from_location_string,
        longitude: $scope.currentUser.from_longitude,
        latitude: $scope.currentUser.from_latitude
      };
    } else { //reset input value
      $scope.selectedFromItem = "";
      $scope.searchFromText = "";
    }
  }
  /**
   * set selected residence address in md-autocomplete
   * @type {{contextname: (string|*), longitude: (string|*), latitude: (string|*)}}
   */
  function _setResidenceLocation() {
    if ($scope.currentUser.residence_location_string) {
      $scope.selectedResidenceItem = {
        contextname: $scope.currentUser.residence_location_string,
        longitude: $scope.currentUser.residence_longitude,
        latitude: $scope.currentUser.residence_latitude
      };
    } else { //reset input value
      $scope.selectedResidenceItem = "";
      $scope.searchResidenceText = "";
    }
  }
  _setFromLocation();
  _setResidenceLocation();
  /**
   * Call server to return world location for FROM and RESIDENCE fields
   * @param text
   * @returns {Function}
   */
  $scope.searchForLocation = function(text) {
    var deferred = $q.defer();
    if (text) {
      PrimoService.getWorldLocation(text).then(function(data) {
        deferred.resolve(data.data);
      });
    }
    return deferred.promise;
  };
  /**
   * Call server to return world location for FROM and RESIDENCE fields
   * @param text
   * @returns {Function}
   */
  $scope.searchForLocationFunction = function(text) {
    
    if (text) {
      PrimoService.getWorldLocation(text).then(function(data) {
          $scope.states = data.data;
      });
    }

    return $scope.states;
  };
  /**
   * When From field is updated we need to update location, longitude and latitude
   * @param item
   */
  $scope.selectedFromChanged = function(item) {
    if (item) {
      $scope.currentUser.from_location_string = item.selectCountryName.contextname;
      $scope.currentUser.from_longitude = item.selectCountryName.longitude;
      $scope.currentUser.from_latitude = item.selectCountryName.latitude;
    }
  };
  /**
   * When Residence field is updated we need to update fields
   * @param item
   */
  $scope.selectedResidenceChanged = function(item) {
    if (item) {
      $scope.currentUser.residence_location_string = item.contextname;
      $scope.currentUser.residence_longitude = item.longitude;
      $scope.currentUser.residence_latitude = item.latitude;
    }
  };
  /**
   * Enable all the inputs to allow editing of contact information
   */
  $scope.startEditing = function() {
    $scope.isEditing = true;
  };
  /**
   * Disable all the inputs for editing and submit form
   */
  $scope.stopEditing = function(shouldSubmit) {
    if (shouldSubmit && $scope.form.$invalid) {
      return;
    }
    $scope.isEditing = false;
    if (shouldSubmit) {
      $scope.submit();
    } else {
      $scope.currentUser = angular.copy($rootScope.user);
      _setFromLocation();
      _setResidenceLocation();
    }
  };
  $scope.inviteFriends = function() {
    UiService.showConfirmDialog('AccountInviteFriendsController', 'partials/account-invite-friends.html', function(clb) {
      if (clb) {
        PrimoService.inviteFriends({
          invited_emails: clb
        }).then(function(response) {
          
          $scope.message = $filter('translate')('INVITE_SUCCESSFULLY SENT');
          $scope.statusType     = 'Success';
          $scope.successClass = "success";
          $('#myModalpac').modal('toggle');

          $scope.$root.alert = {
            show: true,
            context: {
              type: 'success',
              msg: $filter('translate')('INVITE_SUCCESSFULLY SENT')
            }
          }
        });
      }
    })
  };
  /**
   * Call Primo to update user information
   */
  $scope.submit = function() {
    $scope.isLoadLocal = true;
    $scope.isSubmitting = true;
    PrimoService.setAccountInfo(_extractDataToSend())
      .success(function() {
        $scope.isLoadLocal = false;
        $scope.$root.alert = {
          show: true,
          context: {
            type: 'success',
            msg: $filter('translate')('ACCOUNT_SUCCESS_UPDATE')
          }
        };
        if ($scope.currentUser['msisdn'] != $rootScope.user['msisdn']) {
          AuthService.verifyMSISDN();
        }
        //update balance and free minute
        updateBalance($scope.currentUser);
        SessionService.updateSession($scope.currentUser);
        mParticleService.logEditProfile($scope.currentUser);
      })
      .finally(function() {
        $scope.isLoadLocal = false;
        $scope.isSubmitting = false;
      });
  };
  /**
   * Data that is being sent to primo is only data that is changed
   * @private
   */
  function _extractDataToSend() {
    var retVal = {};
    angular.forEach($scope.currentUser, function(val, key) {
      if ($scope.currentUser[key] != $rootScope.user[key]) {
        retVal[key] = $scope.currentUser[key];
      }
    });
    if (retVal['msisdn']) {
      retVal['new_country'] = $scope.currentUser['msisdn_country_code'];
      retVal['new_msisdn'] = $scope.currentUser['msisdn'];
      delete retVal['msisdn'];
    }
    return retVal;
  }
  /**
   * update balance and update session user
   */
  function updateBalance(user) {
    $scope.updateBalanceInProgress = true;
    PrimoService.getSIPBalanace().then(function(response) {
      user.intl_minutes = response.data.intl_minutes;
      user.balance = response.data.balance;
      user.current_plan = response.data.current_plan;
      user.free_minutes = response.data.free_minutes;
      $scope.updateBalanceInProgress = false;
      SessionService.updateSession(user);
    });
  }
  $scope.flowFilesSubmittedHandler = function($files, $event, $flow) {
    var flowFile = $files[0],
      fileReader = new FileReader();
    if (!flowFile) {
      $scope.$root.alert = {
        show: true,
        context: {
          type: 'error',
          msg: 'File type not supported'
        }
      };
      return;
    }
    fileReader.onload = function(event) {
      var uri = event.target.result;
      PrimoService.setProfilePicture({
        base64_data: uri
      })
    };
    fileReader.readAsDataURL(flowFile.file);
  }
  //=================== Call History Code ==================================
  $scope.units = [{
      'id': -1,
      'label': 'CUSTOM'
    },
    {
      'id': 1,
      'label': '24 HOURS'
    },
    {
      'id': 30,
      'label': '7 DAYS'
    },
    {
      'id': 1800,
      'label': '30 DAYS'
    }
  ]
  $scope.csvExport_calling = {
    filename: 'callHistory.csv',
    decimalSeparator: '.',
    separator: ','
  };
  var today = Date.now();
  var dayInMilliseconds = 86400000;
  $scope.startDate = today - (dayInMilliseconds * 1800); // last 30 days default
  $scope.endDate = today;
  $scope.startDate_bill = today - (dayInMilliseconds * 1800); // last 30 days default
  $scope.endDate_bill = today;
  $scope.changeFilterDates = function() {
    $scope.endDate = Date.now();
    $scope.startDate = today - (dayInMilliseconds * $scope.periodVal);
    $scope.calEndDate = new Date($scope.endDate);
    $scope.calStartDate = new Date($scope.startDate);
  };
  /**
   * Filter billing history in date range
   */
  $scope.applyFilter = function() {
    $scope.periodVal = -1;
    if ($scope.calStartDate) $scope.startDate = Date.parse($scope.calStartDate);
    if ($scope.calEndDate) $scope.endDate = Date.parse($scope.calEndDate);
  };
  /**
   * Iterate through history records and prepare csv data
   */
  $scope.prepareCSV_calling = function() {
    angular.forEach($scope.callHistory, function(value, key) {
      $scope.csvDataCalling.push({
        type: value.rate_plan.indexOf('SMS') != -1 ? 'SMS' : 'Call',
        date: $filter('realTime')(value.history_epoch_pst, 'DD/MM/YYYY'),
        time: $filter('realTime')(value.history_epoch_pst, 'HH:mm a'),
        destination: value.destination,
        recipient: $filter('formatDid')(value.destination_number),
        minutes: value.rate_plan.indexOf('SMS') == -1 ? value.minutes : '-',
        rate: $filter('currency')(value.rate * value.minutes || 0),
        cost: value.AMOUNT
      });
    });
  };
  $scope.changeFilterDates();
  //======================= Billing History Code =========================
  $scope.csvExport_billing = {
    filename: 'billingHistory.csv',
    decimalSeparator: '.',
    separator: ','
  };

  $scope.csvData_billing = [];
  
  $scope.changeFilterDates_billing = function() {
    if ($scope.periodVal_bill > 0) {
      $scope.endDate_bill = Date.now();
      $scope.startDate_bill = today - (dayInMilliseconds * $scope.periodVal_bill);
      $scope.calEndDate_bill = new Date($scope.endDate_bill);
      $scope.calStartDate_bill = new Date($scope.startDate_bill);
    }
  };
  
  $scope.applyFilter_bill = function() {
    $scope.periodVal_bill = -1;
    if ($scope.calStartDate_bill) $scope.startDate_bill = Date.parse($scope.calStartDate_bill);
    if ($scope.calEndDate_bill) $scope.endDate_bill = Date.parse($scope.calEndDate_bill);
  };

  /**
   * Iterate through history records and prepare csv data
   */
  $scope.prepareCSV_billing = function() {
    angular.forEach($scope.billingHistory, function(value, key) {
      $scope.csvDataBilling.push({
        order_id: value.order_id,
        type: value.type,
        date: $filter('realTime')(value.history_epoch, 'DD/MM/YYYY'),
        time: $filter('realTime')(value.history_epoch, 'HH:mm a'),
        description: value.description,
        MINUTES: value.MINUTES,
        AMOUNT: value.AMOUNT
      });
    });
  };

  $scope.addTempEmail = function() {
    $scope.errorRequired = "";
    if(!$scope.emailToInvite || $scope.emailToInvite == ''){
      $scope.errorRequired = "Please Fill email first";
      return false;
    }
    

    //TODO: fetch limit from services
    if ($scope.emailToInviteArray.length == 5) {
      $rootScope.alert = {
        show: true,
        context: {
          type: 'info',
          msg: $filter('translate')("LIMIT_INVITE_PERIOD")
        }
      };
      return;
    }
    //already added email can not be added
    if ($scope.emailToInviteArray.indexOf($scope.emailToInvite) !== -1) {
      $rootScope.alert = {
        show: true,
        context: {
          type: 'danger',
          msg: $filter('translate')("EMAIL_ALREADY_ADDED")
        }
      };
      return;
    }
    //evaluate agains email reges
    var patt =
      /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i
    var res = new RegExp(patt).test($scope.emailToInvite);
    //add to the list
    if (res) {
      $scope.emailToInviteArray.push($scope.emailToInvite);
      $scope.emailToInvite = "";
    }
    // console.log('Invite Email ID is', $scope.emailToInvite, $scope.emailToInviteArray);
  }
  $scope.removeTempEmail = function(email) {
    var indexToRemove = $scope.emailToInviteArray.indexOf(email);
    $scope.emailToInviteArray.splice(indexToRemove, 1);
    // console.log(email, 'Email to remove and now array contains', $scope.emailToInviteArray);
  }
  $scope.inviteFriedsFun = function() {
    $scope.isLoadLocal = true;
    if ($scope.emailToInviteArray.length) {
      PrimoService.inviteFriends({
          invited_emails: $scope.emailToInviteArray
        }).success(function(response) {
          $scope.isLoadLocal = false;
          $scope.emailToInviteArray = [];
          $scope.message = $filter('translate')('INVITE_SUCCESSFULLY SENT');
          $scope.statusType     = 'Success';
          $scope.successClass = "success";
          $('#myModalpac').modal('toggle');
          // $scope.$root.alert = {
          //   show: true,
          //   context: {
          //     type: 'success',
          //     msg: $filter('translate')('INVITE_SUCCESSFULLY SENT')
          //   }
          // }
        })
        .error(function(err) {
          //  
          $scope.message = "Some problem occured, please try again later";
          $scope.statusType     = 'Failure';
          $scope.successClass = "success";
          $('#myModalpac').modal('toggle');

        });
    }
  }
  $scope.changeFilterDates_billing();

  $scope.billingHistoryPagination = function() {
   $scope.isLoadLocal = true;
   PrimoService.getBillingHistory({page_size:50,page_ord:$scope.currentPage}).then(function(response) {
      $scope.isLoadLocal = false;
      $scope.billingHistory = response.data.billing_history;
      $scope.prepareCSV_billing();
    })
  };

  $scope.callHistoryPaginationPagination = function() {
   $scope.isLoadLocal = true;
   PrimoService.getBillingHistory({page_size:50,page_ord:$scope.currentPage}).then(function(response) {
      $scope.isLoadLocal = false;
      $scope.callHistory = response.data.call_history;
      $scope.prepareCSV_calling();
    })
  };

  $scope.init();
});