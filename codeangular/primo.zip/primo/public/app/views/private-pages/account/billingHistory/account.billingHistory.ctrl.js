/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller('AccountBillingHistoryController', function ($rootScope, $scope, history, CountlyManager,
                                                            $filter,
                                                            mParticleService) {

  CountlyManager.sendEventMessage('w: Usage Billing History');
  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);

  $scope.csvExport = {
    filename: 'billingHistory.csv',
    decimalSeparator: '.',
    separator: ','
  };

  $scope.history = history;
  $scope.csvData = [];


  var today             = Date.now();
  var dayInMilliseconds = 86400000;
  $scope.startDate      = today - (dayInMilliseconds * 1800);
  $scope.endDate        = today;


  $scope.changeFilterDates = function () {
    if ($scope.periodVal > 0) {
      $scope.endDate   = Date.now();
      $scope.startDate = today - (dayInMilliseconds * $scope.periodVal);

      $scope.calEndDate   = new Date($scope.endDate);
      $scope.calStartDate = new Date($scope.startDate);
    }
  };

  /**
   * Filter billing history in date range
   */
  $scope.applyFilter = function () {
    $scope.periodVal = -1;
    if ($scope.calStartDate) $scope.startDate = Date.parse($scope.calStartDate);
    if ($scope.calEndDate) $scope.endDate = Date.parse($scope.calEndDate);
  };

  /**
   * Iterate through history records and prepare csv data
   */
  $scope.prepareCSV = function () {
    angular.forEach($scope.history, function (value, key) {
      $scope.csvData.push({
        order_id: value.order_id,
        type: value.type,
        date: $filter('realTime')(value.history_epoch, 'DD/MM/YYYY'),
        time: $filter('realTime')(value.history_epoch, 'HH:mm a'),
        description: value.description,
        MINUTES: value.MINUTES,
        AMOUNT: value.AMOUNT
      });
    });
  };

  $scope.prepareCSV();


  $scope.periodVal = 30;
  $scope.changeFilterDates();

});