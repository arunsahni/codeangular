/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("SigninController", function($scope, PrimoService, $rootScope, $state,
    $q, $cookies,
    SessionService, CountlyManager, $mdDialog, AuthService, $auth, mParticleService, GooglePlus) {


    $scope.user = {};
    $scope.isRemember = false;
    $scope.errorMsg = false;
    //fetch remembered user from cookie if exists
    if ($cookies.getObject('username')) {
        $scope.user.username = $cookies.getObject('username');
        $scope.isRemember = true;
    }

    /**
     * Call primo to check login
     */

      /*Check empty object*/
    $scope.isEmpty = function (obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
        }
        return true;
    }

    $scope.verifyUsername = function(user) {
        if(user.username && user.password){
        $scope.isLoadLocal = true;
        PrimoService.verifyUsername({ username: $scope.user.username, language: 'en' })
            .success(function(data) {
                 if (data.success) {
                     $scope.user.username = data.username;
                     //enable password tab
                     $scope.isPasswordDisabled = false;
                     //$scope.isEpayUser = isEpayUser;
                     if ($scope.isRemember) {
                         $scope.rememberMe();
                     } else {
                         $scope.forgetUser();
                     }
                     //select password tab
                     $scope.setSelectedTab(1);

                     AuthService.doLogin($scope.user).then(function(res){
                            $scope.invalidMsg = false;
                            var state = $rootScope.lastState || "profile";
                            $scope.isLoadLocal = false;
                            $state.go(state, $rootScope.stateParams);
                            $mdDialog.cancel();
                    
                    })
                    .catch(function(err){
                        $scope.isLoadLocal = false;
                        $scope.errorMsg = true;
                        $scope.invalidMsg = err.user_errors[0];
                    });
                 }

            })
            .error(function(err){
                $scope.isLoadLocal = false;
                $scope.errorMsg = true;
                $scope.invalidMsg = err.user_errors[0];
            });
        }
    };

    /**
     * Call Primo service login and get account info. Store to localStorage
     */
    $scope.login = function() {
        AuthService.doLogin($scope.user, {
            epay: function(data) {
                $state.go('register', { claim: data.alias, token: data.login_token });
            },
            normal: function() {
                $mdDialog.cancel();
            }
        })
    };

    $scope.cancelDialog = function() {
        $mdDialog.cancel();
    };

    $scope.register = function() {
        AuthService.register();
    };

    $scope.forgotPassword = function() {
        AuthService.forgotPassword();
    };

    $scope.forgotUsername = function() {
        AuthService.forgotUsername();
    };

    $rootScope.$on('$stateChangeStart', function() {
        $mdDialog.cancel();
    });

    $scope.setSelectedTab = function(index) {
        $scope.selectedTab = index;

        if (index == 1) {
            //focus password
            setTimeout(function() {
                $('#inputPassword').focus();
            }, 200);
        }
    };


    /**
     * Add username to cookie
     */
    $scope.rememberMe = function() {
        $cookies.putObject('username', $scope.user.username);
    };

    /**
     * Remove username from cookie
     */
    $scope.forgetUser = function() {
        $cookies.remove('username');
    };

    /**
     * Facebook Login
     */
    $scope.authenticate = function(provider) {
        $scope.isLoadLocal = true;
        var deferred = $q.defer();

        if (provider == 'facebook') {
            $auth.authenticate(provider).then(function (response) {

                localStorage.removeItem('satellizer_token');
                PrimoService.getFacebookUserId(response.access_token)
                    .success(function (res) {
                        var data = {
                            access_token: response.access_token,
                            social_login_type: 'facebook',
                            user_id: res.id,
                            tos_accepted: 1
                        };

                        PrimoService.socialLogin(data).success(function (data) {
                            if (data.success) {

                                data.alias = data.username;
                                PrimoService.getAccountInfo({
                                    username: data.alias,
                                    login_token: data.login_token
                                }).success(function (accountData) {

                                    PrimoService.getPartnerToken({
                                        username: data.alias,
                                        login_token: data.login_token
                                    }).success(function (partnerData) {
                                        accountData.partner = partnerData;

                                        CountlyManager.sendUserInfo(accountData);
                                        SessionService.storeSession(data, accountData);

                                        mParticleService.sendSignInEvent();
                                        deferred.resolve();

                                        $scope.invalidMsg = false;
                                        var state = $rootScope.lastState || "profile";
                                        $scope.isLoadLocal = false;
                                        $state.go(state, $rootScope.stateParams);
                                        $mdDialog.cancel();

                                    });
                                });
                            }

                        })
                            .error(function (err) {
                                $scope.isLoadLocal = false;
                                $scope.errorMsg = true;
                                // $scope.invalidMsg = err.user_errors[0];
                            });
                    }).error(function (error) {
                    $scope.isLoadLocal = false;
                    $scope.errorMsg = true;
                    //$scope.invalidMsg = error.user_errors[0];
                })
                    .catch(function (response) {
                        // Something went wrong.
                        $scope.isLoadLocal = false;
                        console.log(response);
                    });
            })
                .catch(function (error) {
                    $scope.isLoadLocal = false;
                    console.log(error);
                });
        }
        // if(provider == 'google'){
        //       $auth.authenticate(provider).then(function(response) {
        //           localStorage.removeItem('satellizer_token');
        //           // PrimoService.getFacebookUserId(response.access_token)
        //           //     .success(function(res){
        //           //         var data = {  access_token:response.access_token,
        //           //             social_login_type:'google',
        //           //             user_id:res.id,
        //           //             tos_accepted:1
        //           //         };
        //           console.log('Google login', response);
        //           PrimoService.socialLogin(data).success(function (data) {
        //               if (data.success) {
        //
        //                   data.alias = data.username;
        //                   PrimoService.getAccountInfo({
        //                       username: data.alias,
        //                       login_token: data.login_token
        //                   }).success(function (accountData) {
        //
        //                       PrimoService.getPartnerToken({
        //                           username: data.alias,
        //                           login_token: data.login_token
        //                       }).success(function (partnerData) {
        //                           accountData.partner = partnerData;
        //
        //                           CountlyManager.sendUserInfo(accountData);
        //                           SessionService.storeSession(data, accountData);
        //
        //                           mParticleService.sendSignInEvent();
        //                           deferred.resolve();
        //
        //                           $scope.invalidMsg = false;
        //                           var state = $rootScope.lastState || "profile";
        //                           $scope.isLoadLocal = false;
        //                           $state.go(state, $rootScope.stateParams);
        //                           $mdDialog.cancel();
        //
        //                       });
        //                   });
        //               }
        //
        //           })
        //               .error(function (err) {
        //                   $scope.isLoadLocal = false;
        //                   $scope.errorMsg = true;
        //                   // $scope.invalidMsg = err.user_errors[0];
        //               });
        //       })
        //         }).error(function(error){
        //         $scope.isLoadLocal = false;
        //         $scope.errorMsg = true;
        //         //$scope.invalidMsg = error.user_errors[0];
        //     })
        //         .catch(function(response) {
        //             // Something went wrong.
        //             $scope.isLoadLocal = false;
        //             console.log(response);
        //         });
        // })
        //     .catch(function(error){
        //         $scope.isLoadLocal = false;
        //         console.log(error);
        //     });
    }
    // google login
    $scope.googleLogin = function () {
        GooglePlus.login().then(function (authResult) {
            console.log(authResult);
            GooglePlus.getUser().then(function (user) {
                console.log(user);
            });
        }, function (err) {
            console.log(err);
        });
    }
});
