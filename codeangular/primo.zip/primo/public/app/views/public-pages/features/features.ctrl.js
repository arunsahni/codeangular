/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller('FeaturesController', function ($scope, $rootScope,
                                               PrimoService,
                                               CountlyManager,
                                               mParticleService,
                                               $filter, $state, UiService, AuthService) {

  CountlyManager.sendEventMessage('w: Usage Features Page');
  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);

  $scope.scrollToElement = UiService.scrollToElement;

  $scope.select = function (item) {
    $scope.selected = item;
    $scope.scrollToElement(item);
  };

  $scope.isSelected = function (item) {
    return ($scope.selected && $scope.selected == item);
  };

  $scope.inviteFriends = function () {
    //non authenticated user is transferred to login page
    if (!$rootScope.user) {
      AuthService.login();
      return;
    }

    UiService.showConfirmDialog('AccountInviteFriendsController', 'partials/account-invite-friends.html', function (clb) {
      if (clb) {
        PrimoService.inviteFriends({invited_emails: clb}).then(function (response) {
          $scope.$root.alert = {
            show: true,
            context: {type: 'success', msg: $filter('translate')('INVITE_SUCCESSFULLY SENT')}
          }
        });
      }
    })
  };
});