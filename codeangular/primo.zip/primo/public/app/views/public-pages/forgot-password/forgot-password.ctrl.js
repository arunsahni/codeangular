/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("Forgot_PasswordController", function ($scope, PrimoService, $state, $window, CountlyManager,
                                                     $timeout, $filter, $rootScope, $mdDialog, AuthService) {
  CountlyManager.sendEventMessage('w: Usage Forgot Password');

  $scope.user = {};
  $scope.showMsg = false;
  $scope.forgot_Password = function (user) {
    if(user.username){
    $scope.isLoadLocal = true;
    PrimoService.resetPassword({username: $scope.user.username}).success(function () {
      $scope.isLoadLocal = false;
      $scope.showMsg = false;
      $scope.messageText = 'Updated information has been sent to your Email, Please check !';
      $('#myModalpac').modal('toggle');
     
    })
    .error(function(err){
      $scope.isLoadLocal = false;
      $scope.messageText = err.user_errors[0] || 'The customer does not exist, Please Enter valid Email id';
      $('#myModalpac').modal('toggle');
      $scope.showMsg = true;
    })
  }
  };

  $scope.cancelDialog = function () {
    $mdDialog.cancel();
  };

  $scope.forgotUsername = function () {
    AuthService.forgotUsername();
  };

  // $rootScope.$on('$stateChangeStart', function () {
  //   $mdDialog.cancel();
  // });

});
