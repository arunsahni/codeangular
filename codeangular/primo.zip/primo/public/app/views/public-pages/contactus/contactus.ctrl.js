/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("Contactus_Controller", function($rootScope, $scope, PrimoService, SessionService, $mdDialog, CountlyManager) {

    CountlyManager.sendEventMessage('w: Usage Create Ticket');

    //drop down items possible values
    $scope.subjects = [
        { name: 'My Account' },
        { name: 'Product Information' },
        { name: 'Plans & Credits' },
        { name: 'Rewards' },
        { name: 'Calling Questions' },
        { name: 'Other' }
    ];

    $scope.subject = "";
    $scope.subjectValue = "";
    /**
     * Set default values for all related fields
     */
    $scope.initFields = function() {
        $scope.subjectValue = "";
        $scope.description = "";
        $scope.phone = "";
        $scope.showMsg = false;
        $scope.errMsg = false;

        if ($rootScope.user) {
            //populate predefined fields
            $scope.name = $rootScope.user.first_name + " " + $rootScope.user.last_name;
            $scope.email = $rootScope.user.email || "";
            $scope.username = $rootScope.userId || "";
        }

    };

    /**
     * Depending on selected item set predefined subject value
     */
    $scope.setSelectedSubject = function() {
        $scope.subjectValue = ($scope.subject != 'Other') ? $scope.subject : "";
        return $scope.subject;
    };

    $scope.submitInfo = function(name,email,subject,subjectValue,description) {
        $scope.isLoadLocal = true;
        if(name && email && (subjectValue || subject) && description){

        if(subject == 'Other'){
          if(!subjectValue){
            $scope.isLoadLocal = false;
            return false;
          }
        }
            
        var contactInfo = {
            username: $scope.username,
            name: $scope.name,
            email: $scope.email,
            subject: ($scope.subject != 'Other') ? $scope.subject : $scope.subjectValue,
            description: $scope.description
        }
        PrimoService.createTicket(contactInfo).success(function(response) {
                    $scope.isLoadLocal = false;
                    $scope.statusType = "Success";
                    $scope.message = "SUCCESSFULLY TICKET CREATED";
                    $('#myModalpac').modal('toggle');
                    // $scope.username = "";
                    // $scope.name = "";
                    // $scope.email = "";
                    // $scope.subject = "";
                    // $scope.description = "";
                    // $scope.showMsg = true;
                    window.scrollTo(0,0);
                    
            })
            .error(function(err) {
                $scope.isLoadLocal = false;
                $scope.statusType = "Error";
                $scope.message = err.user_errors[0];
                $('#myModalpac').modal('toggle');
            });
    }else{
        $scope.isLoadLocal = false;
    }
}
    $scope.initFields();
});
