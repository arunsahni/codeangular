app.controller('UnlimitedPlansController', function ($scope, $rootScope,UiService, mParticleService,PrimoService) {
  $scope.isLoadLocal = false;

  $scope.init = function(country){
    /*** For Navigation***/
    if($rootScope.stateToOpen){
      //  
      console.log('plans to open', $rootScope.stateToOpen);
      let offset = $('#' + $rootScope.stateToOpen +'').offset();
      $('html, body').animate({scrollTop: offset.top}, 300);

      /***Angular Code for later use if needed***/
      /*$location.hash($rootScope.stateToOpen);
      $anchorScroll();*/  
    }

    var localCountry = localStorage.getItem('selectedCoutry');
          if(localCountry && localCountry !== "undefined") {
            country = JSON.parse(localCountry).code; 
            $scope.customSelected = JSON.parse(localCountry);
          }
          else{
            country = country;
            // $scope.customSelected = JSON.parse(localCountry);
        }
    country = country ? country :'us';
    
    $scope.getViewAllPackages(country);
	}

  $scope.getViewAllPackages = function(country){
    $scope.isLoadLocal = true;
    PrimoService.getServiceProducts('BUNDLES',country.toUpperCase()).then(function (response){
      
        if(response.status == 200){
          $scope.isLoadLocal = false;
          $scope.smalls  =   [];
          $scope.mediums =   [];
          $scope.larges  =   [];

          $scope.products_plans = response.data.groups[0].products;

          $scope.user_country_code = response.data.groups[0].user_country_code;

          if($scope.user_country_code == undefined){
              $scope.user_country_code = "us";
          }
          
          angular.forEach($scope.products_plans, function(item,index){


              if(index >= 0 && index < 4){
                  $scope.smalls.push($scope.products_plans[index]);
              }

              if(index >= 4 && index < 8){
                  $scope.mediums.push($scope.products_plans[index]);
              }

              if(index >= 8){
                  $scope.larges.push($scope.products_plans[index]);
              }

            });
            
          }
    });
  }
  
	$scope.init('us');

    setTimeout(function () {
    mParticleService.logPageView();
  	}, 1000);

  $scope.showDialog = function (filter) {
    UiService.showAlertDialog('FreeCountriesController', 'partials/free-countries-list.html', function () {
    }, filter)
  };
});