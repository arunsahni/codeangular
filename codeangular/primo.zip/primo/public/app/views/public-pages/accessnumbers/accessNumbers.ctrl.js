app.controller('AccessNumbersController', function ($scope, ACCESS_NUMBERS, CountryService, mParticleService) {

  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);

  $scope.accessNumbersUSCities = ACCESS_NUMBERS.us_cities;
  $scope.accessNumbersCountries = ACCESS_NUMBERS.countries;
  $scope.getCountryCode = CountryService.getCountryCodeByName;

});