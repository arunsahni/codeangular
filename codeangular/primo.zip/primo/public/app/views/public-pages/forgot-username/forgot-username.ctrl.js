/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("Forgot_UserNameController", function ($scope, CountlyManager, mParticleService,$state,PrimoService,$rootScope, $filter) {
  CountlyManager.sendEventMessage('w: Usage Download Page');

  $scope.showMsg = false;
  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);

  $scope.trackOutboundLink = function (url) {
    ga('send', 'event', 'outbound', 'click', url, {
      'transport': 'beacon'
    });
  }

  $scope.forgotUsername = function (user) {
    if(user){
        var params = {};
        if ($scope.user.email) {
            params['email'] = $scope.user.email;
        } else if ($scope.user.msisdn) {
            params['msisdn'] = $scope.user.msisdn;
        }
        if (params['email'] || params['msisdn']) {
            PrimoService.recoverUsername(params).success(function (data) {
            	 
                $scope.showMsg = false;
                $state.go('/');
                if (params['email']) {
                    $rootScope.alert = {
                        show: true,
                        context: {type: 'success', msg: $filter('translate')("RECOVER_USERNAME_EMAIL_SENT")}
                    };
                } else {
                    $rootScope.alert = {
                        show: true,
                        context: {type: 'success', msg: $filter('translate')("RECOVER_USERNAME_SMS_SENT")}
                    };
                }

            })
            .error(function(err){
                $scope.showMsg = true;
            });
        }
}
    };
});
