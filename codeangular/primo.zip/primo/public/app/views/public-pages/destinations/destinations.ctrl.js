/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("DestinationsController", function ($scope, COUNTRIES, _, mParticleService,PrimoService,config) {

	$scope.init = function(){
		$scope.destinationData = [];
		$scope.globalLoader = 'resources/images/loading.gif';
		$scope.isLoadLocal = true;
		PrimoService.getServicesForDestination('RATE_PLANS').then(function (response){
			if(response.status == 200){
				$scope.isLoadLocal = false;
				$scope.countries = response.data.groups[0].all_countries;
				angular.forEach($scope.countries , function(value,index){
					$scope.destinationData.push({
						countryName : value.name,
						country_plan : value.country_plan ? 'yes' : 'no',
						include_mobile_phones : value.include_mobile_phones ? 'yes' : 'no',
						free_minutes : value.free_minutes ? 'yes' : 'no',
						countryCode : value.code,
						flag : value.flag,
						popular : value.popular
					})
				});
			}
		})
		.catch(function(err) {
			$scope.isLoadLocal = true;
			console.log(err);
		});

		// $scope.destinationData = [
		// {id : 1 ,name : 'India', flag : 'resources/images/flag/flag-rnd-argentina.png', unlimitedPlan : 'yes', freeMinutes : 'no', includeMobilePhone : 'yes'},
		// {id : 1 ,name : 'Pakistan', flag : 'resources/images/flag/flag-rnd-argentina.png', unlimitedPlan : 'no', freeMinutes : 'yes', includeMobilePhone : 'yes'},
		// {id : 1 ,name : 'Afganistan', flag : 'resources/images/flag/flag-rnd-argentina.png', unlimitedPlan : 'yes', freeMinutes : 'no', includeMobilePhone : 'yes'},
		// {id : 1 ,name : 'ShriLanka', flag : 'resources/images/flag/flag-rnd-argentina.png', unlimitedPlan : 'no', freeMinutes : 'yes', includeMobilePhone : 'no'}
		// ];
	}

  setTimeout(function () {
    mParticleService.logPageView();
  }, 1000);
  
  $scope.countries = _.sortBy(_.filter(COUNTRIES, function (c) {
    return c.sweet_60_rate_plan || c.sweet_60_free_minutes;
  }), [function (c) {
    return c.name;
  }, 'name']);

  $scope.init();

});