/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("HomeController", function ($scope, $rootScope, $state, $anchorScroll, $location, UiService, $filter, AuthService, PrimoService,$window, $q, $timeout) {

  $scope.talkCellItems = [
    {
      title: 'CALL_FOR_FREE',
      text: 'CALL_FOR_FREE_SUBTEXT',
      image: 'resources/images/rewards_1.png'
    },
    {
      title: 'PRIMO_TO_PRIMO',
      text: 'PRIMO_TO_PRIMO_SUBTEXT',
      image: 'resources/images/rewards_2.png'
    },
    {
      title: 'MESSAGE_AND_SHARE',
      text: 'MESSAGE_AND_SHARE_SUBTEXT',
      image: 'resources/images/rewards_3.png'
    },
    {
      title: 'MY_PRIMO_US_PHONE_NUMBER',
      text: 'MY_US_PHONE_NUMBER_SUBTEXT',
      image: 'resources/images/rewards_4.png'
    }
  ];

  $scope.isLoadLocal = true;
  $scope.selectedCountryBoltOn = 'Select Country...';
  $scope.rewards_image_src = $scope.talkCellItems[0].image;
  //Products Plan
  $scope.init = function(country){
    /*** For Navigation***/
    $scope.isLoadLocal = true;
    $scope.isOpenPopUp = false;

    if($rootScope.stateToOpen){
      var offset = $('#' + $rootScope.stateToOpen +'').offset();
      $('html, body').animate({scrollTop: offset.top}, 300);
      $rootScope.stateToOpen = null;
    }

    var localCountry = localStorage.getItem('selectedCoutry');
      if(localCountry && localCountry !== "undefined") {
        country = JSON.parse(localCountry).code; 
        $scope.customSelected = JSON.parse(localCountry);

        $timeout(function(){
          $("body").find(".topNavCountryStyle").css({backgroundImage:"url("+$scope.customSelected.flag+")"});
        });
      }
      else{
        country = country;
    }
    
    country = country ? country :'us';
    
    PrimoService.getServiceProducts('BUNDLES',country.toUpperCase()).then(function (response){

        if(response.status == 200){
          $scope.small_1m = {};
          $scope.medium_1m = {};
          $scope.large_1m = {};

          $scope.products_plans = response.data.groups[0].products;

          $scope.user_country_code = response.data.groups[0].user_country_code;

          if($scope.user_country_code == undefined){
              $scope.user_country_code = "us";
          }
          
          angular.forEach($scope.products_plans, function(item,index){
              if(item.product =='SMALL_1M'){
                  $scope.small_1m = $scope.products_plans[index];
              }

              if(item.product =='MEDIUM_1M'){
                  $scope.medium_1m = $scope.products_plans[index];
              }

              if(item.product =='LARGE_1M'){
                  $scope.large_1m = $scope.products_plans[index];
              }

          });
          $scope.isLoadLocal = false;
        }
    });

    //Rate Plan
    $scope.scrollToSection = function(stateVal) {
      // $location.hash(stateVal);
      var offset = $('#' + stateVal +'').offset();
      $('html, body').animate({scrollTop: offset.top}, 300);
    }

    PrimoService.getServiceProducts('RATE_PLANS',country.toUpperCase()).then(function (response){

        $scope.rates_plans_slide1 = [];
        $scope.rates_plans_slide2 = [];
        $scope.rates_plans_slide3 = [];
        $scope.rates_plans_slide4 = [];
        $scope.bold_primo_credits = [];
        $scope.call_and_messages  = [];

        if(response.status == 200){

          $scope.all_products = response.data.groups[0].all_products;
          $scope.countries = response.data.groups[0].all_countries;
          
          var i = 0;
          angular.forEach($scope.all_products,function(item,index){

              if(item.type == 'AGGRESSIVE'){
                
                if(i < 3){
                  $scope.rates_plans_slide1.push(item);
                }

                if(i >= 3 && i < 6){
                  $scope.rates_plans_slide2.push(item);
                }

                if(i >= 6 && i < 9){
                  $scope.rates_plans_slide3.push(item);
                }

                if(i >= 9){
                  $scope.rates_plans_slide4.push(item);
                }
                i++;
              }

              if(item.product == 'SMS_199_50')
              {
                $scope.call_and_messages.push(item);
              }

              if(item.product == 'SMS_299_100')
              {
                $scope.call_and_messages.push(item);
              }

              if(item.product == 'SMS_299_50')
              {
                $scope.call_and_messages.push(item);
              }

              if(item.android_pid == 'credit_3')
              {
                $scope.bold_primo_credits.push(item);
              }

              if(item.android_pid == 'credit_5')
              {
                $scope.bold_primo_credits.push(item);
              }

              
          });
          
          $.fn.cycle.defaults.slides = '> div';
          $( '.rateplan-slideshow' ).cycle();
          setTimeout(function(){$(".chosen").chosen();$("input[type=radio]").prop('checked', false);});
        }

        $scope.isLoadLocal = false;

    });

    $scope.getBoltasProducts(country);
  }

  $scope.savePlanValues = function(planName){
    
    $scope.planName = planName;
  }

  $scope.buyBoltsOnProduct = function(clickPlanName,selectedProducts){
    var showingPopupFlag = true;
    $scope.showDialog = false;
    angular.forEach(selectedProducts, function(item,index){
        if($scope.planName){
            if(item.product === $scope.planName.product){
            $scope.showDialog = false;
            showingPopupFlag = false;
            localStorage.setItem('buydata', JSON.stringify(item));
            PrimoService.setSelectedBoltsOnPlans($scope.planName, $scope.selectedProduct);
            $state.go('purchase');
            return false;
          }else{
            if(showingPopupFlag){
              $scope.showDialog = true;
            }
          }
        }else{
            if(showingPopupFlag){
              $scope.showDialog = true;
            }
        }
    });

      if($scope.showDialog){
        $scope.statusType     = 'Error';
        $scope.paymentMessage   = "Please select package";
        $("#myModalpac").modal("toggle");
      }
  };

  $scope.getBoltasProducts =function (country){
    /*BOLT ON PRODUCTS*/
      $scope.BOLTONS_CREDITS = [];
      $scope.BOLTONS_DID = [];
      $scope.BOLTONS_SMS = [];
      $scope.BOLTONS_VOICEMAIL = [];

      if(country) {
          PrimoService.getServiceProducts('BOLTONS', country.toUpperCase()).then(function (response) {
              $scope.selectedItemvalue = response.data.groups[0].user_country_code.toLowerCase();
              $scope.selectedItemvalueTop = $scope.selectedItemvalue;
              var counterRecord = $scope.countries.filter(function (data) {
                  return (data.code == $scope.selectedItemvalue);
              });
              if(counterRecord && counterRecord.length > 0){
                $scope.selectedCountryBoltOn = counterRecord[0].name;
                $scope.selectedCountryFlagBoltOn = counterRecord[0].flag;
              } else {
                $scope.selectedCountryBoltOn = null;
                $scope.selectedCountryFlagBoltOn = null;
              }
              
              if (response.status == 200) {
                $scope.isLoadLocal = false;
                  //$rootScope.isLoad = false;
                  if (response.data.groups[0].credit.length) {
                      $scope.BOLTONS_CREDITS = response.data.groups[0].credit;
                  }
                  if (response.data.groups[0].did.length) {
                      $scope.BOLTONS_DID = response.data.groups[0].did;
                  }
                  if (response.data.groups[0].sms.length) {
                      $scope.BOLTONS_SMS = response.data.groups[0].sms;
                  }
                  if (response.data.groups[0].voicemail.length) {
                      $scope.BOLTONS_VOICEMAIL = response.data.groups[0].voicemail;
                  }
              }
          });
      }
  }

   $scope.checkCountryAvaliable = function(){
      $scope.disabledCountry = $scope.countries ? false : true;  
    }

  $scope.boltOnChangeProduct = function(selectBoltsCountry, obj){
    $scope.isLoadLocal = true;
    $scope.getBoltasProducts(selectBoltsCountry);
    localStorage.setItem('selectedCoutry', JSON.stringify(obj.country));
    $scope.init(obj.country.code);
  }

  $scope.sliderBuyButton = function(buydata){
    $scope.isLoadLocal = true;
    var deferred = $q.defer();
    angular.forEach($scope.countries, function(item,index){
      if(item.code == buydata.code){
            $scope.buyCountrySelected = item;
        }
    });

    localStorage.setItem('sliderSelectedCoutry', JSON.stringify($scope.buyCountrySelected));
    
    localStorage.setItem('buydata', JSON.stringify(buydata));

    PrimoService.getServiceProducts('ALL',buydata.code).then(function (data) {
      $scope.isLoadLocal = false;
      $window.localStorage.serviceProducts            = JSON.stringify(data.data);
      $window.localStorage.serviceProductsRefreshDate = Date.now();
      deferred.resolve(data.data);
      $state.go('purchase',{new_product:buydata.product});
    });


  }

  $scope.searchCrad = function (input){
    
    localStorage.setItem('selectedCoutry', JSON.stringify(input.customSelected));
    if(input.customSelected){
      if(input.customSelected.code){

        $scope.init(input.customSelected.code);
      }
    }
  }
  $scope.init('us');


  $scope.hoverIn = function (index) {
    $scope.rewards_image_src = $scope.talkCellItems[index].image;
  };


  $scope.isSelected = function (item) {
    return (item.image == $scope.rewards_image_src);
  };

  $scope.inviteFriends = function () {
    //non authenticated user is transferred to login page
    if (!$rootScope.user) {
      AuthService.login();
      return;
    }

    UiService.showConfirmDialog('AccountInviteFriendsController', 'partials/account-invite-friends.html', function (clb) {
      if (clb) {
        PrimoService.inviteFriends({invited_emails: clb}).then(function (response) {
          $scope.$root.alert = {
            show: true,
            context: {type: 'success', msg: $filter('translate')('INVITE_SUCCESSFULLY SENT')}
          }
        });
      }
    });
  };

  $scope.hoverIn(1);
});

app.filter('capitalize', function() {
    return function(input) {
      return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
});