/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.directive('homeSearchBar', function () {
  return {
    restrict: 'E',
    templateUrl: "partials/home-search-bar.html",
    replace: true,
    controller: function ($scope, $element, $rootScope,
                          $state, $stateParams,
                          InternationalRatesService,
                          mParticleService,
                          ServiceProductsService,
                          PrimoService, $q, $filter, UiService, AuthService, $anchorScroll, _, COUNTRIES, $timeout) {

      $scope.serviceProducts = ServiceProductsService.getServiceProducts();
      angular.forEach($scope.serviceProducts.groups, function (val, key) {
        if (val.group == 'RATED') {
          $scope.rate_plans = val.products;
        }
        if (val.group == 'CREDIT') {
          $scope.credit_products       = val.products;
          $scope.selectedCreditProduct = $scope.credit_products[0];
        }
        if (val.group == 'UNLIMITED') {
          $scope.service_plans       = val.products;
          $scope.selectedServicePlan = $scope.service_plans[0];
        }
      });

      updateScenario();
      //});

      $scope.selectedItemChange   = selectedItemChange;
      $scope.searchForLocation    = searchForLocation;
      $scope.trySearchForLocation = trySearchForLocation;
      $scope.isVisible            = isVisible;

      //selected item default empty
      $scope.selected = null;

      //default search text value
      if ($stateParams.country) {
        trySearchForLocation($stateParams.country);
      } else {
        $scope.searchText = "";
      }

      //fetch rates from rates service
      $scope.rates = InternationalRatesService.getRates();

      /**
       * Select item on click
       * @param name
       */
      $scope.selectCountryOnClick = function (name) {
        selectedItemChange(searchForLocation(name)[0]);
      };

      $scope.showDialog = function (filter) {
        UiService.showAlertDialog('FreeCountriesController', 'partials/free-countries-list.html', function () {
        }, filter)
      };

      $scope.inviteFriends = function () {
        //non authenticated user is transferred to login page
        if (!$rootScope.user) {
          AuthService.login();
          return;
        }
        UiService.showConfirmDialog('AccountInviteFriendsController', 'partials/account-invite-friends.html', function (clb) {
          if (clb) {
            PrimoService.inviteFriends({invited_emails: clb}).then(function (response) {
              $scope.$root.alert = {
                show: true,
                context: {type: 'success', msg: $filter('translate')('INVITE_SUCCESSFULLY SENT')}
              }
            });
          }
        });
      };

      $scope.formatAutocompleteItem = function (item) {
        return item.country + " |||"
      };

      $anchorScroll.yOffset = 50;

      $scope.$watch('selected', function (newValue) {
        if (newValue) {
          UiService.scrollToElement($element, 70);
          updateScenario();
        }
      });

      function trySearchForLocation(searchText) {
        var results = searchForLocation(searchText);
        if (results && angular.isArray(results) && results.length) {
          selectedItemChange(results[0])
        } else {
          $scope.$root.alert = {
            show: true,
            context: {
              type: 'danger',
              msg: $filter('translate')('NO_MATCHING_STATES') + ' "' + $scope.searchText + '" ' + $filter('translate')('WERE_FOUND')
            }
          }
        }
      }

      function searchForLocation(text) {
        var deferred = $q.defer();
        if (text) {
          mParticleService.logSearchEvent('Unlimited Plans - Where are you calling?', text);
          return InternationalRatesService.getCountryByName(text);
        }
        return deferred.promise;
      }

      function selectedItemChange(item) {
        $scope.selected = item;
      }

      function updateScenario() {
        $scope.scenario = 1;

        if ($scope.selected) {
          var country = _.find(COUNTRIES, {iso: $scope.selected.country_code});

          if (country) {
            if (country.sweet_60_rate_plan) {
              $scope.scenario = 2;
              if ($scope.service_plans) {
                $scope.servicePlan = _.find($scope.service_plans, {product: 'UNLM_PRIMO_60'})
              }
            } else if (country.unlimited_for_country) {
              if (country.sweet_60_free_minutes) {
                $scope.scenario = 3;
              } else {
                $scope.scenario = 4;
              }
              if ($scope.service_plans) {
                $scope.servicePlan = _.find($scope.service_plans, function (sp) {
                  return sp.product.indexOf('UNLM_' + country.un + '_') !== -1
                })
              }
            }
          }
        }

      }

      function isVisible(name) {
        var scenarios = {
          1: ['unlimited', 'credit', 'free_disabled'],
          2: ['unlimited', 'free', 'rate_plan', 'credit'],
          3: ['unlimited', 'service_plan_country', 'free', 'credit'],
          4: ['unlimited', 'service_plan_country', 'credit', 'free_disabled']
        };

        if ($scope.scenario) {
          return scenarios[$scope.scenario].indexOf(name) !== -1;
        }

      }

    }
  }
});