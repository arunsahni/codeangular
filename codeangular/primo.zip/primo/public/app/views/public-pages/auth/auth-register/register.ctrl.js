/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("RegisterController", function ($scope, PrimoService, $rootScope, SessionService,
                                               $stateParams, $q,
                                               $state, $timeout, $filter, $mdDialog, AuthService) {

  $scope.claimNumber    = $stateParams.claim;
  $scope.isClaimAccount = $stateParams.claim && $stateParams.claim != "";
  $scope.token          = $stateParams.token;

  $scope.resolve = function () {
    if ($scope.isClaimAccount) {
      $scope.claimAccount();
    } else {
      $scope.register();
    }
  };

  $scope.register = function () {
    $scope.user['tos_accepted']  = ($scope.isAgreed) ? 1 : 0;
    $scope.user['signup_source'] = "WEB";

    AuthService.doRegister($scope.user, {
      withMSISDN: function () {
        $rootScope.alert = {
          show: true,
          context: {type: 'success', msg: $filter('translate')('SUCCESS_REGISTER')}
        };
        $timeout(function () {
          AuthService.verifyMSISDN();
        }, 2000);
      },
      withoutMSISDN: function () {
        $state.go('profile');
      }
    });
  };

  /**
   * Call Primo to Claim account
   * @returns {*}
   */
  $scope.claimAccount = function () {
    AuthService.doClaimAccount($scope.claimNumber, $scope.token, $scope.user, function () {
      $state.go('profile');
    });
  };

  $scope.cancelDialog = function () {
    $mdDialog.cancel()
  };

  $scope.login = function () {
    AuthService.login();
  };

  $rootScope.$on('$stateChangeStart', function () {
    $mdDialog.cancel();
  });


});