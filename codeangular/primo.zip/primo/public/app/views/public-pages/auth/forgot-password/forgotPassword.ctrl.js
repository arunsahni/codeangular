/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */
app.controller("ForgotPasswordController", function ($scope, PrimoService, $state, $window, CountlyManager,
                                                     $timeout, $filter, $rootScope, $mdDialog, AuthService) {
  CountlyManager.sendEventMessage('w: Usage Forgot Password');

  $scope.forgotPassword = function () {
    PrimoService.resetPassword({username: $scope.user.username}).success(function () {

      document.getElementById('submitButton').childNodes[0].innerHTML = $filter('translate')('PASSWORD_LINK_SENT');
      document.getElementById('username').value                       = "";
      $timeout(function () {
        document.getElementById('submitButton').childNodes[0].innerHTML = $filter('translate')('SEND_RESET_LINK');
      }, 2000);
    });
  };

  $scope.cancelDialog = function () {
    $mdDialog.cancel();
  };

  $scope.forgotUsername = function () {
    AuthService.forgotUsername();
  };

  $rootScope.$on('$stateChangeStart', function () {
    $mdDialog.cancel();
  });

});