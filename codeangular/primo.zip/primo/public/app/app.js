/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

var app = angular.module("Primo",
  [
    'ui.router',
    'ng.deviceDetector',
    'ngAnimate',
    'ngMaterial',
    'ngMessages',
    'ngSanitize',
    'ngCookies',
    'config',
    'angular-loading-bar',
    'pascalprecht.translate',
    'mparticleWidget',
    'braintree-angular',
    'ngMenuSidenav',
    'flow',
    'countlyWidget',
    'ngCsv',
    'ngRoute',
    'sticky',
    'ui.bootstrap',
    'satellizer',
    'googleplus'
  ]);

app.constant('clientTokenPath', '/get-client-token');

app.config(function ($stateProvider, $urlRouterProvider,
                     config,
                     $httpProvider, $translateProvider,
                     countlyWidgetProvider,
                     $mdThemingProvider,
                     deviceDetectorProvider,
                     mparticleWidgetProvider,
                     flowFactoryProvider,
                     $compileProvider,
                     $locationProvider,$authProvider, GooglePlusProvider, socialKeys) {

  // Disabling Debug Data
  $compileProvider.debugInfoEnabled(false);

  mparticleWidgetProvider.init({
    app_key: config.mparticle.key,
    isSandbox: config.mparticle.isSandbox
  });

  //init countly
  countlyWidgetProvider.init({
    url: config.countly.url,
    app_key: config.countly.appKey
  });

  //translate provider
  $translateProvider.useSanitizeValueStrategy(null);
  $translateProvider.useStaticFilesLoader({
    prefix: 'resources/i18n/',
    suffix: '.json'
  });

  //Social Login Credentials
  $authProvider.facebook({
    clientId: socialKeys[0].facebookDevCredentials.appId,
    responseType: socialKeys[0].facebookDevCredentials.responseType
  });

  GooglePlusProvider.init({
      clientId: '357812345587-k2jgk07hpds4mllulkl2tggdtn16oka1.apps.googleusercontent.com'
      // apiKey: 'YOUR_API_KEY'
  });
  // $authProvider.google({
  //     clientId: "357812345587-k2jgk07hpds4mllulkl2tggdtn16oka1.apps.googleusercontent.com"
  // });
  $authProvider.httpInterceptor = function() { return true; },
  $authProvider.withCredentials = false;
  $authProvider.tokenRoot = null;
  $authProvider.baseUrl = '/';
  $authProvider.loginUrl = '/auth/login';
  $authProvider.signupUrl = '/auth/signup';
  $authProvider.unlinkUrl = '/auth/unlink/';
  $authProvider.tokenName = 'token';
  $authProvider.tokenPrefix = 'satellizer';
  $authProvider.tokenHeader = 'Authorization';
  $authProvider.tokenType = 'Bearer';
  $authProvider.storageType = 'localStorage';

  // Facebook
  $authProvider.facebook({
    name: 'facebook',
    url: '/auth/facebook',
    authorizationEndpoint: 'https://www.facebook.com/v2.5/dialog/oauth',
    redirectUri: window.location.origin + '/',
    requiredUrlParams: ['display', 'scope'],
    scope: ['email'],
    scopeDelimiter: ',',
    display: 'popup',
    oauthType: '2.0',
    popupOptions: { width: 580, height: 400 }
  });
  // $authProvider.google({
  //       url: '/auth/google',
  //       authorizationEndpoint: 'https://accounts.google.com/o/oauth2/auth',
  //       redirectUri: window.location.origin,
  //       requiredUrlParams: ['scope'],
  //       optionalUrlParams: ['display'],
  //       scope: ['profile', 'email'],
  //       scopePrefix: 'openid',
  //       scopeDelimiter: ' ',
  //       display: 'popup',
  //       oauthType: '2.0',
  //       popupOptions: { width: 452, height: 633 }
  //   });

  //theme provider
  $mdThemingProvider.definePalette('primoPrimary', {
    '50': '#515151',
    '100': '#444444',
    '200': '#373737',
    '300': '#2a2a2a',
    '400': '#1e1e1e',
    '500': '#111',
    '600': '#040404',
    '700': '#000000',
    '800': '#000000',
    '900': '#000000',
    'A100': '#5d5d5d',
    'A200': '#6a6a6a',
    'A400': '#777777',
    'A700': '#000000',
    'contrastDefaultColor': 'light',    // whether, by default, text (contrast)
                                        // on this palette should be dark or light
    'contrastDarkColors': ['50', '100', //hues which contrast should be 'dark' by default
      '200', '300', '400', 'A100'],
    'contrastLightColors': undefined    // could also specify this if default was 'dark'
  });

  $mdThemingProvider.definePalette('primoAccent', {
    '50': '#39feff',
    '100': '#20feff',
    '200': '#06feff',
    '300': '#00ebec',
    '400': '#00d1d2',
    '500': '#00b8b9',
    '600': '#009f9f',
    '700': '#008586',
    '800': '#006c6c',
    '900': '#005353',
    'A100': '#53feff',
    'A200': '#6cfeff',
    'A400': '#86feff',
    'A700': '#003939',
    'contrastDefaultColor': 'light'
  });
  //theme configuration
  $mdThemingProvider.theme('default')
    .primaryPalette('primoPrimary')
    .accentPalette('primoAccent');

  $mdThemingProvider.alwaysWatchTheme(true);

  $urlRouterProvider.otherwise(function ($injector) {
    var $state = $injector.get('$state');
    $state.go("/");
  });

  $httpProvider.interceptors.push('sessionInterceptor');

  $stateProvider 
    .state("login", {
      url: "/login",
      isPublic: true,
      isNavVisible: true,
      isAuthPage: true,
      onEnter: function ($state, AuthService) {
        AuthService.login();
      }
    })
    .state("verifyMSISDN", {
      url: "/verify-msisdn/:username/:msisdn/:country",
      isPublic: true,
      isNavVisible: true,
      isAuthPage: true,
      onEnter: function (AuthService) {
        AuthService.verifyMSISDN();
      }
    })
    .state("checkout", {
      url: "/checkout",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/checkout.html",
          controller: 'CheckoutController'
        }
      }
    })
    .state("forgotPassword", {
      url: "/forgot-password",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/forgot-pwd.html",
          controller: 'Forgot_PasswordController'
        }
      }
    })
    .state("forgotUsername", {
      url: "/forgot-username",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/forgot-uname.html",
          controller: 'Forgot_UserNameController'
        }
      }
    })
    .state("tos", {
      url: "/terms-of-service",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/tos.html",
          controller: "TosController"
        }
      }
    })
    .state("rup", {
      url: "/reasonable-use-policy",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/rup.html"
        }
      }
    })
    .state("addCredit", {
      url: "/add-credit/:plan",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/add-credit.html",
          controller: 'AddCreditController',
          resolve: {
            items: function (PrimoService) {
              return PrimoService.getCreditProducts({}).then(function (response) {
                return response.data.product_ids;
              });
            }
          }
        }
      }
    })
    .state("addRatePlan", {
      url: "/add-rate-plan/:plan",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/rate-plans.html",
          controller: 'AddRatePlanController',
          resolve: {
            items: function (PrimoService) {
              return PrimoService.getRatePlans({}).then(function (response) {
                return response.data.rate_plans;
              });
            }
          }
        }
      }
    })
    .state("purchase", {
      url: "/purchase?:credit,:rate_plan,:service_plan,:did_plan,:new_product",
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/purchase.html",
          controller: 'PurchaseController'
        }
      }
    })
    .state("privacyPolicy", {
      url: "/privacy-policy",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/privacy-policy.html",
          controller: "PrivacyController"
        }
      }
    })
    .state("/", {
      url: "/",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/home.html",
          controller: 'HomeController',
          className: ""
        }
      }
    })
    .state("unlimitedPlans", {
      url: "/unlimited-plans",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/unlimited-plans.html",
          controller: 'UnlimitedPlansController'
        }
      }
    })
    .state("unlimitedForCountry", {
      url: "/unlimited-:country",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/home.html",
          controller: 'HomeController'
        }
      }
    })
    .state("dashboard", {
      url: "/dashboard",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/dashboard.html",
          controller: 'DashboardController'
        }
      }
    })
    .state("internationalRates", {
      url: "/international-rates",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-international-rates.html",
          controller: 'AccountIRController'
        }
      }
    })
    .state("profile", {
      url: "/profile",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-profile.html",
          controller: 'AccountProfileController'
        }
      }
    })
    .state("callHistory", {
      url: "/call-history",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-call-history.html",
          controller: 'AccountCallHistoryController',
          resolve: {
            history: function (PrimoService) {
              return PrimoService.getCallHistory({}).then(function (response) {
                 
                return response.data.call_history;
              })
            }
          }
        }
      }
    })
    .state("billingHistory", {
      url: "/billing-history",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-billing-history.html",
          controller: 'AccountBillingHistoryController',
          resolve: {
            history: function (PrimoService) {
              return PrimoService.getBillingHistory({}).then(function (response) {
                return response.data.billing_history;
              })
            }
          }
        }
      }
    })
    .state("changePassword", {
      url: "/change-password",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-change-password.html",
          controller: 'AccountChangePasswordController'
        }
      }
    })
    .state("inviteFriends", {
      url: "/invite-friends",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-invite-friends.html",
          controller: 'AccountInviteFriendsController'
        }
      }
    })
    .state("faq", {
      url: "/faq/:selected",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-faq.html",
          controller: 'AccountFAQController'
        }
      }
    })
    .state("features", {
      url: "/features",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/features.html",
          controller: "FeaturesController"
        }
      }
    })
    .state("ticketList", {
      url: "/ticket-list",
      isPublic: false,
      isNavVisible: true,
      templateUrl: "partials/account-ticket-list.html",
      controller: 'AccountTicketListController',
      resolve: {
        tickets: function (PrimoService) {
          return PrimoService.getTicketList().then(function (res) {
            return res.data;
          })
        }
      }
    })
    .state("ticketCreate", {
      url: "/ticket-create",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/account-ticket-create.html",
          controller: 'AccountTicketCreateController'
        }
      }
    })
    .state("download", {
      url: "/download",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/download.html",
          controller: 'DownloadController'
        }
      }
    })
    .state("primodownload", {
      url: "/primo-download",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/primo-download.html",
          controller: 'PrimoDownloadController'
        }
      }
    })
    .state("signin", {
      url: "/signin",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/signin.html",
          controller: 'SigninController'
        }
      }
    })
    .state("faqs", {
      url: "/faqs",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/faq.html",
          controller: 'FaqController'
        }
      }
    })
    .state("contactus", {
      url: "/contactus",
      isPublic: false,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/contactus.html",
          controller: 'Contactus_Controller'
        }
      }
    })
    .state("about", {
      url: "/about",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/about.html",
          controller: 'AboutController'
        }
      }
    })
    .state("destinations", {
      url: "/destinations",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/destinations.html",
          controller: 'DestinationsController'
        }
      }
    })
    .state("accessNumbers", {
      url: "/access-numbers",
      isPublic: true,
      isNavVisible: true,
      views: {
        "nav": {},
        "contentView": {
          templateUrl: "partials/access-numbers.html",
          controller: "AccessNumbersController"
        }
      }
    })

    $locationProvider.html5Mode({ enabled: true, requireBase: false });
});
