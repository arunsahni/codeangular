/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

app.factory('sessionInterceptor', function ($rootScope, $q, $filter, config) {
  var sessionInterceptor = {
    request: function (cfg) {
      if (cfg.url == '/create-ticket' || cfg.url.includes('world-')) {
        cfg.headers['Content-Type'] = 'application/json';
      } else {
        cfg.headers['Content-Type'] = 'application/x-www-form-urlencoded';
      }

      if (cfg.url.includes('/get-client-token')) {
        cfg.url                   = config.primo.host + '/pr/manageintl/3/primo/api/manageintl__GetPartnerToken';
        cfg.params                = cfg.params || {};
        cfg.params.username       = ($rootScope.data) ? $rootScope.data.alias : '';
        cfg.params.login_token    = ($rootScope.data) ? $rootScope.data.login_token : '';
        cfg.params.partners       = {};
        cfg.params['partners[0]'] = 'braintree';
      }

      return cfg;
    },
    response: function (response) {
      var deferred = $q.defer();
      if (response.data && response.data.error_codes && response.data.error_codes.length > 0) {
        //when invalid login token is received destroy session
        if (response.data && response.data.error_codes &&
          response.data.error_codes[0] == 'SE0007' ||
          response.data.error_codes[0] == 'SE0013' ||
          response.data.error_codes[0] == 'VV0031') {
          if (response.data.error_codes[0] == 'VV0031') {
            $rootScope.alert = {
              show: true,
              context: {type: 'danger', msg: response.data.user_errors}
            };
          }
          $rootScope.$broadcast('destroy-session');
          return $q.reject(response);
        }
        else if (response.data.error_codes[0] == 'AC0001' || //this is not an error, its epay user first login sms sent as password message
          response.data.error_codes[0] == 'AC0002' //first epay success login
        ) {

          if (response.data.error_codes[0] == 'AC0001') {
            $rootScope.alert = {
              show: true,
              context: {type: 'success', msg: response.data.user_errors}
            };
          }

          return $q.resolve(response);
        }
        //display error message
        else if (response.data && response.data.user_errors && response.data.user_errors.length > 0) {
          $rootScope.alert = {
            show: true,
            context: {type: 'danger', msg: response.data.user_errors[0]}
          };
          deferred.reject(response);
        }
      } else if (response.config.url.includes('GetPartnerToken')) {
        //braintree needs a client token as a single paramtere received from response...
        if (response.data.tokens && response.data.tokens.braintree) {
          response.data = response.data.tokens.braintree.token;
        }
        deferred.resolve(response);
      } else {
        deferred.resolve(response);
      }
      return deferred.promise;
    },
    responseError: function (rejection) {
      try {
        //when received invalid login token destroy session
        if (rejection.data.error_codes[0] == 'SE0013' || rejection.data.error_codes[0] == 'VV0031') {
          if (rejection.data.error_codes[0] == 'VV0031') {
            $rootScope.alert = {
              show: true,
              context: {type: 'danger', msg: rejection.data.user_errors}
            };
          }
          $rootScope.$broadcast('destroy-session');
          return $q.reject(rejection);
        } else if (rejection.data.error_codes[0] == 'AC0001' || //this is not an error, its epay user first login sms sent as password message
          rejection.data.error_codes[0] == 'AC0002' //first epay success login
        ) {

          if (rejection.data.error_codes[0] == 'AC0001') {
            $rootScope.alert = {
              show: true,
              context: {type: 'success', msg: rejection.data.user_errors}
            };
          }

          return $q.resolve(rejection);
        } else {
          // Error handler
          if (rejection.data && rejection.data && rejection.data.user_errors) {
            $rootScope.alert = {
              show: true,
              context: {type: 'danger', msg: UtilHelperService.uniCodeToString(rejection.data.user_errors[0])}
            };
          }
          return $q.reject(rejection);

        }

      } catch (e) {
        $rootScope.alert = {show: true, context: {type: 'danger', msg: $filter('translate')("FATAL_ERROR")}};

        return $q.reject(rejection);
      }
    }
  };

  return sessionInterceptor;
});