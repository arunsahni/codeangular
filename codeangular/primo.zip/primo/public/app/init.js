/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

app.run(function ($injector, $window, $location, $rootScope, $timeout, config, SessionService, $mdDialog, UiService, $state, AuthService, _) {
  //google analytics
  $window.ga('create', config.google.analytics.trackingCode, 'auto');
  $window.ga('require', 'ecommerce');

  $rootScope.$on('$stateChangeSuccess', function (newVal, oldVal) {

    /***Scroll to top on every Route change***/
    $("html, body").animate({ scrollTop: 0 }, 100);

    if(oldVal.name != 'purchase'){
      $window.localStorage.setItem('reload',0);
    }

    /*window.scrollTo(0,0);
    $timeout(() => {
      if ($location.hash()) {
        $anchorScroll();
     }
    });*/

    $window.ga('send', 'pageview', $location.path());
  });

  $rootScope.$on('destroy-session', function () {
    SessionService.destroySession();
  });

  SessionService.restoreSession();

  // Load UI config
  UiService.init();

  $rootScope.$on('$stateChangeStart', function (event, next) {

    //close all opened md dialogs
    $mdDialog.cancel();

    /*setTimeout(() => {
      window.scrollTo(0,0);
    }, 200);*/
    /*** For handling different header problem in UI ***/
    if(next.name !== '/') {
      $rootScope.bodyClassName = "innerpages";
      $rootScope.showHeader = true;
      $timeout(function(){
           var localCountry = localStorage.getItem('selectedCoutry');
           if(localCountry && localCountry !== "undefined") {
                 $rootScope.countryValueForOtherPages = JSON.parse(localCountry);
                 $("#typeAheadId").val($rootScope.countryValueForOtherPages.name);
                 $("#typeAheadId").css({backgroundImage: "url("+$rootScope.countryValueForOtherPages.flag+")"});
           }
      }, 500)
    }
    else {
      $rootScope.bodyClassName = "";
      $rootScope.showHeader = false;
    }

    //prevent access to login page when authenticated
    if (next.name === 'login' && SessionService.isAuthenticated()) {
      event.preventDefault();
      return $state.go('/');
    }

    if (next.isAuthPage) {
      UiService.isAuthPage(true);
    } else {
      UiService.isAuthPage(false);
    }

    if (next.isPublic === false) {
      if (SessionService.isAuthenticated()) { //authenticated user is transferred to last state
        if ($rootScope.lastState) {
          event.preventDefault();
          var lastState = $rootScope.lastState;
          delete $rootScope.lastState;
          return $state.go(lastState);
        }
      } else { //non authenticated user is transferred to login
        event.preventDefault();
        $rootScope.lastState = next.name;
        return AuthService.login();
      }
    }
  });

});