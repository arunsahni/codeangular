/*
 * Copyright (C) 2016 Primo, All Rights Reserved.
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Primo and is confidential in nature.
 *
 * Under no circumstances is this software to be exposed to or placed
 * under an Open Source License of any type without the expressed written
 * permission of Primo.
 *
 */

var logger = require('../lib/logger');
logger.info('Initializing [DEV] environment');


var config = {
  primo: {
    username: 'intl_ott_api',
    password: 'Xeb96d496Qa1f5',
    host: 'https://intl-dev.primo.me'
    //host: 'https://pbajic1-dev.primo.me/'
  },
  factual: {
    apiKey: 'Jd3iGayK5VEcyRJMgXeSDmFJJQWiVyHl9PcVzCKm',
    secretKey: 'TKxm150IP6n6nTM3Czl447FQpnGX3CDu2rfwXNyH'
  },
  zendesk: {
    username: 'abhijeet@primo.me',
    password: 'wildnet@123',
    host: 'https://primo.zendesk.com'
  },
  countly: {
    url: "https://count.primo.me",
    appKey: "2bbc7f6d1f6c090dfbc815f3a27fe437e2daf82d"
  },
  google: {
    analytics: {
      trackingCode: 'UA-89045079-3'
    }
  },
  mparticle: {
    key: '1158d52cbe59f74aba3dbe6352425071',
    isSandbox: true
  }
};

module.exports = config;