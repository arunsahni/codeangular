module.exports = {
  "warnings": [],
  "success": false,
  "error_codes": ["AC0001"],
  "user_errors": ["Your temporary password has been sent via SMS."],
  "username": "+1313732273026"
};